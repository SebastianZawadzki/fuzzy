S/W Version Information
Model: SM-R735S
Tizen-Version: 2.3.1.2
Build-Number: R735SKSU1AOKE
Build-Date: 2015.11.25 20:46:58

Crash Information
Process Name: uicomponents
PID: 28754
Date: 2016-06-06 21:42:54+0900
Executable File Path: /opt/usr/apps/org.example.uicomponents/bin/uicomponents
Signal: 11
      (SIGSEGV)
      si_code: -6
      signal sent by tkill (sent by pid 28754, uid 5000)

Register Information
r0   = 0x71737723, r1   = 0xb8061f18
r2   = 0xb8069998, r3   = 0xb8069998
r4   = 0xb8069998, r5   = 0x71737723
r6   = 0xb8061f18, r7   = 0xb6e88e9c
r8   = 0xb6c449c0, r9   = 0xb7e36fd0
r10  = 0xb6c52b18, fp   = 0x00000000
ip   = 0xb6e8a428, sp   = 0xbec76338
lr   = 0xb6e1e507, pc   = 0xb6c80bde
cpsr = 0x20000030

Memory Information
MemTotal:   407572 KB
MemFree:      7276 KB
Buffers:     13464 KB
Cached:      91128 KB
VmPeak:      78128 KB
VmSize:      75964 KB
VmLck:           0 KB
VmPin:           0 KB
VmHWM:       20356 KB
VmRSS:       20356 KB
VmData:      17400 KB
VmStk:         136 KB
VmExe:          20 KB
VmLib:       24764 KB
VmPTE:          58 KB
VmSwap:          0 KB

Threads Information
Threads: 2
PID = 28754 TID = 28754
28754 29022 

Maps Information
b287b000 b287f000 r-xp /usr/lib/libogg.so.0.7.1
b2887000 b28a9000 r-xp /usr/lib/libvorbis.so.0.4.3
b28b1000 b28b9000 r-xp /usr/lib/libmdm-common.so.1.0.89
b28ba000 b28fd000 r-xp /usr/lib/libsndfile.so.1.0.25
b290a000 b2952000 r-xp /usr/lib/pulseaudio/libpulsecommon-4.0.so
b2953000 b2958000 r-xp /usr/lib/libjson.so.0.0.1
b2960000 b2991000 r-xp /usr/lib/libmdm.so.1.1.85
b2999000 b29a1000 r-xp /usr/lib/lib_DNSe_NRSS_ver225.so
b29b0000 b29c0000 r-xp /usr/lib/lib_SamsungRec_TizenV04014.so
b29e1000 b29ee000 r-xp /usr/lib/libail.so.0.1.0
b29f7000 b29fa000 r-xp /usr/lib/libsyspopup_caller.so.0.1.0
b2a02000 b2a3a000 r-xp /usr/lib/libpulse.so.0.16.2
b2a3b000 b2a9c000 r-xp /usr/lib/libasound.so.2.0.0
b2aa6000 b2aa9000 r-xp /usr/lib/libpulse-simple.so.0.0.4
b2ab1000 b2ab6000 r-xp /usr/lib/libascenario-0.2.so.0.0.0
b2abe000 b2ad7000 r-xp /usr/lib/libavsysaudio.so.0.0.1
b2ae0000 b2ae4000 r-xp /usr/lib/libmmfsoundcommon.so.0.0.0
b2aed000 b2af7000 r-xp /usr/lib/libaudio-session-mgr.so.0.0.0
b2b03000 b2b08000 r-xp /usr/lib/libmmfsession.so.0.0.0
b2b10000 b2b26000 r-xp /usr/lib/libmmfsound.so.0.1.0
b2b38000 b2b3f000 r-xp /usr/lib/libmmfcommon.so.0.0.0
b2b47000 b2b48000 r-xp /usr/lib/edje/modules/feedback/linux-gnueabi-armv7l-1.0.0/module.so
b2b50000 b2bd7000 rw-s anon_inode:dmabuf
b2bd7000 b2c5e000 rw-s anon_inode:dmabuf
b2ce9000 b2d70000 rw-s anon_inode:dmabuf
b2def000 b2e76000 rw-s anon_inode:dmabuf
b3100000 b310a000 r-xp /usr/lib/libcapi-media-sound-manager.so.0.1.48
b3112000 b3114000 r-xp /usr/lib/libcapi-media-wav-player.so.0.1.10
b311c000 b311d000 r-xp /usr/lib/libmmfkeysound.so.0.0.0
b3125000 b312c000 r-xp /usr/lib/libfeedback.so.0.1.4
b315b000 b395a000 rwxp [stack:29022]
b395a000 b3971000 r-xp /usr/lib/edje/modules/elm/linux-gnueabi-armv7l-1.0.0/module.so
b397e000 b3980000 r-xp /usr/lib/libgenlock.so
b3989000 b398a000 r-xp /usr/lib/evas/modules/loaders/eet/linux-gnueabi-armv7l-1.7.99/module.so
b3992000 b3994000 r-xp /usr/lib/evas/modules/loaders/png/linux-gnueabi-armv7l-1.7.99/module.so
b399e000 b39a3000 r-xp /usr/lib/bufmgr/libtbm_msm.so.0.0.0
b39ab000 b39b6000 r-xp /usr/lib/evas/modules/engines/software_generic/linux-gnueabi-armv7l-1.7.99/module.so
b3cde000 b3da8000 r-xp /usr/lib/libCOREGL.so.4.0
b3db9000 b3dbe000 r-xp /usr/lib/libcapi-media-tool.so.0.1.5
b3dc6000 b3de7000 r-xp /usr/lib/libexif.so.12.3.3
b3dfa000 b3dff000 r-xp /usr/lib/libmmutil_imgp.so.0.0.0
b3e07000 b3e0c000 r-xp /usr/lib/libmmutil_jpeg.so.0.0.0
b539b000 b539d000 r-xp /usr/lib/libdri2.so.0.0.0
b53a5000 b53ad000 r-xp /usr/lib/libdrm.so.2.4.0
b53b5000 b53b8000 r-xp /usr/lib/libcapi-media-image-util.so.0.3.5
b53c0000 b54a4000 r-xp /usr/lib/libicuuc.so.51.1
b54b9000 b55f6000 r-xp /usr/lib/libicui18n.so.51.1
b5606000 b560b000 r-xp /usr/lib/libcapi-system-info.so.0.2.0
b5613000 b5619000 r-xp /usr/lib/libxcb-render.so.0.0.0
b5621000 b5622000 r-xp /usr/lib/libxcb-shm.so.0.0.0
b562b000 b562e000 r-xp /usr/lib/libEGL.so.1.4
b5636000 b5644000 r-xp /usr/lib/libGLESv2.so.2.0
b564d000 b5654000 r-xp /usr/lib/libtbm.so.1.0.0
b565c000 b567d000 r-xp /usr/lib/libui-extension.so.0.1.0
b5686000 b5698000 r-xp /usr/lib/libtts.so
b56a0000 b5758000 r-xp /usr/lib/libcairo.so.2.11200.14
b5763000 b5775000 r-xp /usr/lib/libefl-assist.so.0.1.0
b577d000 b579e000 r-xp /usr/lib/libefl-extension.so.0.1.0
b57a6000 b57b9000 r-xp /opt/usr/apps/org.example.uicomponents/bin/uicomponents
b5980000 b598a000 r-xp /lib/libnss_files-2.13.so
b5993000 b5a62000 r-xp /usr/lib/libscim-1.0.so.8.2.3
b5a78000 b5a9c000 r-xp /usr/lib/ecore/immodules/libisf-imf-module.so
b5aa5000 b5aab000 r-xp /usr/lib/libappsvc.so.0.1.0
b5ab3000 b5ab5000 r-xp /usr/lib/libcapi-appfw-app-common.so.0.3.2.5
b5abe000 b5ac3000 r-xp /usr/lib/libcapi-appfw-app-control.so.0.3.2.5
b5ace000 b5ad9000 r-xp /usr/lib/evas/modules/engines/software_x11/linux-gnueabi-armv7l-1.7.99/module.so
b5ae1000 b5ae3000 r-xp /usr/lib/libiniparser.so.0
b5aec000 b5af1000 r-xp /usr/lib/libappcore-common.so.1.1
b5afa000 b5b02000 r-xp /usr/lib/libcapi-system-system-settings.so.0.0.2
b5b03000 b5b07000 r-xp /usr/lib/libcapi-appfw-application.so.0.3.2.5
b5b14000 b5b16000 r-xp /usr/lib/libXau.so.6.0.0
b5b1f000 b5b26000 r-xp /lib/libcrypt-2.13.so
b5b56000 b5b58000 r-xp /usr/lib/libiri.so
b5b60000 b5d08000 r-xp /usr/lib/libcrypto.so.1.0.0
b5d21000 b5d6e000 r-xp /usr/lib/libssl.so.1.0.0
b5d7b000 b5da9000 r-xp /usr/lib/libidn.so.11.5.44
b5db1000 b5dba000 r-xp /usr/lib/libcares.so.2.1.0
b5dc3000 b5dd6000 r-xp /usr/lib/libxcb.so.1.1.0
b5ddf000 b5de1000 r-xp /usr/lib/journal/libjournal.so.0.1.0
b5dea000 b5dec000 r-xp /usr/lib/libSLP-db-util.so.0.1.0
b5df5000 b5ec1000 r-xp /usr/lib/libxml2.so.2.7.8
b5ece000 b5ed0000 r-xp /usr/lib/libgmodule-2.0.so.0.3200.3
b5ed8000 b5edd000 r-xp /usr/lib/libffi.so.5.0.10
b5ee5000 b5ee6000 r-xp /usr/lib/libgthread-2.0.so.0.3200.3
b5eef000 b5efa000 r-xp /usr/lib/libgpg-error.so.0.15.0
b5f02000 b5f05000 r-xp /lib/libattr.so.1.1.0
b5f0d000 b5fa1000 r-xp /usr/lib/libstdc++.so.6.0.16
b5fb4000 b5fd0000 r-xp /usr/lib/libsecurity-server-commons.so.1.0.0
b5fd9000 b5ff1000 r-xp /usr/lib/libpng12.so.0.50.0
b5ffa000 b6010000 r-xp /lib/libexpat.so.1.5.2
b601a000 b605e000 r-xp /usr/lib/libcurl.so.4.3.0
b6067000 b6071000 r-xp /usr/lib/libXext.so.6.4.0
b607a000 b607d000 r-xp /usr/lib/libXtst.so.6.1.0
b6086000 b608c000 r-xp /usr/lib/libXrender.so.1.3.0
b6095000 b609b000 r-xp /usr/lib/libXrandr.so.2.2.0
b60a3000 b60a4000 r-xp /usr/lib/libXinerama.so.1.0.0
b60ad000 b60b6000 r-xp /usr/lib/libXi.so.6.1.0
b60be000 b60c1000 r-xp /usr/lib/libXfixes.so.3.1.0
b60c9000 b60cb000 r-xp /usr/lib/libXgesture.so.7.0.0
b60d3000 b60d5000 r-xp /usr/lib/libXcomposite.so.1.0.0
b60de000 b60e0000 r-xp /usr/lib/libXdamage.so.1.1.0
b60e8000 b60ef000 r-xp /usr/lib/libXcursor.so.1.0.2
b60f7000 b60fa000 r-xp /usr/lib/libecore_input_evas.so.1.7.99
b6102000 b6106000 r-xp /usr/lib/libecore_ipc.so.1.7.99
b610f000 b6114000 r-xp /usr/lib/libecore_fb.so.1.7.99
b611e000 b61ff000 r-xp /usr/lib/libX11.so.6.3.0
b620a000 b622d000 r-xp /usr/lib/libjpeg.so.8.0.2
b6245000 b625b000 r-xp /lib/libz.so.1.2.5
b6263000 b62d8000 r-xp /usr/lib/libsqlite3.so.0.8.6
b62e2000 b62f7000 r-xp /usr/lib/libpkgmgr_parser.so.0.1.0
b6300000 b6334000 r-xp /usr/lib/libgobject-2.0.so.0.3200.3
b633d000 b6410000 r-xp /usr/lib/libgio-2.0.so.0.3200.3
b641b000 b642b000 r-xp /lib/libresolv-2.13.so
b642f000 b64ab000 r-xp /usr/lib/libgcrypt.so.20.0.3
b64b7000 b64cf000 r-xp /usr/lib/liblzma.so.5.0.3
b64d8000 b64db000 r-xp /lib/libcap.so.2.21
b64e3000 b6509000 r-xp /usr/lib/libsecurity-server-client.so.1.0.1
b6512000 b6513000 r-xp /usr/lib/libecore_imf_evas.so.1.7.99
b651b000 b6521000 r-xp /usr/lib/libecore_imf.so.1.7.99
b6529000 b6540000 r-xp /usr/lib/liblua-5.1.so
b654a000 b6551000 r-xp /usr/lib/libembryo.so.1.7.99
b6559000 b655f000 r-xp /lib/librt-2.13.so
b6568000 b65be000 r-xp /usr/lib/libpixman-1.so.0.28.2
b65cb000 b6621000 r-xp /usr/lib/libfreetype.so.6.11.3
b662d000 b6655000 r-xp /usr/lib/libfontconfig.so.1.8.0
b6657000 b6694000 r-xp /usr/lib/libharfbuzz.so.0.940.0
b669d000 b66b0000 r-xp /usr/lib/libfribidi.so.0.3.1
b66b8000 b66d2000 r-xp /usr/lib/libecore_con.so.1.7.99
b66db000 b66e4000 r-xp /usr/lib/libedbus.so.1.7.99
b66ec000 b673c000 r-xp /usr/lib/libecore_x.so.1.7.99
b673f000 b6743000 r-xp /usr/lib/libvconf.so.0.2.45
b674b000 b675c000 r-xp /usr/lib/libecore_input.so.1.7.99
b6764000 b6769000 r-xp /usr/lib/libecore_file.so.1.7.99
b6771000 b6793000 r-xp /usr/lib/libecore_evas.so.1.7.99
b679c000 b67dd000 r-xp /usr/lib/libeina.so.1.7.99
b67e6000 b67ff000 r-xp /usr/lib/libeet.so.1.7.99
b6810000 b6879000 r-xp /lib/libm-2.13.so
b6882000 b6888000 r-xp /usr/lib/libcapi-base-common.so.0.1.8
b6891000 b6894000 r-xp /usr/lib/libproc-stat.so.0.2.86
b689c000 b68be000 r-xp /usr/lib/libpkgmgr-info.so.0.0.17
b68c6000 b68cb000 r-xp /usr/lib/libxdgmime.so.1.1.0
b68d3000 b68fd000 r-xp /usr/lib/libdbus-1.so.3.8.12
b6906000 b691d000 r-xp /usr/lib/libdbus-glib-1.so.2.2.2
b6925000 b6930000 r-xp /lib/libunwind.so.8.0.1
b695d000 b6999000 r-xp /usr/lib/libsystemd.so.0.4.0
b69a2000 b6abd000 r-xp /lib/libc-2.13.so
b6acb000 b6ad3000 r-xp /lib/libgcc_s-4.6.so.1
b6ad4000 b6ad7000 r-xp /usr/lib/libsmack.so.1.0.0
b6adf000 b6ae5000 r-xp /usr/lib/libprivilege-control.so.0.0.2
b6aed000 b6bbd000 r-xp /usr/lib/libglib-2.0.so.0.3200.3
b6bbe000 b6c1b000 r-xp /usr/lib/libedje.so.1.7.99
b6c25000 b6c3c000 r-xp /usr/lib/libecore.so.1.7.99
b6c53000 b6d22000 r-xp /usr/lib/libevas.so.1.7.99
b6d46000 b6e80000 r-xp /usr/lib/libelementary.so.1.7.99
b6e96000 b6eaa000 r-xp /lib/libpthread-2.13.so
b6eb5000 b6eb7000 r-xp /usr/lib/libdlog.so.0.0.0
b6ebf000 b6ec2000 r-xp /usr/lib/libbundle.so.0.1.22
b6eca000 b6ecc000 r-xp /lib/libdl-2.13.so
b6ed5000 b6ee1000 r-xp /usr/lib/libaul.so.0.1.0
b6ef3000 b6ef8000 r-xp /usr/lib/libappcore-efl.so.1.1
b6f01000 b6f05000 r-xp /usr/lib/libsys-assert.so
b6f0e000 b6f2b000 r-xp /lib/ld-2.13.so
b6f34000 b6f39000 r-xp /usr/bin/launchpad-loader
b7dff000 b81d3000 rw-p [heap]
bec56000 bec77000 rwxp [stack]
End of Maps Information

Callstack Information (PID:28754)
Call Stack Count: 3
 0: evas_object_evas_get + 0x5 (0xb6c80bde) [/usr/lib/libevas.so.1] + 0x2dbde
 1: elm_scroller_add + 0x16 (0xb6e1e507) [/usr/lib/libelementary.so.1] + 0xd8507
 2: _single_line_entry_cb1 + 0x2c (0xb57aba05) [/opt/usr/apps/org.example.uicomponents/bin/uicomponents] + 0x5a05
End of Call Stack

Package Information
Package Name: org.example.uicomponents
Package ID : org.example.uicomponents
Version: 1.0.0
Package Type: rpm
App Name: uicomponents
App ID: org.example.uicomponents
Type: capp
Categories: 

Latest Debug Message Information
--------- beginning of /dev/log_main
ementary<28754> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), hold(0) freeze(0)
06-06 21:42:49.149+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b8061f18), locked_x(0)
06-06 21:42:49.149+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b8061f18)
06-06 21:42:49.169+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), block(1)
06-06 21:42:49.169+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), ev->cur.canvas.x(269) ev->cur.canvas.y(108)
06-06 21:42:49.169+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), hold(0) freeze(0)
06-06 21:42:49.169+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b8061f18), locked_x(0)
06-06 21:42:49.169+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b8061f18)
06-06 21:42:49.189+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), block(1)
06-06 21:42:49.189+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), ev->cur.canvas.x(269) ev->cur.canvas.y(107)
06-06 21:42:49.189+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), hold(0) freeze(0)
06-06 21:42:49.189+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b8061f18), locked_x(0)
06-06 21:42:49.189+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b8061f18)
06-06 21:42:49.189+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b8061f18), locked_x(0)
06-06 21:42:49.189+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b8061f18), locked_x(0)
06-06 21:42:49.189+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b8061f18), locked_x(0)
06-06 21:42:49.189+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b8061f18), locked_x(0)
06-06 21:42:49.189+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b8061f18), locked_x(0)
06-06 21:42:49.189+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b8061f18), locked_x(0)
06-06 21:42:49.209+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), block(1)
06-06 21:42:49.209+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), ev->cur.canvas.x(270) ev->cur.canvas.y(107)
06-06 21:42:49.209+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), hold(0) freeze(0)
06-06 21:42:49.209+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b8061f18), locked_x(0)
06-06 21:42:49.209+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b8061f18)
06-06 21:42:49.209+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), block(1)
06-06 21:42:49.209+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), ev->cur.canvas.x(270) ev->cur.canvas.y(106)
06-06 21:42:49.209+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), hold(0) freeze(0)
06-06 21:42:49.219+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b8061f18), locked_x(0)
06-06 21:42:49.219+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b8061f18)
06-06 21:42:49.239+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b8061f18), locked_x(0)
06-06 21:42:49.259+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b8061f18), locked_x(0)
06-06 21:42:49.269+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b8061f18), locked_x(0)
06-06 21:42:49.299+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b8061f18), locked_x(0)
06-06 21:42:49.309+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b8061f18), locked_x(0)
06-06 21:42:49.319+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b8061f18), locked_x(0)
06-06 21:42:49.339+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b8061f18), locked_x(0)
06-06 21:42:49.359+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b8061f18), locked_x(0)
06-06 21:42:49.369+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b8061f18), locked_x(0)
06-06 21:42:49.389+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b8061f18), locked_x(0)
06-06 21:42:49.409+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b8061f18), locked_x(0)
06-06 21:42:49.429+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b8061f18), locked_x(0)
06-06 21:42:49.459+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), block(1)
06-06 21:42:49.459+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), ev->cur.canvas.x(270) ev->cur.canvas.y(105)
06-06 21:42:49.459+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), hold(0) freeze(0)
06-06 21:42:49.469+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b8061f18), locked_x(0)
06-06 21:42:49.469+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b8061f18)
06-06 21:42:49.489+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), block(1)
06-06 21:42:49.489+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), ev->cur.canvas.x(270) ev->cur.canvas.y(104)
06-06 21:42:49.489+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), hold(0) freeze(0)
06-06 21:42:49.489+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b8061f18), locked_x(0)
06-06 21:42:49.489+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b8061f18)
06-06 21:42:49.539+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), block(1)
06-06 21:42:49.539+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), ev->cur.canvas.x(270) ev->cur.canvas.y(103)
06-06 21:42:49.539+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), hold(0) freeze(0)
06-06 21:42:49.539+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), block(1)
06-06 21:42:49.539+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), ev->cur.canvas.x(270) ev->cur.canvas.y(102)
06-06 21:42:49.539+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), hold(0) freeze(0)
06-06 21:42:49.539+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), block(1)
06-06 21:42:49.539+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), ev->cur.canvas.x(270) ev->cur.canvas.y(101)
06-06 21:42:49.539+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), hold(0) freeze(0)
06-06 21:42:49.549+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b8061f18), locked_x(0)
06-06 21:42:49.549+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b8061f18)
06-06 21:42:49.579+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), block(1)
06-06 21:42:49.579+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), ev->cur.canvas.x(270) ev->cur.canvas.y(100)
06-06 21:42:49.579+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), hold(0) freeze(0)
06-06 21:42:49.579+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), block(1)
06-06 21:42:49.579+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), ev->cur.canvas.x(270) ev->cur.canvas.y(99)
06-06 21:42:49.579+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), hold(0) freeze(0)
06-06 21:42:49.579+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), block(1)
06-06 21:42:49.579+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), ev->cur.canvas.x(270) ev->cur.canvas.y(98)
06-06 21:42:49.579+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), hold(0) freeze(0)
06-06 21:42:49.579+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b8061f18), locked_x(0)
06-06 21:42:49.579+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b8061f18)
06-06 21:42:49.629+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), block(1)
06-06 21:42:49.629+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), ev->cur.canvas.x(270) ev->cur.canvas.y(97)
06-06 21:42:49.629+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), hold(0) freeze(0)
06-06 21:42:49.629+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b8061f18), locked_x(0)
06-06 21:42:49.629+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b8061f18)
06-06 21:42:49.669+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b8061f18), locked_x(0)
06-06 21:42:49.669+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b8061f18), locked_x(0)
06-06 21:42:49.669+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b8061f18), locked_x(0)
06-06 21:42:49.669+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b8061f18), locked_x(0)
06-06 21:42:49.669+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b8061f18), locked_x(0)
06-06 21:42:49.669+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b8061f18), locked_x(0)
06-06 21:42:49.669+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b8061f18), locked_x(0)
06-06 21:42:49.669+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b8061f18), locked_x(0)
06-06 21:42:49.669+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b8061f18), locked_x(0)
06-06 21:42:49.669+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b8061f18), locked_x(0)
06-06 21:42:49.689+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b8061f18), locked_x(0)
06-06 21:42:49.709+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b8061f18), locked_x(0)
06-06 21:42:49.729+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), block(1)
06-06 21:42:49.729+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), ev->cur.canvas.x(269) ev->cur.canvas.y(97)
06-06 21:42:49.729+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), hold(0) freeze(0)
06-06 21:42:49.729+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b8061f18), locked_x(0)
06-06 21:42:49.729+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b8061f18)
06-06 21:42:49.749+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b8061f18), locked_x(0)
06-06 21:42:49.749+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), block(1)
06-06 21:42:49.749+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), ev->cur.canvas.x(269) ev->cur.canvas.y(98)
06-06 21:42:49.749+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), hold(0) freeze(0)
06-06 21:42:49.759+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b8061f18), locked_x(0)
06-06 21:42:49.759+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b8061f18)
06-06 21:42:49.789+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), block(1)
06-06 21:42:49.789+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), ev->cur.canvas.x(269) ev->cur.canvas.y(99)
06-06 21:42:49.789+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), hold(0) freeze(0)
06-06 21:42:49.789+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), block(1)
06-06 21:42:49.789+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), ev->cur.canvas.x(268) ev->cur.canvas.y(99)
06-06 21:42:49.789+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), hold(0) freeze(0)
06-06 21:42:49.799+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b8061f18), locked_x(0)
06-06 21:42:49.799+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b8061f18)
06-06 21:42:49.799+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b8061f18), locked_x(0)
06-06 21:42:49.799+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), block(1)
06-06 21:42:49.799+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), ev->cur.canvas.x(267) ev->cur.canvas.y(100)
06-06 21:42:49.799+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), hold(0) freeze(0)
06-06 21:42:49.819+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b8061f18), locked_x(0)
06-06 21:42:49.819+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b8061f18)
06-06 21:42:49.839+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), block(1)
06-06 21:42:49.839+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), ev->cur.canvas.x(264) ev->cur.canvas.y(100)
06-06 21:42:49.839+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), hold(0) freeze(0)
06-06 21:42:49.839+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), block(1)
06-06 21:42:49.839+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), ev->cur.canvas.x(263) ev->cur.canvas.y(99)
06-06 21:42:49.839+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), hold(0) freeze(0)
06-06 21:42:49.839+0900 E/EFL     (28754): evas_main<28754> evas_events.c:1275 evas_event_feed_mouse_up() ButtonEvent:up time=16745574 button=1 downs=0
06-06 21:42:49.839+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:2278 _elm_scroll_post_event_up() [DDO] lock set false. : obj(b8061f18), type(elm_genlist)
06-06 21:42:50.419+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), block(1)
06-06 21:42:50.419+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), ev->cur.canvas.x(230) ev->cur.canvas.y(146)
06-06 21:42:50.419+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), hold(0) freeze(0)
06-06 21:42:50.419+0900 E/EFL     (28754): evas_main<28754> evas_events.c:1009 evas_event_feed_mouse_down() ButtonEvent:down time=16746160 button=1 downs=1
06-06 21:42:50.449+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), block(1)
06-06 21:42:50.449+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), ev->cur.canvas.x(235) ev->cur.canvas.y(146)
06-06 21:42:50.449+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), hold(0) freeze(0)
06-06 21:42:50.449+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), block(1)
06-06 21:42:50.449+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), ev->cur.canvas.x(236) ev->cur.canvas.y(150)
06-06 21:42:50.449+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), hold(0) freeze(0)
06-06 21:42:50.449+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), block(1)
06-06 21:42:50.449+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), ev->cur.canvas.x(236) ev->cur.canvas.y(151)
06-06 21:42:50.449+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), hold(0) freeze(0)
06-06 21:42:50.479+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), block(1)
06-06 21:42:50.479+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), ev->cur.canvas.x(236) ev->cur.canvas.y(150)
06-06 21:42:50.479+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), hold(0) freeze(0)
06-06 21:42:50.509+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), block(1)
06-06 21:42:50.509+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), ev->cur.canvas.x(236) ev->cur.canvas.y(149)
06-06 21:42:50.509+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), hold(0) freeze(0)
06-06 21:42:50.509+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), block(1)
06-06 21:42:50.509+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), ev->cur.canvas.x(236) ev->cur.canvas.y(147)
06-06 21:42:50.509+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), hold(0) freeze(0)
06-06 21:42:50.509+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), block(1)
06-06 21:42:50.509+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), ev->cur.canvas.x(235) ev->cur.canvas.y(147)
06-06 21:42:50.509+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), hold(0) freeze(0)
06-06 21:42:50.529+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), block(1)
06-06 21:42:50.529+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), ev->cur.canvas.x(233) ev->cur.canvas.y(147)
06-06 21:42:50.529+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), hold(0) freeze(0)
06-06 21:42:50.529+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), block(1)
06-06 21:42:50.529+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), ev->cur.canvas.x(230) ev->cur.canvas.y(141)
06-06 21:42:50.529+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), hold(0) freeze(0)
06-06 21:42:50.559+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), block(1)
06-06 21:42:50.559+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), ev->cur.canvas.x(222) ev->cur.canvas.y(136)
06-06 21:42:50.559+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), hold(0) freeze(0)
06-06 21:42:50.559+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), block(1)
06-06 21:42:50.559+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), ev->cur.canvas.x(216) ev->cur.canvas.y(134)
06-06 21:42:50.559+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), hold(0) freeze(0)
06-06 21:42:50.559+0900 E/EFL     (28754): evas_main<28754> evas_events.c:1275 evas_event_feed_mouse_up() ButtonEvent:up time=16746300 button=1 downs=0
06-06 21:42:53.569+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), block(1)
06-06 21:42:53.569+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), ev->cur.canvas.x(201) ev->cur.canvas.y(161)
06-06 21:42:53.569+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), hold(0) freeze(0)
06-06 21:42:53.569+0900 E/EFL     (28754): evas_main<28754> evas_events.c:1009 evas_event_feed_mouse_down() ButtonEvent:down time=16749313 button=1 downs=1
06-06 21:42:53.579+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), block(1)
06-06 21:42:53.579+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), ev->cur.canvas.x(199) ev->cur.canvas.y(156)
06-06 21:42:53.579+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), hold(0) freeze(0)
06-06 21:42:53.589+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), block(1)
06-06 21:42:53.589+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), ev->cur.canvas.x(197) ev->cur.canvas.y(151)
06-06 21:42:53.589+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), hold(0) freeze(0)
06-06 21:42:53.609+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), block(1)
06-06 21:42:53.609+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), ev->cur.canvas.x(196) ev->cur.canvas.y(147)
06-06 21:42:53.609+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), block(1)
06-06 21:42:53.609+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), ev->cur.canvas.x(196) ev->cur.canvas.y(145)
06-06 21:42:53.609+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), hold(0) freeze(0)
06-06 21:42:53.609+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), hold(0) freeze(0)
06-06 21:42:53.629+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), block(1)
06-06 21:42:53.629+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), ev->cur.canvas.x(195) ev->cur.canvas.y(143)
06-06 21:42:53.629+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), hold(0) freeze(0)
06-06 21:42:53.639+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), block(1)
06-06 21:42:53.639+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), ev->cur.canvas.x(195) ev->cur.canvas.y(141)
06-06 21:42:53.639+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), hold(0) freeze(0)
06-06 21:42:53.649+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), block(1)
06-06 21:42:53.649+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), ev->cur.canvas.x(195) ev->cur.canvas.y(135)
06-06 21:42:53.649+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), hold(0) freeze(0)
06-06 21:42:53.649+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), block(1)
06-06 21:42:53.649+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), ev->cur.canvas.x(196) ev->cur.canvas.y(128)
06-06 21:42:53.649+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), hold(0) freeze(0)
06-06 21:42:53.669+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), block(1)
06-06 21:42:53.669+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), ev->cur.canvas.x(198) ev->cur.canvas.y(122)
06-06 21:42:53.669+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), hold(0) freeze(0)
06-06 21:42:53.669+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:4249 _elm_scroll_mouse_move_event_cb() [DDO] animator
06-06 21:42:53.669+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3353 _elm_scroll_post_event_move() [DDO] obj(b8061f18), type(elm_genlist)
06-06 21:42:53.669+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3354 _elm_scroll_post_event_move() [DDO] hold_parent(0)
06-06 21:42:53.669+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3405 _elm_scroll_post_event_move() [DDO] elm_widget_drag_lock_y_set : obj(b8061f18), type(elm_genlist)
06-06 21:42:53.679+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), block(1)
06-06 21:42:53.679+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), ev->cur.canvas.x(200) ev->cur.canvas.y(118)
06-06 21:42:53.679+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b8061f18), locked_x(0)
06-06 21:42:53.679+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b8061f18)
06-06 21:42:53.679+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), hold(0) freeze(0)
06-06 21:42:53.699+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), block(1)
06-06 21:42:53.699+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), ev->cur.canvas.x(201) ev->cur.canvas.y(114)
06-06 21:42:53.699+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), hold(0) freeze(0)
06-06 21:42:53.699+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), block(1)
06-06 21:42:53.699+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), ev->cur.canvas.x(202) ev->cur.canvas.y(111)
06-06 21:42:53.699+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), hold(0) freeze(0)
06-06 21:42:53.709+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b8061f18), locked_x(0)
06-06 21:42:53.709+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b8061f18)
06-06 21:42:53.749+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), block(1)
06-06 21:42:53.749+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), ev->cur.canvas.x(203) ev->cur.canvas.y(109)
06-06 21:42:53.749+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), hold(0) freeze(0)
06-06 21:42:53.749+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), block(1)
06-06 21:42:53.749+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), ev->cur.canvas.x(207) ev->cur.canvas.y(107)
06-06 21:42:53.749+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), hold(0) freeze(0)
06-06 21:42:53.759+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), block(1)
06-06 21:42:53.759+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), ev->cur.canvas.x(211) ev->cur.canvas.y(105)
06-06 21:42:53.759+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), hold(0) freeze(0)
06-06 21:42:53.759+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), block(1)
06-06 21:42:53.759+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), ev->cur.canvas.x(212) ev->cur.canvas.y(104)
06-06 21:42:53.759+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), hold(0) freeze(0)
06-06 21:42:53.759+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), block(1)
06-06 21:42:53.759+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), ev->cur.canvas.x(212) ev->cur.canvas.y(100)
06-06 21:42:53.759+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), hold(0) freeze(0)
06-06 21:42:53.759+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b8061f18), locked_x(0)
06-06 21:42:53.759+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b8061f18)
06-06 21:42:53.789+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), block(1)
06-06 21:42:53.789+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), ev->cur.canvas.x(212) ev->cur.canvas.y(95)
06-06 21:42:53.789+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), hold(0) freeze(0)
06-06 21:42:53.789+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), block(1)
06-06 21:42:53.789+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), ev->cur.canvas.x(212) ev->cur.canvas.y(93)
06-06 21:42:53.789+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), hold(0) freeze(0)
06-06 21:42:53.789+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), block(1)
06-06 21:42:53.789+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), ev->cur.canvas.x(212) ev->cur.canvas.y(89)
06-06 21:42:53.789+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), hold(0) freeze(0)
06-06 21:42:53.789+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b8061f18), locked_x(0)
06-06 21:42:53.789+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b8061f18)
06-06 21:42:53.819+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), block(1)
06-06 21:42:53.819+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), ev->cur.canvas.x(212) ev->cur.canvas.y(86)
06-06 21:42:53.819+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), hold(0) freeze(0)
06-06 21:42:53.819+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), block(1)
06-06 21:42:53.819+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), ev->cur.canvas.x(212) ev->cur.canvas.y(84)
06-06 21:42:53.819+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), hold(0) freeze(0)
06-06 21:42:53.819+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), block(1)
06-06 21:42:53.819+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), ev->cur.canvas.x(212) ev->cur.canvas.y(83)
06-06 21:42:53.819+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), hold(0) freeze(0)
06-06 21:42:53.819+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), block(1)
06-06 21:42:53.819+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), ev->cur.canvas.x(212) ev->cur.canvas.y(82)
06-06 21:42:53.819+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), hold(0) freeze(0)
06-06 21:42:53.829+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b8061f18), locked_x(0)
06-06 21:42:53.829+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b8061f18)
06-06 21:42:53.849+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), block(1)
06-06 21:42:53.849+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), ev->cur.canvas.x(212) ev->cur.canvas.y(81)
06-06 21:42:53.849+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), hold(0) freeze(0)
06-06 21:42:53.849+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b8061f18), locked_x(0)
06-06 21:42:53.849+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b8061f18)
06-06 21:42:53.879+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), block(1)
06-06 21:42:53.879+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), ev->cur.canvas.x(212) ev->cur.canvas.y(80)
06-06 21:42:53.879+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), hold(0) freeze(0)
06-06 21:42:53.879+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), block(1)
06-06 21:42:53.879+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), ev->cur.canvas.x(209) ev->cur.canvas.y(79)
06-06 21:42:53.879+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), hold(0) freeze(0)
06-06 21:42:53.879+0900 E/EFL     (28754): evas_main<28754> evas_events.c:1275 evas_event_feed_mouse_up() ButtonEvent:up time=16749621 button=1 downs=0
06-06 21:42:53.879+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:2278 _elm_scroll_post_event_up() [DDO] lock set false. : obj(b8061f18), type(elm_genlist)
06-06 21:42:54.689+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), block(1)
06-06 21:42:54.689+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), ev->cur.canvas.x(224) ev->cur.canvas.y(169)
06-06 21:42:54.689+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), hold(0) freeze(0)
06-06 21:42:54.689+0900 E/EFL     (28754): evas_main<28754> evas_events.c:1009 evas_event_feed_mouse_down() ButtonEvent:down time=16750425 button=1 downs=1
06-06 21:42:54.699+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), block(1)
06-06 21:42:54.699+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), ev->cur.canvas.x(228) ev->cur.canvas.y(171)
06-06 21:42:54.699+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), hold(0) freeze(0)
06-06 21:42:54.699+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), block(1)
06-06 21:42:54.699+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), ev->cur.canvas.x(231) ev->cur.canvas.y(175)
06-06 21:42:54.699+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), hold(0) freeze(0)
06-06 21:42:54.719+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), block(1)
06-06 21:42:54.719+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), ev->cur.canvas.x(231) ev->cur.canvas.y(176)
06-06 21:42:54.719+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), hold(0) freeze(0)
06-06 21:42:54.749+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), block(1)
06-06 21:42:54.749+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), ev->cur.canvas.x(230) ev->cur.canvas.y(176)
06-06 21:42:54.749+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), hold(0) freeze(0)
06-06 21:42:54.769+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), block(1)
06-06 21:42:54.769+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), ev->cur.canvas.x(229) ev->cur.canvas.y(176)
06-06 21:42:54.769+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), hold(0) freeze(0)
06-06 21:42:54.789+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), block(1)
06-06 21:42:54.789+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), ev->cur.canvas.x(229) ev->cur.canvas.y(177)
06-06 21:42:54.789+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), hold(0) freeze(0)
06-06 21:42:54.829+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), block(1)
06-06 21:42:54.829+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), ev->cur.canvas.x(229) ev->cur.canvas.y(174)
06-06 21:42:54.829+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), hold(0) freeze(0)
06-06 21:42:54.829+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), block(1)
06-06 21:42:54.829+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), ev->cur.canvas.x(229) ev->cur.canvas.y(169)
06-06 21:42:54.829+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), hold(0) freeze(0)
06-06 21:42:54.829+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), block(1)
06-06 21:42:54.829+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), ev->cur.canvas.x(228) ev->cur.canvas.y(165)
06-06 21:42:54.829+0900 E/EFL     (28754): elementary<28754> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8061f18), hold(0) freeze(0)
06-06 21:42:54.839+0900 E/EFL     (28754): evas_main<28754> evas_events.c:1275 evas_event_feed_mouse_up() ButtonEvent:up time=16750587 button=1 downs=0
06-06 21:42:55.089+0900 W/CRASH_MANAGER(29055): worker.c: worker_job(1199) > 1128754756963146521697
