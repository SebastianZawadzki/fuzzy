S/W Version Information
Model: SM-R735S
Tizen-Version: 2.3.1.2
Build-Number: R735SKSU1AOKE
Build-Date: 2015.11.25 20:46:58

Crash Information
Process Name: uicomponents
PID: 32727
Date: 2016-06-06 22:34:14+0900
Executable File Path: /opt/usr/apps/org.example.uicomponents/bin/uicomponents
Signal: 11
      (SIGSEGV)
      si_code: -6
      signal sent by tkill (sent by pid 32727, uid 5000)

Register Information
r0   = 0x71737723, r1   = 0x71737723
r2   = 0xb89eefe0, r3   = 0xb89eefe0
r4   = 0xb8a57388, r5   = 0x71737723
r6   = 0x00000000, r7   = 0xb6f24e9c
r8   = 0xb6ce09c0, r9   = 0xb8808e88
r10  = 0xb6ceeb18, fp   = 0x00000000
ip   = 0xb6f26428, sp   = 0xbe9f22e0
lr   = 0xb6eba507, pc   = 0xb6d1cbde
cpsr = 0x20000030

Memory Information
MemTotal:   407572 KB
MemFree:      8876 KB
Buffers:     13376 KB
Cached:      91896 KB
VmPeak:      77092 KB
VmSize:      74928 KB
VmLck:           0 KB
VmPin:           0 KB
VmHWM:       19108 KB
VmRSS:       19108 KB
VmData:      16364 KB
VmStk:         136 KB
VmExe:          20 KB
VmLib:       24764 KB
VmPTE:          56 KB
VmSwap:          0 KB

Threads Information
Threads: 2
PID = 32727 TID = 32727
32727 571 

Maps Information
b2916000 b291a000 r-xp /usr/lib/libogg.so.0.7.1
b2922000 b2944000 r-xp /usr/lib/libvorbis.so.0.4.3
b294c000 b2954000 r-xp /usr/lib/libmdm-common.so.1.0.89
b2955000 b2998000 r-xp /usr/lib/libsndfile.so.1.0.25
b29a5000 b29ed000 r-xp /usr/lib/pulseaudio/libpulsecommon-4.0.so
b29ee000 b29f3000 r-xp /usr/lib/libjson.so.0.0.1
b29fb000 b2a2c000 r-xp /usr/lib/libmdm.so.1.1.85
b2a34000 b2a3c000 r-xp /usr/lib/lib_DNSe_NRSS_ver225.so
b2a4b000 b2a5b000 r-xp /usr/lib/lib_SamsungRec_TizenV04014.so
b2a7c000 b2a89000 r-xp /usr/lib/libail.so.0.1.0
b2a92000 b2a95000 r-xp /usr/lib/libsyspopup_caller.so.0.1.0
b2a9d000 b2ad5000 r-xp /usr/lib/libpulse.so.0.16.2
b2ad6000 b2b37000 r-xp /usr/lib/libasound.so.2.0.0
b2b41000 b2b44000 r-xp /usr/lib/libpulse-simple.so.0.0.4
b2b4c000 b2b51000 r-xp /usr/lib/libascenario-0.2.so.0.0.0
b2b59000 b2b72000 r-xp /usr/lib/libavsysaudio.so.0.0.1
b2b7b000 b2b7f000 r-xp /usr/lib/libmmfsoundcommon.so.0.0.0
b2b88000 b2b92000 r-xp /usr/lib/libaudio-session-mgr.so.0.0.0
b2b9e000 b2bb4000 r-xp /usr/lib/libmmfsound.so.0.1.0
b2bc6000 b2bc7000 r-xp /usr/lib/edje/modules/feedback/linux-gnueabi-armv7l-1.0.0/module.so
b2bcf000 b2c56000 rw-s anon_inode:dmabuf
b2c56000 b2cdd000 rw-s anon_inode:dmabuf
b2d68000 b2def000 rw-s anon_inode:dmabuf
b2e6e000 b2ef5000 rw-s anon_inode:dmabuf
b3101000 b3106000 r-xp /usr/lib/libmmfsession.so.0.0.0
b310e000 b3115000 r-xp /usr/lib/libmmfcommon.so.0.0.0
b311d000 b3127000 r-xp /usr/lib/libcapi-media-sound-manager.so.0.1.48
b312f000 b3131000 r-xp /usr/lib/libcapi-media-wav-player.so.0.1.10
b3139000 b313a000 r-xp /usr/lib/libmmfkeysound.so.0.0.0
b3142000 b3149000 r-xp /usr/lib/libfeedback.so.0.1.4
b31f7000 b39f6000 rwxp [stack:571]
b39f6000 b3a0d000 r-xp /usr/lib/edje/modules/elm/linux-gnueabi-armv7l-1.0.0/module.so
b3a1a000 b3a1c000 r-xp /usr/lib/libgenlock.so
b3a25000 b3a26000 r-xp /usr/lib/evas/modules/loaders/eet/linux-gnueabi-armv7l-1.7.99/module.so
b3a2e000 b3a30000 r-xp /usr/lib/evas/modules/loaders/png/linux-gnueabi-armv7l-1.7.99/module.so
b3a3a000 b3a3f000 r-xp /usr/lib/bufmgr/libtbm_msm.so.0.0.0
b3a47000 b3a52000 r-xp /usr/lib/evas/modules/engines/software_generic/linux-gnueabi-armv7l-1.7.99/module.so
b3d7a000 b3e44000 r-xp /usr/lib/libCOREGL.so.4.0
b3e55000 b3e5a000 r-xp /usr/lib/libcapi-media-tool.so.0.1.5
b3e62000 b3e83000 r-xp /usr/lib/libexif.so.12.3.3
b3e96000 b3e9b000 r-xp /usr/lib/libmmutil_imgp.so.0.0.0
b3ea3000 b3ea8000 r-xp /usr/lib/libmmutil_jpeg.so.0.0.0
b5437000 b5439000 r-xp /usr/lib/libdri2.so.0.0.0
b5441000 b5449000 r-xp /usr/lib/libdrm.so.2.4.0
b5451000 b5454000 r-xp /usr/lib/libcapi-media-image-util.so.0.3.5
b545c000 b5540000 r-xp /usr/lib/libicuuc.so.51.1
b5555000 b5692000 r-xp /usr/lib/libicui18n.so.51.1
b56a2000 b56a7000 r-xp /usr/lib/libcapi-system-info.so.0.2.0
b56af000 b56b5000 r-xp /usr/lib/libxcb-render.so.0.0.0
b56bd000 b56be000 r-xp /usr/lib/libxcb-shm.so.0.0.0
b56c7000 b56ca000 r-xp /usr/lib/libEGL.so.1.4
b56d2000 b56e0000 r-xp /usr/lib/libGLESv2.so.2.0
b56e9000 b56f0000 r-xp /usr/lib/libtbm.so.1.0.0
b56f8000 b5719000 r-xp /usr/lib/libui-extension.so.0.1.0
b5722000 b5734000 r-xp /usr/lib/libtts.so
b573c000 b57f4000 r-xp /usr/lib/libcairo.so.2.11200.14
b57ff000 b5811000 r-xp /usr/lib/libefl-assist.so.0.1.0
b5819000 b583a000 r-xp /usr/lib/libefl-extension.so.0.1.0
b5842000 b5855000 r-xp /opt/usr/apps/org.example.uicomponents/bin/uicomponents
b5a1c000 b5a26000 r-xp /lib/libnss_files-2.13.so
b5a2f000 b5afe000 r-xp /usr/lib/libscim-1.0.so.8.2.3
b5b14000 b5b38000 r-xp /usr/lib/ecore/immodules/libisf-imf-module.so
b5b41000 b5b47000 r-xp /usr/lib/libappsvc.so.0.1.0
b5b4f000 b5b51000 r-xp /usr/lib/libcapi-appfw-app-common.so.0.3.2.5
b5b5a000 b5b5f000 r-xp /usr/lib/libcapi-appfw-app-control.so.0.3.2.5
b5b6a000 b5b75000 r-xp /usr/lib/evas/modules/engines/software_x11/linux-gnueabi-armv7l-1.7.99/module.so
b5b7d000 b5b7f000 r-xp /usr/lib/libiniparser.so.0
b5b88000 b5b8d000 r-xp /usr/lib/libappcore-common.so.1.1
b5b96000 b5b9e000 r-xp /usr/lib/libcapi-system-system-settings.so.0.0.2
b5b9f000 b5ba3000 r-xp /usr/lib/libcapi-appfw-application.so.0.3.2.5
b5bb0000 b5bb2000 r-xp /usr/lib/libXau.so.6.0.0
b5bbb000 b5bc2000 r-xp /lib/libcrypt-2.13.so
b5bf2000 b5bf4000 r-xp /usr/lib/libiri.so
b5bfc000 b5da4000 r-xp /usr/lib/libcrypto.so.1.0.0
b5dbd000 b5e0a000 r-xp /usr/lib/libssl.so.1.0.0
b5e17000 b5e45000 r-xp /usr/lib/libidn.so.11.5.44
b5e4d000 b5e56000 r-xp /usr/lib/libcares.so.2.1.0
b5e5f000 b5e72000 r-xp /usr/lib/libxcb.so.1.1.0
b5e7b000 b5e7d000 r-xp /usr/lib/journal/libjournal.so.0.1.0
b5e86000 b5e88000 r-xp /usr/lib/libSLP-db-util.so.0.1.0
b5e91000 b5f5d000 r-xp /usr/lib/libxml2.so.2.7.8
b5f6a000 b5f6c000 r-xp /usr/lib/libgmodule-2.0.so.0.3200.3
b5f74000 b5f79000 r-xp /usr/lib/libffi.so.5.0.10
b5f81000 b5f82000 r-xp /usr/lib/libgthread-2.0.so.0.3200.3
b5f8b000 b5f96000 r-xp /usr/lib/libgpg-error.so.0.15.0
b5f9e000 b5fa1000 r-xp /lib/libattr.so.1.1.0
b5fa9000 b603d000 r-xp /usr/lib/libstdc++.so.6.0.16
b6050000 b606c000 r-xp /usr/lib/libsecurity-server-commons.so.1.0.0
b6075000 b608d000 r-xp /usr/lib/libpng12.so.0.50.0
b6096000 b60ac000 r-xp /lib/libexpat.so.1.5.2
b60b6000 b60fa000 r-xp /usr/lib/libcurl.so.4.3.0
b6103000 b610d000 r-xp /usr/lib/libXext.so.6.4.0
b6116000 b6119000 r-xp /usr/lib/libXtst.so.6.1.0
b6122000 b6128000 r-xp /usr/lib/libXrender.so.1.3.0
b6131000 b6137000 r-xp /usr/lib/libXrandr.so.2.2.0
b613f000 b6140000 r-xp /usr/lib/libXinerama.so.1.0.0
b6149000 b6152000 r-xp /usr/lib/libXi.so.6.1.0
b615a000 b615d000 r-xp /usr/lib/libXfixes.so.3.1.0
b6165000 b6167000 r-xp /usr/lib/libXgesture.so.7.0.0
b616f000 b6171000 r-xp /usr/lib/libXcomposite.so.1.0.0
b617a000 b617c000 r-xp /usr/lib/libXdamage.so.1.1.0
b6184000 b618b000 r-xp /usr/lib/libXcursor.so.1.0.2
b6193000 b6196000 r-xp /usr/lib/libecore_input_evas.so.1.7.99
b619e000 b61a2000 r-xp /usr/lib/libecore_ipc.so.1.7.99
b61ab000 b61b0000 r-xp /usr/lib/libecore_fb.so.1.7.99
b61ba000 b629b000 r-xp /usr/lib/libX11.so.6.3.0
b62a6000 b62c9000 r-xp /usr/lib/libjpeg.so.8.0.2
b62e1000 b62f7000 r-xp /lib/libz.so.1.2.5
b62ff000 b6374000 r-xp /usr/lib/libsqlite3.so.0.8.6
b637e000 b6393000 r-xp /usr/lib/libpkgmgr_parser.so.0.1.0
b639c000 b63d0000 r-xp /usr/lib/libgobject-2.0.so.0.3200.3
b63d9000 b64ac000 r-xp /usr/lib/libgio-2.0.so.0.3200.3
b64b7000 b64c7000 r-xp /lib/libresolv-2.13.so
b64cb000 b6547000 r-xp /usr/lib/libgcrypt.so.20.0.3
b6553000 b656b000 r-xp /usr/lib/liblzma.so.5.0.3
b6574000 b6577000 r-xp /lib/libcap.so.2.21
b657f000 b65a5000 r-xp /usr/lib/libsecurity-server-client.so.1.0.1
b65ae000 b65af000 r-xp /usr/lib/libecore_imf_evas.so.1.7.99
b65b7000 b65bd000 r-xp /usr/lib/libecore_imf.so.1.7.99
b65c5000 b65dc000 r-xp /usr/lib/liblua-5.1.so
b65e6000 b65ed000 r-xp /usr/lib/libembryo.so.1.7.99
b65f5000 b65fb000 r-xp /lib/librt-2.13.so
b6604000 b665a000 r-xp /usr/lib/libpixman-1.so.0.28.2
b6667000 b66bd000 r-xp /usr/lib/libfreetype.so.6.11.3
b66c9000 b66f1000 r-xp /usr/lib/libfontconfig.so.1.8.0
b66f3000 b6730000 r-xp /usr/lib/libharfbuzz.so.0.940.0
b6739000 b674c000 r-xp /usr/lib/libfribidi.so.0.3.1
b6754000 b676e000 r-xp /usr/lib/libecore_con.so.1.7.99
b6777000 b6780000 r-xp /usr/lib/libedbus.so.1.7.99
b6788000 b67d8000 r-xp /usr/lib/libecore_x.so.1.7.99
b67db000 b67df000 r-xp /usr/lib/libvconf.so.0.2.45
b67e7000 b67f8000 r-xp /usr/lib/libecore_input.so.1.7.99
b6800000 b6805000 r-xp /usr/lib/libecore_file.so.1.7.99
b680d000 b682f000 r-xp /usr/lib/libecore_evas.so.1.7.99
b6838000 b6879000 r-xp /usr/lib/libeina.so.1.7.99
b6882000 b689b000 r-xp /usr/lib/libeet.so.1.7.99
b68ac000 b6915000 r-xp /lib/libm-2.13.so
b691e000 b6924000 r-xp /usr/lib/libcapi-base-common.so.0.1.8
b692d000 b6930000 r-xp /usr/lib/libproc-stat.so.0.2.86
b6938000 b695a000 r-xp /usr/lib/libpkgmgr-info.so.0.0.17
b6962000 b6967000 r-xp /usr/lib/libxdgmime.so.1.1.0
b696f000 b6999000 r-xp /usr/lib/libdbus-1.so.3.8.12
b69a2000 b69b9000 r-xp /usr/lib/libdbus-glib-1.so.2.2.2
b69c1000 b69cc000 r-xp /lib/libunwind.so.8.0.1
b69f9000 b6a35000 r-xp /usr/lib/libsystemd.so.0.4.0
b6a3e000 b6b59000 r-xp /lib/libc-2.13.so
b6b67000 b6b6f000 r-xp /lib/libgcc_s-4.6.so.1
b6b70000 b6b73000 r-xp /usr/lib/libsmack.so.1.0.0
b6b7b000 b6b81000 r-xp /usr/lib/libprivilege-control.so.0.0.2
b6b89000 b6c59000 r-xp /usr/lib/libglib-2.0.so.0.3200.3
b6c5a000 b6cb7000 r-xp /usr/lib/libedje.so.1.7.99
b6cc1000 b6cd8000 r-xp /usr/lib/libecore.so.1.7.99
b6cef000 b6dbe000 r-xp /usr/lib/libevas.so.1.7.99
b6de2000 b6f1c000 r-xp /usr/lib/libelementary.so.1.7.99
b6f32000 b6f46000 r-xp /lib/libpthread-2.13.so
b6f51000 b6f53000 r-xp /usr/lib/libdlog.so.0.0.0
b6f5b000 b6f5e000 r-xp /usr/lib/libbundle.so.0.1.22
b6f66000 b6f68000 r-xp /lib/libdl-2.13.so
b6f71000 b6f7d000 r-xp /usr/lib/libaul.so.0.1.0
b6f8f000 b6f94000 r-xp /usr/lib/libappcore-efl.so.1.1
b6f9d000 b6fa1000 r-xp /usr/lib/libsys-assert.so
b6faa000 b6fc7000 r-xp /lib/ld-2.13.so
b6fd0000 b6fd5000 r-xp /usr/bin/launchpad-loader
b87d1000 b8aa0000 rw-p [heap]
be9d2000 be9f3000 rwxp [stack]
End of Maps Information

Callstack Information (PID:32727)
Call Stack Count: 3
 0: evas_object_evas_get + 0x5 (0xb6d1cbde) [/usr/lib/libevas.so.1] + 0x2dbde
 1: elm_scroller_add + 0x16 (0xb6eba507) [/usr/lib/libelementary.so.1] + 0xd8507
 2: create_scroller + 0x10 (0xb58471e5) [/opt/usr/apps/org.example.uicomponents/bin/uicomponents] + 0x51e5
End of Call Stack

Package Information
Package Name: org.example.uicomponents
Package ID : org.example.uicomponents
Version: 1.0.0
Package Type: rpm
App Name: uicomponents
App ID: org.example.uicomponents
Type: capp
Categories: 

Latest Debug Message Information
--------- beginning of /dev/log_main
put object is wrong type
06-06 22:32:36.429+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.429+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.479+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.479+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.479+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.479+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.479+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.479+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.479+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.479+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.479+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.479+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.479+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.479+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.479+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.479+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.479+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.519+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.519+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.519+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.519+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.519+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.519+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.519+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.519+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.519+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.519+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.519+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.519+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.519+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.519+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.519+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.569+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.569+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.569+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.569+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.569+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.569+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.569+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.569+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.569+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.569+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.569+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.569+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.569+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.569+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.569+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.599+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.599+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.599+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.599+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.599+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.599+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.599+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.599+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.599+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.599+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.599+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.599+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.599+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.599+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.599+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.609+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.609+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.609+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.609+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.609+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.609+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.609+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.609+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.609+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.609+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.609+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.609+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.609+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.609+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.609+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.609+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.609+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.609+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.609+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.609+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.609+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:37.089+0900 E/EFL     (32474): evas_main<32474> evas_events.c:1009 evas_event_feed_mouse_down() ButtonEvent:down time=19732835 button=1 downs=1
06-06 22:32:37.339+0900 E/EFL     (32474): evas_main<32474> evas_events.c:1275 evas_event_feed_mouse_up() ButtonEvent:up time=19733076 button=1 downs=0
06-06 22:32:37.659+0900 E/EFL     (32474): evas_main<32474> evas_events.c:1009 evas_event_feed_mouse_down() ButtonEvent:down time=19733398 button=1 downs=1
06-06 22:32:38.339+0900 E/EFL     (32474): evas_main<32474> evas_events.c:1275 evas_event_feed_mouse_up() ButtonEvent:up time=19734084 button=1 downs=0
06-06 22:32:38.479+0900 E/EFL     (32474): evas_main<32474> evas_events.c:1009 evas_event_feed_mouse_down() ButtonEvent:down time=19734227 button=1 downs=1
06-06 22:32:39.249+0900 E/EFL     (32474): evas_main<32474> evas_events.c:1275 evas_event_feed_mouse_up() ButtonEvent:up time=19734995 button=1 downs=0
06-06 22:32:39.499+0900 E/EFL     (32474): evas_main<32474> evas_events.c:1009 evas_event_feed_mouse_down() ButtonEvent:down time=19735239 button=1 downs=1
06-06 22:32:40.819+0900 E/EFL     (32474): evas_main<32474> evas_events.c:1275 evas_event_feed_mouse_up() ButtonEvent:up time=19736558 button=1 downs=0
06-06 22:32:54.049+0900 I/watchface-viewer(12148): viewer-data-provider.cpp: AddPendingChanges(1053) > added [32] to pending list
06-06 22:32:54.049+0900 I/watchface-viewer(12148): viewer-data-provider.cpp: AddPendingChanges(1053) > added [34] to pending list
06-06 22:32:54.069+0900 I/RESOURCED(  906): heart-battery.c: heart_battery_add_capacity(1168) > [heart_battery_add_capacity,1168] 36 -> 37 1465219974 184
06-06 22:32:54.079+0900 I/RESOURCED(  906): heart-battery.c: heart_battery_calculate_prediction(1137) > [heart_battery_calculate_prediction,1137] TimeToFull: 37 121 162 127
06-06 22:32:54.079+0900 I/RESOURCED(  906): heart-battery.c: heart_battery_calculate_prediction(1137) > [heart_battery_calculate_prediction,1137] TimeToFull: 37 0 0 98
06-06 22:32:54.079+0900 I/RESOURCED(  906): heart-battery.c: heart_battery_calculate_prediction(1137) > [heart_battery_calculate_prediction,1137] TimeToFull: 37 110 131 116
06-06 22:32:54.079+0900 I/RESOURCED(  906): heart-battery.c: heart_battery_calculate_prediction(1137) > [heart_battery_calculate_prediction,1137] TimeToFull: 37 207 5 217
06-06 22:32:54.079+0900 I/RESOURCED(  906): heart-battery.c: heart_battery_calculate_prediction(1137) > [heart_battery_calculate_prediction,1137] TimeToFull: 37 135 38 142
06-06 22:33:00.269+0900 I/RESOURCED(  906): logging.c: logging_send_signal_to_data(1097) > [logging_send_signal_to_data,1097] send signal to logging data thread
06-06 22:33:00.269+0900 I/RESOURCED(  906): logging.c: logging_send_signal_to_update(1177) > [logging_send_signal_to_update,1177] send signal to logging update thread
06-06 22:33:00.269+0900 I/RESOURCED(  906): logging.c: logging_save_to_storage(969) > [logging_save_to_storage,969] storage cache is empty
06-06 22:33:00.839+0900 E/TIZEN_N_SYSTEM_SETTINGS( 1282): system_settings.c: system_settings_get_value_string(522) > Enter [system_settings_get_value_string]
06-06 22:33:00.839+0900 E/TIZEN_N_SYSTEM_SETTINGS( 1282): system_settings.c: system_settings_get_value(386) > Enter [system_settings_get_value]
06-06 22:33:00.839+0900 E/TIZEN_N_SYSTEM_SETTINGS( 1282): system_settings.c: system_settings_get_item(361) > Enter [system_settings_get_item], key=13
06-06 22:33:00.839+0900 E/TIZEN_N_SYSTEM_SETTINGS( 1282): system_settings.c: system_settings_get_item(374) > Enter [system_settings_get_item], index = 13, key = 13, type = 0
06-06 22:33:45.519+0900 E/PKGMGR_SERVER(  331): pkgmgr-server.c: main(2126) > package manager server start
06-06 22:33:45.609+0900 E/PKGMGR_SERVER(  331): pkgmgr-server.c: req_cb(686) > req_id=[org.example.uicomponents_522319720], req_type=[12], pkg_type=[rpm], pkgid=[org.example.uicomponents], args=[], cookie=[], backend_flag=[0]
06-06 22:33:45.609+0900 E/PKGMGR_SERVER(  336): pkgmgr-server.c: queue_job(1954) > KILL/CHECK APP, pkgid=[org.example.uicomponents]
06-06 22:33:45.619+0900 E/PKGMGR  (  329): pkgmgr.c: __check_sync_process(842) > file is can not remove[/tmp/org.example.uicomponents, -1]
06-06 22:33:45.699+0900 W/AUL_AMD (  905): amd_request.c: __request_handler(640) > __request_handler: 14
06-06 22:33:45.709+0900 W/AUL_AMD (  905): amd_request.c: __send_result_to_client(83) > __send_result_to_client, pid: 32474
06-06 22:33:45.709+0900 W/AUL_AMD (  905): amd_request.c: __request_handler(640) > __request_handler: 12
06-06 22:33:45.709+0900 W/AUL_AMD (  905): amd_request.c: __request_handler(640) > __request_handler: 5
06-06 22:33:45.709+0900 I/APP_CORE(32474): appcore-efl.c: __do_app(429) > [APP 32474] Event: TERMINATE State: RUNNING
06-06 22:33:45.709+0900 W/AUL_AMD (  905): amd_request.c: __request_handler(640) > __request_handler: 22
06-06 22:33:45.709+0900 W/AUL_AMD (  905): amd_request.c: __request_handler(884) > app status : 4
06-06 22:33:45.709+0900 W/AUL_AMD (  905): amd_launch.c: __reply_handler(909) > listen fd(27) , send fd(13), pid(32474), cmd(4)
06-06 22:33:45.719+0900 W/AUL_AMD (  905): amd_request.c: __request_handler(640) > __request_handler: 14
06-06 22:33:45.719+0900 W/AUL_AMD (  905): amd_request.c: __send_result_to_client(83) > __send_result_to_client, pid: 32474
06-06 22:33:45.779+0900 I/APP_CORE(32474): appcore-efl.c: __after_loop(1086) > Legacy lifecycle: 0
06-06 22:33:45.779+0900 I/CAPI_APPFW_APPLICATION(32474): app_main.c: _ui_app_appcore_terminate(585) > app_appcore_terminate
06-06 22:33:45.799+0900 W/AUL_AMD (  905): amd_key.c: _key_ungrab(254) > fail(-1) to ungrab key(XF86Stop)
06-06 22:33:45.799+0900 W/AUL_AMD (  905): amd_launch.c: __e17_status_handler(2194) > back key ungrab error
06-06 22:33:45.799+0900 W/AUL_AMD (  905): amd_key.c: _key_ungrab(254) > fail(-1) to ungrab key(XF86Stop)
06-06 22:33:45.799+0900 W/AUL_AMD (  905): amd_launch.c: __e17_status_handler(2194) > back key ungrab error
06-06 22:33:45.799+0900 I/efl-extension(32474): efl_extension_rotary.c: _object_deleted_cb(572) > In: data: 0xb803a1d0, obj: 0xb803a1d0
06-06 22:33:45.799+0900 I/efl-extension(32474): efl_extension_rotary.c: _object_deleted_cb(601) > done
06-06 22:33:45.809+0900 I/efl-extension(32474): efl_extension_rotary.c: eext_rotary_object_event_callback_del(235) > In
06-06 22:33:45.809+0900 I/efl-extension(32474): efl_extension_rotary.c: eext_rotary_object_event_callback_del(240) > callback del 0xb803a1d0, elm_genlist, func : 0xb5800079
06-06 22:33:45.809+0900 I/efl-extension(32474): efl_extension_rotary.c: eext_rotary_object_event_callback_del(273) > done
06-06 22:33:45.809+0900 I/efl-extension(32474): efl_extension_rotary.c: _object_deleted_cb(572) > In: data: 0xb80f1178, obj: 0xb80f1178
06-06 22:33:45.809+0900 I/efl-extension(32474): efl_extension_rotary.c: _object_deleted_cb(601) > done
06-06 22:33:45.809+0900 I/efl-extension(32474): efl_extension_rotary.c: eext_rotary_object_event_callback_del(235) > In
06-06 22:33:45.809+0900 I/efl-extension(32474): efl_extension_rotary.c: eext_rotary_object_event_callback_del(240) > callback del 0xb80f1178, elm_genlist, func : 0xb5800079
06-06 22:33:45.809+0900 I/efl-extension(32474): efl_extension_rotary.c: eext_rotary_object_event_callback_del(273) > done
06-06 22:33:45.819+0900 I/efl-extension(32474): efl_extension_rotary.c: _object_deleted_cb(572) > In: data: 0xb8160218, obj: 0xb8160218
06-06 22:33:45.819+0900 I/efl-extension(32474): efl_extension_rotary.c: _remove_ecore_handlers(554) > In
06-06 22:33:45.819+0900 I/efl-extension(32474): efl_extension_rotary.c: _remove_ecore_handlers(559) > removed _motion_handler
06-06 22:33:45.819+0900 I/efl-extension(32474): efl_extension_rotary.c: _remove_ecore_handlers(565) > removed _rotate_handler
06-06 22:33:45.819+0900 I/efl-extension(32474): efl_extension_rotary.c: _object_deleted_cb(601) > done
06-06 22:33:45.819+0900 W/AUL_AMD (  905): amd_request.c: __request_handler(640) > __request_handler: 14
06-06 22:33:45.829+0900 W/AUL_AMD (  905): amd_request.c: __send_result_to_client(83) > __send_result_to_client, pid: 32474
06-06 22:33:45.829+0900 I/efl-extension(32474): efl_extension_rotary.c: _activated_obj_del_cb(607) > _activated_obj_del_cb : 0xb8170720
06-06 22:33:45.829+0900 I/efl-extension(32474): efl_extension_rotary.c: eext_rotary_object_event_callback_del(235) > In
06-06 22:33:45.829+0900 I/efl-extension(32474): efl_extension_rotary.c: eext_rotary_object_event_callback_del(240) > callback del 0xb8160218, elm_genlist, func : 0xb5800079
06-06 22:33:45.829+0900 I/efl-extension(32474): efl_extension_rotary.c: eext_rotary_object_event_callback_del(273) > done
06-06 22:33:45.839+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:33:45.839+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:33:45.839+0900 F/EFL     (32474):     Supplied: 1234fedc - <UNKNOWN>
06-06 22:33:45.839+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:33:45.839+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:33:45.839+0900 F/EFL     (32474):     Supplied: 1234fedc - <UNKNOWN>
06-06 22:33:45.839+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:33:45.839+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:33:45.839+0900 F/EFL     (32474):     Supplied: 1234fedc - <UNKNOWN>
06-06 22:33:45.839+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:33:45.839+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:33:45.839+0900 F/EFL     (32474):     Supplied: 1234fedc - <UNKNOWN>
06-06 22:33:45.839+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:33:45.839+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:33:45.839+0900 F/EFL     (32474):     Supplied: 1234fedc - <UNKNOWN>
06-06 22:33:45.839+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:33:45.839+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:33:45.839+0900 F/EFL     (32474):     Supplied: 1234fedc - <UNKNOWN>
06-06 22:33:45.839+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:33:45.839+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:33:45.839+0900 F/EFL     (32474):     Supplied: 1234fedc - <UNKNOWN>
06-06 22:33:45.839+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:33:45.839+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:33:45.839+0900 F/EFL     (32474):     Supplied: 1234fedc - <UNKNOWN>
06-06 22:33:45.839+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:33:45.839+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:33:45.839+0900 F/EFL     (32474):     Supplied: 1234fedc - <UNKNOWN>
06-06 22:33:45.839+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:33:45.839+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:33:45.839+0900 F/EFL     (32474):     Supplied: 1234fedc - <UNKNOWN>
06-06 22:33:45.839+0900 E/EFL     (32474): elementary<32474> elm_widget.c:386 _elm_widget_sub_object_del_func() removing sub object 0xb7f37780 ((null)) from parent 0xb816d060 (elm_layout), but elm-parent is different (nil) ((null))!
06-06 22:33:45.839+0900 E/EFL     (32474): elementary<32474> elm_widget.c:675 _smart_del() failed to remove sub object 0xb7f37780 from 0xb816d060
06-06 22:33:45.839+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:33:45.839+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:33:45.839+0900 F/EFL     (32474):     Supplied: 1234fedc - <UNKNOWN>
06-06 22:33:45.839+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:33:45.839+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:33:45.839+0900 F/EFL     (32474):     Supplied: 1234fedc - <UNKNOWN>
06-06 22:33:45.839+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:33:45.839+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:33:45.839+0900 F/EFL     (32474):     Supplied: 1234fedc - <UNKNOWN>
06-06 22:33:45.839+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:33:45.839+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:33:45.839+0900 F/EFL     (32474):     Supplied: 1234fedc - <UNKNOWN>
06-06 22:33:45.839+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:33:45.839+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:33:45.839+0900 F/EFL     (32474):     Supplied: 1234fedc - <UNKNOWN>
06-06 22:33:45.889+0900 I/APP_CORE(32401): appcore-efl.c: __do_app(429) > [APP 32401] Event: RESUME State: PAUSED
06-06 22:33:45.889+0900 I/CAPI_APPFW_APPLICATION(32401): app_main.c: app_appcore_resume(223) > app_appcore_resume
06-06 22:33:45.889+0900 I/WIFI_EFL_SDK(32401): app_main.c: app_resume(4329) > [Enter]
06-06 22:33:45.889+0900 I/WIFI_EFL_SDK(32401): wifi_manager.c: wifi_manager_set_scan_mode(526) > Wi-Fi Scan mode 1.
06-06 22:33:45.929+0900 W/AUL_AMD (  905): amd_request.c: __request_handler(640) > __request_handler: 14
06-06 22:33:45.949+0900 W/AUL_AMD (  905): amd_request.c: __send_result_to_client(83) > __send_result_to_client, pid: 32474
06-06 22:33:46.059+0900 W/AUL_AMD (  905): amd_request.c: __request_handler(640) > __request_handler: 14
06-06 22:33:46.059+0900 W/AUL_AMD (  905): amd_request.c: __send_result_to_client(83) > __send_result_to_client, pid: -1
06-06 22:33:46.059+0900 E/PKGMGR_SERVER(  336): pkgmgr-server.c: queue_job(1976) > KILL/CHECK_APP end.
06-06 22:33:46.079+0900 E/PKGMGR_SERVER(  331): pkgmgr-server.c: sighandler(445) > child NORMAL exit [336]
06-06 22:33:46.209+0900 W/CRASH_MANAGER(  339): worker.c: worker_job(1199) > 11324747569631465220025
06-06 22:33:46.269+0900 I/AUL_AMD (  905): amd_main.c: __app_dead_handler(261) > __app_dead_handler, pid: 32474
06-06 22:33:47.299+0900 I/WIFI_EFL_SDK(32401): app_main.c: __wifi_manager_background_scan_cb(580) > [Enter]
06-06 22:33:47.299+0900 E/WIFI_EFL_SDK(32401): app_main.c: __wifi_manager_background_scan_cb(585) > 'app_obj->scan != NULL' failed.
06-06 22:33:47.719+0900 W/AUL_AMD (  905): amd_status.c: __app_terminate_timer_cb(166) > send SIGKILL: No such process
06-06 22:33:48.259+0900 E/PKGMGR_SERVER(  331): pkgmgr-server.c: exit_server(1338) > exit_server Start [backend_status=1, queue_status=1] 
06-06 22:33:48.259+0900 E/PKGMGR_SERVER(  331): pkgmgr-server.c: main(2180) > package manager server terminated.
06-06 22:33:56.029+0900 E/PKGMGR  (  485): pkgmgr.c: pkgmgr_client_reinstall(1823) > reinstall pkg start.
06-06 22:33:56.169+0900 E/PKGMGR_SERVER(  487): pkgmgr-server.c: main(2126) > package manager server start
06-06 22:33:56.229+0900 E/PKGMGR_SERVER(  487): pkgmgr-server.c: req_cb(686) > req_id=[org.example.uicomponents_532960150], req_type=[1], pkg_type=[rpm], pkgid=[org.example.uicomponents], args=[/usr/etc/package-manager/backend/rpm '-k' 'org.example.uicomponents_532960150' '-r' 'org.example.uicomponents'], cookie=[L9c5+uVwKWN3Ixj0DSJCXDodgSI=], backend_flag=[0]
06-06 22:33:56.229+0900 E/PKGMGR  (  487): pkgmgr-internal.c: _get_type_from_zip(733) > can not access to [org.example.uicomponents]
06-06 22:33:56.229+0900 E/PKGMGR_SERVER(  487): pkgmgr-server.c: __get_type_from_msg(364) > pkgtype is null for org.example.uicomponents 
06-06 22:33:56.239+0900 E/PKGMGR_SERVER(  493): pkgmgr-server.c: queue_job(1820) > INSTALL start, pkg path=[org.example.uicomponents]
06-06 22:33:56.239+0900 E/PKGMGR  (  485): pkgmgr.c: pkgmgr_client_reinstall(1935) > reinstall pkg finish, ret=[4850002]
06-06 22:33:56.369+0900 W/W_HOME  ( 1184): clock_event.c: _pkgmgr_event_cb(209) > Pkg:org.example.uicomponents is being updateded:0
06-06 22:33:56.369+0900 E/WMS     (  903): wms_event_handler.c: _wms_event_handler_cb_log_package(4459) > package [_________] callback : [UPDATE, STARTED]
06-06 22:33:56.379+0900 W/AUL_AMD (  905): amd_appinfo.c: __amd_pkgmgrinfo_status_cb(783) > __amd_pkgmgrinfo_start_handler
06-06 22:33:56.389+0900 E/WMS     (  903): wms_event_handler.c: _wms_event_handler_cb_log_package(4459) > package [_________] callback : [UPDATE, PROCESSING]
06-06 22:33:57.019+0900 E/PKGMGR_CERT(  493): pkgmgrinfo_certinfo.c: pkgmgrinfo_save_certinfo(426) > Transaction Begin
06-06 22:33:57.029+0900 E/PKGMGR_CERT(  493): pkgmgrinfo_certinfo.c: pkgmgrinfo_save_certinfo(495) > Id:Count = 1 99
06-06 22:33:57.029+0900 E/PKGMGR_CERT(  493): pkgmgrinfo_certinfo.c: pkgmgrinfo_save_certinfo(495) > Id:Count = 2 99
06-06 22:33:57.029+0900 E/PKGMGR_CERT(  493): pkgmgrinfo_certinfo.c: pkgmgrinfo_save_certinfo(495) > Id:Count = 26 3
06-06 22:33:57.029+0900 E/PKGMGR_CERT(  493): pkgmgrinfo_certinfo.c: pkgmgrinfo_save_certinfo(495) > Id:Count = 27 3
06-06 22:33:57.029+0900 E/PKGMGR_CERT(  493): pkgmgrinfo_certinfo.c: pkgmgrinfo_save_certinfo(495) > Id:Count = 28 3
06-06 22:33:57.029+0900 E/PKGMGR_CERT(  493): pkgmgrinfo_certinfo.c: pkgmgrinfo_save_certinfo(495) > Id:Count = 29 3
06-06 22:33:57.029+0900 E/WMS     (  903): wms_event_handler.c: _wms_event_handler_cb_log_package(4459) > package [_________] callback : [UPDATE, PROCESSING]
06-06 22:33:57.049+0900 E/PKGMGR_CERT(  493): pkgmgrinfo_certinfo.c: pkgmgrinfo_save_certinfo(570) > Transaction Commit and End
06-06 22:33:58.259+0900 E/PKGMGR_SERVER(  487): pkgmgr-server.c: exit_server(1338) > exit_server Start [backend_status=0, queue_status=1] 
06-06 22:33:58.799+0900 E/rpm-installer(  493): installer-util.c: _installer_util_get_configuration_value(331) > [signature]=[on]
06-06 22:34:00.169+0900 I/RESOURCED(  906): logging.c: logging_send_signal_to_data(1097) > [logging_send_signal_to_data,1097] send signal to logging data thread
06-06 22:34:00.169+0900 I/RESOURCED(  906): logging.c: logging_send_signal_to_update(1177) > [logging_send_signal_to_update,1177] send signal to logging update thread
06-06 22:34:00.259+0900 E/PKGMGR_SERVER(  487): pkgmgr-server.c: exit_server(1338) > exit_server Start [backend_status=0, queue_status=1] 
06-06 22:34:00.929+0900 E/TIZEN_N_SYSTEM_SETTINGS( 1282): system_settings.c: system_settings_get_value_string(522) > Enter [system_settings_get_value_string]
06-06 22:34:00.929+0900 E/TIZEN_N_SYSTEM_SETTINGS( 1282): system_settings.c: system_settings_get_value(386) > Enter [system_settings_get_value]
06-06 22:34:00.929+0900 E/TIZEN_N_SYSTEM_SETTINGS( 1282): system_settings.c: system_settings_get_item(361) > Enter [system_settings_get_item], key=13
06-06 22:34:00.929+0900 E/TIZEN_N_SYSTEM_SETTINGS( 1282): system_settings.c: system_settings_get_item(374) > Enter [system_settings_get_item], index = 13, key = 13, type = 0
06-06 22:34:01.889+0900 E/PKGMGR_SERVER(  487): pkgmgr-server.c: sighandler(445) > child NORMAL exit [493]
06-06 22:34:01.909+0900 E/WMS     (  903): wms_event_handler.c: _wms_event_handler_cb_log_package(4459) > package [_________] callback : [UPDATE, PROCESSING]
06-06 22:34:01.929+0900 W/W_HOME  ( 1184): clock_event.c: _pkgmgr_event_cb(238) > Pkg:org.example.uicomponents is updated, need to check validation
06-06 22:34:01.929+0900 W/W_HOME  ( 1184): clock_event.c: _pkgmgr_event_cb(242) > attacheck clock:com.samsung.watchface
06-06 22:34:01.949+0900 E/WMS     (  903): wms_event_handler.c: _wms_event_handler_cb_log_package(4459) > package [_________] callback : [UPDATE, COMPLETED]
06-06 22:34:01.949+0900 E/WMS     (  903): wms_event_handler.c: _wms_event_handler_cb_package_manager_event(6806) > package install complete
06-06 22:34:01.949+0900 E/WMS     (  903): wms_event_handler.c: _wms_event_handler_package_install_event(4687) > 
06-06 22:34:01.949+0900 E/WMS     (  903): wms_event_handler.c: _wms_event_handler_get_index_from_install_req_list(1750) > Found in install_req_list?[0], index[-1]
06-06 22:34:02.069+0900 W/APPS    ( 1184): pkgmgr.c: _update_app(732) >  old order:[26]
06-06 22:34:02.139+0900 E/PKGMGR_INFO(  899): pkgmgrinfo_appinfo.c: pkgmgrinfo_appinfo_get_list(848) > (component == PMINFO_SVC_APP) PMINFO_SVC_APP is done
06-06 22:34:02.139+0900 E/EFL     ( 1184): elementary<1184> elm_layout.c:1020 _elm_layout_smart_content_set() could not swallow 0xb7546e88 into part 'elm.swallow.event.0'
06-06 22:34:02.139+0900 E/APPS    ( 1184): AppsViewNecklace.cpp: onShow(569) >  AppsItemList[28]
06-06 22:34:02.179+0900 E/Vi::Animations( 1184): result Vi::Animations::_AnimationManager::addAnimation(Vi::Animations::Visual&, const string*, Vi::Animations::Animation&)(288) > [E_OBJ_ALREADY_EXIST] Animation with keyName already exists. key name = hide
06-06 22:34:02.179+0900 I/Vi::Animations( 1184): result Vi::Animations::_VisualImpl::addAnimation(const string*, Vi::Animations::Animation&)(6999) > [E_OBJ_ALREADY_EXIST] Propagating.
06-06 22:34:02.179+0900 E/Vi::Animations( 1184): result Vi::Animations::_AnimationManager::addAnimation(Vi::Animations::Visual&, const string*, Vi::Animations::Animation&)(288) > [E_OBJ_ALREADY_EXIST] Animation with keyName already exists. key name = hide
06-06 22:34:02.179+0900 I/Vi::Animations( 1184): result Vi::Animations::_VisualImpl::addAnimation(const string*, Vi::Animations::Animation&)(6999) > [E_OBJ_ALREADY_EXIST] Propagating.
06-06 22:34:02.189+0900 E/EFL     ( 1184): elementary<1184> elm_layout.c:1020 _elm_layout_smart_content_set() could not swallow 0xb7546e88 into part 'elm.swallow.event.0'
06-06 22:34:02.189+0900 E/APPS    ( 1184): AppsViewNecklace.cpp: onShow(569) >  AppsItemList[29]
06-06 22:34:02.259+0900 E/PKGMGR_SERVER(  487): pkgmgr-server.c: exit_server(1338) > exit_server Start [backend_status=1, queue_status=1] 
06-06 22:34:02.259+0900 E/PKGMGR_SERVER(  487): pkgmgr-server.c: main(2180) > package manager server terminated.
06-06 22:34:02.699+0900 W/APPS    ( 1184): pkgmgr.c: _update_app_cb(711) >  Update apps order
06-06 22:34:02.699+0900 W/APPS    ( 1184): AppsViewNecklace.cpp: onTouchEventCancel(4335) >  touch cancel
06-06 22:34:03.739+0900 I/WIFI_EFL_SDK(32401): app_main.c: __wifi_manager_background_scan_cb(580) > [Enter]
06-06 22:34:03.739+0900 E/WIFI_EFL_SDK(32401): app_main.c: __wifi_manager_background_scan_cb(585) > 'app_obj->scan != NULL' failed.
06-06 22:34:08.669+0900 W/AUL_AMD (  905): amd_request.c: __request_handler(640) > __request_handler: 0
06-06 22:34:08.689+0900 I/AUL_AMD (  905): menu_db_util.h: _get_app_info_from_db_by_apppath(239) > path : /usr/bin/launch_app, ret : 0
06-06 22:34:08.699+0900 I/AUL_AMD (  905): menu_db_util.h: _get_app_info_from_db_by_apppath(239) > path : /bin/bash, ret : 0
06-06 22:34:08.699+0900 E/AUL_AMD (  905): amd_launch.c: _start_app(1649) > no caller appid info, ret: -1
06-06 22:34:08.699+0900 W/AUL_AMD (  905): amd_launch.c: _start_app(1659) > caller pid : 552
06-06 22:34:08.709+0900 E/RESOURCED(  906): block.c: block_prelaunch_state(134) > [block_prelaunch_state,134] insert data org.example.uicomponents, table num : 3
06-06 22:34:08.709+0900 E/RESOURCED(  906): heart-memory.c: heart_memory_get_data(601) > [heart_memory_get_data,601] hashtable heart_memory_app_list is NULL
06-06 22:34:08.709+0900 W/AUL_AMD (  905): amd_launch.c: _start_app(2026) > pad pid(-5)
06-06 22:34:08.709+0900 W/AUL_PAD ( 1730): launchpad.c: __launchpad_main_loop(512) > Launch on type-based process-pool
06-06 22:34:08.709+0900 W/AUL_PAD ( 1730): launchpad.c: __send_result_to_caller(265) > Check app launching
06-06 22:34:08.739+0900 I/efl-extension(32727): efl_extension.c: eext_mod_init(40) > Init
06-06 22:34:08.749+0900 I/UXT     (32727): Uxt_ObjectManager.cpp: OnInitialized(731) > Initialized.
06-06 22:34:08.749+0900 I/CAPI_APPFW_APPLICATION(32727): app_main.c: ui_app_main(704) > app_efl_main
06-06 22:34:08.749+0900 I/CAPI_APPFW_APPLICATION(32727): app_main.c: _ui_app_appcore_create(563) > app_appcore_create
06-06 22:34:08.829+0900 E/RESOURCED(  906): proc-main.c: proc_add_program_list(233) > [proc_add_program_list,233] not found ppi : org.example.uicomponents
06-06 22:34:08.869+0900 I/efl-extension(32727): efl_extension_circle_surface.c: eext_circle_surface_conformant_add(1245) > Put the surface[0xb88fa5c0]'s widget[0xb890ad58] to elm_conformant widget[0xb88d3b78]
06-06 22:34:08.869+0900 I/efl-extension(32727): efl_extension_circle_surface.c: _eext_circle_surface_resize_cb(642) > surface 0xb88fa5c0 = w: 0 h: 0  obj 0xb890ad58 w: 1 h: 1
06-06 22:34:08.889+0900 I/efl-extension(32727): efl_extension_rotary.c: eext_rotary_object_event_callback_add(147) > In
06-06 22:34:08.889+0900 I/efl-extension(32727): efl_extension_rotary.c: eext_rotary_event_handler_add(77) > init_count: 0
06-06 22:34:08.889+0900 I/efl-extension(32727): efl_extension_rotary.c: _init_Xi2_system(314) > In
06-06 22:34:08.889+0900 I/efl-extension(32727): efl_extension_rotary.c: _init_Xi2_system(375) > Done
06-06 22:34:08.889+0900 I/efl-extension(32727): efl_extension_rotary.c: eext_rotary_object_event_activated_set(283) > eext_rotary_object_event_activated_set : 0xb89229d8, elm_image, _activated_obj : 0x0, activated : 1
06-06 22:34:08.929+0900 E/E17     (  585): e_manager.c: _e_manager_cb_window_show_request(1128) > Show request(0x04c00002)
06-06 22:34:08.929+0900 I/APP_CORE(32727): appcore-efl.c: __do_app(429) > [APP 32727] Event: RESET State: CREATED
06-06 22:34:08.929+0900 I/CAPI_APPFW_APPLICATION(32727): app_main.c: _ui_app_appcore_reset(645) > app_appcore_reset
06-06 22:34:08.939+0900 I/APP_CORE(32727): appcore-efl.c: __do_app(472) > Legacy lifecycle: 0
06-06 22:34:08.939+0900 I/APP_CORE(32727): appcore-efl.c: __do_app(474) > [APP 32727] Initial Launching, call the resume_cb
06-06 22:34:08.939+0900 I/CAPI_APPFW_APPLICATION(32727): app_main.c: _ui_app_appcore_resume(628) > app_appcore_resume
06-06 22:34:08.979+0900 W/APP_CORE(32727): appcore-efl.c: __show_cb(787) > [EVENT_TEST][EVENT] GET SHOW EVENT!!!. WIN:4c00002
06-06 22:34:08.979+0900 I/efl-extension(32727): efl_extension_circle_surface.c: _eext_circle_surface_resize_cb(642) > surface 0xb88fa5c0 = w: 0 h: 0  obj 0xb890ad58 w: 360 h: 360
06-06 22:34:08.979+0900 I/efl-extension(32727): efl_extension_circle_surface.c: _eext_circle_surface_resize_cb(666) > Surface will be initialized! surface->w= 360 surface->h = 360
06-06 22:34:09.039+0900 I/APP_CORE(32401): appcore-efl.c: __do_app(429) > [APP 32401] Event: PAUSE State: RUNNING
06-06 22:34:09.039+0900 I/CAPI_APPFW_APPLICATION(32401): app_main.c: app_appcore_pause(202) > app_appcore_pause
06-06 22:34:09.039+0900 I/WIFI_EFL_SDK(32401): app_main.c: app_pause(4312) > [Enter]
06-06 22:34:09.039+0900 I/WIFI_EFL_SDK(32401): wifi_manager.c: wifi_manager_set_scan_mode(526) > Wi-Fi Scan mode 0.
06-06 22:34:09.089+0900 W/AUL_AMD (  905): amd_key.c: _key_ungrab(254) > fail(-1) to ungrab key(XF86Stop)
06-06 22:34:09.089+0900 W/AUL_AMD (  905): amd_launch.c: __e17_status_handler(2194) > back key ungrab error
06-06 22:34:09.179+0900 I/APP_CORE(32727): appcore-efl.c: __do_app(429) > [APP 32727] Event: RESUME State: RUNNING
06-06 22:34:09.889+0900 W/AUL_AMD (  905): amd_request.c: __request_handler(640) > __request_handler: 14
06-06 22:34:09.909+0900 W/AUL_AMD (  905): amd_request.c: __send_result_to_client(83) > __send_result_to_client, pid: 32727
06-06 22:34:09.909+0900 W/AUL_AMD (  905): amd_request.c: __request_handler(640) > __request_handler: 12
06-06 22:34:10.139+0900 I/AUL_PAD (  563): launchpad_loader.c: main(600) > [candidate] elm init, returned: 1
06-06 22:34:11.649+0900 E/EFL     (32727): elementary<32727> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b890c0d8), block(1)
06-06 22:34:11.649+0900 E/EFL     (32727): elementary<32727> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b890c0d8), ev->cur.canvas.x(178) ev->cur.canvas.y(318)
06-06 22:34:11.649+0900 E/EFL     (32727): elementary<32727> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b890c0d8), hold(0) freeze(0)
06-06 22:34:11.669+0900 E/EFL     (32727): elementary<32727> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b890c0d8), block(1)
06-06 22:34:11.669+0900 E/EFL     (32727): elementary<32727> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b890c0d8), ev->cur.canvas.x(179) ev->cur.canvas.y(318)
06-06 22:34:11.669+0900 E/EFL     (32727): elementary<32727> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b890c0d8), hold(0) freeze(0)
06-06 22:34:11.669+0900 E/EFL     (32727): evas_main<32727> evas_events.c:1009 evas_event_feed_mouse_down() ButtonEvent:down time=19827403 button=1 downs=1
06-06 22:34:11.669+0900 E/EFL     (32727): elementary<32727> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b890c0d8), block(1)
06-06 22:34:11.669+0900 E/EFL     (32727): elementary<32727> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b890c0d8), ev->cur.canvas.x(181) ev->cur.canvas.y(318)
06-06 22:34:11.669+0900 E/EFL     (32727): elementary<32727> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b890c0d8), hold(0) freeze(0)
06-06 22:34:11.679+0900 E/EFL     (32727): elementary<32727> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b890c0d8), block(1)
06-06 22:34:11.679+0900 E/EFL     (32727): elementary<32727> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b890c0d8), ev->cur.canvas.x(182) ev->cur.canvas.y(317)
06-06 22:34:11.679+0900 E/EFL     (32727): elementary<32727> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b890c0d8), hold(0) freeze(0)
06-06 22:34:11.689+0900 E/EFL     (32727): elementary<32727> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b890c0d8), block(1)
06-06 22:34:11.689+0900 E/EFL     (32727): elementary<32727> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b890c0d8), ev->cur.canvas.x(183) ev->cur.canvas.y(317)
06-06 22:34:11.689+0900 E/EFL     (32727): elementary<32727> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b890c0d8), hold(0) freeze(0)
06-06 22:34:11.709+0900 E/EFL     (32727): elementary<32727> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b890c0d8), block(1)
06-06 22:34:11.709+0900 E/EFL     (32727): elementary<32727> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b890c0d8), ev->cur.canvas.x(184) ev->cur.canvas.y(317)
06-06 22:34:11.709+0900 E/EFL     (32727): elementary<32727> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b890c0d8), block(1)
06-06 22:34:11.709+0900 E/EFL     (32727): elementary<32727> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b890c0d8), ev->cur.canvas.x(185) ev->cur.canvas.y(317)
06-06 22:34:11.709+0900 E/EFL     (32727): elementary<32727> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b890c0d8), hold(0) freeze(0)
06-06 22:34:11.709+0900 E/EFL     (32727): elementary<32727> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b890c0d8), hold(0) freeze(0)
06-06 22:34:11.729+0900 E/EFL     (32727): elementary<32727> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b890c0d8), block(1)
06-06 22:34:11.729+0900 E/EFL     (32727): elementary<32727> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b890c0d8), ev->cur.canvas.x(185) ev->cur.canvas.y(319)
06-06 22:34:11.729+0900 E/EFL     (32727): elementary<32727> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b890c0d8), hold(0) freeze(0)
06-06 22:34:11.749+0900 E/EFL     (32727): elementary<32727> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b890c0d8), block(1)
06-06 22:34:11.749+0900 E/EFL     (32727): elementary<32727> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b890c0d8), ev->cur.canvas.x(186) ev->cur.canvas.y(315)
06-06 22:34:11.749+0900 E/EFL     (32727): elementary<32727> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b890c0d8), hold(0) freeze(0)
06-06 22:34:11.759+0900 E/EFL     (32727): evas_main<32727> evas_events.c:1275 evas_event_feed_mouse_up() ButtonEvent:up time=19827499 button=1 downs=0
06-06 22:34:12.079+0900 I/efl-extension(32727): efl_extension_rotary.c: eext_rotary_object_event_callback_add(147) > In
06-06 22:34:12.079+0900 I/efl-extension(32727): efl_extension_rotary.c: eext_rotary_object_event_activated_set(283) > eext_rotary_object_event_activated_set : 0xb8a3e810, elm_image, _activated_obj : 0xb89229d8, activated : 1
06-06 22:34:12.079+0900 I/efl-extension(32727): efl_extension_rotary.c: eext_rotary_object_event_activated_set(291) > Activation delete!!!!
06-06 22:34:13.029+0900 E/EFL     (32727): elementary<32727> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b89e7e60), block(1)
06-06 22:34:13.029+0900 E/EFL     (32727): elementary<32727> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b89e7e60), ev->cur.canvas.x(185) ev->cur.canvas.y(315)
06-06 22:34:13.029+0900 E/EFL     (32727): elementary<32727> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b89e7e60), hold(0) freeze(0)
06-06 22:34:13.029+0900 E/EFL     (32727): evas_main<32727> evas_events.c:1009 evas_event_feed_mouse_down() ButtonEvent:down time=19828773 button=1 downs=1
06-06 22:34:13.029+0900 E/EFL     (32727): elementary<32727> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b89e7e60), block(1)
06-06 22:34:13.029+0900 E/EFL     (32727): elementary<32727> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b89e7e60), ev->cur.canvas.x(185) ev->cur.canvas.y(314)
06-06 22:34:13.029+0900 E/EFL     (32727): elementary<32727> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b89e7e60), hold(0) freeze(0)
06-06 22:34:13.069+0900 E/EFL     (32727): elementary<32727> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b89e7e60), block(1)
06-06 22:34:13.069+0900 E/EFL     (32727): elementary<32727> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b89e7e60), ev->cur.canvas.x(186) ev->cur.canvas.y(314)
06-06 22:34:13.069+0900 E/EFL     (32727): elementary<32727> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b89e7e60), hold(0) freeze(0)
06-06 22:34:13.069+0900 E/EFL     (32727): elementary<32727> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b89e7e60), block(1)
06-06 22:34:13.069+0900 E/EFL     (32727): elementary<32727> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b89e7e60), ev->cur.canvas.x(186) ev->cur.canvas.y(315)
06-06 22:34:13.069+0900 E/EFL     (32727): elementary<32727> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b89e7e60), hold(0) freeze(0)
06-06 22:34:13.089+0900 E/EFL     (32727): elementary<32727> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b89e7e60), block(1)
06-06 22:34:13.089+0900 E/EFL     (32727): elementary<32727> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b89e7e60), ev->cur.canvas.x(186) ev->cur.canvas.y(321)
06-06 22:34:13.089+0900 E/EFL     (32727): elementary<32727> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b89e7e60), hold(0) freeze(0)
06-06 22:34:13.099+0900 E/EFL     (32727): elementary<32727> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b89e7e60), block(1)
06-06 22:34:13.099+0900 E/EFL     (32727): elementary<32727> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b89e7e60), ev->cur.canvas.x(184) ev->cur.canvas.y(327)
06-06 22:34:13.099+0900 E/EFL     (32727): elementary<32727> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b89e7e60), hold(0) freeze(0)
06-06 22:34:13.109+0900 E/EFL     (32727): elementary<32727> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b89e7e60), block(1)
06-06 22:34:13.109+0900 E/EFL     (32727): elementary<32727> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b89e7e60), ev->cur.canvas.x(184) ev->cur.canvas.y(321)
06-06 22:34:13.109+0900 E/EFL     (32727): elementary<32727> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b89e7e60), hold(0) freeze(0)
06-06 22:34:13.109+0900 E/EFL     (32727): evas_main<32727> evas_events.c:1275 evas_event_feed_mouse_up() ButtonEvent:up time=19828856 button=1 downs=0
06-06 22:34:13.449+0900 I/efl-extension(32727): efl_extension_rotary.c: eext_rotary_object_event_callback_add(147) > In
06-06 22:34:13.449+0900 I/efl-extension(32727): efl_extension_rotary.c: eext_rotary_object_event_activated_set(283) > eext_rotary_object_event_activated_set : 0xb8a67890, elm_image, _activated_obj : 0xb8a3e810, activated : 1
06-06 22:34:13.449+0900 I/efl-extension(32727): efl_extension_rotary.c: eext_rotary_object_event_activated_set(291) > Activation delete!!!!
06-06 22:34:14.069+0900 I/APP_CORE(32401): appcore-efl.c: __do_app(429) > [APP 32401] Event: MEM_FLUSH State: PAUSED
06-06 22:34:14.079+0900 E/EFL     (32727): elementary<32727> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8a57388), block(1)
06-06 22:34:14.079+0900 E/EFL     (32727): elementary<32727> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8a57388), ev->cur.canvas.x(189) ev->cur.canvas.y(324)
06-06 22:34:14.079+0900 E/EFL     (32727): elementary<32727> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8a57388), hold(0) freeze(0)
06-06 22:34:14.079+0900 E/EFL     (32727): evas_main<32727> evas_events.c:1009 evas_event_feed_mouse_down() ButtonEvent:down time=19829827 button=1 downs=1
06-06 22:34:14.089+0900 E/EFL     (32727): elementary<32727> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8a57388), block(1)
06-06 22:34:14.089+0900 E/EFL     (32727): elementary<32727> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8a57388), ev->cur.canvas.x(187) ev->cur.canvas.y(319)
06-06 22:34:14.089+0900 E/EFL     (32727): elementary<32727> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8a57388), hold(0) freeze(0)
06-06 22:34:14.149+0900 E/EFL     (32727): elementary<32727> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8a57388), block(1)
06-06 22:34:14.149+0900 E/EFL     (32727): elementary<32727> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8a57388), ev->cur.canvas.x(187) ev->cur.canvas.y(318)
06-06 22:34:14.149+0900 E/EFL     (32727): elementary<32727> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8a57388), hold(0) freeze(0)
06-06 22:34:14.149+0900 E/EFL     (32727): elementary<32727> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8a57388), block(1)
06-06 22:34:14.149+0900 E/EFL     (32727): elementary<32727> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8a57388), ev->cur.canvas.x(190) ev->cur.canvas.y(319)
06-06 22:34:14.149+0900 E/EFL     (32727): elementary<32727> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8a57388), hold(0) freeze(0)
06-06 22:34:14.179+0900 E/EFL     (32727): elementary<32727> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8a57388), block(1)
06-06 22:34:14.179+0900 E/EFL     (32727): elementary<32727> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8a57388), ev->cur.canvas.x(191) ev->cur.canvas.y(316)
06-06 22:34:14.179+0900 E/EFL     (32727): elementary<32727> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8a57388), hold(0) freeze(0)
06-06 22:34:14.179+0900 E/EFL     (32727): elementary<32727> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8a57388), block(1)
06-06 22:34:14.179+0900 E/EFL     (32727): elementary<32727> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8a57388), ev->cur.canvas.x(196) ev->cur.canvas.y(305)
06-06 22:34:14.179+0900 E/EFL     (32727): elementary<32727> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8a57388), hold(0) freeze(0)
06-06 22:34:14.219+0900 E/EFL     (32727): evas_main<32727> evas_events.c:1275 evas_event_feed_mouse_up() ButtonEvent:up time=19829927 button=1 downs=0
06-06 22:34:14.649+0900 W/CRASH_MANAGER(  339): worker.c: worker_job(1199) > 1132727756963146522005
