S/W Version Information
Model: SM-R735S
Tizen-Version: 2.3.1.2
Build-Number: R735SKSU1AOKE
Build-Date: 2015.11.25 20:46:58

Crash Information
Process Name: uicomponents
PID: 2724
Date: 2016-06-06 23:01:34+0900
Executable File Path: /opt/usr/apps/org.example.uicomponents/bin/uicomponents
Signal: 11
      (SIGSEGV)
      si_code: -6
      signal sent by tkill (sent by pid 2724, uid 5000)

Register Information
r0   = 0x000000e8, r1   = 0xb84b7310
r2   = 0xb5855ff9, r3   = 0x00000000
r4   = 0x000000e8, r5   = 0xb8462428
r6   = 0xb5855ff9, r7   = 0xb848c1b8
r8   = 0x000000e8, r9   = 0x00000001
r10  = 0xb84807f0, fp   = 0xb5855ff9
ip   = 0xb6cc2d80, sp   = 0xbea79218
lr   = 0xb6caa6d5, pc   = 0xb685fc0a
cpsr = 0x20000030

Memory Information
MemTotal:   407572 KB
MemFree:     15596 KB
Buffers:     12232 KB
Cached:      88596 KB
VmPeak:      78936 KB
VmSize:      76772 KB
VmLck:           0 KB
VmPin:           0 KB
VmHWM:       20324 KB
VmRSS:       20324 KB
VmData:      16764 KB
VmStk:         136 KB
VmExe:          20 KB
VmLib:       24848 KB
VmPTE:          56 KB
VmSwap:          0 KB

Threads Information
Threads: 2
PID = 2724 TID = 2724
2724 2764 

Maps Information
b2745000 b27cc000 rw-s anon_inode:dmabuf
b28fe000 b290e000 r-xp /usr/lib/scim-1.0/1.4.0/IMEngine/socket.so
b2916000 b291a000 r-xp /usr/lib/libogg.so.0.7.1
b2922000 b2944000 r-xp /usr/lib/libvorbis.so.0.4.3
b294c000 b2954000 r-xp /usr/lib/libmdm-common.so.1.0.89
b2955000 b2998000 r-xp /usr/lib/libsndfile.so.1.0.25
b29a5000 b29ed000 r-xp /usr/lib/pulseaudio/libpulsecommon-4.0.so
b29ee000 b29f3000 r-xp /usr/lib/libjson.so.0.0.1
b29fb000 b2a2c000 r-xp /usr/lib/libmdm.so.1.1.85
b2a34000 b2a3c000 r-xp /usr/lib/lib_DNSe_NRSS_ver225.so
b2a4b000 b2a5b000 r-xp /usr/lib/lib_SamsungRec_TizenV04014.so
b2a7c000 b2a89000 r-xp /usr/lib/libail.so.0.1.0
b2a92000 b2a95000 r-xp /usr/lib/libsyspopup_caller.so.0.1.0
b2a9d000 b2ad5000 r-xp /usr/lib/libpulse.so.0.16.2
b2ad6000 b2b37000 r-xp /usr/lib/libasound.so.2.0.0
b2b41000 b2b44000 r-xp /usr/lib/libpulse-simple.so.0.0.4
b2b4c000 b2b51000 r-xp /usr/lib/libascenario-0.2.so.0.0.0
b2b59000 b2b72000 r-xp /usr/lib/libavsysaudio.so.0.0.1
b2b7b000 b2b7f000 r-xp /usr/lib/libmmfsoundcommon.so.0.0.0
b2b88000 b2b92000 r-xp /usr/lib/libaudio-session-mgr.so.0.0.0
b2b9e000 b2bb4000 r-xp /usr/lib/libmmfsound.so.0.1.0
b2bc6000 b2bc7000 r-xp /usr/lib/edje/modules/feedback/linux-gnueabi-armv7l-1.0.0/module.so
b2c4f000 b2cd6000 rw-s anon_inode:dmabuf
b2d68000 b2def000 rw-s anon_inode:dmabuf
b2e6e000 b2ef5000 rw-s anon_inode:dmabuf
b3104000 b3109000 r-xp /usr/lib/libmmfsession.so.0.0.0
b3111000 b3118000 r-xp /usr/lib/libmmfcommon.so.0.0.0
b3120000 b312a000 r-xp /usr/lib/libcapi-media-sound-manager.so.0.1.48
b3132000 b3134000 r-xp /usr/lib/libcapi-media-wav-player.so.0.1.10
b313c000 b313d000 r-xp /usr/lib/libmmfkeysound.so.0.0.0
b3145000 b314c000 r-xp /usr/lib/libfeedback.so.0.1.4
b3157000 b315c000 r-xp /usr/lib/scim-1.0/1.4.0/Config/socket.so
b31fa000 b39f9000 rwxp [stack:2764]
b39f9000 b3a10000 r-xp /usr/lib/edje/modules/elm/linux-gnueabi-armv7l-1.0.0/module.so
b3a1d000 b3a1f000 r-xp /usr/lib/libgenlock.so
b3a28000 b3a29000 r-xp /usr/lib/evas/modules/loaders/eet/linux-gnueabi-armv7l-1.7.99/module.so
b3a31000 b3a33000 r-xp /usr/lib/evas/modules/loaders/png/linux-gnueabi-armv7l-1.7.99/module.so
b3a3d000 b3a42000 r-xp /usr/lib/bufmgr/libtbm_msm.so.0.0.0
b3a4a000 b3a55000 r-xp /usr/lib/evas/modules/engines/software_generic/linux-gnueabi-armv7l-1.7.99/module.so
b3d7d000 b3e47000 r-xp /usr/lib/libCOREGL.so.4.0
b3e58000 b3e5d000 r-xp /usr/lib/libcapi-media-tool.so.0.1.5
b3e65000 b3e86000 r-xp /usr/lib/libexif.so.12.3.3
b3e99000 b3e9e000 r-xp /usr/lib/libmmutil_imgp.so.0.0.0
b3ea6000 b3eab000 r-xp /usr/lib/libmmutil_jpeg.so.0.0.0
b543a000 b543c000 r-xp /usr/lib/libdri2.so.0.0.0
b5444000 b544c000 r-xp /usr/lib/libdrm.so.2.4.0
b5454000 b5457000 r-xp /usr/lib/libcapi-media-image-util.so.0.3.5
b545f000 b5543000 r-xp /usr/lib/libicuuc.so.51.1
b5558000 b5695000 r-xp /usr/lib/libicui18n.so.51.1
b56a5000 b56aa000 r-xp /usr/lib/libcapi-system-info.so.0.2.0
b56b2000 b56b8000 r-xp /usr/lib/libxcb-render.so.0.0.0
b56c0000 b56c1000 r-xp /usr/lib/libxcb-shm.so.0.0.0
b56ca000 b56cd000 r-xp /usr/lib/libEGL.so.1.4
b56d5000 b56e3000 r-xp /usr/lib/libGLESv2.so.2.0
b56ec000 b56f3000 r-xp /usr/lib/libtbm.so.1.0.0
b56fb000 b571c000 r-xp /usr/lib/libui-extension.so.0.1.0
b5725000 b5737000 r-xp /usr/lib/libtts.so
b573f000 b57f7000 r-xp /usr/lib/libcairo.so.2.11200.14
b5802000 b5814000 r-xp /usr/lib/libefl-assist.so.0.1.0
b581c000 b583d000 r-xp /usr/lib/libefl-extension.so.0.1.0
b5845000 b5858000 r-xp /opt/usr/apps/org.example.uicomponents/bin/uicomponents
b5a1f000 b5a29000 r-xp /lib/libnss_files-2.13.so
b5a32000 b5b01000 r-xp /usr/lib/libscim-1.0.so.8.2.3
b5b17000 b5b3b000 r-xp /usr/lib/ecore/immodules/libisf-imf-module.so
b5b44000 b5b4a000 r-xp /usr/lib/libappsvc.so.0.1.0
b5b52000 b5b54000 r-xp /usr/lib/libcapi-appfw-app-common.so.0.3.2.5
b5b5d000 b5b62000 r-xp /usr/lib/libcapi-appfw-app-control.so.0.3.2.5
b5b6d000 b5b78000 r-xp /usr/lib/evas/modules/engines/software_x11/linux-gnueabi-armv7l-1.7.99/module.so
b5b80000 b5b82000 r-xp /usr/lib/libiniparser.so.0
b5b8b000 b5b90000 r-xp /usr/lib/libappcore-common.so.1.1
b5b99000 b5ba1000 r-xp /usr/lib/libcapi-system-system-settings.so.0.0.2
b5ba2000 b5ba6000 r-xp /usr/lib/libcapi-appfw-application.so.0.3.2.5
b5bb3000 b5bb5000 r-xp /usr/lib/libXau.so.6.0.0
b5bbe000 b5bc5000 r-xp /lib/libcrypt-2.13.so
b5bf5000 b5bf7000 r-xp /usr/lib/libiri.so
b5bff000 b5da7000 r-xp /usr/lib/libcrypto.so.1.0.0
b5dc0000 b5e0d000 r-xp /usr/lib/libssl.so.1.0.0
b5e1a000 b5e48000 r-xp /usr/lib/libidn.so.11.5.44
b5e50000 b5e59000 r-xp /usr/lib/libcares.so.2.1.0
b5e62000 b5e75000 r-xp /usr/lib/libxcb.so.1.1.0
b5e7e000 b5e80000 r-xp /usr/lib/journal/libjournal.so.0.1.0
b5e89000 b5e8b000 r-xp /usr/lib/libSLP-db-util.so.0.1.0
b5e94000 b5f60000 r-xp /usr/lib/libxml2.so.2.7.8
b5f6d000 b5f6f000 r-xp /usr/lib/libgmodule-2.0.so.0.3200.3
b5f77000 b5f7c000 r-xp /usr/lib/libffi.so.5.0.10
b5f84000 b5f85000 r-xp /usr/lib/libgthread-2.0.so.0.3200.3
b5f8e000 b5f99000 r-xp /usr/lib/libgpg-error.so.0.15.0
b5fa1000 b5fa4000 r-xp /lib/libattr.so.1.1.0
b5fac000 b6040000 r-xp /usr/lib/libstdc++.so.6.0.16
b6053000 b606f000 r-xp /usr/lib/libsecurity-server-commons.so.1.0.0
b6078000 b6090000 r-xp /usr/lib/libpng12.so.0.50.0
b6099000 b60af000 r-xp /lib/libexpat.so.1.5.2
b60b9000 b60fd000 r-xp /usr/lib/libcurl.so.4.3.0
b6106000 b6110000 r-xp /usr/lib/libXext.so.6.4.0
b6119000 b611c000 r-xp /usr/lib/libXtst.so.6.1.0
b6125000 b612b000 r-xp /usr/lib/libXrender.so.1.3.0
b6134000 b613a000 r-xp /usr/lib/libXrandr.so.2.2.0
b6142000 b6143000 r-xp /usr/lib/libXinerama.so.1.0.0
b614c000 b6155000 r-xp /usr/lib/libXi.so.6.1.0
b615d000 b6160000 r-xp /usr/lib/libXfixes.so.3.1.0
b6168000 b616a000 r-xp /usr/lib/libXgesture.so.7.0.0
b6172000 b6174000 r-xp /usr/lib/libXcomposite.so.1.0.0
b617d000 b617f000 r-xp /usr/lib/libXdamage.so.1.1.0
b6187000 b618e000 r-xp /usr/lib/libXcursor.so.1.0.2
b6196000 b6199000 r-xp /usr/lib/libecore_input_evas.so.1.7.99
b61a1000 b61a5000 r-xp /usr/lib/libecore_ipc.so.1.7.99
b61ae000 b61b3000 r-xp /usr/lib/libecore_fb.so.1.7.99
b61bd000 b629e000 r-xp /usr/lib/libX11.so.6.3.0
b62a9000 b62cc000 r-xp /usr/lib/libjpeg.so.8.0.2
b62e4000 b62fa000 r-xp /lib/libz.so.1.2.5
b6302000 b6377000 r-xp /usr/lib/libsqlite3.so.0.8.6
b6381000 b6396000 r-xp /usr/lib/libpkgmgr_parser.so.0.1.0
b639f000 b63d3000 r-xp /usr/lib/libgobject-2.0.so.0.3200.3
b63dc000 b64af000 r-xp /usr/lib/libgio-2.0.so.0.3200.3
b64ba000 b64ca000 r-xp /lib/libresolv-2.13.so
b64ce000 b654a000 r-xp /usr/lib/libgcrypt.so.20.0.3
b6556000 b656e000 r-xp /usr/lib/liblzma.so.5.0.3
b6577000 b657a000 r-xp /lib/libcap.so.2.21
b6582000 b65a8000 r-xp /usr/lib/libsecurity-server-client.so.1.0.1
b65b1000 b65b2000 r-xp /usr/lib/libecore_imf_evas.so.1.7.99
b65ba000 b65c0000 r-xp /usr/lib/libecore_imf.so.1.7.99
b65c8000 b65df000 r-xp /usr/lib/liblua-5.1.so
b65e9000 b65f0000 r-xp /usr/lib/libembryo.so.1.7.99
b65f8000 b65fe000 r-xp /lib/librt-2.13.so
b6607000 b665d000 r-xp /usr/lib/libpixman-1.so.0.28.2
b666a000 b66c0000 r-xp /usr/lib/libfreetype.so.6.11.3
b66cc000 b66f4000 r-xp /usr/lib/libfontconfig.so.1.8.0
b66f6000 b6733000 r-xp /usr/lib/libharfbuzz.so.0.940.0
b673c000 b674f000 r-xp /usr/lib/libfribidi.so.0.3.1
b6757000 b6771000 r-xp /usr/lib/libecore_con.so.1.7.99
b677a000 b6783000 r-xp /usr/lib/libedbus.so.1.7.99
b678b000 b67db000 r-xp /usr/lib/libecore_x.so.1.7.99
b67de000 b67e2000 r-xp /usr/lib/libvconf.so.0.2.45
b67ea000 b67fb000 r-xp /usr/lib/libecore_input.so.1.7.99
b6803000 b6808000 r-xp /usr/lib/libecore_file.so.1.7.99
b6810000 b6832000 r-xp /usr/lib/libecore_evas.so.1.7.99
b683b000 b687c000 r-xp /usr/lib/libeina.so.1.7.99
b6885000 b689e000 r-xp /usr/lib/libeet.so.1.7.99
b68af000 b6918000 r-xp /lib/libm-2.13.so
b6921000 b6927000 r-xp /usr/lib/libcapi-base-common.so.0.1.8
b6930000 b6933000 r-xp /usr/lib/libproc-stat.so.0.2.86
b693b000 b695d000 r-xp /usr/lib/libpkgmgr-info.so.0.0.17
b6965000 b696a000 r-xp /usr/lib/libxdgmime.so.1.1.0
b6972000 b699c000 r-xp /usr/lib/libdbus-1.so.3.8.12
b69a5000 b69bc000 r-xp /usr/lib/libdbus-glib-1.so.2.2.2
b69c4000 b69cf000 r-xp /lib/libunwind.so.8.0.1
b69fc000 b6a38000 r-xp /usr/lib/libsystemd.so.0.4.0
b6a41000 b6b5c000 r-xp /lib/libc-2.13.so
b6b6a000 b6b72000 r-xp /lib/libgcc_s-4.6.so.1
b6b73000 b6b76000 r-xp /usr/lib/libsmack.so.1.0.0
b6b7e000 b6b84000 r-xp /usr/lib/libprivilege-control.so.0.0.2
b6b8c000 b6c5c000 r-xp /usr/lib/libglib-2.0.so.0.3200.3
b6c5d000 b6cba000 r-xp /usr/lib/libedje.so.1.7.99
b6cc4000 b6cdb000 r-xp /usr/lib/libecore.so.1.7.99
b6cf2000 b6dc1000 r-xp /usr/lib/libevas.so.1.7.99
b6de5000 b6f1f000 r-xp /usr/lib/libelementary.so.1.7.99
b6f35000 b6f49000 r-xp /lib/libpthread-2.13.so
b6f54000 b6f56000 r-xp /usr/lib/libdlog.so.0.0.0
b6f5e000 b6f61000 r-xp /usr/lib/libbundle.so.0.1.22
b6f69000 b6f6b000 r-xp /lib/libdl-2.13.so
b6f74000 b6f80000 r-xp /usr/lib/libaul.so.0.1.0
b6f92000 b6f97000 r-xp /usr/lib/libappcore-efl.so.1.1
b6fa0000 b6fa4000 r-xp /usr/lib/libsys-assert.so
b6fad000 b6fca000 r-xp /lib/ld-2.13.so
b6fd3000 b6fd8000 r-xp /usr/bin/launchpad-loader
b81c8000 b84f6000 rw-p [heap]
bea59000 bea7a000 rwxp [stack]
End of Maps Information

Callstack Information (PID:2724)
Call Stack Count: 1
 0: eina_stringshare_add + 0x5 (0xb685fc0a) [/usr/lib/libeina.so.1] + 0x24c0a
End of Call Stack

Package Information
Package Name: org.example.uicomponents
Package ID : org.example.uicomponents
Version: 1.0.0
Package Type: rpm
App Name: uicomponents
App ID: org.example.uicomponents
Type: capp
Categories: 

Latest Debug Message Information
--------- beginning of /dev/log_main
ntary<2724> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), ev->cur.canvas.x(163) ev->cur.canvas.y(270)
06-06 23:01:19.569+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), hold(0) freeze(0)
06-06 23:01:19.569+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), block(1)
06-06 23:01:19.569+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), ev->cur.canvas.x(163) ev->cur.canvas.y(274)
06-06 23:01:19.569+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), hold(0) freeze(0)
06-06 23:01:19.569+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), block(1)
06-06 23:01:19.569+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), ev->cur.canvas.x(163) ev->cur.canvas.y(275)
06-06 23:01:19.569+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), hold(0) freeze(0)
06-06 23:01:19.569+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), block(1)
06-06 23:01:19.569+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), ev->cur.canvas.x(163) ev->cur.canvas.y(278)
06-06 23:01:19.569+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), hold(0) freeze(0)
06-06 23:01:19.579+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b8430788), locked_x(0)
06-06 23:01:19.579+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3843 _elm_scroll_hold_animator() [DDO] obj(b8430788)
06-06 23:01:19.579+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b8430788)
06-06 23:01:19.619+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), block(1)
06-06 23:01:19.619+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), ev->cur.canvas.x(163) ev->cur.canvas.y(281)
06-06 23:01:19.619+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), hold(0) freeze(0)
06-06 23:01:19.619+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), block(1)
06-06 23:01:19.619+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), ev->cur.canvas.x(163) ev->cur.canvas.y(283)
06-06 23:01:19.619+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), hold(0) freeze(0)
06-06 23:01:19.619+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), block(1)
06-06 23:01:19.619+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), ev->cur.canvas.x(163) ev->cur.canvas.y(285)
06-06 23:01:19.619+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), hold(0) freeze(0)
06-06 23:01:19.619+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), block(1)
06-06 23:01:19.619+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), ev->cur.canvas.x(163) ev->cur.canvas.y(286)
06-06 23:01:19.619+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), hold(0) freeze(0)
06-06 23:01:19.619+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b8430788), locked_x(0)
06-06 23:01:19.619+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3843 _elm_scroll_hold_animator() [DDO] obj(b8430788)
06-06 23:01:19.619+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b8430788)
06-06 23:01:19.669+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), block(1)
06-06 23:01:19.669+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), ev->cur.canvas.x(163) ev->cur.canvas.y(287)
06-06 23:01:19.669+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), hold(0) freeze(0)
06-06 23:01:19.669+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), block(1)
06-06 23:01:19.669+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), ev->cur.canvas.x(163) ev->cur.canvas.y(289)
06-06 23:01:19.669+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), hold(0) freeze(0)
06-06 23:01:19.669+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), block(1)
06-06 23:01:19.669+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), ev->cur.canvas.x(163) ev->cur.canvas.y(290)
06-06 23:01:19.669+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), hold(0) freeze(0)
06-06 23:01:19.669+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), block(1)
06-06 23:01:19.669+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), ev->cur.canvas.x(163) ev->cur.canvas.y(292)
06-06 23:01:19.669+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), hold(0) freeze(0)
06-06 23:01:19.669+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b8430788), locked_x(0)
06-06 23:01:19.669+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3843 _elm_scroll_hold_animator() [DDO] obj(b8430788)
06-06 23:01:19.669+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b8430788)
06-06 23:01:19.709+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), block(1)
06-06 23:01:19.709+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), ev->cur.canvas.x(163) ev->cur.canvas.y(293)
06-06 23:01:19.709+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), hold(0) freeze(0)
06-06 23:01:19.709+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), block(1)
06-06 23:01:19.709+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), ev->cur.canvas.x(163) ev->cur.canvas.y(295)
06-06 23:01:19.709+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), hold(0) freeze(0)
06-06 23:01:19.709+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), block(1)
06-06 23:01:19.709+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), ev->cur.canvas.x(164) ev->cur.canvas.y(296)
06-06 23:01:19.709+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), hold(0) freeze(0)
06-06 23:01:19.709+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), block(1)
06-06 23:01:19.709+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), ev->cur.canvas.x(164) ev->cur.canvas.y(298)
06-06 23:01:19.709+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), hold(0) freeze(0)
06-06 23:01:19.719+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b8430788), locked_x(0)
06-06 23:01:19.719+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3843 _elm_scroll_hold_animator() [DDO] obj(b8430788)
06-06 23:01:19.719+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b8430788)
06-06 23:01:19.749+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), block(1)
06-06 23:01:19.749+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), ev->cur.canvas.x(164) ev->cur.canvas.y(300)
06-06 23:01:19.749+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), hold(0) freeze(0)
06-06 23:01:19.749+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), block(1)
06-06 23:01:19.749+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), ev->cur.canvas.x(165) ev->cur.canvas.y(301)
06-06 23:01:19.749+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), hold(0) freeze(0)
06-06 23:01:19.749+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b8430788), locked_x(0)
06-06 23:01:19.749+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3843 _elm_scroll_hold_animator() [DDO] obj(b8430788)
06-06 23:01:19.749+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b8430788)
06-06 23:01:19.749+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b8430788), locked_x(0)
06-06 23:01:19.749+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b8430788), locked_x(0)
06-06 23:01:19.749+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b8430788), locked_x(0)
06-06 23:01:19.749+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b8430788), locked_x(0)
06-06 23:01:19.749+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b8430788), locked_x(0)
06-06 23:01:19.749+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b8430788), locked_x(0)
06-06 23:01:19.749+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b8430788), locked_x(0)
06-06 23:01:19.749+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), block(1)
06-06 23:01:19.749+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), ev->cur.canvas.x(165) ev->cur.canvas.y(302)
06-06 23:01:19.749+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), hold(0) freeze(0)
06-06 23:01:19.749+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b8430788), locked_x(0)
06-06 23:01:19.749+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3843 _elm_scroll_hold_animator() [DDO] obj(b8430788)
06-06 23:01:19.749+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b8430788)
06-06 23:01:19.789+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), block(1)
06-06 23:01:19.789+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), ev->cur.canvas.x(165) ev->cur.canvas.y(303)
06-06 23:01:19.789+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), hold(0) freeze(0)
06-06 23:01:19.799+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b8430788), locked_x(0)
06-06 23:01:19.799+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3843 _elm_scroll_hold_animator() [DDO] obj(b8430788)
06-06 23:01:19.799+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b8430788)
06-06 23:01:19.839+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), block(1)
06-06 23:01:19.839+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), ev->cur.canvas.x(165) ev->cur.canvas.y(304)
06-06 23:01:19.839+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), hold(0) freeze(0)
06-06 23:01:19.839+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), block(1)
06-06 23:01:19.839+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), ev->cur.canvas.x(166) ev->cur.canvas.y(307)
06-06 23:01:19.839+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), hold(0) freeze(0)
06-06 23:01:19.839+0900 E/EFL     ( 2724): evas_main<2724> evas_events.c:1275 evas_event_feed_mouse_up() ButtonEvent:up time=21455573 button=1 downs=0
06-06 23:01:19.839+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:2278 _elm_scroll_post_event_up() [DDO] lock set false. : obj(b8430788), type(elm_genlist)
06-06 23:01:24.449+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), block(1)
06-06 23:01:24.449+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), ev->cur.canvas.x(130) ev->cur.canvas.y(303)
06-06 23:01:24.449+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), hold(0) freeze(0)
06-06 23:01:24.449+0900 E/EFL     ( 2724): evas_main<2724> evas_events.c:1009 evas_event_feed_mouse_down() ButtonEvent:down time=21460188 button=1 downs=1
06-06 23:01:24.449+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), block(1)
06-06 23:01:24.449+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), ev->cur.canvas.x(131) ev->cur.canvas.y(303)
06-06 23:01:24.449+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), hold(0) freeze(0)
06-06 23:01:24.469+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), block(1)
06-06 23:01:24.469+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), ev->cur.canvas.x(131) ev->cur.canvas.y(302)
06-06 23:01:24.469+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), hold(0) freeze(0)
06-06 23:01:24.479+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), block(1)
06-06 23:01:24.479+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), ev->cur.canvas.x(132) ev->cur.canvas.y(302)
06-06 23:01:24.479+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), hold(0) freeze(0)
06-06 23:01:24.489+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), block(1)
06-06 23:01:24.489+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), ev->cur.canvas.x(133) ev->cur.canvas.y(300)
06-06 23:01:24.489+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), hold(0) freeze(0)
06-06 23:01:24.499+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), block(1)
06-06 23:01:24.499+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), ev->cur.canvas.x(136) ev->cur.canvas.y(294)
06-06 23:01:24.499+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), hold(0) freeze(0)
06-06 23:01:24.519+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), block(1)
06-06 23:01:24.519+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), ev->cur.canvas.x(140) ev->cur.canvas.y(288)
06-06 23:01:24.519+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), hold(0) freeze(0)
06-06 23:01:24.519+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), block(1)
06-06 23:01:24.519+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), ev->cur.canvas.x(144) ev->cur.canvas.y(284)
06-06 23:01:24.519+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), hold(0) freeze(0)
06-06 23:01:24.529+0900 E/EFL     ( 2724): evas_main<2724> evas_events.c:1275 evas_event_feed_mouse_up() ButtonEvent:up time=21460272 button=1 downs=0
06-06 23:01:24.949+0900 E/EFL     ( 2724): edje<2724> edje_util.c:3770 edje_object_size_min_restricted_calc() group entry_layout has a non-fixed part 'entry_part'. Adding 'fixed: 1 1;' to source EDC may help. Continuing discarding faulty part.
06-06 23:01:24.959+0900 E/EFL     ( 2724): edje<2724> edje_util.c:3770 edje_object_size_min_restricted_calc() group entry_layout has a non-fixed part 'entry_part'. Adding 'fixed: 1 1;' to source EDC may help. Continuing discarding faulty part.
06-06 23:01:24.989+0900 E/EFL     ( 2724): edje<2724> edje_util.c:3770 edje_object_size_min_restricted_calc() group entry_layout has a non-fixed part 'entry_part'. Adding 'fixed: 1 1;' to source EDC may help. Continuing discarding faulty part.
06-06 23:01:25.659+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b84616a8), block(1)
06-06 23:01:25.659+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b84616a8), ev->cur.canvas.x(139) ev->cur.canvas.y(51)
06-06 23:01:25.659+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b84616a8), hold(0) freeze(0)
06-06 23:01:25.659+0900 E/EFL     ( 2724): evas_main<2724> evas_events.c:1009 evas_event_feed_mouse_down() ButtonEvent:down time=21461397 button=1 downs=1
06-06 23:01:25.719+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b84616a8), block(1)
06-06 23:01:25.719+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b84616a8), ev->cur.canvas.x(137) ev->cur.canvas.y(51)
06-06 23:01:25.719+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b84616a8), hold(0) freeze(0)
06-06 23:01:25.719+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b846a8a8), block(2)
06-06 23:01:25.719+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b846a8a8), ev->cur.canvas.x(137) ev->cur.canvas.y(51)
06-06 23:01:25.719+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b846a8a8), hold(0) freeze(0)
06-06 23:01:25.729+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b84616a8), block(1)
06-06 23:01:25.729+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b84616a8), ev->cur.canvas.x(135) ev->cur.canvas.y(51)
06-06 23:01:25.729+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b84616a8), hold(0) freeze(0)
06-06 23:01:25.729+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b846a8a8), block(2)
06-06 23:01:25.729+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b846a8a8), ev->cur.canvas.x(135) ev->cur.canvas.y(51)
06-06 23:01:25.729+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b846a8a8), hold(0) freeze(0)
06-06 23:01:25.749+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b84616a8), block(1)
06-06 23:01:25.749+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b84616a8), ev->cur.canvas.x(132) ev->cur.canvas.y(51)
06-06 23:01:25.749+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b84616a8), hold(0) freeze(0)
06-06 23:01:25.749+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b846a8a8), block(2)
06-06 23:01:25.749+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b846a8a8), ev->cur.canvas.x(132) ev->cur.canvas.y(51)
06-06 23:01:25.749+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b846a8a8), hold(0) freeze(0)
06-06 23:01:25.749+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b84616a8), block(1)
06-06 23:01:25.749+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b84616a8), ev->cur.canvas.x(132) ev->cur.canvas.y(56)
06-06 23:01:25.749+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b84616a8), hold(0) freeze(0)
06-06 23:01:25.749+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b846a8a8), block(2)
06-06 23:01:25.749+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b846a8a8), ev->cur.canvas.x(132) ev->cur.canvas.y(56)
06-06 23:01:25.749+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b846a8a8), hold(0) freeze(0)
06-06 23:01:25.779+0900 E/EFL     ( 2724): evas_main<2724> evas_events.c:1275 evas_event_feed_mouse_up() ButtonEvent:up time=21461501 button=1 downs=0
06-06 23:01:25.819+0900 W/ISF_PANEL_EFL( 1433): isf_panel_efl.cpp: efl_get_window_rotate_angle(3431) > WINDOW angle of 0x3000002 FAILED!
06-06 23:01:25.819+0900 W/ISF_PANEL_EFL( 1433): isf_panel_efl.cpp: efl_get_window_rotate_angle(3431) > WINDOW angle of 0x3000002 FAILED!
06-06 23:01:25.829+0900 E/EFL     ( 2724): <2724> elc_popup.c:2455 elm_popup_add() safety check failed: parent == NULL
06-06 23:01:25.829+0900 E/EFL     ( 2724): <2724> elm_main.c:1247 elm_object_style_set() safety check failed: obj == NULL
06-06 23:01:25.829+0900 E/efl-extension( 2724): efl_extension_events.c: _eext_key_grab_obj_create(269) > Failed to grab END KEY
06-06 23:01:25.829+0900 E/efl-extension( 2724): efl_extension_events.c: _eext_key_grab_obj_create(272) > Failed to grab END KEY
06-06 23:01:25.829+0900 E/efl-extension( 2724): efl_extension_events.c: _eext_key_grab_obj_create(275) > Failed to grab END KEY
06-06 23:01:25.829+0900 E/efl-extension( 2724): efl_extension_events.c: _eext_key_grab_obj_create(278) > Failed to grab MORE KEY
06-06 23:01:25.829+0900 E/efl-extension( 2724): efl_extension_events.c: _eext_key_grab_obj_create(281) > Failed to grab MORE KEY
06-06 23:01:25.829+0900 E/efl-extension( 2724): efl_extension_events.c: _eext_key_grab_obj_create(284) > Failed to grab MORE KEY
06-06 23:01:25.829+0900 E/EFL     ( 2724): <2724> elm_main.c:1156 elm_object_part_text_set() safety check failed: obj == NULL
06-06 23:01:25.899+0900 E/TIZEN_N_SYSTEM_SETTINGS( 1503): system_settings.c: system_settings_get_value_string(522) > Enter [system_settings_get_value_string]
06-06 23:01:25.899+0900 E/TIZEN_N_SYSTEM_SETTINGS( 1503): system_settings.c: system_settings_get_value(386) > Enter [system_settings_get_value]
06-06 23:01:25.899+0900 E/TIZEN_N_SYSTEM_SETTINGS( 1503): system_settings.c: system_settings_get_item(361) > Enter [system_settings_get_item], key=4
06-06 23:01:25.899+0900 E/TIZEN_N_SYSTEM_SETTINGS( 1503): system_settings.c: system_settings_get_item(374) > Enter [system_settings_get_item], index = 4, key = 4, type = 0
06-06 23:01:25.929+0900 I/ISE_MULTI( 1503): isemain.cpp: slot_set_caps_mode(1123) > [0;36m[hidden state:true] mode=1[0m
06-06 23:01:25.929+0900 I/ISE_MULTI( 1503): isemain.cpp: slot_update_cursor_position(1183) > [0;36m[hidden state:true] pos=0[0m
06-06 23:01:25.929+0900 I/ISE_MULTI( 1503): isemain.cpp: slot_reset_ise_input_context(1375) > [0;36m[hidden state:true][0m
06-06 23:01:26.269+0900 E/E17     (  585): e_manager.c: _e_manager_cb_window_show_request(1128) > Show request(0x0440081b)
06-06 23:01:26.349+0900 I/ISE_MULTI( 1503): xt9-setting.cpp: xt9_change_onoff(133) > [0;36mxt9_change_onoff [0m
06-06 23:01:26.349+0900 E/ISE_MULTI( 1503): ise-rotary-event-listener.cpp: rotary_input_init(87) > [0;31mrotary_input_init[0m
06-06 23:01:26.399+0900 I/CANDIDATE( 1503): soft_candidate.cpp: ui_candidate_hide(921) > [0;36mcandidate_hide[0m
06-06 23:01:26.409+0900 E/E17     (  585): e_manager.c: _e_manager_cb_window_show_request(1128) > Show request(0x04400002)
06-06 23:01:26.629+0900 E/AUL_AMD (  905): amd_appinfo.c: appinfo_get_value(999) > appinfo get value: Invalid argument, 9
06-06 23:01:27.009+0900 W/ISF_PANEL_EFL( 1433): isf_panel_efl.cpp: efl_get_window_rotate_angle(3431) > WINDOW angle of 0x4400002 FAILED!
06-06 23:01:27.009+0900 W/ISF_PANEL_EFL( 1433): isf_panel_efl.cpp: efl_get_window_rotate_angle(3431) > WINDOW angle of 0x4400002 FAILED!
06-06 23:01:27.029+0900 E/EFL     ( 2724): edje<2724> edje_util.c:3770 edje_object_size_min_restricted_calc() group entry_layout has a non-fixed part 'entry_part'. Adding 'fixed: 1 1;' to source EDC may help. Continuing discarding faulty part.
06-06 23:01:27.259+0900 W/ISE_MULTI( 1503): ise.cpp: on_event_key_clicked(924) > [0;33mkeyEventDesc.keyModifier [0] and key event [57589][0m
06-06 23:01:27.259+0900 W/IMMODULE( 2724): isf_imf_context.cpp: feed_key_event(2491) > Unknown key code : 57589
06-06 23:01:27.309+0900 I/ISE_MULTI( 1503): isemain.cpp: slot_set_caps_mode(1123) > [0;36m[hidden state:false] mode=0[0m
06-06 23:01:27.319+0900 W/IMMODULE( 2724): isf_imf_context.cpp: feed_key_event(2491) > Unknown key code : 57589
06-06 23:01:27.489+0900 W/ISE_MULTI( 1503): ise.cpp: on_event_key_clicked(924) > [0;33mkeyEventDesc.keyModifier [0] and key event [57589][0m
06-06 23:01:27.489+0900 W/IMMODULE( 2724): isf_imf_context.cpp: feed_key_event(2491) > Unknown key code : 57589
06-06 23:01:27.539+0900 W/IMMODULE( 2724): isf_imf_context.cpp: feed_key_event(2491) > Unknown key code : 57589
06-06 23:01:27.699+0900 W/ISE_MULTI( 1503): ise.cpp: on_event_key_clicked(924) > [0;33mkeyEventDesc.keyModifier [0] and key event [57588][0m
06-06 23:01:27.719+0900 W/IMMODULE( 2724): isf_imf_context.cpp: feed_key_event(2491) > Unknown key code : 57588
06-06 23:01:27.749+0900 W/IMMODULE( 2724): isf_imf_context.cpp: feed_key_event(2491) > Unknown key code : 57588
06-06 23:01:27.939+0900 W/ISE_MULTI( 1503): ise.cpp: on_event_key_clicked(924) > [0;33mkeyEventDesc.keyModifier [0] and key event [57589][0m
06-06 23:01:27.939+0900 W/IMMODULE( 2724): isf_imf_context.cpp: feed_key_event(2491) > Unknown key code : 57589
06-06 23:01:27.999+0900 W/IMMODULE( 2724): isf_imf_context.cpp: feed_key_event(2491) > Unknown key code : 57589
06-06 23:01:28.149+0900 W/ISE_MULTI( 1503): ise.cpp: on_event_key_clicked(924) > [0;33mkeyEventDesc.keyModifier [0] and key event [57590][0m
06-06 23:01:28.149+0900 W/IMMODULE( 2724): isf_imf_context.cpp: feed_key_event(2491) > Unknown key code : 57590
06-06 23:01:28.219+0900 W/IMMODULE( 2724): isf_imf_context.cpp: feed_key_event(2491) > Unknown key code : 57590
06-06 23:01:28.369+0900 W/ISE_MULTI( 1503): ise.cpp: on_event_key_clicked(924) > [0;33mkeyEventDesc.keyModifier [0] and key event [57589][0m
06-06 23:01:28.369+0900 W/IMMODULE( 2724): isf_imf_context.cpp: feed_key_event(2491) > Unknown key code : 57589
06-06 23:01:28.429+0900 W/IMMODULE( 2724): isf_imf_context.cpp: feed_key_event(2491) > Unknown key code : 57589
06-06 23:01:28.889+0900 W/ISE_MULTI( 1503): ise.cpp: on_event_key_clicked(924) > [0;33mkeyEventDesc.keyModifier [0] and key event [65293][0m
06-06 23:01:29.239+0900 W/ISE_MULTI( 1503): ise.cpp: on_event_key_clicked(924) > [0;33mkeyEventDesc.keyModifier [0] and key event [65293][0m
06-06 23:01:29.749+0900 W/ISE_MULTI( 1503): ise.cpp: on_event_key_clicked(924) > [0;33mkeyEventDesc.keyModifier [0] and key event [65293][0m
06-06 23:01:30.149+0900 W/ISE_MULTI( 1503): ise.cpp: on_event_key_clicked(924) > [0;33mkeyEventDesc.keyModifier [0] and key event [65293][0m
06-06 23:01:30.299+0900 W/ISE_MULTI( 1503): ise.cpp: on_event_key_clicked(924) > [0;33mkeyEventDesc.keyModifier [0] and key event [65293][0m
06-06 23:01:31.329+0900 I/ISE_MULTI( 1503): isemain.cpp: slot_reset_ise_input_context(1375) > [0;36m[hidden state:false][0m
06-06 23:01:31.409+0900 E/ISE_MULTI( 1503): ise-rotary-event-listener.cpp: rotary_input_clear(94) > [0;31mrotary_input_clear[0m
06-06 23:01:31.409+0900 I/efl-extension( 1503): efl_extension_rotary.c: _remove_ecore_handlers(554) > In
06-06 23:01:31.409+0900 I/efl-extension( 1503): efl_extension_rotary.c: _remove_ecore_handlers(559) > removed _motion_handler
06-06 23:01:31.409+0900 I/efl-extension( 1503): efl_extension_rotary.c: _remove_ecore_handlers(565) > removed _rotate_handler
06-06 23:01:31.409+0900 E/ISE_MULTI( 1503): rotary_input.cpp: destroy_rotary_input_layout(613) > [0;31mdestroy_rotary_input_layout[0m
06-06 23:01:31.499+0900 W/ISF_PANEL_EFL( 1433): isf_panel_efl.cpp: efl_get_window_rotate_angle(3431) > WINDOW angle of 0x3000002 FAILED!
06-06 23:01:31.529+0900 E/EFL     ( 2724): edje<2724> edje_util.c:3770 edje_object_size_min_restricted_calc() group entry_layout has a non-fixed part 'entry_part'. Adding 'fixed: 1 1;' to source EDC may help. Continuing discarding faulty part.
06-06 23:01:32.039+0900 I/RESOURCED(  906): swap.c: swap_send_signal(594) > [swap_send_signal,594] send signal to swap thread
06-06 23:01:32.609+0900 E/SWIFTKEY( 1407): swiftkey_engine.cpp: IME_Learn_sentence(2544) > [0;31mskip : session is null[0m
06-06 23:01:32.679+0900 I/ISE_MULTI( 1503): isemain.cpp: slot_reset_ise_input_context(1375) > [0;36m[hidden state:true][0m
06-06 23:01:33.119+0900 I/RESOURCED(  906): swap.c: swap_send_signal(594) > [swap_send_signal,594] send signal to swap thread
06-06 23:01:33.409+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), block(1)
06-06 23:01:33.409+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), ev->cur.canvas.x(124) ev->cur.canvas.y(79)
06-06 23:01:33.409+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), hold(0) freeze(0)
06-06 23:01:33.409+0900 E/EFL     ( 2724): evas_main<2724> evas_events.c:1009 evas_event_feed_mouse_down() ButtonEvent:down time=21469149 button=1 downs=1
06-06 23:01:33.409+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), block(1)
06-06 23:01:33.409+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), ev->cur.canvas.x(124) ev->cur.canvas.y(83)
06-06 23:01:33.409+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), hold(0) freeze(0)
06-06 23:01:33.419+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), block(1)
06-06 23:01:33.419+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), ev->cur.canvas.x(128) ev->cur.canvas.y(85)
06-06 23:01:33.419+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), hold(0) freeze(0)
06-06 23:01:33.439+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), block(1)
06-06 23:01:33.439+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), ev->cur.canvas.x(132) ev->cur.canvas.y(87)
06-06 23:01:33.439+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), hold(0) freeze(0)
06-06 23:01:33.449+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), block(1)
06-06 23:01:33.449+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), ev->cur.canvas.x(141) ev->cur.canvas.y(93)
06-06 23:01:33.449+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), hold(0) freeze(0)
06-06 23:01:33.449+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), block(1)
06-06 23:01:33.449+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), ev->cur.canvas.x(151) ev->cur.canvas.y(102)
06-06 23:01:33.449+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), hold(0) freeze(0)
06-06 23:01:33.449+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:4249 _elm_scroll_mouse_move_event_cb() [DDO] animator
06-06 23:01:33.449+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3353 _elm_scroll_post_event_move() [DDO] obj(b8430788), type(elm_genlist)
06-06 23:01:33.449+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3354 _elm_scroll_post_event_move() [DDO] hold_parent(0)
06-06 23:01:33.449+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3382 _elm_scroll_post_event_move() [DDO] elm_widget_drag_lock_x_set : obj(b8430788), type(elm_genlist)
06-06 23:01:33.449+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3405 _elm_scroll_post_event_move() [DDO] elm_widget_drag_lock_y_set : obj(b8430788), type(elm_genlist)
06-06 23:01:33.469+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b8430788), locked_x(0)
06-06 23:01:33.469+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3843 _elm_scroll_hold_animator() [DDO] obj(b8430788)
06-06 23:01:33.469+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b8430788)
06-06 23:01:33.489+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), block(1)
06-06 23:01:33.489+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), ev->cur.canvas.x(156) ev->cur.canvas.y(114)
06-06 23:01:33.489+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), hold(0) freeze(0)
06-06 23:01:33.489+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), block(1)
06-06 23:01:33.489+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), ev->cur.canvas.x(163) ev->cur.canvas.y(130)
06-06 23:01:33.489+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), hold(0) freeze(0)
06-06 23:01:33.489+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), block(1)
06-06 23:01:33.489+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), ev->cur.canvas.x(170) ev->cur.canvas.y(149)
06-06 23:01:33.489+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), hold(0) freeze(0)
06-06 23:01:33.499+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b8430788), locked_x(0)
06-06 23:01:33.499+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3843 _elm_scroll_hold_animator() [DDO] obj(b8430788)
06-06 23:01:33.499+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b8430788)
06-06 23:01:33.549+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), block(1)
06-06 23:01:33.549+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), ev->cur.canvas.x(173) ev->cur.canvas.y(175)
06-06 23:01:33.549+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), hold(0) freeze(0)
06-06 23:01:33.549+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), block(1)
06-06 23:01:33.549+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), ev->cur.canvas.x(178) ev->cur.canvas.y(203)
06-06 23:01:33.549+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), hold(0) freeze(0)
06-06 23:01:33.549+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), block(1)
06-06 23:01:33.549+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), ev->cur.canvas.x(185) ev->cur.canvas.y(236)
06-06 23:01:33.549+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), hold(0) freeze(0)
06-06 23:01:33.549+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), block(1)
06-06 23:01:33.549+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), ev->cur.canvas.x(190) ev->cur.canvas.y(262)
06-06 23:01:33.549+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), hold(0) freeze(0)
06-06 23:01:33.549+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), block(1)
06-06 23:01:33.549+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), ev->cur.canvas.x(192) ev->cur.canvas.y(283)
06-06 23:01:33.549+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), hold(0) freeze(0)
06-06 23:01:33.549+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), block(1)
06-06 23:01:33.549+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), ev->cur.canvas.x(192) ev->cur.canvas.y(304)
06-06 23:01:33.549+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), hold(0) freeze(0)
06-06 23:01:33.569+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b8430788), locked_x(0)
06-06 23:01:33.569+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3843 _elm_scroll_hold_animator() [DDO] obj(b8430788)
06-06 23:01:33.569+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b8430788)
06-06 23:01:33.609+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), block(1)
06-06 23:01:33.609+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), ev->cur.canvas.x(192) ev->cur.canvas.y(323)
06-06 23:01:33.609+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), hold(0) freeze(0)
06-06 23:01:33.609+0900 E/EFL     ( 2724): evas_main<2724> evas_events.c:1275 evas_event_feed_mouse_up() ButtonEvent:up time=21469313 button=1 downs=0
06-06 23:01:33.609+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:2278 _elm_scroll_post_event_up() [DDO] lock set false. : obj(b8430788), type(elm_genlist)
06-06 23:01:34.529+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), block(1)
06-06 23:01:34.529+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), ev->cur.canvas.x(141) ev->cur.canvas.y(151)
06-06 23:01:34.529+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), hold(0) freeze(0)
06-06 23:01:34.529+0900 E/EFL     ( 2724): evas_main<2724> evas_events.c:1009 evas_event_feed_mouse_down() ButtonEvent:down time=21470272 button=1 downs=1
06-06 23:01:34.529+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), block(1)
06-06 23:01:34.529+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), ev->cur.canvas.x(144) ev->cur.canvas.y(157)
06-06 23:01:34.529+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), hold(0) freeze(0)
06-06 23:01:34.539+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), block(1)
06-06 23:01:34.539+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), ev->cur.canvas.x(149) ev->cur.canvas.y(161)
06-06 23:01:34.539+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), hold(0) freeze(0)
06-06 23:01:34.569+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), block(1)
06-06 23:01:34.569+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), ev->cur.canvas.x(150) ev->cur.canvas.y(161)
06-06 23:01:34.569+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), hold(0) freeze(0)
06-06 23:01:34.589+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), block(1)
06-06 23:01:34.589+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), ev->cur.canvas.x(151) ev->cur.canvas.y(161)
06-06 23:01:34.589+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), hold(0) freeze(0)
06-06 23:01:34.589+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), block(1)
06-06 23:01:34.589+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), ev->cur.canvas.x(152) ev->cur.canvas.y(161)
06-06 23:01:34.589+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), hold(0) freeze(0)
06-06 23:01:34.609+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), block(1)
06-06 23:01:34.609+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), ev->cur.canvas.x(152) ev->cur.canvas.y(158)
06-06 23:01:34.609+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), hold(0) freeze(0)
06-06 23:01:34.619+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), block(1)
06-06 23:01:34.619+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), ev->cur.canvas.x(143) ev->cur.canvas.y(149)
06-06 23:01:34.619+0900 E/EFL     ( 2724): elementary<2724> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8430788), hold(0) freeze(0)
06-06 23:01:34.629+0900 E/EFL     ( 2724): evas_main<2724> evas_events.c:1275 evas_event_feed_mouse_up() ButtonEvent:up time=21470371 button=1 downs=0
06-06 23:01:34.879+0900 W/CRASH_MANAGER( 2731): worker.c: worker_job(1199) > 1102724756963146522169
