S/W Version Information
Model: SM-R735S
Tizen-Version: 2.3.1.2
Build-Number: R735SKSU1AOKE
Build-Date: 2015.11.25 20:46:58

Crash Information
Process Name: uicomponents
PID: 12744
Date: 2016-06-06 18:04:01+0900
Executable File Path: /opt/usr/apps/org.example.uicomponents/bin/uicomponents
Signal: 11
      (SIGSEGV)
      si_code: -6
      signal sent by tkill (sent by pid 12744, uid 5000)

Register Information
r0   = 0x71737723, r1   = 0x71737723
r2   = 0x00000001, r3   = 0x00000000
r4   = 0x71737723, r5   = 0xb6f169f8
r6   = 0xb828bb58, r7   = 0xbe9eb3e8
r8   = 0xb6cca9c0, r9   = 0xb819a638
r10  = 0xb6f0ee9c, fp   = 0x00000000
ip   = 0xb6f10428, sp   = 0xbe9eb310
lr   = 0xb6ebd32d, pc   = 0xb6d06bde
cpsr = 0xa0000030

Memory Information
MemTotal:   407572 KB
MemFree:     15436 KB
Buffers:     13148 KB
Cached:      94452 KB
VmPeak:      77456 KB
VmSize:      75292 KB
VmLck:           0 KB
VmPin:           0 KB
VmHWM:       19660 KB
VmRSS:       19660 KB
VmData:      16728 KB
VmStk:         136 KB
VmExe:          20 KB
VmLib:       24764 KB
VmPTE:          56 KB
VmSwap:          0 KB

Threads Information
Threads: 2
PID = 12744 TID = 12744
12744 12890 

Maps Information
b28fa000 b28fe000 r-xp /usr/lib/libogg.so.0.7.1
b2906000 b2928000 r-xp /usr/lib/libvorbis.so.0.4.3
b2930000 b2938000 r-xp /usr/lib/libmdm-common.so.1.0.89
b2939000 b297c000 r-xp /usr/lib/libsndfile.so.1.0.25
b2989000 b29d1000 r-xp /usr/lib/pulseaudio/libpulsecommon-4.0.so
b29d2000 b29d7000 r-xp /usr/lib/libjson.so.0.0.1
b29df000 b2a10000 r-xp /usr/lib/libmdm.so.1.1.85
b2a18000 b2a20000 r-xp /usr/lib/lib_DNSe_NRSS_ver225.so
b2a2f000 b2a3f000 r-xp /usr/lib/lib_SamsungRec_TizenV04014.so
b2a60000 b2a6d000 r-xp /usr/lib/libail.so.0.1.0
b2a76000 b2a79000 r-xp /usr/lib/libsyspopup_caller.so.0.1.0
b2a81000 b2ab9000 r-xp /usr/lib/libpulse.so.0.16.2
b2aba000 b2b1b000 r-xp /usr/lib/libasound.so.2.0.0
b2b25000 b2b28000 r-xp /usr/lib/libpulse-simple.so.0.0.4
b2b30000 b2b35000 r-xp /usr/lib/libascenario-0.2.so.0.0.0
b2b3d000 b2b56000 r-xp /usr/lib/libavsysaudio.so.0.0.1
b2b5f000 b2b63000 r-xp /usr/lib/libmmfsoundcommon.so.0.0.0
b2b6c000 b2b76000 r-xp /usr/lib/libaudio-session-mgr.so.0.0.0
b2b82000 b2b87000 r-xp /usr/lib/libmmfsession.so.0.0.0
b2b8f000 b2ba5000 r-xp /usr/lib/libmmfsound.so.0.1.0
b2bb7000 b2bbe000 r-xp /usr/lib/libmmfcommon.so.0.0.0
b2bc6000 b2bc7000 r-xp /usr/lib/edje/modules/feedback/linux-gnueabi-armv7l-1.0.0/module.so
b2bcf000 b2c56000 rw-s anon_inode:dmabuf
b2c56000 b2cdd000 rw-s anon_inode:dmabuf
b2d68000 b2def000 rw-s anon_inode:dmabuf
b2e6e000 b2ef5000 rw-s anon_inode:dmabuf
b3107000 b3111000 r-xp /usr/lib/libcapi-media-sound-manager.so.0.1.48
b3119000 b311b000 r-xp /usr/lib/libcapi-media-wav-player.so.0.1.10
b3123000 b3124000 r-xp /usr/lib/libmmfkeysound.so.0.0.0
b312c000 b3133000 r-xp /usr/lib/libfeedback.so.0.1.4
b31e1000 b39e0000 rwxp [stack:12890]
b39e0000 b39f7000 r-xp /usr/lib/edje/modules/elm/linux-gnueabi-armv7l-1.0.0/module.so
b3a04000 b3a06000 r-xp /usr/lib/libgenlock.so
b3a0f000 b3a10000 r-xp /usr/lib/evas/modules/loaders/eet/linux-gnueabi-armv7l-1.7.99/module.so
b3a18000 b3a1a000 r-xp /usr/lib/evas/modules/loaders/png/linux-gnueabi-armv7l-1.7.99/module.so
b3a24000 b3a29000 r-xp /usr/lib/bufmgr/libtbm_msm.so.0.0.0
b3a31000 b3a3c000 r-xp /usr/lib/evas/modules/engines/software_generic/linux-gnueabi-armv7l-1.7.99/module.so
b3d64000 b3e2e000 r-xp /usr/lib/libCOREGL.so.4.0
b3e3f000 b3e44000 r-xp /usr/lib/libcapi-media-tool.so.0.1.5
b3e4c000 b3e6d000 r-xp /usr/lib/libexif.so.12.3.3
b3e80000 b3e85000 r-xp /usr/lib/libmmutil_imgp.so.0.0.0
b3e8d000 b3e92000 r-xp /usr/lib/libmmutil_jpeg.so.0.0.0
b5421000 b5423000 r-xp /usr/lib/libdri2.so.0.0.0
b542b000 b5433000 r-xp /usr/lib/libdrm.so.2.4.0
b543b000 b543e000 r-xp /usr/lib/libcapi-media-image-util.so.0.3.5
b5446000 b552a000 r-xp /usr/lib/libicuuc.so.51.1
b553f000 b567c000 r-xp /usr/lib/libicui18n.so.51.1
b568c000 b5691000 r-xp /usr/lib/libcapi-system-info.so.0.2.0
b5699000 b569f000 r-xp /usr/lib/libxcb-render.so.0.0.0
b56a7000 b56a8000 r-xp /usr/lib/libxcb-shm.so.0.0.0
b56b1000 b56b4000 r-xp /usr/lib/libEGL.so.1.4
b56bc000 b56ca000 r-xp /usr/lib/libGLESv2.so.2.0
b56d3000 b56da000 r-xp /usr/lib/libtbm.so.1.0.0
b56e2000 b5703000 r-xp /usr/lib/libui-extension.so.0.1.0
b570c000 b571e000 r-xp /usr/lib/libtts.so
b5726000 b57de000 r-xp /usr/lib/libcairo.so.2.11200.14
b57e9000 b57fb000 r-xp /usr/lib/libefl-assist.so.0.1.0
b5803000 b5824000 r-xp /usr/lib/libefl-extension.so.0.1.0
b582c000 b583f000 r-xp /opt/usr/apps/org.example.uicomponents/bin/uicomponents
b5a06000 b5a10000 r-xp /lib/libnss_files-2.13.so
b5a19000 b5ae8000 r-xp /usr/lib/libscim-1.0.so.8.2.3
b5afe000 b5b22000 r-xp /usr/lib/ecore/immodules/libisf-imf-module.so
b5b2b000 b5b31000 r-xp /usr/lib/libappsvc.so.0.1.0
b5b39000 b5b3b000 r-xp /usr/lib/libcapi-appfw-app-common.so.0.3.2.5
b5b44000 b5b49000 r-xp /usr/lib/libcapi-appfw-app-control.so.0.3.2.5
b5b54000 b5b5f000 r-xp /usr/lib/evas/modules/engines/software_x11/linux-gnueabi-armv7l-1.7.99/module.so
b5b67000 b5b69000 r-xp /usr/lib/libiniparser.so.0
b5b72000 b5b77000 r-xp /usr/lib/libappcore-common.so.1.1
b5b80000 b5b88000 r-xp /usr/lib/libcapi-system-system-settings.so.0.0.2
b5b89000 b5b8d000 r-xp /usr/lib/libcapi-appfw-application.so.0.3.2.5
b5b9a000 b5b9c000 r-xp /usr/lib/libXau.so.6.0.0
b5ba5000 b5bac000 r-xp /lib/libcrypt-2.13.so
b5bdc000 b5bde000 r-xp /usr/lib/libiri.so
b5be6000 b5d8e000 r-xp /usr/lib/libcrypto.so.1.0.0
b5da7000 b5df4000 r-xp /usr/lib/libssl.so.1.0.0
b5e01000 b5e2f000 r-xp /usr/lib/libidn.so.11.5.44
b5e37000 b5e40000 r-xp /usr/lib/libcares.so.2.1.0
b5e49000 b5e5c000 r-xp /usr/lib/libxcb.so.1.1.0
b5e65000 b5e67000 r-xp /usr/lib/journal/libjournal.so.0.1.0
b5e70000 b5e72000 r-xp /usr/lib/libSLP-db-util.so.0.1.0
b5e7b000 b5f47000 r-xp /usr/lib/libxml2.so.2.7.8
b5f54000 b5f56000 r-xp /usr/lib/libgmodule-2.0.so.0.3200.3
b5f5e000 b5f63000 r-xp /usr/lib/libffi.so.5.0.10
b5f6b000 b5f6c000 r-xp /usr/lib/libgthread-2.0.so.0.3200.3
b5f75000 b5f80000 r-xp /usr/lib/libgpg-error.so.0.15.0
b5f88000 b5f8b000 r-xp /lib/libattr.so.1.1.0
b5f93000 b6027000 r-xp /usr/lib/libstdc++.so.6.0.16
b603a000 b6056000 r-xp /usr/lib/libsecurity-server-commons.so.1.0.0
b605f000 b6077000 r-xp /usr/lib/libpng12.so.0.50.0
b6080000 b6096000 r-xp /lib/libexpat.so.1.5.2
b60a0000 b60e4000 r-xp /usr/lib/libcurl.so.4.3.0
b60ed000 b60f7000 r-xp /usr/lib/libXext.so.6.4.0
b6100000 b6103000 r-xp /usr/lib/libXtst.so.6.1.0
b610c000 b6112000 r-xp /usr/lib/libXrender.so.1.3.0
b611b000 b6121000 r-xp /usr/lib/libXrandr.so.2.2.0
b6129000 b612a000 r-xp /usr/lib/libXinerama.so.1.0.0
b6133000 b613c000 r-xp /usr/lib/libXi.so.6.1.0
b6144000 b6147000 r-xp /usr/lib/libXfixes.so.3.1.0
b614f000 b6151000 r-xp /usr/lib/libXgesture.so.7.0.0
b6159000 b615b000 r-xp /usr/lib/libXcomposite.so.1.0.0
b6164000 b6166000 r-xp /usr/lib/libXdamage.so.1.1.0
b616e000 b6175000 r-xp /usr/lib/libXcursor.so.1.0.2
b617d000 b6180000 r-xp /usr/lib/libecore_input_evas.so.1.7.99
b6188000 b618c000 r-xp /usr/lib/libecore_ipc.so.1.7.99
b6195000 b619a000 r-xp /usr/lib/libecore_fb.so.1.7.99
b61a4000 b6285000 r-xp /usr/lib/libX11.so.6.3.0
b6290000 b62b3000 r-xp /usr/lib/libjpeg.so.8.0.2
b62cb000 b62e1000 r-xp /lib/libz.so.1.2.5
b62e9000 b635e000 r-xp /usr/lib/libsqlite3.so.0.8.6
b6368000 b637d000 r-xp /usr/lib/libpkgmgr_parser.so.0.1.0
b6386000 b63ba000 r-xp /usr/lib/libgobject-2.0.so.0.3200.3
b63c3000 b6496000 r-xp /usr/lib/libgio-2.0.so.0.3200.3
b64a1000 b64b1000 r-xp /lib/libresolv-2.13.so
b64b5000 b6531000 r-xp /usr/lib/libgcrypt.so.20.0.3
b653d000 b6555000 r-xp /usr/lib/liblzma.so.5.0.3
b655e000 b6561000 r-xp /lib/libcap.so.2.21
b6569000 b658f000 r-xp /usr/lib/libsecurity-server-client.so.1.0.1
b6598000 b6599000 r-xp /usr/lib/libecore_imf_evas.so.1.7.99
b65a1000 b65a7000 r-xp /usr/lib/libecore_imf.so.1.7.99
b65af000 b65c6000 r-xp /usr/lib/liblua-5.1.so
b65d0000 b65d7000 r-xp /usr/lib/libembryo.so.1.7.99
b65df000 b65e5000 r-xp /lib/librt-2.13.so
b65ee000 b6644000 r-xp /usr/lib/libpixman-1.so.0.28.2
b6651000 b66a7000 r-xp /usr/lib/libfreetype.so.6.11.3
b66b3000 b66db000 r-xp /usr/lib/libfontconfig.so.1.8.0
b66dd000 b671a000 r-xp /usr/lib/libharfbuzz.so.0.940.0
b6723000 b6736000 r-xp /usr/lib/libfribidi.so.0.3.1
b673e000 b6758000 r-xp /usr/lib/libecore_con.so.1.7.99
b6761000 b676a000 r-xp /usr/lib/libedbus.so.1.7.99
b6772000 b67c2000 r-xp /usr/lib/libecore_x.so.1.7.99
b67c5000 b67c9000 r-xp /usr/lib/libvconf.so.0.2.45
b67d1000 b67e2000 r-xp /usr/lib/libecore_input.so.1.7.99
b67ea000 b67ef000 r-xp /usr/lib/libecore_file.so.1.7.99
b67f7000 b6819000 r-xp /usr/lib/libecore_evas.so.1.7.99
b6822000 b6863000 r-xp /usr/lib/libeina.so.1.7.99
b686c000 b6885000 r-xp /usr/lib/libeet.so.1.7.99
b6896000 b68ff000 r-xp /lib/libm-2.13.so
b6908000 b690e000 r-xp /usr/lib/libcapi-base-common.so.0.1.8
b6917000 b691a000 r-xp /usr/lib/libproc-stat.so.0.2.86
b6922000 b6944000 r-xp /usr/lib/libpkgmgr-info.so.0.0.17
b694c000 b6951000 r-xp /usr/lib/libxdgmime.so.1.1.0
b6959000 b6983000 r-xp /usr/lib/libdbus-1.so.3.8.12
b698c000 b69a3000 r-xp /usr/lib/libdbus-glib-1.so.2.2.2
b69ab000 b69b6000 r-xp /lib/libunwind.so.8.0.1
b69e3000 b6a1f000 r-xp /usr/lib/libsystemd.so.0.4.0
b6a28000 b6b43000 r-xp /lib/libc-2.13.so
b6b51000 b6b59000 r-xp /lib/libgcc_s-4.6.so.1
b6b5a000 b6b5d000 r-xp /usr/lib/libsmack.so.1.0.0
b6b65000 b6b6b000 r-xp /usr/lib/libprivilege-control.so.0.0.2
b6b73000 b6c43000 r-xp /usr/lib/libglib-2.0.so.0.3200.3
b6c44000 b6ca1000 r-xp /usr/lib/libedje.so.1.7.99
b6cab000 b6cc2000 r-xp /usr/lib/libecore.so.1.7.99
b6cd9000 b6da8000 r-xp /usr/lib/libevas.so.1.7.99
b6dcc000 b6f06000 r-xp /usr/lib/libelementary.so.1.7.99
b6f1c000 b6f30000 r-xp /lib/libpthread-2.13.so
b6f3b000 b6f3d000 r-xp /usr/lib/libdlog.so.0.0.0
b6f45000 b6f48000 r-xp /usr/lib/libbundle.so.0.1.22
b6f50000 b6f52000 r-xp /lib/libdl-2.13.so
b6f5b000 b6f67000 r-xp /usr/lib/libaul.so.0.1.0
b6f79000 b6f7e000 r-xp /usr/lib/libappcore-efl.so.1.1
b6f87000 b6f8b000 r-xp /usr/lib/libsys-assert.so
b6f94000 b6fb1000 r-xp /lib/ld-2.13.so
b6fba000 b6fbf000 r-xp /usr/bin/launchpad-loader
b8162000 b848c000 rw-p [heap]
be9cb000 be9ec000 rwxp [stack]
End of Maps Information

Callstack Information (PID:12744)
Call Stack Count: 4
 0: evas_object_evas_get + 0x5 (0xb6d06bde) [/usr/lib/libevas.so.1] + 0x2dbde
 1: elm_widget_add + 0xc (0xb6ebd32d) [/usr/lib/libelementary.so.1] + 0xf132d
 2: elm_genlist_add + 0x28 (0xb6e580bd) [/usr/lib/libelementary.so.1] + 0x8c0bd
 3: calorie_goal_cb + 0x44 (0xb583150d) [/opt/usr/apps/org.example.uicomponents/bin/uicomponents] + 0x550d
End of Call Stack

Package Information
Package Name: org.example.uicomponents
Package ID : org.example.uicomponents
Version: 1.0.0
Package Type: rpm
App Name: uicomponents
App ID: org.example.uicomponents
Type: capp
Categories: 

Latest Debug Message Information
--------- beginning of /dev/log_main
o apps display 
06-06 18:03:58.345+0900 I/APP_CORE(12744): appcore-efl.c: __do_app(429) > [APP 12744] Event: RESUME State: RUNNING
06-06 18:03:58.375+0900 I/wnotib  ( 1184): w-notification-board-broker-main.c: _wnotib_ecore_x_event_visibility_changed_cb(701) > fully_obscured: 1
06-06 18:03:58.375+0900 E/wnotib  ( 1184): w-notification-board-action-drawer.c: wnotib_action_drawer_hidden_get(4570) > [NULL==g_wnotib_action_drawer_data] msg Drawer not initialized.
06-06 18:03:58.805+0900 I/APP_CORE( 1184): appcore-efl.c: __do_app(429) > [APP 1184] Event: MEM_FLUSH State: PAUSED
06-06 18:03:59.015+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b829d2b8), block(1)
06-06 18:03:59.015+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b829d2b8), ev->cur.canvas.x(223) ev->cur.canvas.y(249)
06-06 18:03:59.015+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b829d2b8), hold(0) freeze(0)
06-06 18:03:59.015+0900 E/EFL     (12744): evas_main<12744> evas_events.c:1009 evas_event_feed_mouse_down() ButtonEvent:down time=8757834 button=1 downs=1
06-06 18:03:59.025+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b829d2b8), block(1)
06-06 18:03:59.025+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b829d2b8), ev->cur.canvas.x(220) ev->cur.canvas.y(245)
06-06 18:03:59.025+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b829d2b8), hold(0) freeze(0)
06-06 18:03:59.035+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b829d2b8), block(1)
06-06 18:03:59.035+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b829d2b8), ev->cur.canvas.x(215) ev->cur.canvas.y(240)
06-06 18:03:59.035+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b829d2b8), hold(0) freeze(0)
06-06 18:03:59.045+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b829d2b8), block(1)
06-06 18:03:59.045+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b829d2b8), ev->cur.canvas.x(210) ev->cur.canvas.y(234)
06-06 18:03:59.045+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b829d2b8), hold(0) freeze(0)
06-06 18:03:59.055+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b829d2b8), block(1)
06-06 18:03:59.055+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b829d2b8), ev->cur.canvas.x(208) ev->cur.canvas.y(228)
06-06 18:03:59.055+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b829d2b8), hold(0) freeze(0)
06-06 18:03:59.065+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b829d2b8), block(1)
06-06 18:03:59.065+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b829d2b8), ev->cur.canvas.x(204) ev->cur.canvas.y(220)
06-06 18:03:59.065+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b829d2b8), hold(0) freeze(0)
06-06 18:03:59.075+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b829d2b8), block(1)
06-06 18:03:59.075+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b829d2b8), ev->cur.canvas.x(203) ev->cur.canvas.y(206)
06-06 18:03:59.075+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b829d2b8), hold(0) freeze(0)
06-06 18:03:59.075+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:4249 _elm_scroll_mouse_move_event_cb() [DDO] animator
06-06 18:03:59.075+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3353 _elm_scroll_post_event_move() [DDO] obj(b829d2b8), type(elm_genlist)
06-06 18:03:59.075+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3354 _elm_scroll_post_event_move() [DDO] hold_parent(0)
06-06 18:03:59.075+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3405 _elm_scroll_post_event_move() [DDO] elm_widget_drag_lock_y_set : obj(b829d2b8), type(elm_genlist)
06-06 18:03:59.085+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b829d2b8), locked_x(0)
06-06 18:03:59.085+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b829d2b8)
06-06 18:03:59.125+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b829d2b8), block(1)
06-06 18:03:59.125+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b829d2b8), ev->cur.canvas.x(203) ev->cur.canvas.y(189)
06-06 18:03:59.125+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b829d2b8), hold(0) freeze(0)
06-06 18:03:59.125+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b829d2b8), block(1)
06-06 18:03:59.125+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b829d2b8), ev->cur.canvas.x(203) ev->cur.canvas.y(176)
06-06 18:03:59.125+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b829d2b8), hold(0) freeze(0)
06-06 18:03:59.125+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b829d2b8), block(1)
06-06 18:03:59.125+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b829d2b8), ev->cur.canvas.x(210) ev->cur.canvas.y(163)
06-06 18:03:59.125+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b829d2b8), hold(0) freeze(0)
06-06 18:03:59.125+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b829d2b8), block(1)
06-06 18:03:59.125+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b829d2b8), ev->cur.canvas.x(220) ev->cur.canvas.y(148)
06-06 18:03:59.125+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b829d2b8), hold(0) freeze(0)
06-06 18:03:59.125+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b829d2b8), block(1)
06-06 18:03:59.125+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b829d2b8), ev->cur.canvas.x(223) ev->cur.canvas.y(138)
06-06 18:03:59.125+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b829d2b8), hold(0) freeze(0)
06-06 18:03:59.135+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b829d2b8), locked_x(0)
06-06 18:03:59.135+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b829d2b8)
06-06 18:03:59.155+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b829d2b8), block(1)
06-06 18:03:59.155+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b829d2b8), ev->cur.canvas.x(228) ev->cur.canvas.y(130)
06-06 18:03:59.155+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b829d2b8), hold(0) freeze(0)
06-06 18:03:59.155+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b829d2b8), block(1)
06-06 18:03:59.155+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b829d2b8), ev->cur.canvas.x(231) ev->cur.canvas.y(122)
06-06 18:03:59.155+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b829d2b8), hold(0) freeze(0)
06-06 18:03:59.155+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b829d2b8), locked_x(0)
06-06 18:03:59.155+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b829d2b8)
06-06 18:03:59.185+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b829d2b8), block(1)
06-06 18:03:59.185+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b829d2b8), ev->cur.canvas.x(231) ev->cur.canvas.y(118)
06-06 18:03:59.185+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b829d2b8), hold(0) freeze(0)
06-06 18:03:59.185+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b829d2b8), block(1)
06-06 18:03:59.185+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b829d2b8), ev->cur.canvas.x(231) ev->cur.canvas.y(115)
06-06 18:03:59.185+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b829d2b8), hold(0) freeze(0)
06-06 18:03:59.185+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b829d2b8), locked_x(0)
06-06 18:03:59.185+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b829d2b8)
06-06 18:03:59.205+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b829d2b8), block(1)
06-06 18:03:59.205+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b829d2b8), ev->cur.canvas.x(231) ev->cur.canvas.y(113)
06-06 18:03:59.205+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b829d2b8), hold(0) freeze(0)
06-06 18:03:59.205+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b829d2b8), locked_x(0)
06-06 18:03:59.205+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b829d2b8)
06-06 18:03:59.235+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b829d2b8), locked_x(0)
06-06 18:03:59.245+0900 W/AUL_AMD (  905): amd_request.c: __request_handler(640) > __request_handler: 14
06-06 18:03:59.255+0900 W/AUL_AMD (  905): amd_request.c: __send_result_to_client(83) > __send_result_to_client, pid: 12744
06-06 18:03:59.255+0900 W/AUL_AMD (  905): amd_request.c: __request_handler(640) > __request_handler: 12
06-06 18:03:59.265+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b829d2b8), block(1)
06-06 18:03:59.265+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b829d2b8), ev->cur.canvas.x(233) ev->cur.canvas.y(114)
06-06 18:03:59.265+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b829d2b8), hold(0) freeze(0)
06-06 18:03:59.265+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b829d2b8), block(1)
06-06 18:03:59.265+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b829d2b8), ev->cur.canvas.x(236) ev->cur.canvas.y(117)
06-06 18:03:59.265+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b829d2b8), hold(0) freeze(0)
06-06 18:03:59.265+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b829d2b8), locked_x(0)
06-06 18:03:59.265+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b829d2b8)
06-06 18:03:59.285+0900 E/EFL     (12744): evas_main<12744> evas_events.c:1275 evas_event_feed_mouse_up() ButtonEvent:up time=8758089 button=1 downs=0
06-06 18:03:59.285+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:2278 _elm_scroll_post_event_up() [DDO] lock set false. : obj(b829d2b8), type(elm_genlist)
06-06 18:03:59.415+0900 I/APP_CORE( 7465): appcore-efl.c: __do_app(429) > [APP 7465] Event: MEM_FLUSH State: PAUSED
06-06 18:03:59.465+0900 I/AUL_PAD (12884): launchpad_loader.c: main(600) > [candidate] elm init, returned: 1
06-06 18:03:59.595+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b829d2b8), block(1)
06-06 18:03:59.595+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b829d2b8), ev->cur.canvas.x(215) ev->cur.canvas.y(189)
06-06 18:03:59.595+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b829d2b8), hold(0) freeze(0)
06-06 18:03:59.595+0900 E/EFL     (12744): evas_main<12744> evas_events.c:1009 evas_event_feed_mouse_down() ButtonEvent:down time=8758418 button=1 downs=1
06-06 18:03:59.605+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b829d2b8), block(1)
06-06 18:03:59.605+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b829d2b8), ev->cur.canvas.x(212) ev->cur.canvas.y(192)
06-06 18:03:59.605+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b829d2b8), hold(0) freeze(0)
06-06 18:03:59.625+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b829d2b8), block(1)
06-06 18:03:59.625+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b829d2b8), ev->cur.canvas.x(210) ev->cur.canvas.y(192)
06-06 18:03:59.625+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b829d2b8), hold(0) freeze(0)
06-06 18:03:59.635+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b829d2b8), block(1)
06-06 18:03:59.635+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b829d2b8), ev->cur.canvas.x(209) ev->cur.canvas.y(193)
06-06 18:03:59.635+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b829d2b8), hold(0) freeze(0)
06-06 18:03:59.645+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b829d2b8), block(1)
06-06 18:03:59.645+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b829d2b8), ev->cur.canvas.x(208) ev->cur.canvas.y(192)
06-06 18:03:59.645+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b829d2b8), hold(0) freeze(0)
06-06 18:03:59.655+0900 E/EFL     (12744): evas_main<12744> evas_events.c:1275 evas_event_feed_mouse_up() ButtonEvent:up time=8758472 button=1 downs=0
06-06 18:03:59.865+0900 I/efl-extension(12744): efl_extension_rotary.c: eext_rotary_object_event_callback_add(147) > In
06-06 18:03:59.865+0900 I/efl-extension(12744): efl_extension_rotary.c: eext_rotary_object_event_activated_set(283) > eext_rotary_object_event_activated_set : 0xb83a4630, elm_image, _activated_obj : 0xb3010708, activated : 1
06-06 18:03:59.865+0900 I/efl-extension(12744): efl_extension_rotary.c: eext_rotary_object_event_activated_set(291) > Activation delete!!!!
06-06 18:04:00.195+0900 E/TIZEN_N_SYSTEM_SETTINGS( 1282): system_settings.c: system_settings_get_value_string(522) > Enter [system_settings_get_value_string]
06-06 18:04:00.195+0900 E/TIZEN_N_SYSTEM_SETTINGS( 1282): system_settings.c: system_settings_get_value(386) > Enter [system_settings_get_value]
06-06 18:04:00.195+0900 E/TIZEN_N_SYSTEM_SETTINGS( 1282): system_settings.c: system_settings_get_item(361) > Enter [system_settings_get_item], key=13
06-06 18:04:00.195+0900 E/TIZEN_N_SYSTEM_SETTINGS( 1282): system_settings.c: system_settings_get_item(374) > Enter [system_settings_get_item], index = 13, key = 13, type = 0
06-06 18:04:00.405+0900 W/APPS    ( 1184): apps_main.c: _time_changed_cb(294) >  date : 6->6
06-06 18:04:00.735+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), block(1)
06-06 18:04:00.745+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), ev->cur.canvas.x(231) ev->cur.canvas.y(225)
06-06 18:04:00.745+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), hold(0) freeze(0)
06-06 18:04:00.745+0900 E/EFL     (12744): evas_main<12744> evas_events.c:1009 evas_event_feed_mouse_down() ButtonEvent:down time=8759556 button=1 downs=1
06-06 18:04:00.745+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), block(1)
06-06 18:04:00.745+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), ev->cur.canvas.x(232) ev->cur.canvas.y(225)
06-06 18:04:00.745+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), hold(0) freeze(0)
06-06 18:04:00.755+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), block(1)
06-06 18:04:00.755+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), ev->cur.canvas.x(232) ev->cur.canvas.y(228)
06-06 18:04:00.755+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), hold(0) freeze(0)
06-06 18:04:00.765+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), block(1)
06-06 18:04:00.765+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), ev->cur.canvas.x(231) ev->cur.canvas.y(228)
06-06 18:04:00.765+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), hold(0) freeze(0)
06-06 18:04:00.775+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), block(1)
06-06 18:04:00.775+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), ev->cur.canvas.x(231) ev->cur.canvas.y(226)
06-06 18:04:00.775+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), hold(0) freeze(0)
06-06 18:04:00.785+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), block(1)
06-06 18:04:00.785+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), ev->cur.canvas.x(231) ev->cur.canvas.y(224)
06-06 18:04:00.785+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), hold(0) freeze(0)
06-06 18:04:00.805+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), block(1)
06-06 18:04:00.805+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), ev->cur.canvas.x(231) ev->cur.canvas.y(222)
06-06 18:04:00.805+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), hold(0) freeze(0)
06-06 18:04:00.815+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), block(1)
06-06 18:04:00.815+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), ev->cur.canvas.x(231) ev->cur.canvas.y(219)
06-06 18:04:00.815+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), hold(0) freeze(0)
06-06 18:04:00.825+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), block(1)
06-06 18:04:00.825+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), ev->cur.canvas.x(231) ev->cur.canvas.y(212)
06-06 18:04:00.825+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), hold(0) freeze(0)
06-06 18:04:00.825+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), block(1)
06-06 18:04:00.825+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), ev->cur.canvas.x(232) ev->cur.canvas.y(201)
06-06 18:04:00.825+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), hold(0) freeze(0)
06-06 18:04:00.845+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), block(1)
06-06 18:04:00.845+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), ev->cur.canvas.x(233) ev->cur.canvas.y(191)
06-06 18:04:00.845+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), hold(0) freeze(0)
06-06 18:04:00.865+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), block(1)
06-06 18:04:00.865+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), ev->cur.canvas.x(233) ev->cur.canvas.y(186)
06-06 18:04:00.865+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), hold(0) freeze(0)
06-06 18:04:00.865+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:4249 _elm_scroll_mouse_move_event_cb() [DDO] animator
06-06 18:04:00.865+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3353 _elm_scroll_post_event_move() [DDO] obj(b8354160), type(elm_genlist)
06-06 18:04:00.865+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3354 _elm_scroll_post_event_move() [DDO] hold_parent(0)
06-06 18:04:00.865+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3405 _elm_scroll_post_event_move() [DDO] elm_widget_drag_lock_y_set : obj(b8354160), type(elm_genlist)
06-06 18:04:00.865+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), block(1)
06-06 18:04:00.865+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), ev->cur.canvas.x(235) ev->cur.canvas.y(181)
06-06 18:04:00.865+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), hold(0) freeze(0)
06-06 18:04:00.885+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), block(1)
06-06 18:04:00.885+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), ev->cur.canvas.x(238) ev->cur.canvas.y(176)
06-06 18:04:00.885+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), hold(0) freeze(0)
06-06 18:04:00.885+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), block(1)
06-06 18:04:00.885+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), ev->cur.canvas.x(240) ev->cur.canvas.y(170)
06-06 18:04:00.885+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), hold(0) freeze(0)
06-06 18:04:00.885+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b8354160), locked_x(0)
06-06 18:04:00.885+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b8354160)
06-06 18:04:00.925+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), block(1)
06-06 18:04:00.925+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), ev->cur.canvas.x(240) ev->cur.canvas.y(166)
06-06 18:04:00.925+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), hold(0) freeze(0)
06-06 18:04:00.925+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), block(1)
06-06 18:04:00.925+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), ev->cur.canvas.x(241) ev->cur.canvas.y(164)
06-06 18:04:00.925+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), hold(0) freeze(0)
06-06 18:04:00.935+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), block(1)
06-06 18:04:00.935+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), ev->cur.canvas.x(242) ev->cur.canvas.y(159)
06-06 18:04:00.935+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), hold(0) freeze(0)
06-06 18:04:00.935+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), block(1)
06-06 18:04:00.935+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), ev->cur.canvas.x(244) ev->cur.canvas.y(153)
06-06 18:04:00.935+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), hold(0) freeze(0)
06-06 18:04:00.935+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b8354160), locked_x(0)
06-06 18:04:00.935+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b8354160)
06-06 18:04:00.955+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), block(1)
06-06 18:04:00.955+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), ev->cur.canvas.x(247) ev->cur.canvas.y(149)
06-06 18:04:00.955+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), hold(0) freeze(0)
06-06 18:04:00.955+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), block(1)
06-06 18:04:00.955+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), ev->cur.canvas.x(248) ev->cur.canvas.y(144)
06-06 18:04:00.955+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), hold(0) freeze(0)
06-06 18:04:00.955+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b8354160), locked_x(0)
06-06 18:04:00.955+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b8354160)
06-06 18:04:00.975+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), block(1)
06-06 18:04:00.975+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), ev->cur.canvas.x(249) ev->cur.canvas.y(140)
06-06 18:04:00.975+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), hold(0) freeze(0)
06-06 18:04:00.975+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), block(1)
06-06 18:04:00.975+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), ev->cur.canvas.x(249) ev->cur.canvas.y(139)
06-06 18:04:00.975+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), hold(0) freeze(0)
06-06 18:04:00.975+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b8354160), locked_x(0)
06-06 18:04:00.975+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b8354160)
06-06 18:04:01.005+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), block(1)
06-06 18:04:01.005+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), ev->cur.canvas.x(250) ev->cur.canvas.y(137)
06-06 18:04:01.005+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), hold(0) freeze(0)
06-06 18:04:01.005+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), block(1)
06-06 18:04:01.005+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), ev->cur.canvas.x(250) ev->cur.canvas.y(135)
06-06 18:04:01.005+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), hold(0) freeze(0)
06-06 18:04:01.005+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), block(1)
06-06 18:04:01.005+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), ev->cur.canvas.x(250) ev->cur.canvas.y(134)
06-06 18:04:01.005+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), hold(0) freeze(0)
06-06 18:04:01.005+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b8354160), locked_x(0)
06-06 18:04:01.005+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b8354160)
06-06 18:04:01.035+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), block(1)
06-06 18:04:01.035+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), ev->cur.canvas.x(250) ev->cur.canvas.y(133)
06-06 18:04:01.035+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), hold(0) freeze(0)
06-06 18:04:01.035+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), block(1)
06-06 18:04:01.035+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), ev->cur.canvas.x(250) ev->cur.canvas.y(132)
06-06 18:04:01.035+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), hold(0) freeze(0)
06-06 18:04:01.035+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b8354160), locked_x(0)
06-06 18:04:01.035+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b8354160)
06-06 18:04:01.055+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), block(1)
06-06 18:04:01.055+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), ev->cur.canvas.x(251) ev->cur.canvas.y(131)
06-06 18:04:01.055+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), hold(0) freeze(0)
06-06 18:04:01.055+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), block(1)
06-06 18:04:01.055+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), ev->cur.canvas.x(251) ev->cur.canvas.y(130)
06-06 18:04:01.055+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), hold(0) freeze(0)
06-06 18:04:01.055+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b8354160), locked_x(0)
06-06 18:04:01.055+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b8354160)
06-06 18:04:01.075+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), block(1)
06-06 18:04:01.075+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), ev->cur.canvas.x(251) ev->cur.canvas.y(129)
06-06 18:04:01.075+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), hold(0) freeze(0)
06-06 18:04:01.075+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), block(1)
06-06 18:04:01.075+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), ev->cur.canvas.x(251) ev->cur.canvas.y(126)
06-06 18:04:01.075+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), hold(0) freeze(0)
06-06 18:04:01.075+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b8354160), locked_x(0)
06-06 18:04:01.075+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b8354160)
06-06 18:04:01.095+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), block(1)
06-06 18:04:01.095+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), ev->cur.canvas.x(252) ev->cur.canvas.y(124)
06-06 18:04:01.095+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), hold(0) freeze(0)
06-06 18:04:01.095+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), block(1)
06-06 18:04:01.095+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), ev->cur.canvas.x(252) ev->cur.canvas.y(122)
06-06 18:04:01.095+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), hold(0) freeze(0)
06-06 18:04:01.095+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b8354160), locked_x(0)
06-06 18:04:01.095+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b8354160)
06-06 18:04:01.115+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), block(1)
06-06 18:04:01.115+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), ev->cur.canvas.x(253) ev->cur.canvas.y(120)
06-06 18:04:01.115+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), hold(0) freeze(0)
06-06 18:04:01.115+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), block(1)
06-06 18:04:01.115+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), ev->cur.canvas.x(253) ev->cur.canvas.y(119)
06-06 18:04:01.115+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), hold(0) freeze(0)
06-06 18:04:01.115+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b8354160), locked_x(0)
06-06 18:04:01.115+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b8354160)
06-06 18:04:01.135+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), block(1)
06-06 18:04:01.135+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), ev->cur.canvas.x(253) ev->cur.canvas.y(118)
06-06 18:04:01.135+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), hold(0) freeze(0)
06-06 18:04:01.135+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b8354160), locked_x(0)
06-06 18:04:01.135+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b8354160)
06-06 18:04:01.155+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), block(1)
06-06 18:04:01.155+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), ev->cur.canvas.x(254) ev->cur.canvas.y(117)
06-06 18:04:01.155+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), hold(0) freeze(0)
06-06 18:04:01.155+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b8354160), locked_x(0)
06-06 18:04:01.155+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b8354160)
06-06 18:04:01.155+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b8354160), locked_x(0)
06-06 18:04:01.155+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b8354160), locked_x(0)
06-06 18:04:01.155+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b8354160), locked_x(0)
06-06 18:04:01.155+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b8354160), locked_x(0)
06-06 18:04:01.155+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b8354160), locked_x(0)
06-06 18:04:01.155+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b8354160), locked_x(0)
06-06 18:04:01.165+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b8354160), locked_x(0)
06-06 18:04:01.185+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b8354160), locked_x(0)
06-06 18:04:01.185+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), block(1)
06-06 18:04:01.185+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), ev->cur.canvas.x(255) ev->cur.canvas.y(117)
06-06 18:04:01.185+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), hold(0) freeze(0)
06-06 18:04:01.205+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), block(1)
06-06 18:04:01.205+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), ev->cur.canvas.x(258) ev->cur.canvas.y(117)
06-06 18:04:01.205+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), hold(0) freeze(0)
06-06 18:04:01.205+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b8354160), locked_x(0)
06-06 18:04:01.205+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b8354160)
06-06 18:04:01.205+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), block(1)
06-06 18:04:01.205+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), ev->cur.canvas.x(262) ev->cur.canvas.y(115)
06-06 18:04:01.205+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), hold(0) freeze(0)
06-06 18:04:01.215+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b8354160), locked_x(0)
06-06 18:04:01.215+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b8354160)
06-06 18:04:01.245+0900 E/EFL     (12744): evas_main<12744> evas_events.c:1275 evas_event_feed_mouse_up() ButtonEvent:up time=8760037 button=1 downs=0
06-06 18:04:01.245+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:2278 _elm_scroll_post_event_up() [DDO] lock set false. : obj(b8354160), type(elm_genlist)
06-06 18:04:01.705+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), block(1)
06-06 18:04:01.705+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), ev->cur.canvas.x(231) ev->cur.canvas.y(203)
06-06 18:04:01.705+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), hold(0) freeze(0)
06-06 18:04:01.705+0900 E/EFL     (12744): evas_main<12744> evas_events.c:1009 evas_event_feed_mouse_down() ButtonEvent:down time=8760512 button=1 downs=1
06-06 18:04:01.705+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), block(1)
06-06 18:04:01.705+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), ev->cur.canvas.x(230) ev->cur.canvas.y(209)
06-06 18:04:01.705+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), hold(0) freeze(0)
06-06 18:04:01.735+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), block(1)
06-06 18:04:01.735+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), ev->cur.canvas.x(230) ev->cur.canvas.y(214)
06-06 18:04:01.735+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), hold(0) freeze(0)
06-06 18:04:01.735+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), block(1)
06-06 18:04:01.735+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), ev->cur.canvas.x(229) ev->cur.canvas.y(214)
06-06 18:04:01.735+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), hold(0) freeze(0)
06-06 18:04:01.755+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), block(1)
06-06 18:04:01.755+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), ev->cur.canvas.x(227) ev->cur.canvas.y(214)
06-06 18:04:01.755+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), hold(0) freeze(0)
06-06 18:04:01.755+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), block(1)
06-06 18:04:01.755+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), ev->cur.canvas.x(226) ev->cur.canvas.y(208)
06-06 18:04:01.755+0900 E/EFL     (12744): elementary<12744> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8354160), hold(0) freeze(0)
06-06 18:04:01.765+0900 E/EFL     (12744): evas_main<12744> evas_events.c:1275 evas_event_feed_mouse_up() ButtonEvent:up time=8760576 button=1 downs=0
06-06 18:04:01.885+0900 W/CRASH_MANAGER(12784): worker.c: worker_job(1199) > 1112744756963146520384
