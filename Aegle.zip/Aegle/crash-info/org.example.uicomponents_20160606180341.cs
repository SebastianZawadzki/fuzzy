S/W Version Information
Model: SM-R735S
Tizen-Version: 2.3.1.2
Build-Number: R735SKSU1AOKE
Build-Date: 2015.11.25 20:46:58

Crash Information
Process Name: uicomponents
PID: 12325
Date: 2016-06-06 18:03:41+0900
Executable File Path: /opt/usr/apps/org.example.uicomponents/bin/uicomponents
Signal: 11
      (SIGSEGV)
      si_code: -6
      signal sent by tkill (sent by pid 12325, uid 5000)

Register Information
r0   = 0x71737723, r1   = 0x71737723
r2   = 0x00000001, r3   = 0x00000000
r4   = 0x71737723, r5   = 0xb6eda9f8
r6   = 0xb7fda8e0, r7   = 0xbec6a3e8
r8   = 0xb6c8e9c0, r9   = 0xb7ed2a10
r10  = 0xb6ed2e9c, fp   = 0x00000000
ip   = 0xb6ed4428, sp   = 0xbec6a310
lr   = 0xb6e8132d, pc   = 0xb6ccabde
cpsr = 0xa0000030

Memory Information
MemTotal:   407572 KB
MemFree:      8460 KB
Buffers:     12848 KB
Cached:      93616 KB
VmPeak:      77456 KB
VmSize:      75292 KB
VmLck:           0 KB
VmPin:           0 KB
VmHWM:       19696 KB
VmRSS:       19696 KB
VmData:      16728 KB
VmStk:         136 KB
VmExe:          20 KB
VmLib:       24764 KB
VmPTE:          56 KB
VmSwap:          0 KB

Threads Information
Threads: 2
PID = 12325 TID = 12325
12325 12768 

Maps Information
b28c5000 b28c9000 r-xp /usr/lib/libogg.so.0.7.1
b28d1000 b28f3000 r-xp /usr/lib/libvorbis.so.0.4.3
b28fb000 b2903000 r-xp /usr/lib/libmdm-common.so.1.0.89
b2904000 b2947000 r-xp /usr/lib/libsndfile.so.1.0.25
b2954000 b299c000 r-xp /usr/lib/pulseaudio/libpulsecommon-4.0.so
b299d000 b29a2000 r-xp /usr/lib/libjson.so.0.0.1
b29aa000 b29db000 r-xp /usr/lib/libmdm.so.1.1.85
b29e3000 b29eb000 r-xp /usr/lib/lib_DNSe_NRSS_ver225.so
b29fa000 b2a0a000 r-xp /usr/lib/lib_SamsungRec_TizenV04014.so
b2a2b000 b2a38000 r-xp /usr/lib/libail.so.0.1.0
b2a41000 b2a44000 r-xp /usr/lib/libsyspopup_caller.so.0.1.0
b2a4c000 b2a84000 r-xp /usr/lib/libpulse.so.0.16.2
b2a85000 b2ae6000 r-xp /usr/lib/libasound.so.2.0.0
b2af0000 b2af3000 r-xp /usr/lib/libpulse-simple.so.0.0.4
b2afb000 b2b00000 r-xp /usr/lib/libascenario-0.2.so.0.0.0
b2b08000 b2b21000 r-xp /usr/lib/libavsysaudio.so.0.0.1
b2b2a000 b2b2e000 r-xp /usr/lib/libmmfsoundcommon.so.0.0.0
b2b37000 b2b41000 r-xp /usr/lib/libaudio-session-mgr.so.0.0.0
b2b4d000 b2b52000 r-xp /usr/lib/libmmfsession.so.0.0.0
b2b5a000 b2b70000 r-xp /usr/lib/libmmfsound.so.0.1.0
b2b82000 b2b89000 r-xp /usr/lib/libmmfcommon.so.0.0.0
b2b91000 b2b9b000 r-xp /usr/lib/libcapi-media-sound-manager.so.0.1.48
b2ba3000 b2ba5000 r-xp /usr/lib/libcapi-media-wav-player.so.0.1.10
b2bad000 b2bae000 r-xp /usr/lib/libmmfkeysound.so.0.0.0
b2bb6000 b2bbd000 r-xp /usr/lib/libfeedback.so.0.1.4
b2bc6000 b2bc7000 r-xp /usr/lib/edje/modules/feedback/linux-gnueabi-armv7l-1.0.0/module.so
b2bcf000 b2c56000 rw-s anon_inode:dmabuf
b2c56000 b2cdd000 rw-s anon_inode:dmabuf
b2d68000 b2def000 rw-s anon_inode:dmabuf
b2e6e000 b2ef5000 rw-s anon_inode:dmabuf
b31a5000 b39a4000 rwxp [stack:12768]
b39a4000 b39bb000 r-xp /usr/lib/edje/modules/elm/linux-gnueabi-armv7l-1.0.0/module.so
b39c8000 b39ca000 r-xp /usr/lib/libgenlock.so
b39d3000 b39d4000 r-xp /usr/lib/evas/modules/loaders/eet/linux-gnueabi-armv7l-1.7.99/module.so
b39dc000 b39de000 r-xp /usr/lib/evas/modules/loaders/png/linux-gnueabi-armv7l-1.7.99/module.so
b39e8000 b39ed000 r-xp /usr/lib/bufmgr/libtbm_msm.so.0.0.0
b39f5000 b3a00000 r-xp /usr/lib/evas/modules/engines/software_generic/linux-gnueabi-armv7l-1.7.99/module.so
b3d28000 b3df2000 r-xp /usr/lib/libCOREGL.so.4.0
b3e03000 b3e08000 r-xp /usr/lib/libcapi-media-tool.so.0.1.5
b3e10000 b3e31000 r-xp /usr/lib/libexif.so.12.3.3
b3e44000 b3e49000 r-xp /usr/lib/libmmutil_imgp.so.0.0.0
b3e51000 b3e56000 r-xp /usr/lib/libmmutil_jpeg.so.0.0.0
b53e5000 b53e7000 r-xp /usr/lib/libdri2.so.0.0.0
b53ef000 b53f7000 r-xp /usr/lib/libdrm.so.2.4.0
b53ff000 b5402000 r-xp /usr/lib/libcapi-media-image-util.so.0.3.5
b540a000 b54ee000 r-xp /usr/lib/libicuuc.so.51.1
b5503000 b5640000 r-xp /usr/lib/libicui18n.so.51.1
b5650000 b5655000 r-xp /usr/lib/libcapi-system-info.so.0.2.0
b565d000 b5663000 r-xp /usr/lib/libxcb-render.so.0.0.0
b566b000 b566c000 r-xp /usr/lib/libxcb-shm.so.0.0.0
b5675000 b5678000 r-xp /usr/lib/libEGL.so.1.4
b5680000 b568e000 r-xp /usr/lib/libGLESv2.so.2.0
b5697000 b569e000 r-xp /usr/lib/libtbm.so.1.0.0
b56a6000 b56c7000 r-xp /usr/lib/libui-extension.so.0.1.0
b56d0000 b56e2000 r-xp /usr/lib/libtts.so
b56ea000 b57a2000 r-xp /usr/lib/libcairo.so.2.11200.14
b57ad000 b57bf000 r-xp /usr/lib/libefl-assist.so.0.1.0
b57c7000 b57e8000 r-xp /usr/lib/libefl-extension.so.0.1.0
b57f0000 b5803000 r-xp /opt/usr/apps/org.example.uicomponents/bin/uicomponents
b59ca000 b59d4000 r-xp /lib/libnss_files-2.13.so
b59dd000 b5aac000 r-xp /usr/lib/libscim-1.0.so.8.2.3
b5ac2000 b5ae6000 r-xp /usr/lib/ecore/immodules/libisf-imf-module.so
b5aef000 b5af5000 r-xp /usr/lib/libappsvc.so.0.1.0
b5afd000 b5aff000 r-xp /usr/lib/libcapi-appfw-app-common.so.0.3.2.5
b5b08000 b5b0d000 r-xp /usr/lib/libcapi-appfw-app-control.so.0.3.2.5
b5b18000 b5b23000 r-xp /usr/lib/evas/modules/engines/software_x11/linux-gnueabi-armv7l-1.7.99/module.so
b5b2b000 b5b2d000 r-xp /usr/lib/libiniparser.so.0
b5b36000 b5b3b000 r-xp /usr/lib/libappcore-common.so.1.1
b5b44000 b5b4c000 r-xp /usr/lib/libcapi-system-system-settings.so.0.0.2
b5b4d000 b5b51000 r-xp /usr/lib/libcapi-appfw-application.so.0.3.2.5
b5b5e000 b5b60000 r-xp /usr/lib/libXau.so.6.0.0
b5b69000 b5b70000 r-xp /lib/libcrypt-2.13.so
b5ba0000 b5ba2000 r-xp /usr/lib/libiri.so
b5baa000 b5d52000 r-xp /usr/lib/libcrypto.so.1.0.0
b5d6b000 b5db8000 r-xp /usr/lib/libssl.so.1.0.0
b5dc5000 b5df3000 r-xp /usr/lib/libidn.so.11.5.44
b5dfb000 b5e04000 r-xp /usr/lib/libcares.so.2.1.0
b5e0d000 b5e20000 r-xp /usr/lib/libxcb.so.1.1.0
b5e29000 b5e2b000 r-xp /usr/lib/journal/libjournal.so.0.1.0
b5e34000 b5e36000 r-xp /usr/lib/libSLP-db-util.so.0.1.0
b5e3f000 b5f0b000 r-xp /usr/lib/libxml2.so.2.7.8
b5f18000 b5f1a000 r-xp /usr/lib/libgmodule-2.0.so.0.3200.3
b5f22000 b5f27000 r-xp /usr/lib/libffi.so.5.0.10
b5f2f000 b5f30000 r-xp /usr/lib/libgthread-2.0.so.0.3200.3
b5f39000 b5f44000 r-xp /usr/lib/libgpg-error.so.0.15.0
b5f4c000 b5f4f000 r-xp /lib/libattr.so.1.1.0
b5f57000 b5feb000 r-xp /usr/lib/libstdc++.so.6.0.16
b5ffe000 b601a000 r-xp /usr/lib/libsecurity-server-commons.so.1.0.0
b6023000 b603b000 r-xp /usr/lib/libpng12.so.0.50.0
b6044000 b605a000 r-xp /lib/libexpat.so.1.5.2
b6064000 b60a8000 r-xp /usr/lib/libcurl.so.4.3.0
b60b1000 b60bb000 r-xp /usr/lib/libXext.so.6.4.0
b60c4000 b60c7000 r-xp /usr/lib/libXtst.so.6.1.0
b60d0000 b60d6000 r-xp /usr/lib/libXrender.so.1.3.0
b60df000 b60e5000 r-xp /usr/lib/libXrandr.so.2.2.0
b60ed000 b60ee000 r-xp /usr/lib/libXinerama.so.1.0.0
b60f7000 b6100000 r-xp /usr/lib/libXi.so.6.1.0
b6108000 b610b000 r-xp /usr/lib/libXfixes.so.3.1.0
b6113000 b6115000 r-xp /usr/lib/libXgesture.so.7.0.0
b611d000 b611f000 r-xp /usr/lib/libXcomposite.so.1.0.0
b6128000 b612a000 r-xp /usr/lib/libXdamage.so.1.1.0
b6132000 b6139000 r-xp /usr/lib/libXcursor.so.1.0.2
b6141000 b6144000 r-xp /usr/lib/libecore_input_evas.so.1.7.99
b614c000 b6150000 r-xp /usr/lib/libecore_ipc.so.1.7.99
b6159000 b615e000 r-xp /usr/lib/libecore_fb.so.1.7.99
b6168000 b6249000 r-xp /usr/lib/libX11.so.6.3.0
b6254000 b6277000 r-xp /usr/lib/libjpeg.so.8.0.2
b628f000 b62a5000 r-xp /lib/libz.so.1.2.5
b62ad000 b6322000 r-xp /usr/lib/libsqlite3.so.0.8.6
b632c000 b6341000 r-xp /usr/lib/libpkgmgr_parser.so.0.1.0
b634a000 b637e000 r-xp /usr/lib/libgobject-2.0.so.0.3200.3
b6387000 b645a000 r-xp /usr/lib/libgio-2.0.so.0.3200.3
b6465000 b6475000 r-xp /lib/libresolv-2.13.so
b6479000 b64f5000 r-xp /usr/lib/libgcrypt.so.20.0.3
b6501000 b6519000 r-xp /usr/lib/liblzma.so.5.0.3
b6522000 b6525000 r-xp /lib/libcap.so.2.21
b652d000 b6553000 r-xp /usr/lib/libsecurity-server-client.so.1.0.1
b655c000 b655d000 r-xp /usr/lib/libecore_imf_evas.so.1.7.99
b6565000 b656b000 r-xp /usr/lib/libecore_imf.so.1.7.99
b6573000 b658a000 r-xp /usr/lib/liblua-5.1.so
b6594000 b659b000 r-xp /usr/lib/libembryo.so.1.7.99
b65a3000 b65a9000 r-xp /lib/librt-2.13.so
b65b2000 b6608000 r-xp /usr/lib/libpixman-1.so.0.28.2
b6615000 b666b000 r-xp /usr/lib/libfreetype.so.6.11.3
b6677000 b669f000 r-xp /usr/lib/libfontconfig.so.1.8.0
b66a1000 b66de000 r-xp /usr/lib/libharfbuzz.so.0.940.0
b66e7000 b66fa000 r-xp /usr/lib/libfribidi.so.0.3.1
b6702000 b671c000 r-xp /usr/lib/libecore_con.so.1.7.99
b6725000 b672e000 r-xp /usr/lib/libedbus.so.1.7.99
b6736000 b6786000 r-xp /usr/lib/libecore_x.so.1.7.99
b6789000 b678d000 r-xp /usr/lib/libvconf.so.0.2.45
b6795000 b67a6000 r-xp /usr/lib/libecore_input.so.1.7.99
b67ae000 b67b3000 r-xp /usr/lib/libecore_file.so.1.7.99
b67bb000 b67dd000 r-xp /usr/lib/libecore_evas.so.1.7.99
b67e6000 b6827000 r-xp /usr/lib/libeina.so.1.7.99
b6830000 b6849000 r-xp /usr/lib/libeet.so.1.7.99
b685a000 b68c3000 r-xp /lib/libm-2.13.so
b68cc000 b68d2000 r-xp /usr/lib/libcapi-base-common.so.0.1.8
b68db000 b68de000 r-xp /usr/lib/libproc-stat.so.0.2.86
b68e6000 b6908000 r-xp /usr/lib/libpkgmgr-info.so.0.0.17
b6910000 b6915000 r-xp /usr/lib/libxdgmime.so.1.1.0
b691d000 b6947000 r-xp /usr/lib/libdbus-1.so.3.8.12
b6950000 b6967000 r-xp /usr/lib/libdbus-glib-1.so.2.2.2
b696f000 b697a000 r-xp /lib/libunwind.so.8.0.1
b69a7000 b69e3000 r-xp /usr/lib/libsystemd.so.0.4.0
b69ec000 b6b07000 r-xp /lib/libc-2.13.so
b6b15000 b6b1d000 r-xp /lib/libgcc_s-4.6.so.1
b6b1e000 b6b21000 r-xp /usr/lib/libsmack.so.1.0.0
b6b29000 b6b2f000 r-xp /usr/lib/libprivilege-control.so.0.0.2
b6b37000 b6c07000 r-xp /usr/lib/libglib-2.0.so.0.3200.3
b6c08000 b6c65000 r-xp /usr/lib/libedje.so.1.7.99
b6c6f000 b6c86000 r-xp /usr/lib/libecore.so.1.7.99
b6c9d000 b6d6c000 r-xp /usr/lib/libevas.so.1.7.99
b6d90000 b6eca000 r-xp /usr/lib/libelementary.so.1.7.99
b6ee0000 b6ef4000 r-xp /lib/libpthread-2.13.so
b6eff000 b6f01000 r-xp /usr/lib/libdlog.so.0.0.0
b6f09000 b6f0c000 r-xp /usr/lib/libbundle.so.0.1.22
b6f14000 b6f16000 r-xp /lib/libdl-2.13.so
b6f1f000 b6f2b000 r-xp /usr/lib/libaul.so.0.1.0
b6f3d000 b6f42000 r-xp /usr/lib/libappcore-efl.so.1.1
b6f4b000 b6f4f000 r-xp /usr/lib/libsys-assert.so
b6f58000 b6f75000 r-xp /lib/ld-2.13.so
b6f7e000 b6f83000 r-xp /usr/bin/launchpad-loader
b7e9a000 b81c6000 rw-p [heap]
bec4a000 bec6b000 rwxp [stack]
End of Maps Information

Callstack Information (PID:12325)
Call Stack Count: 4
 0: evas_object_evas_get + 0x5 (0xb6ccabde) [/usr/lib/libevas.so.1] + 0x2dbde
 1: elm_widget_add + 0xc (0xb6e8132d) [/usr/lib/libelementary.so.1] + 0xf132d
 2: elm_genlist_add + 0x28 (0xb6e1c0bd) [/usr/lib/libelementary.so.1] + 0x8c0bd
 3: calorie_goal_cb + 0x44 (0xb57f550d) [/opt/usr/apps/org.example.uicomponents/bin/uicomponents] + 0x550d
End of Call Stack

Package Information
Package Name: org.example.uicomponents
Package ID : org.example.uicomponents
Version: 1.0.0
Package Type: rpm
App Name: uicomponents
App ID: org.example.uicomponents
Type: capp
Categories: 

Latest Debug Message Information
--------- beginning of /dev/log_main
l_mouse_move_event_cb() [DDO] obj(b7fd53a0), hold(0) freeze(0)
06-06 18:03:36.925+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b7fd53a0), locked_x(0)
06-06 18:03:36.925+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b7fd53a0)
06-06 18:03:36.945+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7fd53a0), block(1)
06-06 18:03:36.945+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7fd53a0), ev->cur.canvas.x(218) ev->cur.canvas.y(123)
06-06 18:03:36.945+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7fd53a0), hold(0) freeze(0)
06-06 18:03:36.945+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7fd53a0), block(1)
06-06 18:03:36.945+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7fd53a0), ev->cur.canvas.x(219) ev->cur.canvas.y(120)
06-06 18:03:36.945+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7fd53a0), hold(0) freeze(0)
06-06 18:03:36.945+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b7fd53a0), locked_x(0)
06-06 18:03:36.945+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b7fd53a0)
06-06 18:03:36.965+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7fd53a0), block(1)
06-06 18:03:36.965+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7fd53a0), ev->cur.canvas.x(222) ev->cur.canvas.y(117)
06-06 18:03:36.965+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7fd53a0), hold(0) freeze(0)
06-06 18:03:36.965+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7fd53a0), block(1)
06-06 18:03:36.965+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7fd53a0), ev->cur.canvas.x(225) ev->cur.canvas.y(113)
06-06 18:03:36.965+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7fd53a0), hold(0) freeze(0)
06-06 18:03:36.965+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b7fd53a0), locked_x(0)
06-06 18:03:36.965+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b7fd53a0)
06-06 18:03:36.985+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7fd53a0), block(1)
06-06 18:03:36.985+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7fd53a0), ev->cur.canvas.x(227) ev->cur.canvas.y(110)
06-06 18:03:36.985+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7fd53a0), hold(0) freeze(0)
06-06 18:03:36.985+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7fd53a0), block(1)
06-06 18:03:36.985+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7fd53a0), ev->cur.canvas.x(228) ev->cur.canvas.y(102)
06-06 18:03:36.985+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7fd53a0), hold(0) freeze(0)
06-06 18:03:36.995+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b7fd53a0), locked_x(0)
06-06 18:03:36.995+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b7fd53a0)
06-06 18:03:37.015+0900 E/EFL     (12325): evas_main<12325> evas_events.c:1275 evas_event_feed_mouse_up() ButtonEvent:up time=8735811 button=1 downs=0
06-06 18:03:37.015+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:2278 _elm_scroll_post_event_up() [DDO] lock set false. : obj(b7fd53a0), type(elm_genlist)
06-06 18:03:37.535+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7fd53a0), block(1)
06-06 18:03:37.535+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7fd53a0), ev->cur.canvas.x(230) ev->cur.canvas.y(138)
06-06 18:03:37.535+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7fd53a0), hold(0) freeze(0)
06-06 18:03:37.535+0900 E/EFL     (12325): evas_main<12325> evas_events.c:1009 evas_event_feed_mouse_down() ButtonEvent:down time=8736346 button=1 downs=1
06-06 18:03:37.555+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7fd53a0), block(1)
06-06 18:03:37.555+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7fd53a0), ev->cur.canvas.x(219) ev->cur.canvas.y(145)
06-06 18:03:37.555+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7fd53a0), hold(0) freeze(0)
06-06 18:03:37.555+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7fd53a0), block(1)
06-06 18:03:37.555+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7fd53a0), ev->cur.canvas.x(208) ev->cur.canvas.y(151)
06-06 18:03:37.555+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7fd53a0), hold(0) freeze(0)
06-06 18:03:37.575+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7fd53a0), block(1)
06-06 18:03:37.575+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7fd53a0), ev->cur.canvas.x(205) ev->cur.canvas.y(158)
06-06 18:03:37.575+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7fd53a0), hold(0) freeze(0)
06-06 18:03:37.575+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7fd53a0), block(1)
06-06 18:03:37.575+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7fd53a0), ev->cur.canvas.x(202) ev->cur.canvas.y(164)
06-06 18:03:37.575+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7fd53a0), hold(0) freeze(0)
06-06 18:03:37.575+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:4249 _elm_scroll_mouse_move_event_cb() [DDO] animator
06-06 18:03:37.575+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3353 _elm_scroll_post_event_move() [DDO] obj(b7fd53a0), type(elm_genlist)
06-06 18:03:37.575+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3354 _elm_scroll_post_event_move() [DDO] hold_parent(0)
06-06 18:03:37.575+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3382 _elm_scroll_post_event_move() [DDO] elm_widget_drag_lock_x_set : obj(b7fd53a0), type(elm_genlist)
06-06 18:03:37.575+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3405 _elm_scroll_post_event_move() [DDO] elm_widget_drag_lock_y_set : obj(b7fd53a0), type(elm_genlist)
06-06 18:03:37.585+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b7fd53a0), locked_x(0)
06-06 18:03:37.585+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3843 _elm_scroll_hold_animator() [DDO] obj(b7fd53a0)
06-06 18:03:37.585+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b7fd53a0)
06-06 18:03:37.605+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7fd53a0), block(1)
06-06 18:03:37.605+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7fd53a0), ev->cur.canvas.x(200) ev->cur.canvas.y(168)
06-06 18:03:37.605+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7fd53a0), hold(0) freeze(0)
06-06 18:03:37.605+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7fd53a0), block(1)
06-06 18:03:37.605+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7fd53a0), ev->cur.canvas.x(198) ev->cur.canvas.y(174)
06-06 18:03:37.605+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7fd53a0), hold(0) freeze(0)
06-06 18:03:37.605+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b7fd53a0), locked_x(0)
06-06 18:03:37.605+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3843 _elm_scroll_hold_animator() [DDO] obj(b7fd53a0)
06-06 18:03:37.605+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b7fd53a0)
06-06 18:03:37.625+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7fd53a0), block(1)
06-06 18:03:37.625+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7fd53a0), ev->cur.canvas.x(197) ev->cur.canvas.y(181)
06-06 18:03:37.625+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7fd53a0), hold(0) freeze(0)
06-06 18:03:37.625+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7fd53a0), block(1)
06-06 18:03:37.625+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7fd53a0), ev->cur.canvas.x(194) ev->cur.canvas.y(187)
06-06 18:03:37.625+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7fd53a0), hold(0) freeze(0)
06-06 18:03:37.625+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b7fd53a0), locked_x(0)
06-06 18:03:37.625+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3843 _elm_scroll_hold_animator() [DDO] obj(b7fd53a0)
06-06 18:03:37.625+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b7fd53a0)
06-06 18:03:37.645+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7fd53a0), block(1)
06-06 18:03:37.645+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7fd53a0), ev->cur.canvas.x(189) ev->cur.canvas.y(191)
06-06 18:03:37.645+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7fd53a0), hold(0) freeze(0)
06-06 18:03:37.645+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7fd53a0), block(1)
06-06 18:03:37.645+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7fd53a0), ev->cur.canvas.x(188) ev->cur.canvas.y(194)
06-06 18:03:37.645+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7fd53a0), hold(0) freeze(0)
06-06 18:03:37.645+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b7fd53a0), locked_x(0)
06-06 18:03:37.645+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3843 _elm_scroll_hold_animator() [DDO] obj(b7fd53a0)
06-06 18:03:37.645+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b7fd53a0)
06-06 18:03:37.665+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7fd53a0), block(1)
06-06 18:03:37.665+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7fd53a0), ev->cur.canvas.x(188) ev->cur.canvas.y(197)
06-06 18:03:37.665+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7fd53a0), hold(0) freeze(0)
06-06 18:03:37.665+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7fd53a0), block(1)
06-06 18:03:37.665+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7fd53a0), ev->cur.canvas.x(187) ev->cur.canvas.y(202)
06-06 18:03:37.665+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7fd53a0), hold(0) freeze(0)
06-06 18:03:37.665+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b7fd53a0), locked_x(0)
06-06 18:03:37.665+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3843 _elm_scroll_hold_animator() [DDO] obj(b7fd53a0)
06-06 18:03:37.665+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b7fd53a0)
06-06 18:03:37.685+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7fd53a0), block(1)
06-06 18:03:37.685+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7fd53a0), ev->cur.canvas.x(186) ev->cur.canvas.y(207)
06-06 18:03:37.685+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7fd53a0), hold(0) freeze(0)
06-06 18:03:37.685+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7fd53a0), block(1)
06-06 18:03:37.685+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7fd53a0), ev->cur.canvas.x(185) ev->cur.canvas.y(211)
06-06 18:03:37.685+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7fd53a0), hold(0) freeze(0)
06-06 18:03:37.685+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b7fd53a0), locked_x(0)
06-06 18:03:37.685+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3843 _elm_scroll_hold_animator() [DDO] obj(b7fd53a0)
06-06 18:03:37.685+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b7fd53a0)
06-06 18:03:37.705+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7fd53a0), block(1)
06-06 18:03:37.705+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7fd53a0), ev->cur.canvas.x(185) ev->cur.canvas.y(213)
06-06 18:03:37.705+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7fd53a0), hold(0) freeze(0)
06-06 18:03:37.705+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7fd53a0), block(1)
06-06 18:03:37.705+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7fd53a0), ev->cur.canvas.x(185) ev->cur.canvas.y(215)
06-06 18:03:37.705+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7fd53a0), hold(0) freeze(0)
06-06 18:03:37.705+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b7fd53a0), locked_x(0)
06-06 18:03:37.705+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3843 _elm_scroll_hold_animator() [DDO] obj(b7fd53a0)
06-06 18:03:37.705+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b7fd53a0)
06-06 18:03:37.725+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7fd53a0), block(1)
06-06 18:03:37.725+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7fd53a0), ev->cur.canvas.x(185) ev->cur.canvas.y(218)
06-06 18:03:37.725+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7fd53a0), hold(0) freeze(0)
06-06 18:03:37.725+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7fd53a0), block(1)
06-06 18:03:37.725+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7fd53a0), ev->cur.canvas.x(185) ev->cur.canvas.y(220)
06-06 18:03:37.725+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7fd53a0), hold(0) freeze(0)
06-06 18:03:37.725+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b7fd53a0), locked_x(0)
06-06 18:03:37.725+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3843 _elm_scroll_hold_animator() [DDO] obj(b7fd53a0)
06-06 18:03:37.725+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b7fd53a0)
06-06 18:03:37.745+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7fd53a0), block(1)
06-06 18:03:37.745+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7fd53a0), ev->cur.canvas.x(185) ev->cur.canvas.y(222)
06-06 18:03:37.745+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7fd53a0), hold(0) freeze(0)
06-06 18:03:37.745+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7fd53a0), block(1)
06-06 18:03:37.745+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7fd53a0), ev->cur.canvas.x(185) ev->cur.canvas.y(223)
06-06 18:03:37.745+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7fd53a0), hold(0) freeze(0)
06-06 18:03:37.745+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b7fd53a0), locked_x(0)
06-06 18:03:37.745+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3843 _elm_scroll_hold_animator() [DDO] obj(b7fd53a0)
06-06 18:03:37.745+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b7fd53a0)
06-06 18:03:37.765+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7fd53a0), block(1)
06-06 18:03:37.765+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7fd53a0), ev->cur.canvas.x(185) ev->cur.canvas.y(225)
06-06 18:03:37.765+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7fd53a0), hold(0) freeze(0)
06-06 18:03:37.765+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7fd53a0), block(1)
06-06 18:03:37.765+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7fd53a0), ev->cur.canvas.x(185) ev->cur.canvas.y(226)
06-06 18:03:37.765+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7fd53a0), hold(0) freeze(0)
06-06 18:03:37.765+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b7fd53a0), locked_x(0)
06-06 18:03:37.765+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3843 _elm_scroll_hold_animator() [DDO] obj(b7fd53a0)
06-06 18:03:37.765+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b7fd53a0)
06-06 18:03:37.785+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7fd53a0), block(1)
06-06 18:03:37.785+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7fd53a0), ev->cur.canvas.x(185) ev->cur.canvas.y(227)
06-06 18:03:37.785+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7fd53a0), hold(0) freeze(0)
06-06 18:03:37.785+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7fd53a0), block(1)
06-06 18:03:37.785+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7fd53a0), ev->cur.canvas.x(185) ev->cur.canvas.y(228)
06-06 18:03:37.785+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7fd53a0), hold(0) freeze(0)
06-06 18:03:37.785+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b7fd53a0), locked_x(0)
06-06 18:03:37.785+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3843 _elm_scroll_hold_animator() [DDO] obj(b7fd53a0)
06-06 18:03:37.785+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b7fd53a0)
06-06 18:03:37.805+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7fd53a0), block(1)
06-06 18:03:37.805+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7fd53a0), ev->cur.canvas.x(185) ev->cur.canvas.y(229)
06-06 18:03:37.805+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7fd53a0), hold(0) freeze(0)
06-06 18:03:37.805+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b7fd53a0), locked_x(0)
06-06 18:03:37.805+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3843 _elm_scroll_hold_animator() [DDO] obj(b7fd53a0)
06-06 18:03:37.805+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b7fd53a0)
06-06 18:03:37.825+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7fd53a0), block(1)
06-06 18:03:37.825+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7fd53a0), ev->cur.canvas.x(185) ev->cur.canvas.y(230)
06-06 18:03:37.825+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7fd53a0), hold(0) freeze(0)
06-06 18:03:37.825+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b7fd53a0), locked_x(0)
06-06 18:03:37.825+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3843 _elm_scroll_hold_animator() [DDO] obj(b7fd53a0)
06-06 18:03:37.825+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b7fd53a0)
06-06 18:03:37.845+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7fd53a0), block(1)
06-06 18:03:37.845+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7fd53a0), ev->cur.canvas.x(185) ev->cur.canvas.y(231)
06-06 18:03:37.845+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7fd53a0), hold(0) freeze(0)
06-06 18:03:37.845+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b7fd53a0), locked_x(0)
06-06 18:03:37.845+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3843 _elm_scroll_hold_animator() [DDO] obj(b7fd53a0)
06-06 18:03:37.845+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b7fd53a0)
06-06 18:03:37.855+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7fd53a0), block(1)
06-06 18:03:37.855+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7fd53a0), ev->cur.canvas.x(185) ev->cur.canvas.y(232)
06-06 18:03:37.855+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7fd53a0), hold(0) freeze(0)
06-06 18:03:37.865+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b7fd53a0), locked_x(0)
06-06 18:03:37.865+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3843 _elm_scroll_hold_animator() [DDO] obj(b7fd53a0)
06-06 18:03:37.865+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b7fd53a0)
06-06 18:03:37.875+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b7fd53a0), locked_x(0)
06-06 18:03:37.875+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b7fd53a0), locked_x(0)
06-06 18:03:37.875+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b7fd53a0), locked_x(0)
06-06 18:03:37.885+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b7fd53a0), locked_x(0)
06-06 18:03:37.895+0900 E/EFL     (12325): evas_main<12325> evas_events.c:1275 evas_event_feed_mouse_up() ButtonEvent:up time=8736713 button=1 downs=0
06-06 18:03:37.895+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:2278 _elm_scroll_post_event_up() [DDO] lock set false. : obj(b7fd53a0), type(elm_genlist)
06-06 18:03:38.435+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7fd53a0), block(1)
06-06 18:03:38.435+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7fd53a0), ev->cur.canvas.x(227) ev->cur.canvas.y(184)
06-06 18:03:38.435+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7fd53a0), hold(0) freeze(0)
06-06 18:03:38.435+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7fd53a0), block(1)
06-06 18:03:38.435+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7fd53a0), ev->cur.canvas.x(216) ev->cur.canvas.y(188)
06-06 18:03:38.435+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7fd53a0), hold(0) freeze(0)
06-06 18:03:38.435+0900 E/EFL     (12325): evas_main<12325> evas_events.c:1009 evas_event_feed_mouse_down() ButtonEvent:down time=8737244 button=1 downs=1
06-06 18:03:38.455+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7fd53a0), block(1)
06-06 18:03:38.455+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7fd53a0), ev->cur.canvas.x(208) ev->cur.canvas.y(190)
06-06 18:03:38.455+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7fd53a0), hold(0) freeze(0)
06-06 18:03:38.485+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7fd53a0), block(1)
06-06 18:03:38.485+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7fd53a0), ev->cur.canvas.x(213) ev->cur.canvas.y(190)
06-06 18:03:38.485+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7fd53a0), hold(0) freeze(0)
06-06 18:03:38.485+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7fd53a0), block(1)
06-06 18:03:38.485+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7fd53a0), ev->cur.canvas.x(221) ev->cur.canvas.y(188)
06-06 18:03:38.485+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7fd53a0), hold(0) freeze(0)
06-06 18:03:38.505+0900 E/EFL     (12325): evas_main<12325> evas_events.c:1275 evas_event_feed_mouse_up() ButtonEvent:up time=8737309 button=1 downs=0
06-06 18:03:38.715+0900 I/efl-extension(12325): efl_extension_rotary.c: eext_rotary_object_event_callback_add(147) > In
06-06 18:03:38.715+0900 I/efl-extension(12325): efl_extension_rotary.c: eext_rotary_object_event_activated_set(283) > eext_rotary_object_event_activated_set : 0xb80e21e0, elm_image, _activated_obj : 0xb3010708, activated : 1
06-06 18:03:38.715+0900 I/efl-extension(12325): efl_extension_rotary.c: eext_rotary_object_event_activated_set(291) > Activation delete!!!!
06-06 18:03:39.535+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b808d220), block(1)
06-06 18:03:39.535+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b808d220), ev->cur.canvas.x(215) ev->cur.canvas.y(204)
06-06 18:03:39.535+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b808d220), hold(0) freeze(0)
06-06 18:03:39.535+0900 E/EFL     (12325): evas_main<12325> evas_events.c:1009 evas_event_feed_mouse_down() ButtonEvent:down time=8738355 button=1 downs=1
06-06 18:03:39.535+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b808d220), block(1)
06-06 18:03:39.535+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b808d220), ev->cur.canvas.x(211) ev->cur.canvas.y(203)
06-06 18:03:39.535+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b808d220), hold(0) freeze(0)
06-06 18:03:39.545+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b808d220), block(1)
06-06 18:03:39.545+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b808d220), ev->cur.canvas.x(206) ev->cur.canvas.y(201)
06-06 18:03:39.545+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b808d220), hold(0) freeze(0)
06-06 18:03:39.565+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b808d220), block(1)
06-06 18:03:39.565+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b808d220), ev->cur.canvas.x(206) ev->cur.canvas.y(198)
06-06 18:03:39.565+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b808d220), hold(0) freeze(0)
06-06 18:03:39.575+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b808d220), block(1)
06-06 18:03:39.575+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b808d220), ev->cur.canvas.x(206) ev->cur.canvas.y(194)
06-06 18:03:39.575+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b808d220), hold(0) freeze(0)
06-06 18:03:39.575+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b808d220), block(1)
06-06 18:03:39.575+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b808d220), ev->cur.canvas.x(206) ev->cur.canvas.y(189)
06-06 18:03:39.575+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b808d220), hold(0) freeze(0)
06-06 18:03:39.595+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b808d220), block(1)
06-06 18:03:39.595+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b808d220), ev->cur.canvas.x(206) ev->cur.canvas.y(182)
06-06 18:03:39.595+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b808d220), hold(0) freeze(0)
06-06 18:03:39.605+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b808d220), block(1)
06-06 18:03:39.605+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b808d220), ev->cur.canvas.x(214) ev->cur.canvas.y(175)
06-06 18:03:39.605+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b808d220), hold(0) freeze(0)
06-06 18:03:39.615+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b808d220), block(1)
06-06 18:03:39.615+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b808d220), ev->cur.canvas.x(221) ev->cur.canvas.y(171)
06-06 18:03:39.615+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b808d220), hold(0) freeze(0)
06-06 18:03:39.625+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b808d220), block(1)
06-06 18:03:39.625+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b808d220), ev->cur.canvas.x(223) ev->cur.canvas.y(167)
06-06 18:03:39.625+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b808d220), hold(0) freeze(0)
06-06 18:03:39.625+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:4249 _elm_scroll_mouse_move_event_cb() [DDO] animator
06-06 18:03:39.625+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3353 _elm_scroll_post_event_move() [DDO] obj(b808d220), type(elm_genlist)
06-06 18:03:39.625+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3354 _elm_scroll_post_event_move() [DDO] hold_parent(0)
06-06 18:03:39.625+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3405 _elm_scroll_post_event_move() [DDO] elm_widget_drag_lock_y_set : obj(b808d220), type(elm_genlist)
06-06 18:03:39.635+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b808d220), locked_x(0)
06-06 18:03:39.635+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b808d220)
06-06 18:03:39.675+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b808d220), block(1)
06-06 18:03:39.675+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b808d220), ev->cur.canvas.x(226) ev->cur.canvas.y(158)
06-06 18:03:39.675+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b808d220), hold(0) freeze(0)
06-06 18:03:39.675+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b808d220), block(1)
06-06 18:03:39.675+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b808d220), ev->cur.canvas.x(228) ev->cur.canvas.y(150)
06-06 18:03:39.675+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b808d220), hold(0) freeze(0)
06-06 18:03:39.675+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b808d220), block(1)
06-06 18:03:39.675+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b808d220), ev->cur.canvas.x(229) ev->cur.canvas.y(147)
06-06 18:03:39.675+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b808d220), hold(0) freeze(0)
06-06 18:03:39.675+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b808d220), block(1)
06-06 18:03:39.675+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b808d220), ev->cur.canvas.x(231) ev->cur.canvas.y(143)
06-06 18:03:39.675+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b808d220), hold(0) freeze(0)
06-06 18:03:39.675+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b808d220), locked_x(0)
06-06 18:03:39.675+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b808d220)
06-06 18:03:39.705+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b808d220), block(1)
06-06 18:03:39.705+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b808d220), ev->cur.canvas.x(233) ev->cur.canvas.y(140)
06-06 18:03:39.705+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b808d220), hold(0) freeze(0)
06-06 18:03:39.705+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b808d220), block(1)
06-06 18:03:39.705+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b808d220), ev->cur.canvas.x(234) ev->cur.canvas.y(138)
06-06 18:03:39.705+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b808d220), hold(0) freeze(0)
06-06 18:03:39.705+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b808d220), block(1)
06-06 18:03:39.705+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b808d220), ev->cur.canvas.x(235) ev->cur.canvas.y(136)
06-06 18:03:39.705+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b808d220), hold(0) freeze(0)
06-06 18:03:39.705+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b808d220), locked_x(0)
06-06 18:03:39.705+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b808d220)
06-06 18:03:39.725+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b808d220), block(1)
06-06 18:03:39.725+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b808d220), ev->cur.canvas.x(237) ev->cur.canvas.y(132)
06-06 18:03:39.725+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b808d220), hold(0) freeze(0)
06-06 18:03:39.725+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b808d220), block(1)
06-06 18:03:39.725+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b808d220), ev->cur.canvas.x(239) ev->cur.canvas.y(129)
06-06 18:03:39.725+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b808d220), hold(0) freeze(0)
06-06 18:03:39.725+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b808d220), block(1)
06-06 18:03:39.725+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b808d220), ev->cur.canvas.x(240) ev->cur.canvas.y(126)
06-06 18:03:39.725+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b808d220), hold(0) freeze(0)
06-06 18:03:39.735+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b808d220), locked_x(0)
06-06 18:03:39.735+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b808d220)
06-06 18:03:39.755+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b808d220), block(1)
06-06 18:03:39.755+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b808d220), ev->cur.canvas.x(242) ev->cur.canvas.y(124)
06-06 18:03:39.755+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b808d220), hold(0) freeze(0)
06-06 18:03:39.755+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b808d220), block(1)
06-06 18:03:39.755+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b808d220), ev->cur.canvas.x(243) ev->cur.canvas.y(121)
06-06 18:03:39.755+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b808d220), hold(0) freeze(0)
06-06 18:03:39.755+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b808d220), locked_x(0)
06-06 18:03:39.755+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b808d220)
06-06 18:03:39.775+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b808d220), block(1)
06-06 18:03:39.775+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b808d220), ev->cur.canvas.x(244) ev->cur.canvas.y(119)
06-06 18:03:39.775+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b808d220), hold(0) freeze(0)
06-06 18:03:39.775+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b808d220), block(1)
06-06 18:03:39.775+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b808d220), ev->cur.canvas.x(245) ev->cur.canvas.y(117)
06-06 18:03:39.775+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b808d220), hold(0) freeze(0)
06-06 18:03:39.775+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b808d220), locked_x(0)
06-06 18:03:39.775+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b808d220)
06-06 18:03:39.805+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b808d220), block(1)
06-06 18:03:39.805+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b808d220), ev->cur.canvas.x(247) ev->cur.canvas.y(116)
06-06 18:03:39.805+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b808d220), hold(0) freeze(0)
06-06 18:03:39.805+0900 E/EFL     (12325): evas_main<12325> evas_events.c:1275 evas_event_feed_mouse_up() ButtonEvent:up time=8738615 button=1 downs=0
06-06 18:03:39.805+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:2278 _elm_scroll_post_event_up() [DDO] lock set false. : obj(b808d220), type(elm_genlist)
06-06 18:03:41.455+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b808d220), block(1)
06-06 18:03:41.455+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b808d220), ev->cur.canvas.x(237) ev->cur.canvas.y(199)
06-06 18:03:41.455+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b808d220), hold(0) freeze(0)
06-06 18:03:41.465+0900 E/EFL     (12325): evas_main<12325> evas_events.c:1009 evas_event_feed_mouse_down() ButtonEvent:down time=8740277 button=1 downs=1
06-06 18:03:41.495+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b808d220), block(1)
06-06 18:03:41.495+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b808d220), ev->cur.canvas.x(237) ev->cur.canvas.y(197)
06-06 18:03:41.495+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b808d220), hold(0) freeze(0)
06-06 18:03:41.515+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b808d220), block(1)
06-06 18:03:41.515+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b808d220), ev->cur.canvas.x(241) ev->cur.canvas.y(193)
06-06 18:03:41.515+0900 E/EFL     (12325): elementary<12325> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b808d220), hold(0) freeze(0)
06-06 18:03:41.525+0900 E/EFL     (12325): evas_main<12325> evas_events.c:1275 evas_event_feed_mouse_up() ButtonEvent:up time=8740341 button=1 downs=0
06-06 18:03:41.795+0900 W/CRASH_MANAGER(12784): worker.c: worker_job(1199) > 1112325756963146520382
