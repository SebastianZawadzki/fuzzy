S/W Version Information
Model: SM-R735S
Tizen-Version: 2.3.1.2
Build-Number: R735SKSU1AOKE
Build-Date: 2015.11.25 20:46:58

Crash Information
Process Name: uicomponents
PID: 18545
Date: 2016-06-06 18:59:59+0900
Executable File Path: /opt/usr/apps/org.example.uicomponents/bin/uicomponents
Signal: 11
      (SIGSEGV)
      si_code: -6
      signal sent by tkill (sent by pid 18545, uid 5000)

Register Information
r0   = 0x71737723, r1   = 0x71737723
r2   = 0x00000001, r3   = 0x00000000
r4   = 0x71737723, r5   = 0xb6f1b9f8
r6   = 0xb7dce268, r7   = 0xbed0b3e8
r8   = 0xb6ccf9c0, r9   = 0xb7cdd3a8
r10  = 0xb6f13e9c, fp   = 0x00000000
ip   = 0xb6f15428, sp   = 0xbed0b2d0
lr   = 0xb6ec232d, pc   = 0xb6d0bbde
cpsr = 0xa0000030

Memory Information
MemTotal:   407572 KB
MemFree:     15760 KB
Buffers:     11100 KB
Cached:      91224 KB
VmPeak:      79708 KB
VmSize:      77544 KB
VmLck:           0 KB
VmPin:           0 KB
VmHWM:       20924 KB
VmRSS:       20924 KB
VmData:      17564 KB
VmStk:         136 KB
VmExe:          20 KB
VmLib:       24848 KB
VmPTE:          58 KB
VmSwap:          0 KB

Threads Information
Threads: 2
PID = 18545 TID = 18545
18545 18617 

Maps Information
b28ad000 b28bd000 r-xp /usr/lib/scim-1.0/1.4.0/IMEngine/socket.so
b28c5000 b28c9000 r-xp /usr/lib/libogg.so.0.7.1
b28d1000 b28f3000 r-xp /usr/lib/libvorbis.so.0.4.3
b28fb000 b2903000 r-xp /usr/lib/libmdm-common.so.1.0.89
b2904000 b2947000 r-xp /usr/lib/libsndfile.so.1.0.25
b2954000 b299c000 r-xp /usr/lib/pulseaudio/libpulsecommon-4.0.so
b299d000 b29a2000 r-xp /usr/lib/libjson.so.0.0.1
b29aa000 b29db000 r-xp /usr/lib/libmdm.so.1.1.85
b29e3000 b29eb000 r-xp /usr/lib/lib_DNSe_NRSS_ver225.so
b29fa000 b2a0a000 r-xp /usr/lib/lib_SamsungRec_TizenV04014.so
b2a2b000 b2a38000 r-xp /usr/lib/libail.so.0.1.0
b2a41000 b2a44000 r-xp /usr/lib/libsyspopup_caller.so.0.1.0
b2a4c000 b2a84000 r-xp /usr/lib/libpulse.so.0.16.2
b2a85000 b2ae6000 r-xp /usr/lib/libasound.so.2.0.0
b2af0000 b2af5000 r-xp /usr/lib/libascenario-0.2.so.0.0.0
b2afd000 b2b16000 r-xp /usr/lib/libavsysaudio.so.0.0.1
b2b1f000 b2b23000 r-xp /usr/lib/libmmfsoundcommon.so.0.0.0
b2b2c000 b2b36000 r-xp /usr/lib/libaudio-session-mgr.so.0.0.0
b2b42000 b2b47000 r-xp /usr/lib/libmmfsession.so.0.0.0
b2b4f000 b2b65000 r-xp /usr/lib/libmmfsound.so.0.1.0
b2b77000 b2b7e000 r-xp /usr/lib/libmmfcommon.so.0.0.0
b2b86000 b2b87000 r-xp /usr/lib/edje/modules/feedback/linux-gnueabi-armv7l-1.0.0/module.so
b2b8f000 b2c16000 rw-s anon_inode:dmabuf
b2c16000 b2c9d000 rw-s anon_inode:dmabuf
b2d28000 b2daf000 rw-s anon_inode:dmabuf
b2e2e000 b2eb5000 rw-s anon_inode:dmabuf
b3101000 b3104000 r-xp /usr/lib/libpulse-simple.so.0.0.4
b310c000 b3116000 r-xp /usr/lib/libcapi-media-sound-manager.so.0.1.48
b311e000 b3120000 r-xp /usr/lib/libcapi-media-wav-player.so.0.1.10
b3128000 b3129000 r-xp /usr/lib/libmmfkeysound.so.0.0.0
b3131000 b3138000 r-xp /usr/lib/libfeedback.so.0.1.4
b3143000 b3148000 r-xp /usr/lib/scim-1.0/1.4.0/Config/socket.so
b31e6000 b39e5000 rwxp [stack:18617]
b39e5000 b39fc000 r-xp /usr/lib/edje/modules/elm/linux-gnueabi-armv7l-1.0.0/module.so
b3a09000 b3a0b000 r-xp /usr/lib/libgenlock.so
b3a14000 b3a15000 r-xp /usr/lib/evas/modules/loaders/eet/linux-gnueabi-armv7l-1.7.99/module.so
b3a1d000 b3a1f000 r-xp /usr/lib/evas/modules/loaders/png/linux-gnueabi-armv7l-1.7.99/module.so
b3a29000 b3a2e000 r-xp /usr/lib/bufmgr/libtbm_msm.so.0.0.0
b3a36000 b3a41000 r-xp /usr/lib/evas/modules/engines/software_generic/linux-gnueabi-armv7l-1.7.99/module.so
b3d69000 b3e33000 r-xp /usr/lib/libCOREGL.so.4.0
b3e44000 b3e49000 r-xp /usr/lib/libcapi-media-tool.so.0.1.5
b3e51000 b3e72000 r-xp /usr/lib/libexif.so.12.3.3
b3e85000 b3e8a000 r-xp /usr/lib/libmmutil_imgp.so.0.0.0
b3e92000 b3e97000 r-xp /usr/lib/libmmutil_jpeg.so.0.0.0
b5426000 b5428000 r-xp /usr/lib/libdri2.so.0.0.0
b5430000 b5438000 r-xp /usr/lib/libdrm.so.2.4.0
b5440000 b5443000 r-xp /usr/lib/libcapi-media-image-util.so.0.3.5
b544b000 b552f000 r-xp /usr/lib/libicuuc.so.51.1
b5544000 b5681000 r-xp /usr/lib/libicui18n.so.51.1
b5691000 b5696000 r-xp /usr/lib/libcapi-system-info.so.0.2.0
b569e000 b56a4000 r-xp /usr/lib/libxcb-render.so.0.0.0
b56ac000 b56ad000 r-xp /usr/lib/libxcb-shm.so.0.0.0
b56b6000 b56b9000 r-xp /usr/lib/libEGL.so.1.4
b56c1000 b56cf000 r-xp /usr/lib/libGLESv2.so.2.0
b56d8000 b56df000 r-xp /usr/lib/libtbm.so.1.0.0
b56e7000 b5708000 r-xp /usr/lib/libui-extension.so.0.1.0
b5711000 b5723000 r-xp /usr/lib/libtts.so
b572b000 b57e3000 r-xp /usr/lib/libcairo.so.2.11200.14
b57ee000 b5800000 r-xp /usr/lib/libefl-assist.so.0.1.0
b5808000 b5829000 r-xp /usr/lib/libefl-extension.so.0.1.0
b5831000 b5844000 r-xp /opt/usr/apps/org.example.uicomponents/bin/uicomponents
b5a0b000 b5a15000 r-xp /lib/libnss_files-2.13.so
b5a1e000 b5aed000 r-xp /usr/lib/libscim-1.0.so.8.2.3
b5b03000 b5b27000 r-xp /usr/lib/ecore/immodules/libisf-imf-module.so
b5b30000 b5b36000 r-xp /usr/lib/libappsvc.so.0.1.0
b5b3e000 b5b40000 r-xp /usr/lib/libcapi-appfw-app-common.so.0.3.2.5
b5b49000 b5b4e000 r-xp /usr/lib/libcapi-appfw-app-control.so.0.3.2.5
b5b59000 b5b64000 r-xp /usr/lib/evas/modules/engines/software_x11/linux-gnueabi-armv7l-1.7.99/module.so
b5b6c000 b5b6e000 r-xp /usr/lib/libiniparser.so.0
b5b77000 b5b7c000 r-xp /usr/lib/libappcore-common.so.1.1
b5b85000 b5b8d000 r-xp /usr/lib/libcapi-system-system-settings.so.0.0.2
b5b8e000 b5b92000 r-xp /usr/lib/libcapi-appfw-application.so.0.3.2.5
b5b9f000 b5ba1000 r-xp /usr/lib/libXau.so.6.0.0
b5baa000 b5bb1000 r-xp /lib/libcrypt-2.13.so
b5be1000 b5be3000 r-xp /usr/lib/libiri.so
b5beb000 b5d93000 r-xp /usr/lib/libcrypto.so.1.0.0
b5dac000 b5df9000 r-xp /usr/lib/libssl.so.1.0.0
b5e06000 b5e34000 r-xp /usr/lib/libidn.so.11.5.44
b5e3c000 b5e45000 r-xp /usr/lib/libcares.so.2.1.0
b5e4e000 b5e61000 r-xp /usr/lib/libxcb.so.1.1.0
b5e6a000 b5e6c000 r-xp /usr/lib/journal/libjournal.so.0.1.0
b5e75000 b5e77000 r-xp /usr/lib/libSLP-db-util.so.0.1.0
b5e80000 b5f4c000 r-xp /usr/lib/libxml2.so.2.7.8
b5f59000 b5f5b000 r-xp /usr/lib/libgmodule-2.0.so.0.3200.3
b5f63000 b5f68000 r-xp /usr/lib/libffi.so.5.0.10
b5f70000 b5f71000 r-xp /usr/lib/libgthread-2.0.so.0.3200.3
b5f7a000 b5f85000 r-xp /usr/lib/libgpg-error.so.0.15.0
b5f8d000 b5f90000 r-xp /lib/libattr.so.1.1.0
b5f98000 b602c000 r-xp /usr/lib/libstdc++.so.6.0.16
b603f000 b605b000 r-xp /usr/lib/libsecurity-server-commons.so.1.0.0
b6064000 b607c000 r-xp /usr/lib/libpng12.so.0.50.0
b6085000 b609b000 r-xp /lib/libexpat.so.1.5.2
b60a5000 b60e9000 r-xp /usr/lib/libcurl.so.4.3.0
b60f2000 b60fc000 r-xp /usr/lib/libXext.so.6.4.0
b6105000 b6108000 r-xp /usr/lib/libXtst.so.6.1.0
b6111000 b6117000 r-xp /usr/lib/libXrender.so.1.3.0
b6120000 b6126000 r-xp /usr/lib/libXrandr.so.2.2.0
b612e000 b612f000 r-xp /usr/lib/libXinerama.so.1.0.0
b6138000 b6141000 r-xp /usr/lib/libXi.so.6.1.0
b6149000 b614c000 r-xp /usr/lib/libXfixes.so.3.1.0
b6154000 b6156000 r-xp /usr/lib/libXgesture.so.7.0.0
b615e000 b6160000 r-xp /usr/lib/libXcomposite.so.1.0.0
b6169000 b616b000 r-xp /usr/lib/libXdamage.so.1.1.0
b6173000 b617a000 r-xp /usr/lib/libXcursor.so.1.0.2
b6182000 b6185000 r-xp /usr/lib/libecore_input_evas.so.1.7.99
b618d000 b6191000 r-xp /usr/lib/libecore_ipc.so.1.7.99
b619a000 b619f000 r-xp /usr/lib/libecore_fb.so.1.7.99
b61a9000 b628a000 r-xp /usr/lib/libX11.so.6.3.0
b6295000 b62b8000 r-xp /usr/lib/libjpeg.so.8.0.2
b62d0000 b62e6000 r-xp /lib/libz.so.1.2.5
b62ee000 b6363000 r-xp /usr/lib/libsqlite3.so.0.8.6
b636d000 b6382000 r-xp /usr/lib/libpkgmgr_parser.so.0.1.0
b638b000 b63bf000 r-xp /usr/lib/libgobject-2.0.so.0.3200.3
b63c8000 b649b000 r-xp /usr/lib/libgio-2.0.so.0.3200.3
b64a6000 b64b6000 r-xp /lib/libresolv-2.13.so
b64ba000 b6536000 r-xp /usr/lib/libgcrypt.so.20.0.3
b6542000 b655a000 r-xp /usr/lib/liblzma.so.5.0.3
b6563000 b6566000 r-xp /lib/libcap.so.2.21
b656e000 b6594000 r-xp /usr/lib/libsecurity-server-client.so.1.0.1
b659d000 b659e000 r-xp /usr/lib/libecore_imf_evas.so.1.7.99
b65a6000 b65ac000 r-xp /usr/lib/libecore_imf.so.1.7.99
b65b4000 b65cb000 r-xp /usr/lib/liblua-5.1.so
b65d5000 b65dc000 r-xp /usr/lib/libembryo.so.1.7.99
b65e4000 b65ea000 r-xp /lib/librt-2.13.so
b65f3000 b6649000 r-xp /usr/lib/libpixman-1.so.0.28.2
b6656000 b66ac000 r-xp /usr/lib/libfreetype.so.6.11.3
b66b8000 b66e0000 r-xp /usr/lib/libfontconfig.so.1.8.0
b66e2000 b671f000 r-xp /usr/lib/libharfbuzz.so.0.940.0
b6728000 b673b000 r-xp /usr/lib/libfribidi.so.0.3.1
b6743000 b675d000 r-xp /usr/lib/libecore_con.so.1.7.99
b6766000 b676f000 r-xp /usr/lib/libedbus.so.1.7.99
b6777000 b67c7000 r-xp /usr/lib/libecore_x.so.1.7.99
b67ca000 b67ce000 r-xp /usr/lib/libvconf.so.0.2.45
b67d6000 b67e7000 r-xp /usr/lib/libecore_input.so.1.7.99
b67ef000 b67f4000 r-xp /usr/lib/libecore_file.so.1.7.99
b67fc000 b681e000 r-xp /usr/lib/libecore_evas.so.1.7.99
b6827000 b6868000 r-xp /usr/lib/libeina.so.1.7.99
b6871000 b688a000 r-xp /usr/lib/libeet.so.1.7.99
b689b000 b6904000 r-xp /lib/libm-2.13.so
b690d000 b6913000 r-xp /usr/lib/libcapi-base-common.so.0.1.8
b691c000 b691f000 r-xp /usr/lib/libproc-stat.so.0.2.86
b6927000 b6949000 r-xp /usr/lib/libpkgmgr-info.so.0.0.17
b6951000 b6956000 r-xp /usr/lib/libxdgmime.so.1.1.0
b695e000 b6988000 r-xp /usr/lib/libdbus-1.so.3.8.12
b6991000 b69a8000 r-xp /usr/lib/libdbus-glib-1.so.2.2.2
b69b0000 b69bb000 r-xp /lib/libunwind.so.8.0.1
b69e8000 b6a24000 r-xp /usr/lib/libsystemd.so.0.4.0
b6a2d000 b6b48000 r-xp /lib/libc-2.13.so
b6b56000 b6b5e000 r-xp /lib/libgcc_s-4.6.so.1
b6b5f000 b6b62000 r-xp /usr/lib/libsmack.so.1.0.0
b6b6a000 b6b70000 r-xp /usr/lib/libprivilege-control.so.0.0.2
b6b78000 b6c48000 r-xp /usr/lib/libglib-2.0.so.0.3200.3
b6c49000 b6ca6000 r-xp /usr/lib/libedje.so.1.7.99
b6cb0000 b6cc7000 r-xp /usr/lib/libecore.so.1.7.99
b6cde000 b6dad000 r-xp /usr/lib/libevas.so.1.7.99
b6dd1000 b6f0b000 r-xp /usr/lib/libelementary.so.1.7.99
b6f21000 b6f35000 r-xp /lib/libpthread-2.13.so
b6f40000 b6f42000 r-xp /usr/lib/libdlog.so.0.0.0
b6f4a000 b6f4d000 r-xp /usr/lib/libbundle.so.0.1.22
b6f55000 b6f57000 r-xp /lib/libdl-2.13.so
b6f60000 b6f6c000 r-xp /usr/lib/libaul.so.0.1.0
b6f7e000 b6f83000 r-xp /usr/lib/libappcore-efl.so.1.1
b6f8c000 b6f90000 r-xp /usr/lib/libsys-assert.so
b6f99000 b6fb6000 r-xp /lib/ld-2.13.so
b6fbf000 b6fc4000 r-xp /usr/bin/launchpad-loader
b7ca5000 b805e000 rw-p [heap]
beceb000 bed0c000 rwxp [stack]
End of Maps Information

Callstack Information (PID:18545)
Call Stack Count: 4
 0: evas_object_evas_get + 0x5 (0xb6d0bbde) [/usr/lib/libevas.so.1] + 0x2dbde
 1: elm_widget_add + 0xc (0xb6ec232d) [/usr/lib/libelementary.so.1] + 0xf132d
 2: elm_genlist_add + 0x28 (0xb6e5d0bd) [/usr/lib/libelementary.so.1] + 0x8c0bd
 3: _single_line_entry_cb1 + 0x200 (0xb5836c19) [/opt/usr/apps/org.example.uicomponents/bin/uicomponents] + 0x5c19
End of Call Stack

Package Information
Package Name: org.example.uicomponents
Package ID : org.example.uicomponents
Version: 1.0.0
Package Type: rpm
App Name: uicomponents
App ID: org.example.uicomponents
Type: capp
Categories: 

Latest Debug Message Information
--------- beginning of /dev/log_main
140+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7de0558), ev->cur.canvas.x(157) ev->cur.canvas.y(252)
06-06 18:59:53.140+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7de0558), hold(0) freeze(0)
06-06 18:59:53.140+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7de0558), block(1)
06-06 18:59:53.140+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7de0558), ev->cur.canvas.x(157) ev->cur.canvas.y(259)
06-06 18:59:53.140+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7de0558), hold(0) freeze(0)
06-06 18:59:53.140+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b7de0558), locked_x(0)
06-06 18:59:53.140+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3843 _elm_scroll_hold_animator() [DDO] obj(b7de0558)
06-06 18:59:53.140+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b7de0558)
06-06 18:59:53.160+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7de0558), block(1)
06-06 18:59:53.160+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7de0558), ev->cur.canvas.x(157) ev->cur.canvas.y(267)
06-06 18:59:53.160+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7de0558), hold(0) freeze(0)
06-06 18:59:53.160+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7de0558), block(1)
06-06 18:59:53.160+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7de0558), ev->cur.canvas.x(163) ev->cur.canvas.y(272)
06-06 18:59:53.160+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7de0558), hold(0) freeze(0)
06-06 18:59:53.160+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b7de0558), locked_x(0)
06-06 18:59:53.160+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3843 _elm_scroll_hold_animator() [DDO] obj(b7de0558)
06-06 18:59:53.160+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b7de0558)
06-06 18:59:53.180+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7de0558), block(1)
06-06 18:59:53.180+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7de0558), ev->cur.canvas.x(168) ev->cur.canvas.y(275)
06-06 18:59:53.180+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7de0558), hold(0) freeze(0)
06-06 18:59:53.180+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7de0558), block(1)
06-06 18:59:53.180+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7de0558), ev->cur.canvas.x(168) ev->cur.canvas.y(277)
06-06 18:59:53.180+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7de0558), hold(0) freeze(0)
06-06 18:59:53.180+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b7de0558), locked_x(0)
06-06 18:59:53.180+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3843 _elm_scroll_hold_animator() [DDO] obj(b7de0558)
06-06 18:59:53.180+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b7de0558)
06-06 18:59:53.210+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7de0558), block(1)
06-06 18:59:53.210+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7de0558), ev->cur.canvas.x(169) ev->cur.canvas.y(279)
06-06 18:59:53.210+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7de0558), hold(0) freeze(0)
06-06 18:59:53.210+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7de0558), block(1)
06-06 18:59:53.210+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7de0558), ev->cur.canvas.x(170) ev->cur.canvas.y(280)
06-06 18:59:53.210+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7de0558), hold(0) freeze(0)
06-06 18:59:53.210+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b7de0558), locked_x(0)
06-06 18:59:53.210+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3843 _elm_scroll_hold_animator() [DDO] obj(b7de0558)
06-06 18:59:53.210+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b7de0558)
06-06 18:59:53.230+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7de0558), block(1)
06-06 18:59:53.230+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7de0558), ev->cur.canvas.x(170) ev->cur.canvas.y(283)
06-06 18:59:53.230+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7de0558), hold(0) freeze(0)
06-06 18:59:53.230+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7de0558), block(1)
06-06 18:59:53.230+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7de0558), ev->cur.canvas.x(170) ev->cur.canvas.y(286)
06-06 18:59:53.230+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7de0558), hold(0) freeze(0)
06-06 18:59:53.230+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b7de0558), locked_x(0)
06-06 18:59:53.230+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3843 _elm_scroll_hold_animator() [DDO] obj(b7de0558)
06-06 18:59:53.230+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b7de0558)
06-06 18:59:53.250+0900 E/EFL     (18545): evas_main<18545> evas_events.c:1275 evas_event_feed_mouse_up() ButtonEvent:up time=11187308 button=1 downs=0
06-06 18:59:53.250+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:2278 _elm_scroll_post_event_up() [DDO] lock set false. : obj(b7de0558), type(elm_genlist)
06-06 18:59:53.910+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7de0558), block(1)
06-06 18:59:53.910+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7de0558), ev->cur.canvas.x(146) ev->cur.canvas.y(198)
06-06 18:59:53.910+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7de0558), hold(0) freeze(0)
06-06 18:59:53.910+0900 E/EFL     (18545): evas_main<18545> evas_events.c:1009 evas_event_feed_mouse_down() ButtonEvent:down time=11187968 button=1 downs=1
06-06 18:59:53.910+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7de0558), block(1)
06-06 18:59:53.910+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7de0558), ev->cur.canvas.x(150) ev->cur.canvas.y(194)
06-06 18:59:53.910+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7de0558), hold(0) freeze(0)
06-06 18:59:53.930+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7de0558), block(1)
06-06 18:59:53.930+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7de0558), ev->cur.canvas.x(154) ev->cur.canvas.y(192)
06-06 18:59:53.930+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7de0558), hold(0) freeze(0)
06-06 18:59:53.930+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7de0558), block(1)
06-06 18:59:53.930+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7de0558), ev->cur.canvas.x(156) ev->cur.canvas.y(192)
06-06 18:59:53.930+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7de0558), hold(0) freeze(0)
06-06 18:59:53.950+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7de0558), block(1)
06-06 18:59:53.950+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7de0558), ev->cur.canvas.x(157) ev->cur.canvas.y(191)
06-06 18:59:53.950+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7de0558), hold(0) freeze(0)
06-06 18:59:53.950+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7de0558), block(1)
06-06 18:59:53.950+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7de0558), ev->cur.canvas.x(159) ev->cur.canvas.y(191)
06-06 18:59:53.950+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7de0558), hold(0) freeze(0)
06-06 18:59:53.980+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7de0558), block(1)
06-06 18:59:53.980+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7de0558), ev->cur.canvas.x(156) ev->cur.canvas.y(191)
06-06 18:59:53.980+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7de0558), hold(0) freeze(0)
06-06 18:59:53.980+0900 E/EFL     (18545): evas_main<18545> evas_events.c:1275 evas_event_feed_mouse_up() ButtonEvent:up time=11188042 button=1 downs=0
06-06 18:59:54.150+0900 I/efl-extension(18545): efl_extension_rotary.c: eext_rotary_object_event_callback_add(147) > In
06-06 18:59:54.150+0900 I/efl-extension(18545): efl_extension_rotary.c: eext_rotary_object_event_activated_set(283) > eext_rotary_object_event_activated_set : 0xb7ed32e8, elm_image, _activated_obj : 0xb7df5798, activated : 1
06-06 18:59:54.150+0900 I/efl-extension(18545): efl_extension_rotary.c: eext_rotary_object_event_activated_set(291) > Activation delete!!!!
06-06 18:59:54.840+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7e7dc78), block(1)
06-06 18:59:54.850+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7e7dc78), ev->cur.canvas.x(112) ev->cur.canvas.y(235)
06-06 18:59:54.850+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7e7dc78), hold(0) freeze(0)
06-06 18:59:54.850+0900 E/EFL     (18545): evas_main<18545> evas_events.c:1009 evas_event_feed_mouse_down() ButtonEvent:down time=11188915 button=1 downs=1
06-06 18:59:54.850+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7e7dc78), block(1)
06-06 18:59:54.850+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7e7dc78), ev->cur.canvas.x(111) ev->cur.canvas.y(233)
06-06 18:59:54.850+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7e7dc78), hold(0) freeze(0)
06-06 18:59:54.860+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7e7dc78), block(1)
06-06 18:59:54.860+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7e7dc78), ev->cur.canvas.x(107) ev->cur.canvas.y(228)
06-06 18:59:54.860+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7e7dc78), hold(0) freeze(0)
06-06 18:59:54.870+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7e7dc78), block(1)
06-06 18:59:54.870+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7e7dc78), ev->cur.canvas.x(108) ev->cur.canvas.y(221)
06-06 18:59:54.870+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7e7dc78), hold(0) freeze(0)
06-06 18:59:54.880+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7e7dc78), block(1)
06-06 18:59:54.880+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7e7dc78), ev->cur.canvas.x(110) ev->cur.canvas.y(214)
06-06 18:59:54.880+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7e7dc78), hold(0) freeze(0)
06-06 18:59:54.890+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7e7dc78), block(1)
06-06 18:59:54.890+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7e7dc78), ev->cur.canvas.x(112) ev->cur.canvas.y(206)
06-06 18:59:54.890+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7e7dc78), hold(0) freeze(0)
06-06 18:59:54.910+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7e7dc78), block(1)
06-06 18:59:54.910+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7e7dc78), ev->cur.canvas.x(112) ev->cur.canvas.y(199)
06-06 18:59:54.910+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7e7dc78), hold(0) freeze(0)
06-06 18:59:54.910+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:4249 _elm_scroll_mouse_move_event_cb() [DDO] animator
06-06 18:59:54.910+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3353 _elm_scroll_post_event_move() [DDO] obj(b7e7dc78), type(elm_genlist)
06-06 18:59:54.910+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3354 _elm_scroll_post_event_move() [DDO] hold_parent(0)
06-06 18:59:54.910+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3405 _elm_scroll_post_event_move() [DDO] elm_widget_drag_lock_y_set : obj(b7e7dc78), type(elm_genlist)
06-06 18:59:54.920+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b7e7dc78), locked_x(0)
06-06 18:59:54.920+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b7e7dc78)
06-06 18:59:54.950+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7e7dc78), block(1)
06-06 18:59:54.950+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7e7dc78), ev->cur.canvas.x(112) ev->cur.canvas.y(193)
06-06 18:59:54.950+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7e7dc78), hold(0) freeze(0)
06-06 18:59:54.950+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7e7dc78), block(1)
06-06 18:59:54.950+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7e7dc78), ev->cur.canvas.x(112) ev->cur.canvas.y(190)
06-06 18:59:54.950+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7e7dc78), hold(0) freeze(0)
06-06 18:59:54.950+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7e7dc78), block(1)
06-06 18:59:54.950+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7e7dc78), ev->cur.canvas.x(112) ev->cur.canvas.y(186)
06-06 18:59:54.950+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7e7dc78), hold(0) freeze(0)
06-06 18:59:54.950+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7e7dc78), block(1)
06-06 18:59:54.950+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7e7dc78), ev->cur.canvas.x(109) ev->cur.canvas.y(182)
06-06 18:59:54.950+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7e7dc78), hold(0) freeze(0)
06-06 18:59:54.950+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b7e7dc78), locked_x(0)
06-06 18:59:54.950+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b7e7dc78)
06-06 18:59:54.990+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7e7dc78), block(1)
06-06 18:59:54.990+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7e7dc78), ev->cur.canvas.x(105) ev->cur.canvas.y(179)
06-06 18:59:54.990+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7e7dc78), hold(0) freeze(0)
06-06 18:59:54.990+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7e7dc78), block(1)
06-06 18:59:54.990+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7e7dc78), ev->cur.canvas.x(104) ev->cur.canvas.y(176)
06-06 18:59:54.990+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7e7dc78), hold(0) freeze(0)
06-06 18:59:55.000+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7e7dc78), block(1)
06-06 18:59:55.000+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7e7dc78), ev->cur.canvas.x(103) ev->cur.canvas.y(173)
06-06 18:59:55.000+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7e7dc78), hold(0) freeze(0)
06-06 18:59:55.000+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7e7dc78), block(1)
06-06 18:59:55.000+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7e7dc78), ev->cur.canvas.x(102) ev->cur.canvas.y(170)
06-06 18:59:55.000+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7e7dc78), hold(0) freeze(0)
06-06 18:59:55.000+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b7e7dc78), locked_x(0)
06-06 18:59:55.000+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b7e7dc78)
06-06 18:59:55.030+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7e7dc78), block(1)
06-06 18:59:55.030+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7e7dc78), ev->cur.canvas.x(99) ev->cur.canvas.y(167)
06-06 18:59:55.030+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7e7dc78), hold(0) freeze(0)
06-06 18:59:55.030+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7e7dc78), block(1)
06-06 18:59:55.040+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7e7dc78), ev->cur.canvas.x(95) ev->cur.canvas.y(161)
06-06 18:59:55.040+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7e7dc78), hold(0) freeze(0)
06-06 18:59:55.040+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7e7dc78), block(1)
06-06 18:59:55.040+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7e7dc78), ev->cur.canvas.x(93) ev->cur.canvas.y(156)
06-06 18:59:55.040+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7e7dc78), hold(0) freeze(0)
06-06 18:59:55.040+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7e7dc78), block(1)
06-06 18:59:55.040+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7e7dc78), ev->cur.canvas.x(92) ev->cur.canvas.y(153)
06-06 18:59:55.040+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7e7dc78), hold(0) freeze(0)
06-06 18:59:55.040+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b7e7dc78), locked_x(0)
06-06 18:59:55.040+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b7e7dc78)
06-06 18:59:55.060+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7e7dc78), block(1)
06-06 18:59:55.060+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7e7dc78), ev->cur.canvas.x(90) ev->cur.canvas.y(153)
06-06 18:59:55.060+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7e7dc78), hold(0) freeze(0)
06-06 18:59:55.060+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7e7dc78), block(1)
06-06 18:59:55.060+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7e7dc78), ev->cur.canvas.x(87) ev->cur.canvas.y(150)
06-06 18:59:55.060+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7e7dc78), hold(0) freeze(0)
06-06 18:59:55.060+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b7e7dc78), locked_x(0)
06-06 18:59:55.060+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b7e7dc78)
06-06 18:59:55.080+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7e7dc78), block(1)
06-06 18:59:55.080+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7e7dc78), ev->cur.canvas.x(85) ev->cur.canvas.y(143)
06-06 18:59:55.080+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7e7dc78), hold(0) freeze(0)
06-06 18:59:55.080+0900 E/EFL     (18545): evas_main<18545> evas_events.c:1275 evas_event_feed_mouse_up() ButtonEvent:up time=11189144 button=1 downs=0
06-06 18:59:55.080+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:2278 _elm_scroll_post_event_up() [DDO] lock set false. : obj(b7e7dc78), type(elm_genlist)
06-06 18:59:55.550+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7e7dc78), block(1)
06-06 18:59:55.550+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7e7dc78), ev->cur.canvas.x(137) ev->cur.canvas.y(206)
06-06 18:59:55.550+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7e7dc78), hold(0) freeze(0)
06-06 18:59:55.550+0900 E/EFL     (18545): evas_main<18545> evas_events.c:1009 evas_event_feed_mouse_down() ButtonEvent:down time=11189615 button=1 downs=1
06-06 18:59:55.570+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7e7dc78), block(1)
06-06 18:59:55.570+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7e7dc78), ev->cur.canvas.x(142) ev->cur.canvas.y(201)
06-06 18:59:55.570+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7e7dc78), hold(0) freeze(0)
06-06 18:59:55.570+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7e7dc78), block(1)
06-06 18:59:55.570+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7e7dc78), ev->cur.canvas.x(144) ev->cur.canvas.y(199)
06-06 18:59:55.570+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7e7dc78), hold(0) freeze(0)
06-06 18:59:55.610+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7e7dc78), block(1)
06-06 18:59:55.610+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7e7dc78), ev->cur.canvas.x(143) ev->cur.canvas.y(199)
06-06 18:59:55.610+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7e7dc78), hold(0) freeze(0)
06-06 18:59:55.610+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7e7dc78), block(1)
06-06 18:59:55.610+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7e7dc78), ev->cur.canvas.x(138) ev->cur.canvas.y(199)
06-06 18:59:55.610+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7e7dc78), hold(0) freeze(0)
06-06 18:59:55.630+0900 E/EFL     (18545): evas_main<18545> evas_events.c:1275 evas_event_feed_mouse_up() ButtonEvent:up time=11189690 button=1 downs=0
06-06 18:59:55.660+0900 I/efl-extension(18545): efl_extension_rotary.c: eext_rotary_object_event_callback_add(147) > In
06-06 18:59:55.660+0900 I/efl-extension(18545): efl_extension_rotary.c: eext_rotary_object_event_activated_set(283) > eext_rotary_object_event_activated_set : 0xb7efbb20, elm_image, _activated_obj : 0xb7ed32e8, activated : 1
06-06 18:59:55.660+0900 I/efl-extension(18545): efl_extension_rotary.c: eext_rotary_object_event_activated_set(291) > Activation delete!!!!
06-06 18:59:56.200+0900 I/APP_CORE( 1184): appcore-efl.c: __do_app(429) > [APP 1184] Event: MEM_FLUSH State: PAUSED
06-06 18:59:56.890+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7eed820), block(1)
06-06 18:59:56.890+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7eed820), ev->cur.canvas.x(175) ev->cur.canvas.y(205)
06-06 18:59:56.890+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7eed820), hold(0) freeze(0)
06-06 18:59:56.890+0900 E/EFL     (18545): evas_main<18545> evas_events.c:1009 evas_event_feed_mouse_down() ButtonEvent:down time=11190949 button=1 downs=1
06-06 18:59:56.890+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7eed820), block(1)
06-06 18:59:56.890+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7eed820), ev->cur.canvas.x(178) ev->cur.canvas.y(205)
06-06 18:59:56.890+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7eed820), hold(0) freeze(0)
06-06 18:59:56.910+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7eed820), block(1)
06-06 18:59:56.910+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7eed820), ev->cur.canvas.x(179) ev->cur.canvas.y(203)
06-06 18:59:56.910+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7eed820), hold(0) freeze(0)
06-06 18:59:56.910+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7eed820), block(1)
06-06 18:59:56.910+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7eed820), ev->cur.canvas.x(180) ev->cur.canvas.y(202)
06-06 18:59:56.910+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7eed820), hold(0) freeze(0)
06-06 18:59:56.930+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7eed820), block(1)
06-06 18:59:56.930+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7eed820), ev->cur.canvas.x(179) ev->cur.canvas.y(201)
06-06 18:59:56.930+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7eed820), hold(0) freeze(0)
06-06 18:59:56.940+0900 E/EFL     (18545): evas_main<18545> evas_events.c:1275 evas_event_feed_mouse_up() ButtonEvent:up time=11191013 button=1 downs=0
06-06 18:59:57.880+0900 E/EFL     (18545): evas_main<18545> evas_events.c:1009 evas_event_feed_mouse_down() ButtonEvent:down time=11191957 button=1 downs=1
06-06 18:59:57.960+0900 E/EFL     (18545): evas_main<18545> evas_events.c:1275 evas_event_feed_mouse_up() ButtonEvent:up time=11192031 button=1 downs=0
06-06 18:59:58.810+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7eed820), block(1)
06-06 18:59:58.810+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7eed820), ev->cur.canvas.x(117) ev->cur.canvas.y(260)
06-06 18:59:58.810+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7eed820), hold(0) freeze(0)
06-06 18:59:58.810+0900 E/EFL     (18545): evas_main<18545> evas_events.c:1009 evas_event_feed_mouse_down() ButtonEvent:down time=11192877 button=1 downs=1
06-06 18:59:58.810+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7eed820), block(1)
06-06 18:59:58.810+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7eed820), ev->cur.canvas.x(119) ev->cur.canvas.y(260)
06-06 18:59:58.810+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7eed820), hold(0) freeze(0)
06-06 18:59:58.810+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7eed820), block(1)
06-06 18:59:58.810+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7eed820), ev->cur.canvas.x(127) ev->cur.canvas.y(259)
06-06 18:59:58.810+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7eed820), hold(0) freeze(0)
06-06 18:59:58.830+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7eed820), block(1)
06-06 18:59:58.830+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7eed820), ev->cur.canvas.x(128) ev->cur.canvas.y(251)
06-06 18:59:58.830+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7eed820), hold(0) freeze(0)
06-06 18:59:58.840+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7eed820), block(1)
06-06 18:59:58.840+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7eed820), ev->cur.canvas.x(128) ev->cur.canvas.y(241)
06-06 18:59:58.840+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7eed820), hold(0) freeze(0)
06-06 18:59:58.850+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7eed820), block(1)
06-06 18:59:58.850+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7eed820), ev->cur.canvas.x(128) ev->cur.canvas.y(235)
06-06 18:59:58.850+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7eed820), hold(0) freeze(0)
06-06 18:59:58.860+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7eed820), block(1)
06-06 18:59:58.860+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7eed820), ev->cur.canvas.x(127) ev->cur.canvas.y(231)
06-06 18:59:58.860+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7eed820), hold(0) freeze(0)
06-06 18:59:58.870+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7eed820), block(1)
06-06 18:59:58.870+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7eed820), ev->cur.canvas.x(127) ev->cur.canvas.y(228)
06-06 18:59:58.870+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7eed820), hold(0) freeze(0)
06-06 18:59:58.880+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7eed820), block(1)
06-06 18:59:58.880+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7eed820), ev->cur.canvas.x(126) ev->cur.canvas.y(224)
06-06 18:59:58.880+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7eed820), hold(0) freeze(0)
06-06 18:59:58.880+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:4249 _elm_scroll_mouse_move_event_cb() [DDO] animator
06-06 18:59:58.880+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3353 _elm_scroll_post_event_move() [DDO] obj(b7eed820), type(elm_genlist)
06-06 18:59:58.880+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3354 _elm_scroll_post_event_move() [DDO] hold_parent(0)
06-06 18:59:58.880+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3405 _elm_scroll_post_event_move() [DDO] elm_widget_drag_lock_y_set : obj(b7eed820), type(elm_genlist)
06-06 18:59:58.900+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7eed820), block(1)
06-06 18:59:58.900+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7eed820), ev->cur.canvas.x(126) ev->cur.canvas.y(221)
06-06 18:59:58.900+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7eed820), hold(0) freeze(0)
06-06 18:59:58.900+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b7eed820), locked_x(0)
06-06 18:59:58.900+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b7eed820)
06-06 18:59:58.920+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7eed820), block(1)
06-06 18:59:58.920+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7eed820), ev->cur.canvas.x(125) ev->cur.canvas.y(218)
06-06 18:59:58.920+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7eed820), hold(0) freeze(0)
06-06 18:59:58.930+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7eed820), block(1)
06-06 18:59:58.930+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7eed820), ev->cur.canvas.x(124) ev->cur.canvas.y(213)
06-06 18:59:58.930+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7eed820), hold(0) freeze(0)
06-06 18:59:58.930+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7eed820), block(1)
06-06 18:59:58.930+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7eed820), ev->cur.canvas.x(123) ev->cur.canvas.y(206)
06-06 18:59:58.930+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7eed820), hold(0) freeze(0)
06-06 18:59:58.930+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b7eed820), locked_x(0)
06-06 18:59:58.930+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b7eed820)
06-06 18:59:58.960+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7eed820), block(1)
06-06 18:59:58.960+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7eed820), ev->cur.canvas.x(121) ev->cur.canvas.y(200)
06-06 18:59:58.960+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7eed820), hold(0) freeze(0)
06-06 18:59:58.960+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7eed820), block(1)
06-06 18:59:58.960+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7eed820), ev->cur.canvas.x(119) ev->cur.canvas.y(198)
06-06 18:59:58.960+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7eed820), hold(0) freeze(0)
06-06 18:59:58.960+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7eed820), block(1)
06-06 18:59:58.960+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7eed820), ev->cur.canvas.x(116) ev->cur.canvas.y(196)
06-06 18:59:58.960+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7eed820), hold(0) freeze(0)
06-06 18:59:58.960+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b7eed820), locked_x(0)
06-06 18:59:58.960+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b7eed820)
06-06 18:59:58.980+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7eed820), block(1)
06-06 18:59:58.980+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7eed820), ev->cur.canvas.x(114) ev->cur.canvas.y(194)
06-06 18:59:58.980+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7eed820), hold(0) freeze(0)
06-06 18:59:58.980+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7eed820), block(1)
06-06 18:59:58.980+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7eed820), ev->cur.canvas.x(112) ev->cur.canvas.y(192)
06-06 18:59:58.980+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7eed820), hold(0) freeze(0)
06-06 18:59:58.980+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b7eed820), locked_x(0)
06-06 18:59:58.980+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b7eed820)
06-06 18:59:59.010+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7eed820), block(1)
06-06 18:59:59.010+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7eed820), ev->cur.canvas.x(110) ev->cur.canvas.y(190)
06-06 18:59:59.010+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7eed820), hold(0) freeze(0)
06-06 18:59:59.010+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7eed820), block(1)
06-06 18:59:59.010+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7eed820), ev->cur.canvas.x(109) ev->cur.canvas.y(189)
06-06 18:59:59.010+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7eed820), hold(0) freeze(0)
06-06 18:59:59.010+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7eed820), block(1)
06-06 18:59:59.010+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7eed820), ev->cur.canvas.x(109) ev->cur.canvas.y(187)
06-06 18:59:59.010+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7eed820), hold(0) freeze(0)
06-06 18:59:59.010+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b7eed820), locked_x(0)
06-06 18:59:59.010+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b7eed820)
06-06 18:59:59.030+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7eed820), block(1)
06-06 18:59:59.030+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7eed820), ev->cur.canvas.x(109) ev->cur.canvas.y(185)
06-06 18:59:59.030+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7eed820), hold(0) freeze(0)
06-06 18:59:59.030+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7eed820), block(1)
06-06 18:59:59.030+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7eed820), ev->cur.canvas.x(106) ev->cur.canvas.y(184)
06-06 18:59:59.030+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7eed820), hold(0) freeze(0)
06-06 18:59:59.030+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b7eed820), locked_x(0)
06-06 18:59:59.030+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b7eed820)
06-06 18:59:59.060+0900 E/EFL     (18545): evas_main<18545> evas_events.c:1275 evas_event_feed_mouse_up() ButtonEvent:up time=11193111 button=1 downs=0
06-06 18:59:59.060+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:2278 _elm_scroll_post_event_up() [DDO] lock set false. : obj(b7eed820), type(elm_genlist)
06-06 18:59:59.550+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7eed820), block(1)
06-06 18:59:59.550+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7eed820), ev->cur.canvas.x(131) ev->cur.canvas.y(200)
06-06 18:59:59.550+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7eed820), hold(0) freeze(0)
06-06 18:59:59.550+0900 E/EFL     (18545): evas_main<18545> evas_events.c:1009 evas_event_feed_mouse_down() ButtonEvent:down time=11193620 button=1 downs=1
06-06 18:59:59.560+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7eed820), block(1)
06-06 18:59:59.560+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7eed820), ev->cur.canvas.x(134) ev->cur.canvas.y(200)
06-06 18:59:59.560+0900 E/EFL     (18545): elementary<18545> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7eed820), hold(0) freeze(0)
06-06 18:59:59.640+0900 E/EFL     (18545): evas_main<18545> evas_events.c:1275 evas_event_feed_mouse_up() ButtonEvent:up time=11193695 button=1 downs=0
06-06 18:59:59.720+0900 E/EFL     (18545): edje<18545> edje_util.c:3770 edje_object_size_min_restricted_calc() group entry_layout has a non-fixed part 'entry_part'. Adding 'fixed: 1 1;' to source EDC may help. Continuing discarding faulty part.
06-06 18:59:59.730+0900 E/EFL     (18545): edje<18545> edje_util.c:3770 edje_object_size_min_restricted_calc() group entry_layout has a non-fixed part 'entry_part'. Adding 'fixed: 1 1;' to source EDC may help. Continuing discarding faulty part.
06-06 19:00:00.110+0900 W/CRASH_MANAGER(18648): worker.c: worker_job(1199) > 1118545756963146520719
