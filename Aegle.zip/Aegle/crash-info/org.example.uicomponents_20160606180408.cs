S/W Version Information
Model: SM-R735S
Tizen-Version: 2.3.1.2
Build-Number: R735SKSU1AOKE
Build-Date: 2015.11.25 20:46:58

Crash Information
Process Name: uicomponents
PID: 12884
Date: 2016-06-06 18:04:08+0900
Executable File Path: /opt/usr/apps/org.example.uicomponents/bin/uicomponents
Signal: 11
      (SIGSEGV)
      si_code: -6
      signal sent by tkill (sent by pid 12884, uid 5000)

Register Information
r0   = 0x71737723, r1   = 0x71737723
r2   = 0x00000001, r3   = 0x00000000
r4   = 0x71737723, r5   = 0xb6ebd9f8
r6   = 0xb7281770, r7   = 0xbea6a3e8
r8   = 0xb6c719c0, r9   = 0xb7182f30
r10  = 0xb6eb5e9c, fp   = 0x00000000
ip   = 0xb6eb7428, sp   = 0xbea6a310
lr   = 0xb6e6432d, pc   = 0xb6cadbde
cpsr = 0xa0000030

Memory Information
MemTotal:   407572 KB
MemFree:     15260 KB
Buffers:     13328 KB
Cached:      94872 KB
VmPeak:      76932 KB
VmSize:      74768 KB
VmLck:           0 KB
VmPin:           0 KB
VmHWM:       18976 KB
VmRSS:       18976 KB
VmData:      16204 KB
VmStk:         136 KB
VmExe:          20 KB
VmLib:       24764 KB
VmPTE:          56 KB
VmSwap:          0 KB

Threads Information
Threads: 2
PID = 12884 TID = 12884
12884 12927 

Maps Information
b2860000 b2864000 r-xp /usr/lib/libogg.so.0.7.1
b286c000 b288e000 r-xp /usr/lib/libvorbis.so.0.4.3
b2896000 b289e000 r-xp /usr/lib/libmdm-common.so.1.0.89
b289f000 b28e2000 r-xp /usr/lib/libsndfile.so.1.0.25
b28ef000 b2937000 r-xp /usr/lib/pulseaudio/libpulsecommon-4.0.so
b2938000 b293d000 r-xp /usr/lib/libjson.so.0.0.1
b2945000 b2976000 r-xp /usr/lib/libmdm.so.1.1.85
b297e000 b2986000 r-xp /usr/lib/lib_DNSe_NRSS_ver225.so
b2995000 b29a5000 r-xp /usr/lib/lib_SamsungRec_TizenV04014.so
b29c6000 b29d3000 r-xp /usr/lib/libail.so.0.1.0
b29dc000 b29df000 r-xp /usr/lib/libsyspopup_caller.so.0.1.0
b29e7000 b2a1f000 r-xp /usr/lib/libpulse.so.0.16.2
b2a20000 b2a81000 r-xp /usr/lib/libasound.so.2.0.0
b2a8b000 b2a8e000 r-xp /usr/lib/libpulse-simple.so.0.0.4
b2a96000 b2a9b000 r-xp /usr/lib/libascenario-0.2.so.0.0.0
b2aa3000 b2abc000 r-xp /usr/lib/libavsysaudio.so.0.0.1
b2ac5000 b2ac9000 r-xp /usr/lib/libmmfsoundcommon.so.0.0.0
b2ad2000 b2adc000 r-xp /usr/lib/libaudio-session-mgr.so.0.0.0
b2ae8000 b2aed000 r-xp /usr/lib/libmmfsession.so.0.0.0
b2af5000 b2b0b000 r-xp /usr/lib/libmmfsound.so.0.1.0
b2b1d000 b2b24000 r-xp /usr/lib/libmmfcommon.so.0.0.0
b2b2c000 b2b36000 r-xp /usr/lib/libcapi-media-sound-manager.so.0.1.48
b2b3e000 b2b40000 r-xp /usr/lib/libcapi-media-wav-player.so.0.1.10
b2b48000 b2b49000 r-xp /usr/lib/libmmfkeysound.so.0.0.0
b2b51000 b2b58000 r-xp /usr/lib/libfeedback.so.0.1.4
b2b77000 b2b78000 r-xp /usr/lib/edje/modules/feedback/linux-gnueabi-armv7l-1.0.0/module.so
b2b80000 b2c07000 rw-s anon_inode:dmabuf
b2c07000 b2c8e000 rw-s anon_inode:dmabuf
b2d19000 b2da0000 rw-s anon_inode:dmabuf
b2e1f000 b2ea6000 rw-s anon_inode:dmabuf
b3188000 b3987000 rwxp [stack:12927]
b3987000 b399e000 r-xp /usr/lib/edje/modules/elm/linux-gnueabi-armv7l-1.0.0/module.so
b39ab000 b39ad000 r-xp /usr/lib/libgenlock.so
b39b6000 b39b7000 r-xp /usr/lib/evas/modules/loaders/eet/linux-gnueabi-armv7l-1.7.99/module.so
b39bf000 b39c1000 r-xp /usr/lib/evas/modules/loaders/png/linux-gnueabi-armv7l-1.7.99/module.so
b39cb000 b39d0000 r-xp /usr/lib/bufmgr/libtbm_msm.so.0.0.0
b39d8000 b39e3000 r-xp /usr/lib/evas/modules/engines/software_generic/linux-gnueabi-armv7l-1.7.99/module.so
b3d0b000 b3dd5000 r-xp /usr/lib/libCOREGL.so.4.0
b3de6000 b3deb000 r-xp /usr/lib/libcapi-media-tool.so.0.1.5
b3df3000 b3e14000 r-xp /usr/lib/libexif.so.12.3.3
b3e27000 b3e2c000 r-xp /usr/lib/libmmutil_imgp.so.0.0.0
b3e34000 b3e39000 r-xp /usr/lib/libmmutil_jpeg.so.0.0.0
b53c8000 b53ca000 r-xp /usr/lib/libdri2.so.0.0.0
b53d2000 b53da000 r-xp /usr/lib/libdrm.so.2.4.0
b53e2000 b53e5000 r-xp /usr/lib/libcapi-media-image-util.so.0.3.5
b53ed000 b54d1000 r-xp /usr/lib/libicuuc.so.51.1
b54e6000 b5623000 r-xp /usr/lib/libicui18n.so.51.1
b5633000 b5638000 r-xp /usr/lib/libcapi-system-info.so.0.2.0
b5640000 b5646000 r-xp /usr/lib/libxcb-render.so.0.0.0
b564e000 b564f000 r-xp /usr/lib/libxcb-shm.so.0.0.0
b5658000 b565b000 r-xp /usr/lib/libEGL.so.1.4
b5663000 b5671000 r-xp /usr/lib/libGLESv2.so.2.0
b567a000 b5681000 r-xp /usr/lib/libtbm.so.1.0.0
b5689000 b56aa000 r-xp /usr/lib/libui-extension.so.0.1.0
b56b3000 b56c5000 r-xp /usr/lib/libtts.so
b56cd000 b5785000 r-xp /usr/lib/libcairo.so.2.11200.14
b5790000 b57a2000 r-xp /usr/lib/libefl-assist.so.0.1.0
b57aa000 b57cb000 r-xp /usr/lib/libefl-extension.so.0.1.0
b57d3000 b57e6000 r-xp /opt/usr/apps/org.example.uicomponents/bin/uicomponents
b59ad000 b59b7000 r-xp /lib/libnss_files-2.13.so
b59c0000 b5a8f000 r-xp /usr/lib/libscim-1.0.so.8.2.3
b5aa5000 b5ac9000 r-xp /usr/lib/ecore/immodules/libisf-imf-module.so
b5ad2000 b5ad8000 r-xp /usr/lib/libappsvc.so.0.1.0
b5ae0000 b5ae2000 r-xp /usr/lib/libcapi-appfw-app-common.so.0.3.2.5
b5aeb000 b5af0000 r-xp /usr/lib/libcapi-appfw-app-control.so.0.3.2.5
b5afb000 b5b06000 r-xp /usr/lib/evas/modules/engines/software_x11/linux-gnueabi-armv7l-1.7.99/module.so
b5b0e000 b5b10000 r-xp /usr/lib/libiniparser.so.0
b5b19000 b5b1e000 r-xp /usr/lib/libappcore-common.so.1.1
b5b27000 b5b2f000 r-xp /usr/lib/libcapi-system-system-settings.so.0.0.2
b5b30000 b5b34000 r-xp /usr/lib/libcapi-appfw-application.so.0.3.2.5
b5b41000 b5b43000 r-xp /usr/lib/libXau.so.6.0.0
b5b4c000 b5b53000 r-xp /lib/libcrypt-2.13.so
b5b83000 b5b85000 r-xp /usr/lib/libiri.so
b5b8d000 b5d35000 r-xp /usr/lib/libcrypto.so.1.0.0
b5d4e000 b5d9b000 r-xp /usr/lib/libssl.so.1.0.0
b5da8000 b5dd6000 r-xp /usr/lib/libidn.so.11.5.44
b5dde000 b5de7000 r-xp /usr/lib/libcares.so.2.1.0
b5df0000 b5e03000 r-xp /usr/lib/libxcb.so.1.1.0
b5e0c000 b5e0e000 r-xp /usr/lib/journal/libjournal.so.0.1.0
b5e17000 b5e19000 r-xp /usr/lib/libSLP-db-util.so.0.1.0
b5e22000 b5eee000 r-xp /usr/lib/libxml2.so.2.7.8
b5efb000 b5efd000 r-xp /usr/lib/libgmodule-2.0.so.0.3200.3
b5f05000 b5f0a000 r-xp /usr/lib/libffi.so.5.0.10
b5f12000 b5f13000 r-xp /usr/lib/libgthread-2.0.so.0.3200.3
b5f1c000 b5f27000 r-xp /usr/lib/libgpg-error.so.0.15.0
b5f2f000 b5f32000 r-xp /lib/libattr.so.1.1.0
b5f3a000 b5fce000 r-xp /usr/lib/libstdc++.so.6.0.16
b5fe1000 b5ffd000 r-xp /usr/lib/libsecurity-server-commons.so.1.0.0
b6006000 b601e000 r-xp /usr/lib/libpng12.so.0.50.0
b6027000 b603d000 r-xp /lib/libexpat.so.1.5.2
b6047000 b608b000 r-xp /usr/lib/libcurl.so.4.3.0
b6094000 b609e000 r-xp /usr/lib/libXext.so.6.4.0
b60a7000 b60aa000 r-xp /usr/lib/libXtst.so.6.1.0
b60b3000 b60b9000 r-xp /usr/lib/libXrender.so.1.3.0
b60c2000 b60c8000 r-xp /usr/lib/libXrandr.so.2.2.0
b60d0000 b60d1000 r-xp /usr/lib/libXinerama.so.1.0.0
b60da000 b60e3000 r-xp /usr/lib/libXi.so.6.1.0
b60eb000 b60ee000 r-xp /usr/lib/libXfixes.so.3.1.0
b60f6000 b60f8000 r-xp /usr/lib/libXgesture.so.7.0.0
b6100000 b6102000 r-xp /usr/lib/libXcomposite.so.1.0.0
b610b000 b610d000 r-xp /usr/lib/libXdamage.so.1.1.0
b6115000 b611c000 r-xp /usr/lib/libXcursor.so.1.0.2
b6124000 b6127000 r-xp /usr/lib/libecore_input_evas.so.1.7.99
b612f000 b6133000 r-xp /usr/lib/libecore_ipc.so.1.7.99
b613c000 b6141000 r-xp /usr/lib/libecore_fb.so.1.7.99
b614b000 b622c000 r-xp /usr/lib/libX11.so.6.3.0
b6237000 b625a000 r-xp /usr/lib/libjpeg.so.8.0.2
b6272000 b6288000 r-xp /lib/libz.so.1.2.5
b6290000 b6305000 r-xp /usr/lib/libsqlite3.so.0.8.6
b630f000 b6324000 r-xp /usr/lib/libpkgmgr_parser.so.0.1.0
b632d000 b6361000 r-xp /usr/lib/libgobject-2.0.so.0.3200.3
b636a000 b643d000 r-xp /usr/lib/libgio-2.0.so.0.3200.3
b6448000 b6458000 r-xp /lib/libresolv-2.13.so
b645c000 b64d8000 r-xp /usr/lib/libgcrypt.so.20.0.3
b64e4000 b64fc000 r-xp /usr/lib/liblzma.so.5.0.3
b6505000 b6508000 r-xp /lib/libcap.so.2.21
b6510000 b6536000 r-xp /usr/lib/libsecurity-server-client.so.1.0.1
b653f000 b6540000 r-xp /usr/lib/libecore_imf_evas.so.1.7.99
b6548000 b654e000 r-xp /usr/lib/libecore_imf.so.1.7.99
b6556000 b656d000 r-xp /usr/lib/liblua-5.1.so
b6577000 b657e000 r-xp /usr/lib/libembryo.so.1.7.99
b6586000 b658c000 r-xp /lib/librt-2.13.so
b6595000 b65eb000 r-xp /usr/lib/libpixman-1.so.0.28.2
b65f8000 b664e000 r-xp /usr/lib/libfreetype.so.6.11.3
b665a000 b6682000 r-xp /usr/lib/libfontconfig.so.1.8.0
b6684000 b66c1000 r-xp /usr/lib/libharfbuzz.so.0.940.0
b66ca000 b66dd000 r-xp /usr/lib/libfribidi.so.0.3.1
b66e5000 b66ff000 r-xp /usr/lib/libecore_con.so.1.7.99
b6708000 b6711000 r-xp /usr/lib/libedbus.so.1.7.99
b6719000 b6769000 r-xp /usr/lib/libecore_x.so.1.7.99
b676c000 b6770000 r-xp /usr/lib/libvconf.so.0.2.45
b6778000 b6789000 r-xp /usr/lib/libecore_input.so.1.7.99
b6791000 b6796000 r-xp /usr/lib/libecore_file.so.1.7.99
b679e000 b67c0000 r-xp /usr/lib/libecore_evas.so.1.7.99
b67c9000 b680a000 r-xp /usr/lib/libeina.so.1.7.99
b6813000 b682c000 r-xp /usr/lib/libeet.so.1.7.99
b683d000 b68a6000 r-xp /lib/libm-2.13.so
b68af000 b68b5000 r-xp /usr/lib/libcapi-base-common.so.0.1.8
b68be000 b68c1000 r-xp /usr/lib/libproc-stat.so.0.2.86
b68c9000 b68eb000 r-xp /usr/lib/libpkgmgr-info.so.0.0.17
b68f3000 b68f8000 r-xp /usr/lib/libxdgmime.so.1.1.0
b6900000 b692a000 r-xp /usr/lib/libdbus-1.so.3.8.12
b6933000 b694a000 r-xp /usr/lib/libdbus-glib-1.so.2.2.2
b6952000 b695d000 r-xp /lib/libunwind.so.8.0.1
b698a000 b69c6000 r-xp /usr/lib/libsystemd.so.0.4.0
b69cf000 b6aea000 r-xp /lib/libc-2.13.so
b6af8000 b6b00000 r-xp /lib/libgcc_s-4.6.so.1
b6b01000 b6b04000 r-xp /usr/lib/libsmack.so.1.0.0
b6b0c000 b6b12000 r-xp /usr/lib/libprivilege-control.so.0.0.2
b6b1a000 b6bea000 r-xp /usr/lib/libglib-2.0.so.0.3200.3
b6beb000 b6c48000 r-xp /usr/lib/libedje.so.1.7.99
b6c52000 b6c69000 r-xp /usr/lib/libecore.so.1.7.99
b6c80000 b6d4f000 r-xp /usr/lib/libevas.so.1.7.99
b6d73000 b6ead000 r-xp /usr/lib/libelementary.so.1.7.99
b6ec3000 b6ed7000 r-xp /lib/libpthread-2.13.so
b6ee2000 b6ee4000 r-xp /usr/lib/libdlog.so.0.0.0
b6eec000 b6eef000 r-xp /usr/lib/libbundle.so.0.1.22
b6ef7000 b6ef9000 r-xp /lib/libdl-2.13.so
b6f02000 b6f0e000 r-xp /usr/lib/libaul.so.0.1.0
b6f20000 b6f25000 r-xp /usr/lib/libappcore-efl.so.1.1
b6f2e000 b6f32000 r-xp /usr/lib/libsys-assert.so
b6f3b000 b6f58000 r-xp /lib/ld-2.13.so
b6f61000 b6f66000 r-xp /usr/bin/launchpad-loader
b714a000 b73b1000 rw-p [heap]
bea4a000 bea6b000 rwxp [stack]
End of Maps Information

Callstack Information (PID:12884)
Call Stack Count: 4
 0: evas_object_evas_get + 0x5 (0xb6cadbde) [/usr/lib/libevas.so.1] + 0x2dbde
 1: elm_widget_add + 0xc (0xb6e6432d) [/usr/lib/libelementary.so.1] + 0xf132d
 2: elm_genlist_add + 0x28 (0xb6dff0bd) [/usr/lib/libelementary.so.1] + 0x8c0bd
 3: calorie_goal_cb + 0x44 (0xb57d850d) [/opt/usr/apps/org.example.uicomponents/bin/uicomponents] + 0x550d
End of Call Stack

Package Information
Package Name: org.example.uicomponents
Package ID : org.example.uicomponents
Version: 1.0.0
Package Type: rpm
App Name: uicomponents
App ID: org.example.uicomponents
Type: capp
Categories: 

Latest Debug Message Information
--------- beginning of /dev/log_main
AMD (  905): amd_launch.c: _start_app(1659) > caller pid : 1184
06-06 18:04:04.255+0900 E/RESOURCED(  906): block.c: block_prelaunch_state(134) > [block_prelaunch_state,134] insert data org.example.uicomponents, table num : 1
06-06 18:04:04.255+0900 W/AUL_AMD (  905): amd_launch.c: _start_app(2026) > pad pid(-5)
06-06 18:04:04.255+0900 E/RESOURCED(  906): heart-memory.c: heart_memory_get_data(601) > [heart_memory_get_data,601] hashtable heart_memory_app_list is NULL
06-06 18:04:04.255+0900 W/AUL_PAD ( 1730): launchpad.c: __launchpad_main_loop(512) > Launch on type-based process-pool
06-06 18:04:04.255+0900 W/AUL_PAD ( 1730): launchpad.c: __send_result_to_caller(265) > Check app launching
06-06 18:04:04.285+0900 I/efl-extension(12884): efl_extension.c: eext_mod_init(40) > Init
06-06 18:04:04.285+0900 I/UXT     (12884): Uxt_ObjectManager.cpp: OnInitialized(731) > Initialized.
06-06 18:04:04.285+0900 I/CAPI_APPFW_APPLICATION(12884): app_main.c: ui_app_main(704) > app_efl_main
06-06 18:04:04.295+0900 I/CAPI_APPFW_APPLICATION(12884): app_main.c: _ui_app_appcore_create(563) > app_appcore_create
06-06 18:04:04.365+0900 E/RESOURCED(  906): proc-main.c: proc_add_program_list(233) > [proc_add_program_list,233] not found ppi : org.example.uicomponents
06-06 18:04:04.445+0900 I/efl-extension(12884): efl_extension_circle_surface.c: eext_circle_surface_conformant_add(1245) > Put the surface[0xb72754a8]'s widget[0xb7283fd0] to elm_conformant widget[0xb724d040]
06-06 18:04:04.445+0900 I/efl-extension(12884): efl_extension_circle_surface.c: _eext_circle_surface_resize_cb(642) > surface 0xb72754a8 = w: 0 h: 0  obj 0xb7283fd0 w: 1 h: 1
06-06 18:04:04.475+0900 I/efl-extension(12884): efl_extension_rotary.c: eext_rotary_object_event_callback_add(147) > In
06-06 18:04:04.475+0900 I/efl-extension(12884): efl_extension_rotary.c: eext_rotary_event_handler_add(77) > init_count: 0
06-06 18:04:04.475+0900 I/efl-extension(12884): efl_extension_rotary.c: _init_Xi2_system(314) > In
06-06 18:04:04.475+0900 I/efl-extension(12884): efl_extension_rotary.c: _init_Xi2_system(375) > Done
06-06 18:04:04.475+0900 I/efl-extension(12884): efl_extension_rotary.c: eext_rotary_object_event_activated_set(283) > eext_rotary_object_event_activated_set : 0xb3000498, elm_image, _activated_obj : 0x0, activated : 1
06-06 18:04:04.515+0900 E/E17     (  585): e_manager.c: _e_manager_cb_window_show_request(1128) > Show request(0x03000002)
06-06 18:04:04.525+0900 I/APP_CORE(12884): appcore-efl.c: __do_app(429) > [APP 12884] Event: RESET State: CREATED
06-06 18:04:04.525+0900 I/CAPI_APPFW_APPLICATION(12884): app_main.c: _ui_app_appcore_reset(645) > app_appcore_reset
06-06 18:04:04.545+0900 W/W_HOME  ( 1184): event_manager.c: _ecore_x_message_cb(403) > state: 0 -> 1
06-06 18:04:04.545+0900 W/W_HOME  ( 1184): event_manager.c: _state_control(194) > control:4, app_state:1 win_state:1(1) pm_state:1 home_visible:0 clock_visible:0 tutorial_state:0 editing : 0, home_clocklist:0, addviewer:0 scrolling : 0, powersaving : 0, apptray state : 0, apptray visibility : 1, apptray edit visibility : 0
06-06 18:04:04.545+0900 W/W_HOME  ( 1184): event_manager.c: _state_control(194) > control:2, app_state:1 win_state:1(1) pm_state:1 home_visible:0 clock_visible:0 tutorial_state:0 editing : 0, home_clocklist:0, addviewer:0 scrolling : 0, powersaving : 0, apptray state : 0, apptray visibility : 1, apptray edit visibility : 0
06-06 18:04:04.545+0900 W/W_HOME  ( 1184): event_manager.c: _state_control(194) > control:1, app_state:1 win_state:1(1) pm_state:1 home_visible:0 clock_visible:0 tutorial_state:0 editing : 0, home_clocklist:0, addviewer:0 scrolling : 0, powersaving : 0, apptray state : 0, apptray visibility : 1, apptray edit visibility : 0
06-06 18:04:04.545+0900 W/W_HOME  ( 1184): main.c: _ecore_x_message_cb(1233) > main_info.is_win_on_top: 0
06-06 18:04:04.545+0900 I/GESTURE (  239): gesture.c: BackGestureSetProperty(4533) > [BackGestureSetProperty] atom=_E_MOVE_ENABLE_DISABLE_BACK_GESTURE, value=1, Apps display 
06-06 18:04:04.545+0900 I/GESTURE (  239): gesture.c: BackGestureSetProperty(4538) > [BackGestureSetProperty] atom=_E_MOVE_ENABLE_DISABLE_BACK_GESTURE, value=0, No apps display 
06-06 18:04:04.545+0900 I/APP_CORE(12884): appcore-efl.c: __do_app(472) > Legacy lifecycle: 0
06-06 18:04:04.545+0900 I/APP_CORE(12884): appcore-efl.c: __do_app(474) > [APP 12884] Initial Launching, call the resume_cb
06-06 18:04:04.545+0900 I/CAPI_APPFW_APPLICATION(12884): app_main.c: _ui_app_appcore_resume(628) > app_appcore_resume
06-06 18:04:04.565+0900 W/APP_CORE(12884): appcore-efl.c: __show_cb(787) > [EVENT_TEST][EVENT] GET SHOW EVENT!!!. WIN:3000002
06-06 18:04:04.575+0900 I/efl-extension(12884): efl_extension_circle_surface.c: _eext_circle_surface_resize_cb(642) > surface 0xb72754a8 = w: 0 h: 0  obj 0xb7283fd0 w: 360 h: 360
06-06 18:04:04.575+0900 I/efl-extension(12884): efl_extension_circle_surface.c: _eext_circle_surface_resize_cb(666) > Surface will be initialized! surface->w= 360 surface->h = 360
06-06 18:04:04.635+0900 W/W_HOME  ( 1184): event_manager.c: _window_visibility_cb(448) > Window [0x2C00003] is now visible(1)
06-06 18:04:04.635+0900 W/W_HOME  ( 1184): event_manager.c: _window_visibility_cb(458) > state: 1 -> 0
06-06 18:04:04.635+0900 W/W_HOME  ( 1184): event_manager.c: _state_control(194) > control:4, app_state:1 win_state:1(0) pm_state:1 home_visible:0 clock_visible:0 tutorial_state:0 editing : 0, home_clocklist:0, addviewer:0 scrolling : 0, powersaving : 0, apptray state : 0, apptray visibility : 1, apptray edit visibility : 0
06-06 18:04:04.635+0900 W/W_HOME  ( 1184): main.c: _window_visibility_cb(1200) > Window [0x2C00003] is now visible(1)
06-06 18:04:04.635+0900 I/APP_CORE( 1184): appcore-efl.c: __do_app(429) > [APP 1184] Event: PAUSE State: RUNNING
06-06 18:04:04.635+0900 I/CAPI_APPFW_APPLICATION( 1184): app_main.c: app_appcore_pause(202) > app_appcore_pause
06-06 18:04:04.635+0900 W/W_HOME  ( 1184): main.c: _appcore_pause_cb(692) > appcore pause
06-06 18:04:04.635+0900 W/W_HOME  ( 1184): event_manager.c: _app_pause_cb(372) > state: 1 -> 2
06-06 18:04:04.635+0900 W/W_HOME  ( 1184): event_manager.c: _state_control(194) > control:2, app_state:2 win_state:1(0) pm_state:1 home_visible:0 clock_visible:0 tutorial_state:0 editing : 0, home_clocklist:0, addviewer:0 scrolling : 0, powersaving : 0, apptray state : 0, apptray visibility : 1, apptray edit visibility : 0
06-06 18:04:04.645+0900 W/W_HOME  ( 1184): event_manager.c: _state_control(194) > control:0, app_state:2 win_state:1(0) pm_state:1 home_visible:0 clock_visible:0 tutorial_state:0 editing : 0, home_clocklist:0, addviewer:0 scrolling : 0, powersaving : 0, apptray state : 0, apptray visibility : 1, apptray edit visibility : 0
06-06 18:04:04.645+0900 W/W_HOME  ( 1184): event_manager.c: _state_control(194) > control:1, app_state:2 win_state:1(0) pm_state:1 home_visible:0 clock_visible:0 tutorial_state:0 editing : 0, home_clocklist:0, addviewer:0 scrolling : 0, powersaving : 0, apptray state : 0, apptray visibility : 1, apptray edit visibility : 0
06-06 18:04:04.645+0900 W/W_HOME  ( 1184): rotary.c: rotary_deattach(156) > rotary_deattach:0xaff82190
06-06 18:04:04.645+0900 I/efl-extension( 1184): efl_extension_rotary.c: eext_rotary_object_event_callback_del(235) > In
06-06 18:04:04.645+0900 I/efl-extension( 1184): efl_extension_rotary.c: eext_rotary_object_event_callback_del(240) > callback del 0xaff82190, elm_layout, func : 0xb6f53fd1
06-06 18:04:04.645+0900 I/efl-extension( 1184): efl_extension_rotary.c: eext_rotary_object_event_callback_del(248) > Removed cb from callbacks
06-06 18:04:04.645+0900 I/efl-extension( 1184): efl_extension_rotary.c: eext_rotary_object_event_callback_del(266) > Freed cb
06-06 18:04:04.645+0900 I/efl-extension( 1184): efl_extension_rotary.c: eext_rotary_object_event_callback_del(273) > done
06-06 18:04:04.645+0900 I/efl-extension( 1184): efl_extension_rotary.c: eext_rotary_object_event_activated_set(283) > eext_rotary_object_event_activated_set : 0xb74ac380, elm_box, _activated_obj : 0xaff82190, activated : 1
06-06 18:04:04.645+0900 I/efl-extension( 1184): efl_extension_rotary.c: eext_rotary_object_event_activated_set(291) > Activation delete!!!!
06-06 18:04:04.645+0900 E/wnotib  ( 1184): w-notification-board-action-drawer.c: wnotib_action_drawer_hidden_get(4570) > [NULL==g_wnotib_action_drawer_data] msg Drawer not initialized.
06-06 18:04:04.645+0900 I/wnotib  ( 1184): w-notification-board-broker-main.c: _wnotib_scroller_event_handler(1108) > No second depth view available.
06-06 18:04:04.645+0900 I/MESSAGE_PORT(  839): MessagePortIpcServer.cpp: OnReadMessage(739) > _MessagePortIpcServer::OnReadMessage
06-06 18:04:04.645+0900 I/MESSAGE_PORT(  839): MessagePortIpcServer.cpp: HandleReceivedMessage(578) > _MessagePortIpcServer::HandleReceivedMessage
06-06 18:04:04.645+0900 I/MESSAGE_PORT(  839): MessagePortStub.cpp: OnIpcRequestReceived(147) > MessagePort message received
06-06 18:04:04.645+0900 I/MESSAGE_PORT(  839): MessagePortStub.cpp: OnCheckRemotePort(115) > _MessagePortStub::OnCheckRemotePort.
06-06 18:04:04.645+0900 I/MESSAGE_PORT(  839): MessagePortService.cpp: CheckRemotePort(207) > _MessagePortService::CheckRemotePort
06-06 18:04:04.645+0900 I/MESSAGE_PORT(  839): MessagePortService.cpp: GetKey(365) > _MessagePortService::GetKey
06-06 18:04:04.645+0900 I/MESSAGE_PORT(  839): MessagePortService.cpp: CheckRemotePort(220) > Check a remote message port: [com.samsung.w-music-player.music-control-service:music-control-service-request-message-port]
06-06 18:04:04.645+0900 I/MESSAGE_PORT(  839): MessagePortIpcServer.cpp: Send(847) > _MessagePortIpcServer::Stop
06-06 18:04:04.665+0900 I/MESSAGE_PORT(  839): MessagePortIpcServer.cpp: OnReadMessage(739) > _MessagePortIpcServer::OnReadMessage
06-06 18:04:04.665+0900 I/MESSAGE_PORT(  839): MessagePortIpcServer.cpp: HandleReceivedMessage(578) > _MessagePortIpcServer::HandleReceivedMessage
06-06 18:04:04.665+0900 I/MESSAGE_PORT(  839): MessagePortStub.cpp: OnIpcRequestReceived(147) > MessagePort message received
06-06 18:04:04.665+0900 I/MESSAGE_PORT(  839): MessagePortStub.cpp: OnSendMessage(126) > MessagePort OnSendMessage
06-06 18:04:04.665+0900 I/MESSAGE_PORT(  839): MessagePortService.cpp: SendMessage(291) > _MessagePortService::SendMessage
06-06 18:04:04.665+0900 I/MESSAGE_PORT(  839): MessagePortService.cpp: GetKey(365) > _MessagePortService::GetKey
06-06 18:04:04.665+0900 I/MESSAGE_PORT(  839): MessagePortService.cpp: SendMessage(299) > Sends a message to a remote message port [com.samsung.w-music-player.music-control-service:music-control-service-request-message-port]
06-06 18:04:04.665+0900 I/MESSAGE_PORT(  839): MessagePortStub.cpp: SendMessage(138) > MessagePort SendMessage
06-06 18:04:04.665+0900 I/MESSAGE_PORT(  839): MessagePortIpcServer.cpp: SendResponse(884) > _MessagePortIpcServer::SendResponse
06-06 18:04:04.665+0900 I/MESSAGE_PORT(  839): MessagePortIpcServer.cpp: Send(847) > _MessagePortIpcServer::Stop
06-06 18:04:04.665+0900 I/GESTURE (  239): gesture.c: BackGestureSetProperty(4538) > [BackGestureSetProperty] atom=_E_MOVE_ENABLE_DISABLE_BACK_GESTURE, value=0, No apps display 
06-06 18:04:04.665+0900 I/GESTURE (  239): gesture.c: BackGestureSetProperty(4538) > [BackGestureSetProperty] atom=_E_MOVE_ENABLE_DISABLE_BACK_GESTURE, value=0, No apps display 
06-06 18:04:04.665+0900 E/CAPI_APPFW_APP_CONTROL( 1471): app_control.c: app_control_error(133) > [app_control_get_caller] INVALID_PARAMETER(0xffffffea) : invalid app_control handle type
06-06 18:04:04.665+0900 W/MUSIC_CONTROL_SERVICE( 1471): music-control-service.c: _music_control_service_pasre_request(409) > [33m[TID:1471]   value = [false][0m
06-06 18:04:04.735+0900 I/APP_CORE(12884): appcore-efl.c: __do_app(429) > [APP 12884] Event: RESUME State: RUNNING
06-06 18:04:04.755+0900 I/wnotib  ( 1184): w-notification-board-broker-main.c: _wnotib_ecore_x_event_visibility_changed_cb(701) > fully_obscured: 1
06-06 18:04:04.755+0900 E/wnotib  ( 1184): w-notification-board-action-drawer.c: wnotib_action_drawer_hidden_get(4570) > [NULL==g_wnotib_action_drawer_data] msg Drawer not initialized.
06-06 18:04:05.165+0900 I/APP_CORE( 1184): appcore-efl.c: __do_app(429) > [APP 1184] Event: MEM_FLUSH State: PAUSED
06-06 18:04:05.405+0900 W/AUL_AMD (  905): amd_request.c: __request_handler(640) > __request_handler: 14
06-06 18:04:05.405+0900 W/AUL_AMD (  905): amd_request.c: __send_result_to_client(83) > __send_result_to_client, pid: 12884
06-06 18:04:05.415+0900 W/AUL_AMD (  905): amd_request.c: __request_handler(640) > __request_handler: 12
06-06 18:04:05.675+0900 I/AUL_PAD (12921): launchpad_loader.c: main(600) > [candidate] elm init, returned: 1
06-06 18:04:05.905+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7285350), block(1)
06-06 18:04:05.905+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7285350), ev->cur.canvas.x(241) ev->cur.canvas.y(217)
06-06 18:04:05.905+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7285350), hold(0) freeze(0)
06-06 18:04:05.905+0900 E/EFL     (12884): evas_main<12884> evas_events.c:1009 evas_event_feed_mouse_down() ButtonEvent:down time=8764726 button=1 downs=1
06-06 18:04:05.915+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7285350), block(1)
06-06 18:04:05.915+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7285350), ev->cur.canvas.x(242) ev->cur.canvas.y(217)
06-06 18:04:05.915+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7285350), hold(0) freeze(0)
06-06 18:04:05.925+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7285350), block(1)
06-06 18:04:05.925+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7285350), ev->cur.canvas.x(243) ev->cur.canvas.y(217)
06-06 18:04:05.925+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7285350), hold(0) freeze(0)
06-06 18:04:05.945+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7285350), block(1)
06-06 18:04:05.945+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7285350), ev->cur.canvas.x(243) ev->cur.canvas.y(212)
06-06 18:04:05.955+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7285350), hold(0) freeze(0)
06-06 18:04:05.965+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7285350), block(1)
06-06 18:04:05.965+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7285350), ev->cur.canvas.x(243) ev->cur.canvas.y(203)
06-06 18:04:05.965+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7285350), hold(0) freeze(0)
06-06 18:04:05.975+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7285350), block(1)
06-06 18:04:05.975+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7285350), ev->cur.canvas.x(243) ev->cur.canvas.y(192)
06-06 18:04:05.975+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7285350), hold(0) freeze(0)
06-06 18:04:05.985+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7285350), block(1)
06-06 18:04:05.985+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7285350), ev->cur.canvas.x(243) ev->cur.canvas.y(180)
06-06 18:04:05.985+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7285350), hold(0) freeze(0)
06-06 18:04:05.985+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:4249 _elm_scroll_mouse_move_event_cb() [DDO] animator
06-06 18:04:05.985+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3353 _elm_scroll_post_event_move() [DDO] obj(b7285350), type(elm_genlist)
06-06 18:04:05.985+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3354 _elm_scroll_post_event_move() [DDO] hold_parent(0)
06-06 18:04:05.985+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3405 _elm_scroll_post_event_move() [DDO] elm_widget_drag_lock_y_set : obj(b7285350), type(elm_genlist)
06-06 18:04:05.995+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7285350), block(1)
06-06 18:04:05.995+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7285350), ev->cur.canvas.x(243) ev->cur.canvas.y(167)
06-06 18:04:05.995+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7285350), hold(0) freeze(0)
06-06 18:04:05.995+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b7285350), locked_x(0)
06-06 18:04:05.995+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b7285350)
06-06 18:04:06.035+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7285350), block(1)
06-06 18:04:06.035+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7285350), ev->cur.canvas.x(245) ev->cur.canvas.y(155)
06-06 18:04:06.035+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7285350), hold(0) freeze(0)
06-06 18:04:06.035+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7285350), block(1)
06-06 18:04:06.035+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7285350), ev->cur.canvas.x(249) ev->cur.canvas.y(144)
06-06 18:04:06.035+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7285350), hold(0) freeze(0)
06-06 18:04:06.035+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7285350), block(1)
06-06 18:04:06.035+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7285350), ev->cur.canvas.x(251) ev->cur.canvas.y(135)
06-06 18:04:06.035+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7285350), hold(0) freeze(0)
06-06 18:04:06.035+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b7285350), locked_x(0)
06-06 18:04:06.035+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b7285350)
06-06 18:04:06.055+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7285350), block(1)
06-06 18:04:06.055+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7285350), ev->cur.canvas.x(252) ev->cur.canvas.y(129)
06-06 18:04:06.055+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7285350), hold(0) freeze(0)
06-06 18:04:06.055+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7285350), block(1)
06-06 18:04:06.055+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7285350), ev->cur.canvas.x(252) ev->cur.canvas.y(122)
06-06 18:04:06.055+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7285350), hold(0) freeze(0)
06-06 18:04:06.055+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b7285350), locked_x(0)
06-06 18:04:06.055+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b7285350)
06-06 18:04:06.085+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7285350), block(1)
06-06 18:04:06.085+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7285350), ev->cur.canvas.x(252) ev->cur.canvas.y(117)
06-06 18:04:06.085+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7285350), hold(0) freeze(0)
06-06 18:04:06.085+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7285350), block(1)
06-06 18:04:06.085+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7285350), ev->cur.canvas.x(252) ev->cur.canvas.y(115)
06-06 18:04:06.085+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7285350), hold(0) freeze(0)
06-06 18:04:06.085+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7285350), block(1)
06-06 18:04:06.085+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7285350), ev->cur.canvas.x(254) ev->cur.canvas.y(109)
06-06 18:04:06.085+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7285350), hold(0) freeze(0)
06-06 18:04:06.085+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b7285350), locked_x(0)
06-06 18:04:06.085+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b7285350)
06-06 18:04:06.105+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7285350), block(1)
06-06 18:04:06.105+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7285350), ev->cur.canvas.x(255) ev->cur.canvas.y(104)
06-06 18:04:06.105+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7285350), hold(0) freeze(0)
06-06 18:04:06.105+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7285350), block(1)
06-06 18:04:06.105+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7285350), ev->cur.canvas.x(255) ev->cur.canvas.y(102)
06-06 18:04:06.105+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7285350), hold(0) freeze(0)
06-06 18:04:06.105+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b7285350), locked_x(0)
06-06 18:04:06.105+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b7285350)
06-06 18:04:06.125+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7285350), block(1)
06-06 18:04:06.125+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7285350), ev->cur.canvas.x(255) ev->cur.canvas.y(101)
06-06 18:04:06.125+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7285350), hold(0) freeze(0)
06-06 18:04:06.125+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7285350), block(1)
06-06 18:04:06.125+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7285350), ev->cur.canvas.x(255) ev->cur.canvas.y(100)
06-06 18:04:06.125+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7285350), hold(0) freeze(0)
06-06 18:04:06.125+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b7285350), locked_x(0)
06-06 18:04:06.125+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b7285350)
06-06 18:04:06.155+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7285350), block(1)
06-06 18:04:06.155+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7285350), ev->cur.canvas.x(255) ev->cur.canvas.y(99)
06-06 18:04:06.155+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7285350), hold(0) freeze(0)
06-06 18:04:06.155+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b7285350), locked_x(0)
06-06 18:04:06.155+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b7285350)
06-06 18:04:06.175+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b7285350), locked_x(0)
06-06 18:04:06.175+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b7285350), locked_x(0)
06-06 18:04:06.175+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b7285350), locked_x(0)
06-06 18:04:06.175+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b7285350), locked_x(0)
06-06 18:04:06.175+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7285350), block(1)
06-06 18:04:06.175+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7285350), ev->cur.canvas.x(256) ev->cur.canvas.y(99)
06-06 18:04:06.175+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7285350), hold(0) freeze(0)
06-06 18:04:06.185+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b7285350), locked_x(0)
06-06 18:04:06.185+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b7285350)
06-06 18:04:06.195+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b7285350), locked_x(0)
06-06 18:04:06.195+0900 E/EFL     (12884): evas_main<12884> evas_events.c:1275 evas_event_feed_mouse_up() ButtonEvent:up time=8765018 button=1 downs=0
06-06 18:04:06.205+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:2278 _elm_scroll_post_event_up() [DDO] lock set false. : obj(b7285350), type(elm_genlist)
06-06 18:04:06.625+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7285350), block(1)
06-06 18:04:06.625+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7285350), ev->cur.canvas.x(243) ev->cur.canvas.y(183)
06-06 18:04:06.625+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7285350), hold(0) freeze(0)
06-06 18:04:06.625+0900 E/EFL     (12884): evas_main<12884> evas_events.c:1009 evas_event_feed_mouse_down() ButtonEvent:down time=8765445 button=1 downs=1
06-06 18:04:06.645+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7285350), block(1)
06-06 18:04:06.645+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7285350), ev->cur.canvas.x(239) ev->cur.canvas.y(188)
06-06 18:04:06.645+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7285350), hold(0) freeze(0)
06-06 18:04:06.645+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7285350), block(1)
06-06 18:04:06.645+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7285350), ev->cur.canvas.x(237) ev->cur.canvas.y(189)
06-06 18:04:06.645+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7285350), hold(0) freeze(0)
06-06 18:04:06.665+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7285350), block(1)
06-06 18:04:06.665+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7285350), ev->cur.canvas.x(236) ev->cur.canvas.y(189)
06-06 18:04:06.665+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7285350), hold(0) freeze(0)
06-06 18:04:06.685+0900 E/EFL     (12884): evas_main<12884> evas_events.c:1275 evas_event_feed_mouse_up() ButtonEvent:up time=8765499 button=1 downs=0
06-06 18:04:06.855+0900 I/efl-extension(12884): efl_extension_rotary.c: eext_rotary_object_event_callback_add(147) > In
06-06 18:04:06.855+0900 I/efl-extension(12884): efl_extension_rotary.c: eext_rotary_object_event_activated_set(283) > eext_rotary_object_event_activated_set : 0xb7371668, elm_image, _activated_obj : 0xb3000498, activated : 1
06-06 18:04:06.855+0900 I/efl-extension(12884): efl_extension_rotary.c: eext_rotary_object_event_activated_set(291) > Activation delete!!!!
06-06 18:04:07.565+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b731dfd0), block(1)
06-06 18:04:07.565+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b731dfd0), ev->cur.canvas.x(255) ev->cur.canvas.y(222)
06-06 18:04:07.575+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b731dfd0), hold(0) freeze(0)
06-06 18:04:07.575+0900 E/EFL     (12884): evas_main<12884> evas_events.c:1009 evas_event_feed_mouse_down() ButtonEvent:down time=8766387 button=1 downs=1
06-06 18:04:07.575+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b731dfd0), block(1)
06-06 18:04:07.575+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b731dfd0), ev->cur.canvas.x(256) ev->cur.canvas.y(225)
06-06 18:04:07.575+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b731dfd0), hold(0) freeze(0)
06-06 18:04:07.595+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b731dfd0), block(1)
06-06 18:04:07.595+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b731dfd0), ev->cur.canvas.x(254) ev->cur.canvas.y(225)
06-06 18:04:07.595+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b731dfd0), hold(0) freeze(0)
06-06 18:04:07.605+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b731dfd0), block(1)
06-06 18:04:07.605+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b731dfd0), ev->cur.canvas.x(251) ev->cur.canvas.y(223)
06-06 18:04:07.605+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b731dfd0), hold(0) freeze(0)
06-06 18:04:07.605+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b731dfd0), block(1)
06-06 18:04:07.605+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b731dfd0), ev->cur.canvas.x(250) ev->cur.canvas.y(221)
06-06 18:04:07.605+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b731dfd0), hold(0) freeze(0)
06-06 18:04:07.625+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b731dfd0), block(1)
06-06 18:04:07.625+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b731dfd0), ev->cur.canvas.x(248) ev->cur.canvas.y(218)
06-06 18:04:07.625+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b731dfd0), hold(0) freeze(0)
06-06 18:04:07.635+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b731dfd0), block(1)
06-06 18:04:07.635+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b731dfd0), ev->cur.canvas.x(247) ev->cur.canvas.y(209)
06-06 18:04:07.635+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b731dfd0), hold(0) freeze(0)
06-06 18:04:07.645+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b731dfd0), block(1)
06-06 18:04:07.645+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b731dfd0), ev->cur.canvas.x(243) ev->cur.canvas.y(197)
06-06 18:04:07.645+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b731dfd0), hold(0) freeze(0)
06-06 18:04:07.655+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b731dfd0), block(1)
06-06 18:04:07.655+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b731dfd0), ev->cur.canvas.x(243) ev->cur.canvas.y(186)
06-06 18:04:07.655+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b731dfd0), hold(0) freeze(0)
06-06 18:04:07.655+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:4249 _elm_scroll_mouse_move_event_cb() [DDO] animator
06-06 18:04:07.655+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3353 _elm_scroll_post_event_move() [DDO] obj(b731dfd0), type(elm_genlist)
06-06 18:04:07.655+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3354 _elm_scroll_post_event_move() [DDO] hold_parent(0)
06-06 18:04:07.655+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3405 _elm_scroll_post_event_move() [DDO] elm_widget_drag_lock_y_set : obj(b731dfd0), type(elm_genlist)
06-06 18:04:07.665+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b731dfd0), block(1)
06-06 18:04:07.665+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b731dfd0), ev->cur.canvas.x(246) ev->cur.canvas.y(171)
06-06 18:04:07.665+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b731dfd0), hold(0) freeze(0)
06-06 18:04:07.665+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b731dfd0), locked_x(0)
06-06 18:04:07.665+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b731dfd0)
06-06 18:04:07.715+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b731dfd0), block(1)
06-06 18:04:07.715+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b731dfd0), ev->cur.canvas.x(251) ev->cur.canvas.y(153)
06-06 18:04:07.715+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b731dfd0), hold(0) freeze(0)
06-06 18:04:07.715+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b731dfd0), block(1)
06-06 18:04:07.715+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b731dfd0), ev->cur.canvas.x(256) ev->cur.canvas.y(140)
06-06 18:04:07.715+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b731dfd0), hold(0) freeze(0)
06-06 18:04:07.715+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b731dfd0), block(1)
06-06 18:04:07.715+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b731dfd0), ev->cur.canvas.x(258) ev->cur.canvas.y(133)
06-06 18:04:07.715+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b731dfd0), hold(0) freeze(0)
06-06 18:04:07.715+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b731dfd0), block(1)
06-06 18:04:07.715+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b731dfd0), ev->cur.canvas.x(260) ev->cur.canvas.y(128)
06-06 18:04:07.715+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b731dfd0), hold(0) freeze(0)
06-06 18:04:07.715+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b731dfd0), locked_x(0)
06-06 18:04:07.715+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b731dfd0)
06-06 18:04:07.745+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b731dfd0), block(1)
06-06 18:04:07.745+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b731dfd0), ev->cur.canvas.x(264) ev->cur.canvas.y(121)
06-06 18:04:07.745+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b731dfd0), hold(0) freeze(0)
06-06 18:04:07.745+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b731dfd0), block(1)
06-06 18:04:07.745+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b731dfd0), ev->cur.canvas.x(267) ev->cur.canvas.y(115)
06-06 18:04:07.745+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b731dfd0), hold(0) freeze(0)
06-06 18:04:07.745+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b731dfd0), block(1)
06-06 18:04:07.745+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b731dfd0), ev->cur.canvas.x(267) ev->cur.canvas.y(114)
06-06 18:04:07.745+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b731dfd0), hold(0) freeze(0)
06-06 18:04:07.745+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b731dfd0), locked_x(0)
06-06 18:04:07.745+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b731dfd0)
06-06 18:04:07.765+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b731dfd0), block(1)
06-06 18:04:07.765+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b731dfd0), ev->cur.canvas.x(268) ev->cur.canvas.y(112)
06-06 18:04:07.765+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b731dfd0), hold(0) freeze(0)
06-06 18:04:07.765+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b731dfd0), block(1)
06-06 18:04:07.765+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b731dfd0), ev->cur.canvas.x(268) ev->cur.canvas.y(109)
06-06 18:04:07.765+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b731dfd0), hold(0) freeze(0)
06-06 18:04:07.765+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b731dfd0), locked_x(0)
06-06 18:04:07.765+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b731dfd0)
06-06 18:04:07.785+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b731dfd0), block(1)
06-06 18:04:07.785+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b731dfd0), ev->cur.canvas.x(268) ev->cur.canvas.y(108)
06-06 18:04:07.785+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b731dfd0), hold(0) freeze(0)
06-06 18:04:07.795+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b731dfd0), locked_x(0)
06-06 18:04:07.795+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b731dfd0)
06-06 18:04:07.815+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b731dfd0), block(1)
06-06 18:04:07.815+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b731dfd0), ev->cur.canvas.x(268) ev->cur.canvas.y(107)
06-06 18:04:07.815+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b731dfd0), hold(0) freeze(0)
06-06 18:04:07.815+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b731dfd0), block(1)
06-06 18:04:07.815+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b731dfd0), ev->cur.canvas.x(269) ev->cur.canvas.y(107)
06-06 18:04:07.815+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b731dfd0), hold(0) freeze(0)
06-06 18:04:07.815+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b731dfd0), locked_x(0)
06-06 18:04:07.815+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b731dfd0)
06-06 18:04:07.835+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b731dfd0), block(1)
06-06 18:04:07.835+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b731dfd0), ev->cur.canvas.x(269) ev->cur.canvas.y(108)
06-06 18:04:07.835+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b731dfd0), hold(0) freeze(0)
06-06 18:04:07.835+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b731dfd0), locked_x(0)
06-06 18:04:07.835+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b731dfd0)
06-06 18:04:07.845+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b731dfd0), block(1)
06-06 18:04:07.845+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b731dfd0), ev->cur.canvas.x(271) ev->cur.canvas.y(113)
06-06 18:04:07.845+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b731dfd0), hold(0) freeze(0)
06-06 18:04:07.845+0900 E/EFL     (12884): evas_main<12884> evas_events.c:1275 evas_event_feed_mouse_up() ButtonEvent:up time=8766667 button=1 downs=0
06-06 18:04:07.855+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:2278 _elm_scroll_post_event_up() [DDO] lock set false. : obj(b731dfd0), type(elm_genlist)
06-06 18:04:08.395+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b731dfd0), block(1)
06-06 18:04:08.395+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b731dfd0), ev->cur.canvas.x(231) ev->cur.canvas.y(186)
06-06 18:04:08.395+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b731dfd0), hold(0) freeze(0)
06-06 18:04:08.395+0900 E/EFL     (12884): evas_main<12884> evas_events.c:1009 evas_event_feed_mouse_down() ButtonEvent:down time=8767199 button=1 downs=1
06-06 18:04:08.395+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b731dfd0), block(1)
06-06 18:04:08.395+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b731dfd0), ev->cur.canvas.x(228) ev->cur.canvas.y(189)
06-06 18:04:08.395+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b731dfd0), hold(0) freeze(0)
06-06 18:04:08.415+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b731dfd0), block(1)
06-06 18:04:08.415+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b731dfd0), ev->cur.canvas.x(225) ev->cur.canvas.y(189)
06-06 18:04:08.415+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b731dfd0), hold(0) freeze(0)
06-06 18:04:08.435+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b731dfd0), block(1)
06-06 18:04:08.435+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b731dfd0), ev->cur.canvas.x(224) ev->cur.canvas.y(189)
06-06 18:04:08.435+0900 E/EFL     (12884): elementary<12884> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b731dfd0), hold(0) freeze(0)
06-06 18:04:08.435+0900 E/EFL     (12884): evas_main<12884> evas_events.c:1275 evas_event_feed_mouse_up() ButtonEvent:up time=8767252 button=1 downs=0
06-06 18:04:08.555+0900 W/CRASH_MANAGER(12784): worker.c: worker_job(1199) > 1112884756963146520384
