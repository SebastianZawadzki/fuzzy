S/W Version Information
Model: SM-R735S
Tizen-Version: 2.3.1.2
Build-Number: R735SKSU1AOKE
Build-Date: 2015.11.25 20:46:58

Crash Information
Process Name: uicomponents
PID: 31261
Date: 2016-06-06 22:15:09+0900
Executable File Path: /opt/usr/apps/org.example.uicomponents/bin/uicomponents
Signal: 11
      (SIGSEGV)
      si_code: -6
      signal sent by tkill (sent by pid 31261, uid 5000)

Register Information
r0   = 0x00000000, r1   = 0xb6c9cc78
r2   = 0xfb2b7400, r3   = 0x00000000
r4   = 0xb83339c8, r5   = 0xb82f7690
r6   = 0x00000001, r7   = 0xb83339c8
r8   = 0x00000000, r9   = 0xb6efd4c8
r10  = 0xb6efd58c, fp   = 0xb81a3ec8
ip   = 0xb6cad738, sp   = 0xbe89b1a0
lr   = 0xb6c9a7f3, pc   = 0xb6a9e9d0
cpsr = 0x60000010

Memory Information
MemTotal:   407572 KB
MemFree:     10248 KB
Buffers:     12408 KB
Cached:      92456 KB
VmPeak:      77688 KB
VmSize:      75524 KB
VmLck:           0 KB
VmPin:           0 KB
VmHWM:       19524 KB
VmRSS:       19524 KB
VmData:      15676 KB
VmStk:         136 KB
VmExe:          20 KB
VmLib:       24764 KB
VmPTE:          54 KB
VmSwap:          0 KB

Threads Information
Threads: 2
PID = 31261 TID = 31261
31261 31491 

Maps Information
b29c5000 b29c9000 r-xp /usr/lib/libogg.so.0.7.1
b29d1000 b29f3000 r-xp /usr/lib/libvorbis.so.0.4.3
b29fb000 b2a03000 r-xp /usr/lib/libmdm-common.so.1.0.89
b2a04000 b2a47000 r-xp /usr/lib/libsndfile.so.1.0.25
b2a54000 b2a9c000 r-xp /usr/lib/pulseaudio/libpulsecommon-4.0.so
b2a9d000 b2aa2000 r-xp /usr/lib/libjson.so.0.0.1
b2aaa000 b2adb000 r-xp /usr/lib/libmdm.so.1.1.85
b2ae3000 b2aeb000 r-xp /usr/lib/lib_DNSe_NRSS_ver225.so
b2afa000 b2b0a000 r-xp /usr/lib/lib_SamsungRec_TizenV04014.so
b2b2b000 b2b38000 r-xp /usr/lib/libail.so.0.1.0
b2b41000 b2b44000 r-xp /usr/lib/libsyspopup_caller.so.0.1.0
b2b4c000 b2b84000 r-xp /usr/lib/libpulse.so.0.16.2
b2b85000 b2be6000 r-xp /usr/lib/libasound.so.2.0.0
b2bf0000 b2bf3000 r-xp /usr/lib/libpulse-simple.so.0.0.4
b2bfb000 b2c00000 r-xp /usr/lib/libascenario-0.2.so.0.0.0
b2c08000 b2c21000 r-xp /usr/lib/libavsysaudio.so.0.0.1
b2c2a000 b2c2e000 r-xp /usr/lib/libmmfsoundcommon.so.0.0.0
b2c37000 b2c41000 r-xp /usr/lib/libaudio-session-mgr.so.0.0.0
b2c4d000 b2c52000 r-xp /usr/lib/libmmfsession.so.0.0.0
b2c5a000 b2c70000 r-xp /usr/lib/libmmfsound.so.0.1.0
b2c82000 b2c89000 r-xp /usr/lib/libmmfcommon.so.0.0.0
b2c91000 b2c9b000 r-xp /usr/lib/libcapi-media-sound-manager.so.0.1.48
b2ca3000 b2ca5000 r-xp /usr/lib/libcapi-media-wav-player.so.0.1.10
b2cad000 b2cae000 r-xp /usr/lib/libmmfkeysound.so.0.0.0
b2cb6000 b2cbd000 r-xp /usr/lib/libfeedback.so.0.1.4
b2cdc000 b2cdd000 r-xp /usr/lib/edje/modules/feedback/linux-gnueabi-armv7l-1.0.0/module.so
b2ce5000 b2d6c000 rw-s anon_inode:dmabuf
b2d6c000 b2df3000 rw-s anon_inode:dmabuf
b2e7e000 b2f05000 rw-s anon_inode:dmabuf
b2f84000 b300b000 rw-s anon_inode:dmabuf
b31e5000 b39e4000 rwxp [stack:31491]
b39e4000 b39fb000 r-xp /usr/lib/edje/modules/elm/linux-gnueabi-armv7l-1.0.0/module.so
b3a08000 b3a0a000 r-xp /usr/lib/libgenlock.so
b3a13000 b3a14000 r-xp /usr/lib/evas/modules/loaders/eet/linux-gnueabi-armv7l-1.7.99/module.so
b3a1c000 b3a1e000 r-xp /usr/lib/evas/modules/loaders/png/linux-gnueabi-armv7l-1.7.99/module.so
b3a28000 b3a2d000 r-xp /usr/lib/bufmgr/libtbm_msm.so.0.0.0
b3a35000 b3a40000 r-xp /usr/lib/evas/modules/engines/software_generic/linux-gnueabi-armv7l-1.7.99/module.so
b3d68000 b3e32000 r-xp /usr/lib/libCOREGL.so.4.0
b3e43000 b3e48000 r-xp /usr/lib/libcapi-media-tool.so.0.1.5
b3e50000 b3e71000 r-xp /usr/lib/libexif.so.12.3.3
b3e84000 b3e89000 r-xp /usr/lib/libmmutil_imgp.so.0.0.0
b3e91000 b3e96000 r-xp /usr/lib/libmmutil_jpeg.so.0.0.0
b5425000 b5427000 r-xp /usr/lib/libdri2.so.0.0.0
b542f000 b5437000 r-xp /usr/lib/libdrm.so.2.4.0
b543f000 b5442000 r-xp /usr/lib/libcapi-media-image-util.so.0.3.5
b544a000 b552e000 r-xp /usr/lib/libicuuc.so.51.1
b5543000 b5680000 r-xp /usr/lib/libicui18n.so.51.1
b5690000 b5695000 r-xp /usr/lib/libcapi-system-info.so.0.2.0
b569d000 b56a3000 r-xp /usr/lib/libxcb-render.so.0.0.0
b56ab000 b56ac000 r-xp /usr/lib/libxcb-shm.so.0.0.0
b56b5000 b56b8000 r-xp /usr/lib/libEGL.so.1.4
b56c0000 b56ce000 r-xp /usr/lib/libGLESv2.so.2.0
b56d7000 b56de000 r-xp /usr/lib/libtbm.so.1.0.0
b56e6000 b5707000 r-xp /usr/lib/libui-extension.so.0.1.0
b5710000 b5722000 r-xp /usr/lib/libtts.so
b572a000 b57e2000 r-xp /usr/lib/libcairo.so.2.11200.14
b57ed000 b57ff000 r-xp /usr/lib/libefl-assist.so.0.1.0
b5807000 b5828000 r-xp /usr/lib/libefl-extension.so.0.1.0
b5830000 b5843000 r-xp /opt/usr/apps/org.example.uicomponents/bin/uicomponents
b5a0a000 b5a14000 r-xp /lib/libnss_files-2.13.so
b5a1d000 b5aec000 r-xp /usr/lib/libscim-1.0.so.8.2.3
b5b02000 b5b26000 r-xp /usr/lib/ecore/immodules/libisf-imf-module.so
b5b2f000 b5b35000 r-xp /usr/lib/libappsvc.so.0.1.0
b5b3d000 b5b3f000 r-xp /usr/lib/libcapi-appfw-app-common.so.0.3.2.5
b5b48000 b5b4d000 r-xp /usr/lib/libcapi-appfw-app-control.so.0.3.2.5
b5b58000 b5b63000 r-xp /usr/lib/evas/modules/engines/software_x11/linux-gnueabi-armv7l-1.7.99/module.so
b5b6b000 b5b6d000 r-xp /usr/lib/libiniparser.so.0
b5b76000 b5b7b000 r-xp /usr/lib/libappcore-common.so.1.1
b5b84000 b5b8c000 r-xp /usr/lib/libcapi-system-system-settings.so.0.0.2
b5b8d000 b5b91000 r-xp /usr/lib/libcapi-appfw-application.so.0.3.2.5
b5b9e000 b5ba0000 r-xp /usr/lib/libXau.so.6.0.0
b5ba9000 b5bb0000 r-xp /lib/libcrypt-2.13.so
b5be0000 b5be2000 r-xp /usr/lib/libiri.so
b5bea000 b5d92000 r-xp /usr/lib/libcrypto.so.1.0.0
b5dab000 b5df8000 r-xp /usr/lib/libssl.so.1.0.0
b5e05000 b5e33000 r-xp /usr/lib/libidn.so.11.5.44
b5e3b000 b5e44000 r-xp /usr/lib/libcares.so.2.1.0
b5e4d000 b5e60000 r-xp /usr/lib/libxcb.so.1.1.0
b5e69000 b5e6b000 r-xp /usr/lib/journal/libjournal.so.0.1.0
b5e74000 b5e76000 r-xp /usr/lib/libSLP-db-util.so.0.1.0
b5e7f000 b5f4b000 r-xp /usr/lib/libxml2.so.2.7.8
b5f58000 b5f5a000 r-xp /usr/lib/libgmodule-2.0.so.0.3200.3
b5f62000 b5f67000 r-xp /usr/lib/libffi.so.5.0.10
b5f6f000 b5f70000 r-xp /usr/lib/libgthread-2.0.so.0.3200.3
b5f79000 b5f84000 r-xp /usr/lib/libgpg-error.so.0.15.0
b5f8c000 b5f8f000 r-xp /lib/libattr.so.1.1.0
b5f97000 b602b000 r-xp /usr/lib/libstdc++.so.6.0.16
b603e000 b605a000 r-xp /usr/lib/libsecurity-server-commons.so.1.0.0
b6063000 b607b000 r-xp /usr/lib/libpng12.so.0.50.0
b6084000 b609a000 r-xp /lib/libexpat.so.1.5.2
b60a4000 b60e8000 r-xp /usr/lib/libcurl.so.4.3.0
b60f1000 b60fb000 r-xp /usr/lib/libXext.so.6.4.0
b6104000 b6107000 r-xp /usr/lib/libXtst.so.6.1.0
b6110000 b6116000 r-xp /usr/lib/libXrender.so.1.3.0
b611f000 b6125000 r-xp /usr/lib/libXrandr.so.2.2.0
b612d000 b612e000 r-xp /usr/lib/libXinerama.so.1.0.0
b6137000 b6140000 r-xp /usr/lib/libXi.so.6.1.0
b6148000 b614b000 r-xp /usr/lib/libXfixes.so.3.1.0
b6153000 b6155000 r-xp /usr/lib/libXgesture.so.7.0.0
b615d000 b615f000 r-xp /usr/lib/libXcomposite.so.1.0.0
b6168000 b616a000 r-xp /usr/lib/libXdamage.so.1.1.0
b6172000 b6179000 r-xp /usr/lib/libXcursor.so.1.0.2
b6181000 b6184000 r-xp /usr/lib/libecore_input_evas.so.1.7.99
b618c000 b6190000 r-xp /usr/lib/libecore_ipc.so.1.7.99
b6199000 b619e000 r-xp /usr/lib/libecore_fb.so.1.7.99
b61a8000 b6289000 r-xp /usr/lib/libX11.so.6.3.0
b6294000 b62b7000 r-xp /usr/lib/libjpeg.so.8.0.2
b62cf000 b62e5000 r-xp /lib/libz.so.1.2.5
b62ed000 b6362000 r-xp /usr/lib/libsqlite3.so.0.8.6
b636c000 b6381000 r-xp /usr/lib/libpkgmgr_parser.so.0.1.0
b638a000 b63be000 r-xp /usr/lib/libgobject-2.0.so.0.3200.3
b63c7000 b649a000 r-xp /usr/lib/libgio-2.0.so.0.3200.3
b64a5000 b64b5000 r-xp /lib/libresolv-2.13.so
b64b9000 b6535000 r-xp /usr/lib/libgcrypt.so.20.0.3
b6541000 b6559000 r-xp /usr/lib/liblzma.so.5.0.3
b6562000 b6565000 r-xp /lib/libcap.so.2.21
b656d000 b6593000 r-xp /usr/lib/libsecurity-server-client.so.1.0.1
b659c000 b659d000 r-xp /usr/lib/libecore_imf_evas.so.1.7.99
b65a5000 b65ab000 r-xp /usr/lib/libecore_imf.so.1.7.99
b65b3000 b65ca000 r-xp /usr/lib/liblua-5.1.so
b65d4000 b65db000 r-xp /usr/lib/libembryo.so.1.7.99
b65e3000 b65e9000 r-xp /lib/librt-2.13.so
b65f2000 b6648000 r-xp /usr/lib/libpixman-1.so.0.28.2
b6655000 b66ab000 r-xp /usr/lib/libfreetype.so.6.11.3
b66b7000 b66df000 r-xp /usr/lib/libfontconfig.so.1.8.0
b66e1000 b671e000 r-xp /usr/lib/libharfbuzz.so.0.940.0
b6727000 b673a000 r-xp /usr/lib/libfribidi.so.0.3.1
b6742000 b675c000 r-xp /usr/lib/libecore_con.so.1.7.99
b6765000 b676e000 r-xp /usr/lib/libedbus.so.1.7.99
b6776000 b67c6000 r-xp /usr/lib/libecore_x.so.1.7.99
b67c9000 b67cd000 r-xp /usr/lib/libvconf.so.0.2.45
b67d5000 b67e6000 r-xp /usr/lib/libecore_input.so.1.7.99
b67ee000 b67f3000 r-xp /usr/lib/libecore_file.so.1.7.99
b67fb000 b681d000 r-xp /usr/lib/libecore_evas.so.1.7.99
b6826000 b6867000 r-xp /usr/lib/libeina.so.1.7.99
b6870000 b6889000 r-xp /usr/lib/libeet.so.1.7.99
b689a000 b6903000 r-xp /lib/libm-2.13.so
b690c000 b6912000 r-xp /usr/lib/libcapi-base-common.so.0.1.8
b691b000 b691e000 r-xp /usr/lib/libproc-stat.so.0.2.86
b6926000 b6948000 r-xp /usr/lib/libpkgmgr-info.so.0.0.17
b6950000 b6955000 r-xp /usr/lib/libxdgmime.so.1.1.0
b695d000 b6987000 r-xp /usr/lib/libdbus-1.so.3.8.12
b6990000 b69a7000 r-xp /usr/lib/libdbus-glib-1.so.2.2.2
b69af000 b69ba000 r-xp /lib/libunwind.so.8.0.1
b69e7000 b6a23000 r-xp /usr/lib/libsystemd.so.0.4.0
b6a2c000 b6b47000 r-xp /lib/libc-2.13.so
b6b55000 b6b5d000 r-xp /lib/libgcc_s-4.6.so.1
b6b5e000 b6b61000 r-xp /usr/lib/libsmack.so.1.0.0
b6b69000 b6b6f000 r-xp /usr/lib/libprivilege-control.so.0.0.2
b6b77000 b6c47000 r-xp /usr/lib/libglib-2.0.so.0.3200.3
b6c48000 b6ca5000 r-xp /usr/lib/libedje.so.1.7.99
b6caf000 b6cc6000 r-xp /usr/lib/libecore.so.1.7.99
b6cdd000 b6dac000 r-xp /usr/lib/libevas.so.1.7.99
b6dd0000 b6f0a000 r-xp /usr/lib/libelementary.so.1.7.99
b6f20000 b6f34000 r-xp /lib/libpthread-2.13.so
b6f3f000 b6f41000 r-xp /usr/lib/libdlog.so.0.0.0
b6f49000 b6f4c000 r-xp /usr/lib/libbundle.so.0.1.22
b6f54000 b6f56000 r-xp /lib/libdl-2.13.so
b6f5f000 b6f6b000 r-xp /usr/lib/libaul.so.0.1.0
b6f7d000 b6f82000 r-xp /usr/lib/libappcore-efl.so.1.1
b6f8b000 b6f8f000 r-xp /usr/lib/libsys-assert.so
b6f98000 b6fb5000 r-xp /lib/ld-2.13.so
b6fbe000 b6fc3000 r-xp /usr/bin/launchpad-loader
b80ac000 b8393000 rw-p [heap]
be87b000 be89c000 rwxp [stack]
End of Maps Information

Callstack Information (PID:31261)
Call Stack Count: 1
 0: strcmp + 0x0 (0xb6a9e9d0) [/lib/libc.so.6] + 0x729d0
End of Call Stack

Package Information
Package Name: org.example.uicomponents
Package ID : org.example.uicomponents
Version: 1.0.0
Package Type: rpm
App Name: uicomponents
App ID: org.example.uicomponents
Type: capp
Categories: 

Latest Debug Message Information
--------- beginning of /dev/log_main
ic_wrong() Input object is wrong type
06-06 22:15:06.039+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:06.039+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:06.039+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:06.039+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:06.039+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:06.039+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:06.039+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:06.039+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:06.039+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:06.039+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:06.039+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:06.039+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:06.039+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:06.039+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:06.039+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:06.039+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:06.039+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:06.039+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:06.039+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:06.039+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:06.039+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:06.039+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:06.039+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:06.039+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:06.039+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:06.039+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:06.039+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:06.039+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:06.039+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:06.039+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:06.039+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:06.039+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:06.039+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:06.039+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:06.039+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:06.039+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:06.039+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:06.039+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:06.039+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:06.039+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:06.039+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:06.039+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:06.039+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:06.039+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:06.039+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:06.039+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:06.039+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:06.039+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:06.039+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:06.039+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:06.039+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:06.039+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:06.039+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:06.039+0900 E/EFL     (31261): edje<31261> edje_util.c:3770 edje_object_size_min_restricted_calc() group entry_layout has a non-fixed part 'entry_part'. Adding 'fixed: 1 1;' to source EDC may help. Continuing discarding faulty part.
06-06 22:15:06.039+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:06.039+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:06.039+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:06.039+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:06.039+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:06.039+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:06.039+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:06.039+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:06.039+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:06.039+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:06.039+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:06.039+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:06.039+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:06.039+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:06.039+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:06.069+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:06.069+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:06.069+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:06.069+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:06.069+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:06.069+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:06.069+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:06.069+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:06.069+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:06.069+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:06.069+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:06.069+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:06.069+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:06.069+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:06.069+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:06.129+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:06.129+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:06.129+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:06.129+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:06.129+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:06.129+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:06.129+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:06.129+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:06.129+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:06.129+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:06.129+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:06.129+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:06.129+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:06.129+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:06.129+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:06.179+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:06.179+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:06.179+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:06.179+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:06.179+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:06.179+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:06.179+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:06.179+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:06.179+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:06.179+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:06.179+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:06.179+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:06.179+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:06.179+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:06.179+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:06.209+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:06.209+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:06.209+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:06.209+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:06.209+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:06.209+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:06.209+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:06.209+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:06.209+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:06.209+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:06.209+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:06.209+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:06.209+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:06.209+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:06.209+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:06.259+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:06.259+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:06.259+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:06.259+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:06.259+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:06.259+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:06.259+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:06.259+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:06.259+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:06.259+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:06.259+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:06.259+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:06.259+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:06.259+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:06.259+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:06.309+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:06.309+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:06.309+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:06.309+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:06.309+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:06.309+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:06.309+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:06.309+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:06.309+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:06.309+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:06.309+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:06.309+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:06.309+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:06.309+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:06.309+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:06.349+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:06.349+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:06.349+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:06.349+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:06.349+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:06.349+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:06.349+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:06.349+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:06.349+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:06.349+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:06.349+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:06.349+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:06.349+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:06.349+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:06.349+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:06.399+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:06.399+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:06.399+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:06.399+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:06.399+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:06.399+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:06.399+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:06.399+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:06.399+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:06.399+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:06.399+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:06.399+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:06.399+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:06.399+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:06.399+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:06.449+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:06.449+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:06.449+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:06.449+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:06.449+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:06.449+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:06.449+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:06.449+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:06.449+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:06.449+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:06.449+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:06.449+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:06.449+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:06.449+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:06.449+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:06.499+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:06.499+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:06.499+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:06.499+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:06.499+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:06.499+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:06.499+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:06.499+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:06.499+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:06.499+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:06.499+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:06.499+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:06.499+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:06.499+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:06.499+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:06.529+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:06.529+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:06.529+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:06.529+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:06.529+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:06.529+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:06.529+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:06.529+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:06.529+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:06.529+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:06.529+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:06.529+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:06.529+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:06.529+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:06.529+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:06.529+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:06.529+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:06.529+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:06.529+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:06.529+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:06.529+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:06.889+0900 I/APP_CORE( 1184): appcore-efl.c: __do_app(429) > [APP 1184] Event: MEM_FLUSH State: PAUSED
06-06 22:15:09.179+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:09.179+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:09.179+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:09.179+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:09.179+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:09.179+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:09.179+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:09.179+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:09.179+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:09.179+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:09.179+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:09.179+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:09.179+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:09.179+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:09.179+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:09.279+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:09.279+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:09.279+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:09.279+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:09.279+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:09.279+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:09.279+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:09.279+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:09.279+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:09.279+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:09.279+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:09.279+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:09.279+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:09.279+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:09.279+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:09.319+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:09.319+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:09.319+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:09.319+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:09.319+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:09.319+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:09.319+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:09.319+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:09.319+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:09.319+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:09.319+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:09.319+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:09.319+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:09.319+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:09.319+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:09.349+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:09.349+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:09.349+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:09.349+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:09.349+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:09.349+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:09.349+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:09.349+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:09.349+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:09.349+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:09.349+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:09.349+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:09.349+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:09.349+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:09.349+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:09.389+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:09.389+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:09.389+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:09.389+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:09.389+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:09.389+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:09.389+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:09.389+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:09.389+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:09.389+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:09.389+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:09.389+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:09.389+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:09.389+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:09.389+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:09.419+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:09.419+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:09.419+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:09.419+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:09.419+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:09.419+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:09.419+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:09.419+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:09.419+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:09.419+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:09.419+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:09.419+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:09.419+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:09.419+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:09.419+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:09.459+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:09.459+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:09.459+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:09.459+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:09.459+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:09.459+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:09.459+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:09.459+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:09.459+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:09.459+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:09.459+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:09.459+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:09.459+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:09.459+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:09.459+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:09.489+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:09.489+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:09.489+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:09.489+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:09.489+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:09.489+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:09.489+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:09.489+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:09.489+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:09.489+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:09.489+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:09.489+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:09.489+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:09.489+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:09.489+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:09.519+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:09.519+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:09.519+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:09.519+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:09.519+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:09.519+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:09.519+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:09.519+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:09.519+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:09.519+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:09.519+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:09.519+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:09.519+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:09.519+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:09.519+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:09.559+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:09.559+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:09.559+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:09.559+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:09.559+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:09.559+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:09.559+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:09.559+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:09.559+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:09.559+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:09.559+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:09.559+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:09.559+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:09.559+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:09.559+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:09.599+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:09.599+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:09.599+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:09.599+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:09.599+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:09.599+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:09.599+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:09.599+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:09.599+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:09.599+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:09.599+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:09.599+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:09.599+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:09.599+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:09.599+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:09.639+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:09.639+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:09.639+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:09.639+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:09.639+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:09.639+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:09.639+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:09.639+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:09.639+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:09.639+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:09.639+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:09.639+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:09.639+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:09.639+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:09.639+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:09.639+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:09.639+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:09.639+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:09.639+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:09.639+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:09.639+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:09.639+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:09.639+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:09.639+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:09.639+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:09.639+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:09.639+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:09.639+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:09.639+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:09.639+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:09.639+0900 E/EFL     (31261): elementary<31261> elm_widget.c:386 _elm_widget_sub_object_del_func() removing sub object 0xb82f7690 ((null)) from parent 0xb8328f90 (elm_layout), but elm-parent is different (nil) ((null))!
06-06 22:15:09.639+0900 E/EFL     (31261): elementary<31261> elm_widget.c:675 _smart_del() failed to remove sub object 0xb82f7690 from 0xb8328f90
06-06 22:15:09.639+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:09.639+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:09.639+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:09.639+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:09.639+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:09.639+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:09.639+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:09.639+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:09.639+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:09.639+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:09.639+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:09.639+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:09.639+0900 F/EFL     (31261): evas_main<31261> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:15:09.639+0900 F/EFL     (31261):     Expected: 71737723 - Evas_Object
06-06 22:15:09.639+0900 F/EFL     (31261):     Supplied: b83017f0 - <UNKNOWN>
06-06 22:15:09.849+0900 W/AUL_AMD (  905): amd_key.c: _key_ungrab(254) > fail(-1) to ungrab key(XF86Stop)
06-06 22:15:09.849+0900 W/AUL_AMD (  905): amd_launch.c: __e17_status_handler(2194) > back key ungrab error
06-06 22:15:09.919+0900 I/AUL_AMD (  905): amd_main.c: __app_dead_handler(261) > __app_dead_handler, pid: 31261
06-06 22:15:09.979+0900 W/PROCESSMGR(  585): e_mod_processmgr.c: _e_mod_processmgr_send_update_watch_action(639) > [PROCESSMGR] =====================> send UpdateClock
06-06 22:15:09.979+0900 W/WATCH_CORE(12148): appcore-watch.c: __signal_process_manager_handler(1163) > process_manager_signal
06-06 22:15:09.979+0900 I/WATCH_CORE(12148): appcore-watch.c: __signal_process_manager_handler(1179) > Call the time_tick_cb
06-06 22:15:09.979+0900 I/CAPI_WATCH_APPLICATION(12148): watch_app_main.c: _watch_core_time_tick(306) > _watch_core_time_tick
06-06 22:15:09.979+0900 E/watchface-loader(12148): watchface-loader.cpp: OnAppTimeTick(744) > 
06-06 22:15:09.979+0900 I/watchface-loader(12148): watchface-loader.cpp: OnAppTimeTick(756) > set force update!!
06-06 22:15:09.999+0900 W/W_HOME  ( 1184): event_manager.c: _ecore_x_message_cb(403) > state: 1 -> 0
06-06 22:15:09.999+0900 W/W_HOME  ( 1184): event_manager.c: _state_control(194) > control:4, app_state:2 win_state:0(0) pm_state:1 home_visible:1 clock_visible:1 tutorial_state:0 editing : 0, home_clocklist:0, addviewer:0 scrolling : 0, powersaving : 0, apptray state : 1, apptray visibility : 0, apptray edit visibility : 0
06-06 22:15:09.999+0900 W/W_HOME  ( 1184): event_manager.c: _state_control(194) > control:2, app_state:2 win_state:0(0) pm_state:1 home_visible:1 clock_visible:1 tutorial_state:0 editing : 0, home_clocklist:0, addviewer:0 scrolling : 0, powersaving : 0, apptray state : 1, apptray visibility : 0, apptray edit visibility : 0
06-06 22:15:10.009+0900 W/W_HOME  ( 1184): event_manager.c: _state_control(194) > control:1, app_state:2 win_state:0(0) pm_state:1 home_visible:1 clock_visible:1 tutorial_state:0 editing : 0, home_clocklist:0, addviewer:0 scrolling : 0, powersaving : 0, apptray state : 1, apptray visibility : 0, apptray edit visibility : 0
06-06 22:15:10.009+0900 W/W_HOME  ( 1184): main.c: _ecore_x_message_cb(1233) > main_info.is_win_on_top: 1
06-06 22:15:10.039+0900 W/W_HOME  ( 1184): event_manager.c: _window_visibility_cb(448) > Window [0x2C00003] is now visible(0)
06-06 22:15:10.039+0900 W/W_HOME  ( 1184): event_manager.c: _window_visibility_cb(458) > state: 0 -> 1
06-06 22:15:10.039+0900 W/W_HOME  ( 1184): event_manager.c: _state_control(194) > control:4, app_state:2 win_state:0(1) pm_state:1 home_visible:1 clock_visible:1 tutorial_state:0 editing : 0, home_clocklist:0, addviewer:0 scrolling : 0, powersaving : 0, apptray state : 1, apptray visibility : 0, apptray edit visibility : 0
06-06 22:15:10.039+0900 W/W_HOME  ( 1184): main.c: _window_visibility_cb(1200) > Window [0x2C00003] is now visible(0)
06-06 22:15:10.039+0900 I/APP_CORE( 1184): appcore-efl.c: __do_app(429) > [APP 1184] Event: RESUME State: PAUSED
06-06 22:15:10.039+0900 I/CAPI_APPFW_APPLICATION( 1184): app_main.c: app_appcore_resume(223) > app_appcore_resume
06-06 22:15:10.039+0900 W/W_HOME  ( 1184): main.c: _appcore_resume_cb(683) > appcore resume
06-06 22:15:10.039+0900 W/W_HOME  ( 1184): event_manager.c: _app_resume_cb(355) > state: 2 -> 1
06-06 22:15:10.039+0900 W/W_HOME  ( 1184): event_manager.c: _state_control(194) > control:2, app_state:1 win_state:0(1) pm_state:1 home_visible:1 clock_visible:1 tutorial_state:0 editing : 0, home_clocklist:0, addviewer:0 scrolling : 0, powersaving : 0, apptray state : 1, apptray visibility : 0, apptray edit visibility : 0
06-06 22:15:10.049+0900 W/W_HOME  ( 1184): event_manager.c: _state_control(194) > control:0, app_state:1 win_state:0(1) pm_state:1 home_visible:1 clock_visible:1 tutorial_state:0 editing : 0, home_clocklist:0, addviewer:0 scrolling : 0, powersaving : 0, apptray state : 1, apptray visibility : 0, apptray edit visibility : 0
06-06 22:15:10.049+0900 W/W_HOME  ( 1184): main.c: home_resume(731) > journal_appcore_app_fully_loaded called
06-06 22:15:10.049+0900 W/W_HOME  ( 1184): main.c: home_resume(735) > clock/widget resumed
06-06 22:15:10.049+0900 W/W_HOME  ( 1184): event_manager.c: _state_control(194) > control:1, app_state:1 win_state:0(1) pm_state:1 home_visible:1 clock_visible:1 tutorial_state:0 editing : 0, home_clocklist:0, addviewer:0 scrolling : 0, powersaving : 0, apptray state : 1, apptray visibility : 0, apptray edit visibility : 0
06-06 22:15:10.049+0900 I/wnotib  ( 1184): w-notification-board-broker-main.c: _wnotib_ecore_x_event_visibility_changed_cb(701) > fully_obscured: 0
06-06 22:15:10.049+0900 E/wnotib  ( 1184): w-notification-board-action-drawer.c: wnotib_action_drawer_hidden_get(4570) > [NULL==g_wnotib_action_drawer_data] msg Drawer not initialized.
06-06 22:15:10.049+0900 W/wnotib  ( 1184): w-notification-board-noti-manager.c: wnotib_noti_manager_do_postponed_job(1695) > No postponed update.
06-06 22:15:10.049+0900 I/GESTURE (  239): gesture.c: BackGestureSetProperty(4501) > [BackGestureSetProperty] atom=_E_MOVE_W_HOME_CLOCK_STATE, value=1, Clock display 
06-06 22:15:10.099+0900 W/WATCH_CORE(12148): appcore-watch.c: __widget_resume(1012) > widget_resume
06-06 22:15:10.099+0900 E/watchface-loader(12148): watchface-loader.cpp: OnAppResume(725) > 
06-06 22:15:10.099+0900 I/CAPI_WATCH_APPLICATION(12148): watch_app_main.c: _watch_core_time_tick(306) > _watch_core_time_tick
06-06 22:15:10.099+0900 E/watchface-loader(12148): watchface-loader.cpp: OnAppTimeTick(744) > 
06-06 22:15:10.279+0900 I/CAPI_WATCH_APPLICATION(12148): watch_app_main.c: _watch_core_time_tick(306) > _watch_core_time_tick
06-06 22:15:10.279+0900 E/watchface-loader(12148): watchface-loader.cpp: OnAppTimeTick(744) > 
06-06 22:15:10.459+0900 I/CAPI_WATCH_APPLICATION(12148): watch_app_main.c: _watch_core_time_tick(306) > _watch_core_time_tick
06-06 22:15:10.459+0900 E/watchface-loader(12148): watchface-loader.cpp: OnAppTimeTick(744) > 
06-06 22:15:10.649+0900 I/CAPI_WATCH_APPLICATION(12148): watch_app_main.c: _watch_core_time_tick(306) > _watch_core_time_tick
06-06 22:15:10.649+0900 E/watchface-loader(12148): watchface-loader.cpp: OnAppTimeTick(744) > 
06-06 22:15:10.719+0900 W/CRASH_MANAGER(31493): worker.c: worker_job(1199) > 1131261756963146521890
