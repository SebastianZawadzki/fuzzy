S/W Version Information
Model: SM-R735S
Tizen-Version: 2.3.1.2
Build-Number: R735SKSU1AOKE
Build-Date: 2015.11.25 20:46:58

Crash Information
Process Name: uicomponents
PID: 3266
Date: 2016-06-06 23:44:45+0900
Executable File Path: /opt/usr/apps/org.example.uicomponents/bin/uicomponents
Signal: 11
      (SIGSEGV)
      si_code: -6
      signal sent by tkill (sent by pid 3266, uid 5000)

Register Information
r0   = 0x71737723, r1   = 0x71737723
r2   = 0x00000001, r3   = 0x00000000
r4   = 0x71737723, r5   = 0xb6eec9f8
r6   = 0xb8d18248, r7   = 0xbe9c6380
r8   = 0xb6ca09c0, r9   = 0xb8c278c8
r10  = 0xb6ee4e9c, fp   = 0x00000000
ip   = 0xb6ee6428, sp   = 0xbe9c62a8
lr   = 0xb6e9332d, pc   = 0xb6cdcbde
cpsr = 0xa0000030

Memory Information
MemTotal:   407572 KB
MemFree:     14788 KB
Buffers:     13900 KB
Cached:      91320 KB
VmPeak:      77084 KB
VmSize:      74920 KB
VmLck:           0 KB
VmPin:           0 KB
VmHWM:       19068 KB
VmRSS:       19068 KB
VmData:      16352 KB
VmStk:         136 KB
VmExe:          20 KB
VmLib:       24768 KB
VmPTE:          58 KB
VmSwap:          0 KB

Threads Information
Threads: 2
PID = 3266 TID = 3266
3266 3457 

Maps Information
b29d6000 b29da000 r-xp /usr/lib/libogg.so.0.7.1
b29e2000 b2a04000 r-xp /usr/lib/libvorbis.so.0.4.3
b2a0c000 b2a14000 r-xp /usr/lib/libmdm-common.so.1.0.89
b2a15000 b2a58000 r-xp /usr/lib/libsndfile.so.1.0.25
b2a65000 b2aad000 r-xp /usr/lib/pulseaudio/libpulsecommon-4.0.so
b2aae000 b2ab3000 r-xp /usr/lib/libjson.so.0.0.1
b2abb000 b2aec000 r-xp /usr/lib/libmdm.so.1.1.85
b2af4000 b2afc000 r-xp /usr/lib/lib_DNSe_NRSS_ver225.so
b2b0b000 b2b1b000 r-xp /usr/lib/lib_SamsungRec_TizenV04014.so
b2b3c000 b2b49000 r-xp /usr/lib/libail.so.0.1.0
b2b52000 b2b55000 r-xp /usr/lib/libsyspopup_caller.so.0.1.0
b2b5d000 b2b95000 r-xp /usr/lib/libpulse.so.0.16.2
b2b96000 b2bf7000 r-xp /usr/lib/libasound.so.2.0.0
b2c01000 b2c04000 r-xp /usr/lib/libpulse-simple.so.0.0.4
b2c0c000 b2c11000 r-xp /usr/lib/libascenario-0.2.so.0.0.0
b2c19000 b2c32000 r-xp /usr/lib/libavsysaudio.so.0.0.1
b2c3b000 b2c3f000 r-xp /usr/lib/libmmfsoundcommon.so.0.0.0
b2c48000 b2c52000 r-xp /usr/lib/libaudio-session-mgr.so.0.0.0
b2c5e000 b2c63000 r-xp /usr/lib/libmmfsession.so.0.0.0
b2c6b000 b2c81000 r-xp /usr/lib/libmmfsound.so.0.1.0
b2c93000 b2c9a000 r-xp /usr/lib/libmmfcommon.so.0.0.0
b2ca2000 b2cac000 r-xp /usr/lib/libcapi-media-sound-manager.so.0.1.48
b2cb4000 b2cb6000 r-xp /usr/lib/libcapi-media-wav-player.so.0.1.10
b2cbe000 b2cbf000 r-xp /usr/lib/libmmfkeysound.so.0.0.0
b2cc7000 b2cce000 r-xp /usr/lib/libfeedback.so.0.1.4
b2ced000 b2cee000 r-xp /usr/lib/edje/modules/feedback/linux-gnueabi-armv7l-1.0.0/module.so
b2cf6000 b2d7d000 rw-s anon_inode:dmabuf
b2d7d000 b2e04000 rw-s anon_inode:dmabuf
b2e8f000 b2f16000 rw-s anon_inode:dmabuf
b2f95000 b301c000 rw-s anon_inode:dmabuf
b31b6000 b39b5000 rwxp [stack:3457]
b39b5000 b39cc000 r-xp /usr/lib/edje/modules/elm/linux-gnueabi-armv7l-1.0.0/module.so
b39d9000 b39db000 r-xp /usr/lib/libgenlock.so
b39e4000 b39e5000 r-xp /usr/lib/evas/modules/loaders/eet/linux-gnueabi-armv7l-1.7.99/module.so
b39ed000 b39ef000 r-xp /usr/lib/evas/modules/loaders/png/linux-gnueabi-armv7l-1.7.99/module.so
b39f9000 b39fe000 r-xp /usr/lib/bufmgr/libtbm_msm.so.0.0.0
b3a06000 b3a11000 r-xp /usr/lib/evas/modules/engines/software_generic/linux-gnueabi-armv7l-1.7.99/module.so
b3d39000 b3e03000 r-xp /usr/lib/libCOREGL.so.4.0
b3e14000 b3e19000 r-xp /usr/lib/libcapi-media-tool.so.0.1.5
b3e21000 b3e42000 r-xp /usr/lib/libexif.so.12.3.3
b3e55000 b3e5a000 r-xp /usr/lib/libmmutil_imgp.so.0.0.0
b3e62000 b3e67000 r-xp /usr/lib/libmmutil_jpeg.so.0.0.0
b53f6000 b53f8000 r-xp /usr/lib/libdri2.so.0.0.0
b5400000 b5408000 r-xp /usr/lib/libdrm.so.2.4.0
b5410000 b5413000 r-xp /usr/lib/libcapi-media-image-util.so.0.3.5
b541b000 b54ff000 r-xp /usr/lib/libicuuc.so.51.1
b5514000 b5651000 r-xp /usr/lib/libicui18n.so.51.1
b5661000 b5666000 r-xp /usr/lib/libcapi-system-info.so.0.2.0
b566e000 b5674000 r-xp /usr/lib/libxcb-render.so.0.0.0
b567c000 b567d000 r-xp /usr/lib/libxcb-shm.so.0.0.0
b5686000 b5689000 r-xp /usr/lib/libEGL.so.1.4
b5691000 b569f000 r-xp /usr/lib/libGLESv2.so.2.0
b56a8000 b56af000 r-xp /usr/lib/libtbm.so.1.0.0
b56b7000 b56d8000 r-xp /usr/lib/libui-extension.so.0.1.0
b56e1000 b56f3000 r-xp /usr/lib/libtts.so
b56fb000 b57b3000 r-xp /usr/lib/libcairo.so.2.11200.14
b57be000 b57d0000 r-xp /usr/lib/libefl-assist.so.0.1.0
b57d8000 b57f9000 r-xp /usr/lib/libefl-extension.so.0.1.0
b5801000 b5815000 r-xp /opt/usr/apps/org.example.uicomponents/bin/uicomponents
b59dc000 b59e6000 r-xp /lib/libnss_files-2.13.so
b59ef000 b5abe000 r-xp /usr/lib/libscim-1.0.so.8.2.3
b5ad4000 b5af8000 r-xp /usr/lib/ecore/immodules/libisf-imf-module.so
b5b01000 b5b07000 r-xp /usr/lib/libappsvc.so.0.1.0
b5b0f000 b5b11000 r-xp /usr/lib/libcapi-appfw-app-common.so.0.3.2.5
b5b1a000 b5b1f000 r-xp /usr/lib/libcapi-appfw-app-control.so.0.3.2.5
b5b2a000 b5b35000 r-xp /usr/lib/evas/modules/engines/software_x11/linux-gnueabi-armv7l-1.7.99/module.so
b5b3d000 b5b3f000 r-xp /usr/lib/libiniparser.so.0
b5b48000 b5b4d000 r-xp /usr/lib/libappcore-common.so.1.1
b5b56000 b5b5e000 r-xp /usr/lib/libcapi-system-system-settings.so.0.0.2
b5b5f000 b5b63000 r-xp /usr/lib/libcapi-appfw-application.so.0.3.2.5
b5b70000 b5b72000 r-xp /usr/lib/libXau.so.6.0.0
b5b7b000 b5b82000 r-xp /lib/libcrypt-2.13.so
b5bb2000 b5bb4000 r-xp /usr/lib/libiri.so
b5bbc000 b5d64000 r-xp /usr/lib/libcrypto.so.1.0.0
b5d7d000 b5dca000 r-xp /usr/lib/libssl.so.1.0.0
b5dd7000 b5e05000 r-xp /usr/lib/libidn.so.11.5.44
b5e0d000 b5e16000 r-xp /usr/lib/libcares.so.2.1.0
b5e1f000 b5e32000 r-xp /usr/lib/libxcb.so.1.1.0
b5e3b000 b5e3d000 r-xp /usr/lib/journal/libjournal.so.0.1.0
b5e46000 b5e48000 r-xp /usr/lib/libSLP-db-util.so.0.1.0
b5e51000 b5f1d000 r-xp /usr/lib/libxml2.so.2.7.8
b5f2a000 b5f2c000 r-xp /usr/lib/libgmodule-2.0.so.0.3200.3
b5f34000 b5f39000 r-xp /usr/lib/libffi.so.5.0.10
b5f41000 b5f42000 r-xp /usr/lib/libgthread-2.0.so.0.3200.3
b5f4b000 b5f56000 r-xp /usr/lib/libgpg-error.so.0.15.0
b5f5e000 b5f61000 r-xp /lib/libattr.so.1.1.0
b5f69000 b5ffd000 r-xp /usr/lib/libstdc++.so.6.0.16
b6010000 b602c000 r-xp /usr/lib/libsecurity-server-commons.so.1.0.0
b6035000 b604d000 r-xp /usr/lib/libpng12.so.0.50.0
b6056000 b606c000 r-xp /lib/libexpat.so.1.5.2
b6076000 b60ba000 r-xp /usr/lib/libcurl.so.4.3.0
b60c3000 b60cd000 r-xp /usr/lib/libXext.so.6.4.0
b60d6000 b60d9000 r-xp /usr/lib/libXtst.so.6.1.0
b60e2000 b60e8000 r-xp /usr/lib/libXrender.so.1.3.0
b60f1000 b60f7000 r-xp /usr/lib/libXrandr.so.2.2.0
b60ff000 b6100000 r-xp /usr/lib/libXinerama.so.1.0.0
b6109000 b6112000 r-xp /usr/lib/libXi.so.6.1.0
b611a000 b611d000 r-xp /usr/lib/libXfixes.so.3.1.0
b6125000 b6127000 r-xp /usr/lib/libXgesture.so.7.0.0
b612f000 b6131000 r-xp /usr/lib/libXcomposite.so.1.0.0
b613a000 b613c000 r-xp /usr/lib/libXdamage.so.1.1.0
b6144000 b614b000 r-xp /usr/lib/libXcursor.so.1.0.2
b6153000 b6156000 r-xp /usr/lib/libecore_input_evas.so.1.7.99
b615e000 b6162000 r-xp /usr/lib/libecore_ipc.so.1.7.99
b616b000 b6170000 r-xp /usr/lib/libecore_fb.so.1.7.99
b617a000 b625b000 r-xp /usr/lib/libX11.so.6.3.0
b6266000 b6289000 r-xp /usr/lib/libjpeg.so.8.0.2
b62a1000 b62b7000 r-xp /lib/libz.so.1.2.5
b62bf000 b6334000 r-xp /usr/lib/libsqlite3.so.0.8.6
b633e000 b6353000 r-xp /usr/lib/libpkgmgr_parser.so.0.1.0
b635c000 b6390000 r-xp /usr/lib/libgobject-2.0.so.0.3200.3
b6399000 b646c000 r-xp /usr/lib/libgio-2.0.so.0.3200.3
b6477000 b6487000 r-xp /lib/libresolv-2.13.so
b648b000 b6507000 r-xp /usr/lib/libgcrypt.so.20.0.3
b6513000 b652b000 r-xp /usr/lib/liblzma.so.5.0.3
b6534000 b6537000 r-xp /lib/libcap.so.2.21
b653f000 b6565000 r-xp /usr/lib/libsecurity-server-client.so.1.0.1
b656e000 b656f000 r-xp /usr/lib/libecore_imf_evas.so.1.7.99
b6577000 b657d000 r-xp /usr/lib/libecore_imf.so.1.7.99
b6585000 b659c000 r-xp /usr/lib/liblua-5.1.so
b65a6000 b65ad000 r-xp /usr/lib/libembryo.so.1.7.99
b65b5000 b65bb000 r-xp /lib/librt-2.13.so
b65c4000 b661a000 r-xp /usr/lib/libpixman-1.so.0.28.2
b6627000 b667d000 r-xp /usr/lib/libfreetype.so.6.11.3
b6689000 b66b1000 r-xp /usr/lib/libfontconfig.so.1.8.0
b66b3000 b66f0000 r-xp /usr/lib/libharfbuzz.so.0.940.0
b66f9000 b670c000 r-xp /usr/lib/libfribidi.so.0.3.1
b6714000 b672e000 r-xp /usr/lib/libecore_con.so.1.7.99
b6737000 b6740000 r-xp /usr/lib/libedbus.so.1.7.99
b6748000 b6798000 r-xp /usr/lib/libecore_x.so.1.7.99
b679b000 b679f000 r-xp /usr/lib/libvconf.so.0.2.45
b67a7000 b67b8000 r-xp /usr/lib/libecore_input.so.1.7.99
b67c0000 b67c5000 r-xp /usr/lib/libecore_file.so.1.7.99
b67cd000 b67ef000 r-xp /usr/lib/libecore_evas.so.1.7.99
b67f8000 b6839000 r-xp /usr/lib/libeina.so.1.7.99
b6842000 b685b000 r-xp /usr/lib/libeet.so.1.7.99
b686c000 b68d5000 r-xp /lib/libm-2.13.so
b68de000 b68e4000 r-xp /usr/lib/libcapi-base-common.so.0.1.8
b68ed000 b68f0000 r-xp /usr/lib/libproc-stat.so.0.2.86
b68f8000 b691a000 r-xp /usr/lib/libpkgmgr-info.so.0.0.17
b6922000 b6927000 r-xp /usr/lib/libxdgmime.so.1.1.0
b692f000 b6959000 r-xp /usr/lib/libdbus-1.so.3.8.12
b6962000 b6979000 r-xp /usr/lib/libdbus-glib-1.so.2.2.2
b6981000 b698c000 r-xp /lib/libunwind.so.8.0.1
b69b9000 b69f5000 r-xp /usr/lib/libsystemd.so.0.4.0
b69fe000 b6b19000 r-xp /lib/libc-2.13.so
b6b27000 b6b2f000 r-xp /lib/libgcc_s-4.6.so.1
b6b30000 b6b33000 r-xp /usr/lib/libsmack.so.1.0.0
b6b3b000 b6b41000 r-xp /usr/lib/libprivilege-control.so.0.0.2
b6b49000 b6c19000 r-xp /usr/lib/libglib-2.0.so.0.3200.3
b6c1a000 b6c77000 r-xp /usr/lib/libedje.so.1.7.99
b6c81000 b6c98000 r-xp /usr/lib/libecore.so.1.7.99
b6caf000 b6d7e000 r-xp /usr/lib/libevas.so.1.7.99
b6da2000 b6edc000 r-xp /usr/lib/libelementary.so.1.7.99
b6ef2000 b6f06000 r-xp /lib/libpthread-2.13.so
b6f11000 b6f13000 r-xp /usr/lib/libdlog.so.0.0.0
b6f1b000 b6f1e000 r-xp /usr/lib/libbundle.so.0.1.22
b6f26000 b6f28000 r-xp /lib/libdl-2.13.so
b6f31000 b6f3d000 r-xp /usr/lib/libaul.so.0.1.0
b6f4f000 b6f54000 r-xp /usr/lib/libappcore-efl.so.1.1
b6f5d000 b6f61000 r-xp /usr/lib/libsys-assert.so
b6f6a000 b6f87000 r-xp /lib/ld-2.13.so
b6f90000 b6f95000 r-xp /usr/bin/launchpad-loader
b8bef000 b8ebb000 rw-p [heap]
be9a6000 be9c7000 rwxp [stack]
be9a6000 be9c7000 rwxp [stack]
End of Maps Information

Callstack Information (PID:3266)
Call Stack Count: 4
 0: evas_object_evas_get + 0x5 (0xb6cdcbde) [/usr/lib/libevas.so.1] + 0x2dbde
 1: elm_widget_add + 0xc (0xb6e9332d) [/usr/lib/libelementary.so.1] + 0xf132d
 2: elm_genlist_add + 0x28 (0xb6e2e0bd) [/usr/lib/libelementary.so.1] + 0x8c0bd
 3: _user_info_entry_cb2 + 0x44 (0xb5806dc5) [/opt/usr/apps/org.example.uicomponents/bin/uicomponents] + 0x5dc5
End of Call Stack

Package Information
Package Name: org.example.uicomponents
Package ID : org.example.uicomponents
Version: 1.0.0
Package Type: rpm
App Name: uicomponents
App ID: org.example.uicomponents
Type: capp
Categories: 

Latest Debug Message Information
--------- beginning of /dev/log_main
ated : 1
06-06 23:44:39.581+0900 E/E17     (  585): e_manager.c: _e_manager_cb_window_show_request(1128) > Show request(0x02400002)
06-06 23:44:39.581+0900 I/APP_CORE( 3266): appcore-efl.c: __do_app(429) > [APP 3266] Event: RESET State: CREATED
06-06 23:44:39.581+0900 I/CAPI_APPFW_APPLICATION( 3266): app_main.c: _ui_app_appcore_reset(645) > app_appcore_reset
06-06 23:44:39.601+0900 I/APP_CORE( 3266): appcore-efl.c: __do_app(472) > Legacy lifecycle: 0
06-06 23:44:39.601+0900 I/APP_CORE( 3266): appcore-efl.c: __do_app(474) > [APP 3266] Initial Launching, call the resume_cb
06-06 23:44:39.601+0900 I/CAPI_APPFW_APPLICATION( 3266): app_main.c: _ui_app_appcore_resume(628) > app_appcore_resume
06-06 23:44:39.631+0900 W/APP_CORE( 3266): appcore-efl.c: __show_cb(787) > [EVENT_TEST][EVENT] GET SHOW EVENT!!!. WIN:2400002
06-06 23:44:39.631+0900 I/efl-extension( 3266): efl_extension_circle_surface.c: _eext_circle_surface_resize_cb(642) > surface 0xb8d1c7e0 = w: 0 h: 0  obj 0xb8d293a0 w: 360 h: 360
06-06 23:44:39.631+0900 I/efl-extension( 3266): efl_extension_circle_surface.c: _eext_circle_surface_resize_cb(666) > Surface will be initialized! surface->w= 360 surface->h = 360
06-06 23:44:39.681+0900 I/APP_CORE(  644): appcore-efl.c: __do_app(429) > [APP 644] Event: PAUSE State: RUNNING
06-06 23:44:39.681+0900 I/CAPI_APPFW_APPLICATION(  644): app_main.c: app_appcore_pause(202) > app_appcore_pause
06-06 23:44:39.681+0900 E/EFL     (  644): elementary<644> elm_interface_scrollable.c:5303 _elm_scroll_freeze_set() [DDO] obj(b1fae1d0), freeze(1)
06-06 23:44:39.681+0900 E/EFL     (  644): elementary<644> elm_interface_scrollable.c:5303 _elm_scroll_freeze_set() [DDO] obj(b1fae1d0), freeze(1)
06-06 23:44:39.741+0900 I/APP_CORE( 3266): appcore-efl.c: __do_app(429) > [APP 3266] Event: RESUME State: RUNNING
06-06 23:44:40.041+0900 W/AUL_AMD (  905): amd_request.c: __request_handler(640) > __request_handler: 22
06-06 23:44:40.041+0900 W/AUL_AMD (  905): amd_request.c: __request_handler(884) > app status : 4
06-06 23:44:40.041+0900 E/APP_CORE(  644): appcore.c: __del_vconf(429) > [FAILED]vconfkey_ignore_key_changed
06-06 23:44:40.041+0900 I/APP_CORE(  644): appcore-efl.c: __after_loop(1086) > Legacy lifecycle: 0
06-06 23:44:40.041+0900 I/CAPI_APPFW_APPLICATION(  644): app_main.c: app_appcore_terminate(177) > app_appcore_terminate
06-06 23:44:40.041+0900 I/efl-extension(  644): efl_extension_rotary.c: _object_deleted_cb(572) > In: data: 0xb1fae1d0, obj: 0xb1fae1d0
06-06 23:44:40.041+0900 I/efl-extension(  644): efl_extension_rotary.c: _remove_ecore_handlers(554) > In
06-06 23:44:40.041+0900 I/efl-extension(  644): efl_extension_rotary.c: _remove_ecore_handlers(559) > removed _motion_handler
06-06 23:44:40.041+0900 I/efl-extension(  644): efl_extension_rotary.c: _remove_ecore_handlers(565) > removed _rotate_handler
06-06 23:44:40.041+0900 I/efl-extension(  644): efl_extension_rotary.c: _object_deleted_cb(601) > done
06-06 23:44:40.051+0900 I/efl-extension(  644): efl_extension_rotary.c: _activated_obj_del_cb(607) > _activated_obj_del_cb : 0xb1003d80
06-06 23:44:40.051+0900 I/efl-extension(  644): efl_extension_circle_surface.c: _eext_circle_surface_del_cb(680) > Surface is going to free in delete callback for image widget.
06-06 23:44:40.051+0900 I/efl-extension(  644): efl_extension_circle_surface.c: _eext_circle_surface_del_internal(993) > surface 0xb101bf38 is freed
06-06 23:44:40.051+0900 I/efl-extension(  644): efl_extension_rotary.c: eext_rotary_object_event_callback_del(235) > In
06-06 23:44:40.051+0900 I/efl-extension(  644): efl_extension_rotary.c: eext_rotary_object_event_callback_del(240) > callback del 0xb1fae1d0, elm_scroller, func : 0xb3a2d249
06-06 23:44:40.051+0900 I/efl-extension(  644): efl_extension_rotary.c: eext_rotary_object_event_callback_del(273) > done
06-06 23:44:40.051+0900 I/efl-extension(  644): efl_extension_rotary.c: eext_rotary_object_event_callback_del(235) > In
06-06 23:44:40.051+0900 I/efl-extension(  644): efl_extension_rotary.c: eext_rotary_object_event_callback_del(240) > callback del 0xb1003d80, elm_image, func : 0xb3a2d249
06-06 23:44:40.051+0900 I/efl-extension(  644): efl_extension_rotary.c: eext_rotary_object_event_callback_del(273) > done
06-06 23:44:40.051+0900 I/efl-extension(  644): efl_extension_circle_object_scroller.c: _eext_circle_object_scroller_del_cb(841) > [0xb1fae1d0 : elm_scroller] rotary callabck is deleted
06-06 23:44:40.151+0900 I/UXT     (  644): Uxt_ObjectManager.cpp: OnTerminating(750) > Terminating.
06-06 23:44:40.501+0900 W/AUL_AMD (  905): amd_request.c: __request_handler(640) > __request_handler: 14
06-06 23:44:40.511+0900 W/AUL_AMD (  905): amd_request.c: __send_result_to_client(83) > __send_result_to_client, pid: 3266
06-06 23:44:40.511+0900 W/AUL_AMD (  905): amd_request.c: __request_handler(640) > __request_handler: 12
06-06 23:44:40.701+0900 I/efl-extension(  644): efl_extension.c: eext_mod_shutdown(46) > Shutdown
06-06 23:44:40.741+0900 I/AUL_PAD ( 3448): launchpad_loader.c: main(600) > [candidate] elm init, returned: 1
06-06 23:44:40.811+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d2a720), block(1)
06-06 23:44:40.821+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d2a720), ev->cur.canvas.x(171) ev->cur.canvas.y(274)
06-06 23:44:40.821+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d2a720), hold(0) freeze(0)
06-06 23:44:40.821+0900 E/EFL     ( 3266): evas_main<3266> evas_events.c:1009 evas_event_feed_mouse_down() ButtonEvent:down time=22830556 button=1 downs=1
06-06 23:44:40.821+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d2a720), block(1)
06-06 23:44:40.821+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d2a720), ev->cur.canvas.x(170) ev->cur.canvas.y(274)
06-06 23:44:40.821+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d2a720), hold(0) freeze(0)
06-06 23:44:40.831+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d2a720), block(1)
06-06 23:44:40.831+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d2a720), ev->cur.canvas.x(170) ev->cur.canvas.y(273)
06-06 23:44:40.831+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d2a720), hold(0) freeze(0)
06-06 23:44:40.841+0900 I/AUL_AMD (  905): amd_main.c: __app_dead_handler(261) > __app_dead_handler, pid: 644
06-06 23:44:40.841+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d2a720), block(1)
06-06 23:44:40.841+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d2a720), ev->cur.canvas.x(170) ev->cur.canvas.y(271)
06-06 23:44:40.841+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d2a720), hold(0) freeze(0)
06-06 23:44:40.861+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d2a720), block(1)
06-06 23:44:40.861+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d2a720), ev->cur.canvas.x(172) ev->cur.canvas.y(269)
06-06 23:44:40.861+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d2a720), hold(0) freeze(0)
06-06 23:44:40.871+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d2a720), block(1)
06-06 23:44:40.871+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d2a720), ev->cur.canvas.x(173) ev->cur.canvas.y(268)
06-06 23:44:40.871+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d2a720), hold(0) freeze(0)
06-06 23:44:40.881+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d2a720), block(1)
06-06 23:44:40.881+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d2a720), ev->cur.canvas.x(173) ev->cur.canvas.y(267)
06-06 23:44:40.881+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d2a720), hold(0) freeze(0)
06-06 23:44:40.891+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d2a720), block(1)
06-06 23:44:40.891+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d2a720), ev->cur.canvas.x(173) ev->cur.canvas.y(266)
06-06 23:44:40.891+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d2a720), hold(0) freeze(0)
06-06 23:44:40.901+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d2a720), block(1)
06-06 23:44:40.901+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d2a720), ev->cur.canvas.x(174) ev->cur.canvas.y(265)
06-06 23:44:40.901+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d2a720), hold(0) freeze(0)
06-06 23:44:40.911+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d2a720), block(1)
06-06 23:44:40.911+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d2a720), ev->cur.canvas.x(174) ev->cur.canvas.y(263)
06-06 23:44:40.911+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d2a720), hold(0) freeze(0)
06-06 23:44:40.921+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d2a720), block(1)
06-06 23:44:40.921+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d2a720), ev->cur.canvas.x(174) ev->cur.canvas.y(260)
06-06 23:44:40.921+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d2a720), hold(0) freeze(0)
06-06 23:44:40.931+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d2a720), block(1)
06-06 23:44:40.931+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d2a720), ev->cur.canvas.x(176) ev->cur.canvas.y(256)
06-06 23:44:40.931+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d2a720), hold(0) freeze(0)
06-06 23:44:40.941+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d2a720), block(1)
06-06 23:44:40.941+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d2a720), ev->cur.canvas.x(179) ev->cur.canvas.y(253)
06-06 23:44:40.941+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d2a720), hold(0) freeze(0)
06-06 23:44:40.951+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d2a720), block(1)
06-06 23:44:40.951+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d2a720), ev->cur.canvas.x(181) ev->cur.canvas.y(250)
06-06 23:44:40.951+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d2a720), hold(0) freeze(0)
06-06 23:44:40.961+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d2a720), block(1)
06-06 23:44:40.961+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d2a720), ev->cur.canvas.x(182) ev->cur.canvas.y(248)
06-06 23:44:40.961+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d2a720), hold(0) freeze(0)
06-06 23:44:40.981+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d2a720), block(1)
06-06 23:44:40.981+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d2a720), ev->cur.canvas.x(184) ev->cur.canvas.y(246)
06-06 23:44:40.981+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d2a720), hold(0) freeze(0)
06-06 23:44:40.991+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d2a720), block(1)
06-06 23:44:40.991+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d2a720), ev->cur.canvas.x(185) ev->cur.canvas.y(245)
06-06 23:44:40.991+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d2a720), hold(0) freeze(0)
06-06 23:44:41.001+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d2a720), block(1)
06-06 23:44:41.001+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d2a720), ev->cur.canvas.x(186) ev->cur.canvas.y(243)
06-06 23:44:41.001+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d2a720), hold(0) freeze(0)
06-06 23:44:41.011+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d2a720), block(1)
06-06 23:44:41.011+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d2a720), ev->cur.canvas.x(187) ev->cur.canvas.y(242)
06-06 23:44:41.011+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d2a720), hold(0) freeze(0)
06-06 23:44:41.011+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:4249 _elm_scroll_mouse_move_event_cb() [DDO] animator
06-06 23:44:41.011+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3353 _elm_scroll_post_event_move() [DDO] obj(b8d2a720), type(elm_genlist)
06-06 23:44:41.011+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3354 _elm_scroll_post_event_move() [DDO] hold_parent(0)
06-06 23:44:41.011+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3382 _elm_scroll_post_event_move() [DDO] elm_widget_drag_lock_x_set : obj(b8d2a720), type(elm_genlist)
06-06 23:44:41.011+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3405 _elm_scroll_post_event_move() [DDO] elm_widget_drag_lock_y_set : obj(b8d2a720), type(elm_genlist)
06-06 23:44:41.021+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d2a720), block(1)
06-06 23:44:41.021+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d2a720), ev->cur.canvas.x(189) ev->cur.canvas.y(240)
06-06 23:44:41.021+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d2a720), hold(0) freeze(0)
06-06 23:44:41.021+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b8d2a720), locked_x(0)
06-06 23:44:41.021+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3843 _elm_scroll_hold_animator() [DDO] obj(b8d2a720)
06-06 23:44:41.021+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b8d2a720)
06-06 23:44:41.071+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d2a720), block(1)
06-06 23:44:41.071+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d2a720), ev->cur.canvas.x(195) ev->cur.canvas.y(238)
06-06 23:44:41.071+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d2a720), hold(0) freeze(0)
06-06 23:44:41.071+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d2a720), block(1)
06-06 23:44:41.071+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d2a720), ev->cur.canvas.x(202) ev->cur.canvas.y(235)
06-06 23:44:41.071+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d2a720), hold(0) freeze(0)
06-06 23:44:41.071+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d2a720), block(1)
06-06 23:44:41.071+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d2a720), ev->cur.canvas.x(206) ev->cur.canvas.y(234)
06-06 23:44:41.071+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d2a720), hold(0) freeze(0)
06-06 23:44:41.071+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d2a720), block(1)
06-06 23:44:41.071+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d2a720), ev->cur.canvas.x(209) ev->cur.canvas.y(234)
06-06 23:44:41.071+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d2a720), hold(0) freeze(0)
06-06 23:44:41.071+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b8d2a720), locked_x(0)
06-06 23:44:41.071+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3843 _elm_scroll_hold_animator() [DDO] obj(b8d2a720)
06-06 23:44:41.071+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b8d2a720)
06-06 23:44:41.111+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d2a720), block(1)
06-06 23:44:41.111+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d2a720), ev->cur.canvas.x(214) ev->cur.canvas.y(233)
06-06 23:44:41.111+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d2a720), hold(0) freeze(0)
06-06 23:44:41.111+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d2a720), block(1)
06-06 23:44:41.111+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d2a720), ev->cur.canvas.x(216) ev->cur.canvas.y(231)
06-06 23:44:41.111+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d2a720), hold(0) freeze(0)
06-06 23:44:41.111+0900 E/EFL     ( 3266): evas_main<3266> evas_events.c:1275 evas_event_feed_mouse_up() ButtonEvent:up time=22830838 button=1 downs=0
06-06 23:44:41.111+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:2278 _elm_scroll_post_event_up() [DDO] lock set false. : obj(b8d2a720), type(elm_genlist)
06-06 23:44:41.591+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d2a720), block(1)
06-06 23:44:41.591+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d2a720), ev->cur.canvas.x(170) ev->cur.canvas.y(307)
06-06 23:44:41.591+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d2a720), hold(0) freeze(0)
06-06 23:44:41.591+0900 E/EFL     ( 3266): evas_main<3266> evas_events.c:1009 evas_event_feed_mouse_down() ButtonEvent:down time=22831333 button=1 downs=1
06-06 23:44:41.621+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d2a720), block(1)
06-06 23:44:41.621+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d2a720), ev->cur.canvas.x(170) ev->cur.canvas.y(308)
06-06 23:44:41.621+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d2a720), hold(0) freeze(0)
06-06 23:44:41.641+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d2a720), block(1)
06-06 23:44:41.641+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d2a720), ev->cur.canvas.x(169) ev->cur.canvas.y(308)
06-06 23:44:41.641+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d2a720), hold(0) freeze(0)
06-06 23:44:41.661+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d2a720), block(1)
06-06 23:44:41.661+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d2a720), ev->cur.canvas.x(170) ev->cur.canvas.y(308)
06-06 23:44:41.661+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d2a720), hold(0) freeze(0)
06-06 23:44:41.691+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d2a720), block(1)
06-06 23:44:41.691+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d2a720), ev->cur.canvas.x(168) ev->cur.canvas.y(309)
06-06 23:44:41.691+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d2a720), hold(0) freeze(0)
06-06 23:44:41.691+0900 E/EFL     ( 3266): evas_main<3266> evas_events.c:1275 evas_event_feed_mouse_up() ButtonEvent:up time=22831418 button=1 downs=0
06-06 23:44:42.001+0900 I/efl-extension( 3266): efl_extension_rotary.c: eext_rotary_object_event_callback_add(147) > In
06-06 23:44:42.001+0900 I/efl-extension( 3266): efl_extension_rotary.c: eext_rotary_object_event_activated_set(283) > eext_rotary_object_event_activated_set : 0xb8e598f0, elm_image, _activated_obj : 0xb8d4af88, activated : 1
06-06 23:44:42.001+0900 I/efl-extension( 3266): efl_extension_rotary.c: eext_rotary_object_event_activated_set(291) > Activation delete!!!!
06-06 23:44:42.041+0900 W/AUL_AMD (  905): amd_status.c: __app_terminate_timer_cb(166) > send SIGKILL: No such process
06-06 23:44:42.911+0900 I/APP_CORE( 1184): appcore-efl.c: __do_app(429) > [APP 1184] Event: MEM_FLUSH State: PAUSED
06-06 23:44:42.911+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8e05d58), block(1)
06-06 23:44:42.911+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8e05d58), ev->cur.canvas.x(180) ev->cur.canvas.y(300)
06-06 23:44:42.911+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8e05d58), hold(0) freeze(0)
06-06 23:44:42.911+0900 E/EFL     ( 3266): evas_main<3266> evas_events.c:1009 evas_event_feed_mouse_down() ButtonEvent:down time=22832653 button=1 downs=1
06-06 23:44:42.941+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8e05d58), block(1)
06-06 23:44:42.941+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8e05d58), ev->cur.canvas.x(178) ev->cur.canvas.y(293)
06-06 23:44:42.941+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8e05d58), hold(0) freeze(0)
06-06 23:44:42.951+0900 E/EFL     ( 3266): evas_main<3266> evas_events.c:1275 evas_event_feed_mouse_up() ButtonEvent:up time=22832694 button=1 downs=0
06-06 23:44:43.261+0900 I/efl-extension( 3266): efl_extension_rotary.c: eext_rotary_object_event_callback_add(147) > In
06-06 23:44:43.261+0900 I/efl-extension( 3266): efl_extension_rotary.c: eext_rotary_object_event_activated_set(283) > eext_rotary_object_event_activated_set : 0xb8e815d8, elm_image, _activated_obj : 0xb8e598f0, activated : 1
06-06 23:44:43.261+0900 I/efl-extension( 3266): efl_extension_rotary.c: eext_rotary_object_event_activated_set(291) > Activation delete!!!!
06-06 23:44:43.951+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8e71160), block(1)
06-06 23:44:43.951+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8e71160), ev->cur.canvas.x(200) ev->cur.canvas.y(259)
06-06 23:44:43.951+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8e71160), hold(0) freeze(0)
06-06 23:44:43.951+0900 E/EFL     ( 3266): evas_main<3266> evas_events.c:1009 evas_event_feed_mouse_down() ButtonEvent:down time=22833687 button=1 downs=1
06-06 23:44:43.951+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8e71160), block(1)
06-06 23:44:43.951+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8e71160), ev->cur.canvas.x(197) ev->cur.canvas.y(262)
06-06 23:44:43.951+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8e71160), hold(0) freeze(0)
06-06 23:44:43.961+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8e71160), block(1)
06-06 23:44:43.961+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8e71160), ev->cur.canvas.x(196) ev->cur.canvas.y(265)
06-06 23:44:43.961+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8e71160), hold(0) freeze(0)
06-06 23:44:43.981+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8e71160), block(1)
06-06 23:44:43.981+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8e71160), ev->cur.canvas.x(196) ev->cur.canvas.y(264)
06-06 23:44:43.981+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8e71160), hold(0) freeze(0)
06-06 23:44:43.981+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8e71160), block(1)
06-06 23:44:43.981+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8e71160), ev->cur.canvas.x(196) ev->cur.canvas.y(261)
06-06 23:44:43.981+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8e71160), hold(0) freeze(0)
06-06 23:44:43.991+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8e71160), block(1)
06-06 23:44:43.991+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8e71160), ev->cur.canvas.x(196) ev->cur.canvas.y(260)
06-06 23:44:43.991+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8e71160), hold(0) freeze(0)
06-06 23:44:44.011+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8e71160), block(1)
06-06 23:44:44.011+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8e71160), ev->cur.canvas.x(202) ev->cur.canvas.y(257)
06-06 23:44:44.011+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8e71160), hold(0) freeze(0)
06-06 23:44:44.021+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8e71160), block(1)
06-06 23:44:44.021+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8e71160), ev->cur.canvas.x(208) ev->cur.canvas.y(254)
06-06 23:44:44.021+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8e71160), hold(0) freeze(0)
06-06 23:44:44.031+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8e71160), block(1)
06-06 23:44:44.031+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8e71160), ev->cur.canvas.x(208) ev->cur.canvas.y(249)
06-06 23:44:44.031+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8e71160), hold(0) freeze(0)
06-06 23:44:44.041+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8e71160), block(1)
06-06 23:44:44.041+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8e71160), ev->cur.canvas.x(211) ev->cur.canvas.y(243)
06-06 23:44:44.041+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8e71160), hold(0) freeze(0)
06-06 23:44:44.061+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8e71160), block(1)
06-06 23:44:44.061+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8e71160), ev->cur.canvas.x(216) ev->cur.canvas.y(239)
06-06 23:44:44.061+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8e71160), hold(0) freeze(0)
06-06 23:44:44.061+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8e71160), block(1)
06-06 23:44:44.061+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8e71160), ev->cur.canvas.x(219) ev->cur.canvas.y(232)
06-06 23:44:44.061+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8e71160), hold(0) freeze(0)
06-06 23:44:44.081+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8e71160), block(1)
06-06 23:44:44.081+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8e71160), ev->cur.canvas.x(224) ev->cur.canvas.y(223)
06-06 23:44:44.081+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8e71160), hold(0) freeze(0)
06-06 23:44:44.081+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:4249 _elm_scroll_mouse_move_event_cb() [DDO] animator
06-06 23:44:44.081+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3353 _elm_scroll_post_event_move() [DDO] obj(b8e71160), type(elm_genlist)
06-06 23:44:44.081+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3354 _elm_scroll_post_event_move() [DDO] hold_parent(0)
06-06 23:44:44.081+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3382 _elm_scroll_post_event_move() [DDO] elm_widget_drag_lock_x_set : obj(b8e71160), type(elm_genlist)
06-06 23:44:44.081+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3405 _elm_scroll_post_event_move() [DDO] elm_widget_drag_lock_y_set : obj(b8e71160), type(elm_genlist)
06-06 23:44:44.081+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8e71160), block(1)
06-06 23:44:44.081+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8e71160), ev->cur.canvas.x(227) ev->cur.canvas.y(216)
06-06 23:44:44.081+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8e71160), hold(0) freeze(0)
06-06 23:44:44.091+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b8e71160), locked_x(0)
06-06 23:44:44.091+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3843 _elm_scroll_hold_animator() [DDO] obj(b8e71160)
06-06 23:44:44.091+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b8e71160)
06-06 23:44:44.111+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8e71160), block(1)
06-06 23:44:44.111+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8e71160), ev->cur.canvas.x(230) ev->cur.canvas.y(208)
06-06 23:44:44.111+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8e71160), hold(0) freeze(0)
06-06 23:44:44.111+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8e71160), block(1)
06-06 23:44:44.111+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8e71160), ev->cur.canvas.x(234) ev->cur.canvas.y(200)
06-06 23:44:44.111+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8e71160), hold(0) freeze(0)
06-06 23:44:44.111+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b8e71160), locked_x(0)
06-06 23:44:44.111+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3843 _elm_scroll_hold_animator() [DDO] obj(b8e71160)
06-06 23:44:44.111+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b8e71160)
06-06 23:44:44.141+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8e71160), block(1)
06-06 23:44:44.141+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8e71160), ev->cur.canvas.x(238) ev->cur.canvas.y(195)
06-06 23:44:44.141+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8e71160), hold(0) freeze(0)
06-06 23:44:44.141+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8e71160), block(1)
06-06 23:44:44.141+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8e71160), ev->cur.canvas.x(240) ev->cur.canvas.y(191)
06-06 23:44:44.141+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8e71160), hold(0) freeze(0)
06-06 23:44:44.141+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8e71160), block(1)
06-06 23:44:44.141+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8e71160), ev->cur.canvas.x(241) ev->cur.canvas.y(186)
06-06 23:44:44.141+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8e71160), hold(0) freeze(0)
06-06 23:44:44.141+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b8e71160), locked_x(0)
06-06 23:44:44.141+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3843 _elm_scroll_hold_animator() [DDO] obj(b8e71160)
06-06 23:44:44.141+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b8e71160)
06-06 23:44:44.161+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8e71160), block(1)
06-06 23:44:44.161+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8e71160), ev->cur.canvas.x(242) ev->cur.canvas.y(183)
06-06 23:44:44.161+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8e71160), hold(0) freeze(0)
06-06 23:44:44.161+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8e71160), block(1)
06-06 23:44:44.161+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8e71160), ev->cur.canvas.x(243) ev->cur.canvas.y(181)
06-06 23:44:44.161+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8e71160), hold(0) freeze(0)
06-06 23:44:44.161+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b8e71160), locked_x(0)
06-06 23:44:44.161+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3843 _elm_scroll_hold_animator() [DDO] obj(b8e71160)
06-06 23:44:44.161+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b8e71160)
06-06 23:44:44.171+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8e71160), block(1)
06-06 23:44:44.171+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8e71160), ev->cur.canvas.x(244) ev->cur.canvas.y(179)
06-06 23:44:44.171+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8e71160), hold(0) freeze(0)
06-06 23:44:44.171+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b8e71160), locked_x(0)
06-06 23:44:44.171+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3843 _elm_scroll_hold_animator() [DDO] obj(b8e71160)
06-06 23:44:44.171+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b8e71160)
06-06 23:44:44.191+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8e71160), block(1)
06-06 23:44:44.191+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8e71160), ev->cur.canvas.x(245) ev->cur.canvas.y(177)
06-06 23:44:44.191+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8e71160), hold(0) freeze(0)
06-06 23:44:44.191+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8e71160), block(1)
06-06 23:44:44.191+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8e71160), ev->cur.canvas.x(246) ev->cur.canvas.y(176)
06-06 23:44:44.191+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8e71160), hold(0) freeze(0)
06-06 23:44:44.191+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b8e71160), locked_x(0)
06-06 23:44:44.191+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3843 _elm_scroll_hold_animator() [DDO] obj(b8e71160)
06-06 23:44:44.191+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b8e71160)
06-06 23:44:44.211+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8e71160), block(1)
06-06 23:44:44.211+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8e71160), ev->cur.canvas.x(250) ev->cur.canvas.y(175)
06-06 23:44:44.211+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8e71160), hold(0) freeze(0)
06-06 23:44:44.211+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b8e71160), locked_x(0)
06-06 23:44:44.211+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3843 _elm_scroll_hold_animator() [DDO] obj(b8e71160)
06-06 23:44:44.211+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b8e71160)
06-06 23:44:44.221+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8e71160), block(1)
06-06 23:44:44.221+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8e71160), ev->cur.canvas.x(260) ev->cur.canvas.y(174)
06-06 23:44:44.221+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8e71160), hold(0) freeze(0)
06-06 23:44:44.221+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8e71160), block(1)
06-06 23:44:44.221+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8e71160), ev->cur.canvas.x(269) ev->cur.canvas.y(172)
06-06 23:44:44.221+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8e71160), hold(0) freeze(0)
06-06 23:44:44.221+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b8e71160), locked_x(0)
06-06 23:44:44.221+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3843 _elm_scroll_hold_animator() [DDO] obj(b8e71160)
06-06 23:44:44.221+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b8e71160)
06-06 23:44:44.241+0900 E/EFL     ( 3266): evas_main<3266> evas_events.c:1275 evas_event_feed_mouse_up() ButtonEvent:up time=22833977 button=1 downs=0
06-06 23:44:44.241+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:2278 _elm_scroll_post_event_up() [DDO] lock set false. : obj(b8e71160), type(elm_genlist)
06-06 23:44:44.881+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8e71160), block(1)
06-06 23:44:44.881+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8e71160), ev->cur.canvas.x(171) ev->cur.canvas.y(337)
06-06 23:44:44.881+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8e71160), hold(0) freeze(0)
06-06 23:44:44.881+0900 E/EFL     ( 3266): evas_main<3266> evas_events.c:1009 evas_event_feed_mouse_down() ButtonEvent:down time=22834608 button=1 downs=1
06-06 23:44:44.881+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8e71160), block(1)
06-06 23:44:44.881+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8e71160), ev->cur.canvas.x(173) ev->cur.canvas.y(336)
06-06 23:44:44.881+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8e71160), hold(0) freeze(0)
06-06 23:44:44.881+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8e71160), block(1)
06-06 23:44:44.881+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8e71160), ev->cur.canvas.x(172) ev->cur.canvas.y(334)
06-06 23:44:44.891+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8e71160), hold(0) freeze(0)
06-06 23:44:44.911+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8e71160), block(1)
06-06 23:44:44.911+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8e71160), ev->cur.canvas.x(172) ev->cur.canvas.y(333)
06-06 23:44:44.911+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8e71160), hold(0) freeze(0)
06-06 23:44:44.911+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8e71160), block(1)
06-06 23:44:44.911+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8e71160), ev->cur.canvas.x(172) ev->cur.canvas.y(332)
06-06 23:44:44.911+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8e71160), hold(0) freeze(0)
06-06 23:44:44.931+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8e71160), block(1)
06-06 23:44:44.931+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8e71160), ev->cur.canvas.x(172) ev->cur.canvas.y(331)
06-06 23:44:44.931+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8e71160), hold(0) freeze(0)
06-06 23:44:44.961+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8e71160), block(1)
06-06 23:44:44.961+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8e71160), ev->cur.canvas.x(170) ev->cur.canvas.y(322)
06-06 23:44:44.961+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8e71160), hold(0) freeze(0)
06-06 23:44:44.961+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8e71160), block(1)
06-06 23:44:44.961+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8e71160), ev->cur.canvas.x(170) ev->cur.canvas.y(315)
06-06 23:44:44.961+0900 E/EFL     ( 3266): elementary<3266> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8e71160), hold(0) freeze(0)
06-06 23:44:44.981+0900 E/EFL     ( 3266): evas_main<3266> evas_events.c:1275 evas_event_feed_mouse_up() ButtonEvent:up time=22834703 button=1 downs=0
06-06 23:44:45.391+0900 W/CRASH_MANAGER( 3367): worker.c: worker_job(1199) > 1103266756963146522428
