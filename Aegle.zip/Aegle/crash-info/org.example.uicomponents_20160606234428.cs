S/W Version Information
Model: SM-R735S
Tizen-Version: 2.3.1.2
Build-Number: R735SKSU1AOKE
Build-Date: 2015.11.25 20:46:58

Crash Information
Process Name: uicomponents
PID: 3024
Date: 2016-06-06 23:44:28+0900
Executable File Path: /opt/usr/apps/org.example.uicomponents/bin/uicomponents
Signal: 11
      (SIGSEGV)
      si_code: -6
      signal sent by tkill (sent by pid 3024, uid 5000)

Register Information
r0   = 0x71737723, r1   = 0x71737723
r2   = 0x00000001, r3   = 0x00000000
r4   = 0x71737723, r5   = 0xb6ed29f8
r6   = 0xb7c290e0, r7   = 0xbec3f3e8
r8   = 0xb6c869c0, r9   = 0xb7b33638
r10  = 0xb6ecae9c, fp   = 0x00000000
ip   = 0xb6ecc428, sp   = 0xbec3f310
lr   = 0xb6e7932d, pc   = 0xb6cc2bde
cpsr = 0xa0000030

Memory Information
MemTotal:   407572 KB
MemFree:      9476 KB
Buffers:     14972 KB
Cached:      91992 KB
VmPeak:      78668 KB
VmSize:      76504 KB
VmLck:           0 KB
VmPin:           0 KB
VmHWM:       21000 KB
VmRSS:       21000 KB
VmData:      17936 KB
VmStk:         136 KB
VmExe:          20 KB
VmLib:       24768 KB
VmPTE:          58 KB
VmSwap:          0 KB

Threads Information
Threads: 2
PID = 3024 TID = 3024
3024 3276 

Maps Information
b28b8000 b28bc000 r-xp /usr/lib/libogg.so.0.7.1
b28c4000 b28e6000 r-xp /usr/lib/libvorbis.so.0.4.3
b28ee000 b28f6000 r-xp /usr/lib/libmdm-common.so.1.0.89
b28f7000 b293a000 r-xp /usr/lib/libsndfile.so.1.0.25
b2947000 b298f000 r-xp /usr/lib/pulseaudio/libpulsecommon-4.0.so
b2990000 b2995000 r-xp /usr/lib/libjson.so.0.0.1
b299d000 b29ce000 r-xp /usr/lib/libmdm.so.1.1.85
b29d6000 b29de000 r-xp /usr/lib/lib_DNSe_NRSS_ver225.so
b29ed000 b29fd000 r-xp /usr/lib/lib_SamsungRec_TizenV04014.so
b2a1e000 b2a2b000 r-xp /usr/lib/libail.so.0.1.0
b2a34000 b2a37000 r-xp /usr/lib/libsyspopup_caller.so.0.1.0
b2a3f000 b2a77000 r-xp /usr/lib/libpulse.so.0.16.2
b2a78000 b2ad9000 r-xp /usr/lib/libasound.so.2.0.0
b2ae3000 b2ae6000 r-xp /usr/lib/libpulse-simple.so.0.0.4
b2aee000 b2af3000 r-xp /usr/lib/libascenario-0.2.so.0.0.0
b2afb000 b2b14000 r-xp /usr/lib/libavsysaudio.so.0.0.1
b2b1d000 b2b21000 r-xp /usr/lib/libmmfsoundcommon.so.0.0.0
b2b2a000 b2b34000 r-xp /usr/lib/libaudio-session-mgr.so.0.0.0
b2b40000 b2b45000 r-xp /usr/lib/libmmfsession.so.0.0.0
b2b4d000 b2b63000 r-xp /usr/lib/libmmfsound.so.0.1.0
b2b75000 b2b7c000 r-xp /usr/lib/libmmfcommon.so.0.0.0
b2b84000 b2b8e000 r-xp /usr/lib/libcapi-media-sound-manager.so.0.1.48
b2b96000 b2b98000 r-xp /usr/lib/libcapi-media-wav-player.so.0.1.10
b2ba0000 b2ba7000 r-xp /usr/lib/libfeedback.so.0.1.4
b2bc6000 b2bc7000 r-xp /usr/lib/edje/modules/feedback/linux-gnueabi-armv7l-1.0.0/module.so
b2bcf000 b2c56000 rw-s anon_inode:dmabuf
b2c56000 b2cdd000 rw-s anon_inode:dmabuf
b2d68000 b2def000 rw-s anon_inode:dmabuf
b2e6e000 b2ef5000 rw-s anon_inode:dmabuf
b3104000 b3105000 r-xp /usr/lib/libmmfkeysound.so.0.0.0
b319c000 b399b000 rwxp [stack:3276]
b399b000 b39b2000 r-xp /usr/lib/edje/modules/elm/linux-gnueabi-armv7l-1.0.0/module.so
b39bf000 b39c1000 r-xp /usr/lib/libgenlock.so
b39ca000 b39cb000 r-xp /usr/lib/evas/modules/loaders/eet/linux-gnueabi-armv7l-1.7.99/module.so
b39d3000 b39d5000 r-xp /usr/lib/evas/modules/loaders/png/linux-gnueabi-armv7l-1.7.99/module.so
b39df000 b39e4000 r-xp /usr/lib/bufmgr/libtbm_msm.so.0.0.0
b39ec000 b39f7000 r-xp /usr/lib/evas/modules/engines/software_generic/linux-gnueabi-armv7l-1.7.99/module.so
b3d1f000 b3de9000 r-xp /usr/lib/libCOREGL.so.4.0
b3dfa000 b3dff000 r-xp /usr/lib/libcapi-media-tool.so.0.1.5
b3e07000 b3e28000 r-xp /usr/lib/libexif.so.12.3.3
b3e3b000 b3e40000 r-xp /usr/lib/libmmutil_imgp.so.0.0.0
b3e48000 b3e4d000 r-xp /usr/lib/libmmutil_jpeg.so.0.0.0
b53dc000 b53de000 r-xp /usr/lib/libdri2.so.0.0.0
b53e6000 b53ee000 r-xp /usr/lib/libdrm.so.2.4.0
b53f6000 b53f9000 r-xp /usr/lib/libcapi-media-image-util.so.0.3.5
b5401000 b54e5000 r-xp /usr/lib/libicuuc.so.51.1
b54fa000 b5637000 r-xp /usr/lib/libicui18n.so.51.1
b5647000 b564c000 r-xp /usr/lib/libcapi-system-info.so.0.2.0
b5654000 b565a000 r-xp /usr/lib/libxcb-render.so.0.0.0
b5662000 b5663000 r-xp /usr/lib/libxcb-shm.so.0.0.0
b566c000 b566f000 r-xp /usr/lib/libEGL.so.1.4
b5677000 b5685000 r-xp /usr/lib/libGLESv2.so.2.0
b568e000 b5695000 r-xp /usr/lib/libtbm.so.1.0.0
b569d000 b56be000 r-xp /usr/lib/libui-extension.so.0.1.0
b56c7000 b56d9000 r-xp /usr/lib/libtts.so
b56e1000 b5799000 r-xp /usr/lib/libcairo.so.2.11200.14
b57a4000 b57b6000 r-xp /usr/lib/libefl-assist.so.0.1.0
b57be000 b57df000 r-xp /usr/lib/libefl-extension.so.0.1.0
b57e7000 b57fb000 r-xp /opt/usr/apps/org.example.uicomponents/bin/uicomponents
b59c2000 b59cc000 r-xp /lib/libnss_files-2.13.so
b59d5000 b5aa4000 r-xp /usr/lib/libscim-1.0.so.8.2.3
b5aba000 b5ade000 r-xp /usr/lib/ecore/immodules/libisf-imf-module.so
b5ae7000 b5aed000 r-xp /usr/lib/libappsvc.so.0.1.0
b5af5000 b5af7000 r-xp /usr/lib/libcapi-appfw-app-common.so.0.3.2.5
b5b00000 b5b05000 r-xp /usr/lib/libcapi-appfw-app-control.so.0.3.2.5
b5b10000 b5b1b000 r-xp /usr/lib/evas/modules/engines/software_x11/linux-gnueabi-armv7l-1.7.99/module.so
b5b23000 b5b25000 r-xp /usr/lib/libiniparser.so.0
b5b2e000 b5b33000 r-xp /usr/lib/libappcore-common.so.1.1
b5b3c000 b5b44000 r-xp /usr/lib/libcapi-system-system-settings.so.0.0.2
b5b45000 b5b49000 r-xp /usr/lib/libcapi-appfw-application.so.0.3.2.5
b5b56000 b5b58000 r-xp /usr/lib/libXau.so.6.0.0
b5b61000 b5b68000 r-xp /lib/libcrypt-2.13.so
b5b98000 b5b9a000 r-xp /usr/lib/libiri.so
b5ba2000 b5d4a000 r-xp /usr/lib/libcrypto.so.1.0.0
b5d63000 b5db0000 r-xp /usr/lib/libssl.so.1.0.0
b5dbd000 b5deb000 r-xp /usr/lib/libidn.so.11.5.44
b5df3000 b5dfc000 r-xp /usr/lib/libcares.so.2.1.0
b5e05000 b5e18000 r-xp /usr/lib/libxcb.so.1.1.0
b5e21000 b5e23000 r-xp /usr/lib/journal/libjournal.so.0.1.0
b5e2c000 b5e2e000 r-xp /usr/lib/libSLP-db-util.so.0.1.0
b5e37000 b5f03000 r-xp /usr/lib/libxml2.so.2.7.8
b5f10000 b5f12000 r-xp /usr/lib/libgmodule-2.0.so.0.3200.3
b5f1a000 b5f1f000 r-xp /usr/lib/libffi.so.5.0.10
b5f27000 b5f28000 r-xp /usr/lib/libgthread-2.0.so.0.3200.3
b5f31000 b5f3c000 r-xp /usr/lib/libgpg-error.so.0.15.0
b5f44000 b5f47000 r-xp /lib/libattr.so.1.1.0
b5f4f000 b5fe3000 r-xp /usr/lib/libstdc++.so.6.0.16
b5ff6000 b6012000 r-xp /usr/lib/libsecurity-server-commons.so.1.0.0
b601b000 b6033000 r-xp /usr/lib/libpng12.so.0.50.0
b603c000 b6052000 r-xp /lib/libexpat.so.1.5.2
b605c000 b60a0000 r-xp /usr/lib/libcurl.so.4.3.0
b60a9000 b60b3000 r-xp /usr/lib/libXext.so.6.4.0
b60bc000 b60bf000 r-xp /usr/lib/libXtst.so.6.1.0
b60c8000 b60ce000 r-xp /usr/lib/libXrender.so.1.3.0
b60d7000 b60dd000 r-xp /usr/lib/libXrandr.so.2.2.0
b60e5000 b60e6000 r-xp /usr/lib/libXinerama.so.1.0.0
b60ef000 b60f8000 r-xp /usr/lib/libXi.so.6.1.0
b6100000 b6103000 r-xp /usr/lib/libXfixes.so.3.1.0
b610b000 b610d000 r-xp /usr/lib/libXgesture.so.7.0.0
b6115000 b6117000 r-xp /usr/lib/libXcomposite.so.1.0.0
b6120000 b6122000 r-xp /usr/lib/libXdamage.so.1.1.0
b612a000 b6131000 r-xp /usr/lib/libXcursor.so.1.0.2
b6139000 b613c000 r-xp /usr/lib/libecore_input_evas.so.1.7.99
b6144000 b6148000 r-xp /usr/lib/libecore_ipc.so.1.7.99
b6151000 b6156000 r-xp /usr/lib/libecore_fb.so.1.7.99
b6160000 b6241000 r-xp /usr/lib/libX11.so.6.3.0
b624c000 b626f000 r-xp /usr/lib/libjpeg.so.8.0.2
b6287000 b629d000 r-xp /lib/libz.so.1.2.5
b62a5000 b631a000 r-xp /usr/lib/libsqlite3.so.0.8.6
b6324000 b6339000 r-xp /usr/lib/libpkgmgr_parser.so.0.1.0
b6342000 b6376000 r-xp /usr/lib/libgobject-2.0.so.0.3200.3
b637f000 b6452000 r-xp /usr/lib/libgio-2.0.so.0.3200.3
b645d000 b646d000 r-xp /lib/libresolv-2.13.so
b6471000 b64ed000 r-xp /usr/lib/libgcrypt.so.20.0.3
b64f9000 b6511000 r-xp /usr/lib/liblzma.so.5.0.3
b651a000 b651d000 r-xp /lib/libcap.so.2.21
b6525000 b654b000 r-xp /usr/lib/libsecurity-server-client.so.1.0.1
b6554000 b6555000 r-xp /usr/lib/libecore_imf_evas.so.1.7.99
b655d000 b6563000 r-xp /usr/lib/libecore_imf.so.1.7.99
b656b000 b6582000 r-xp /usr/lib/liblua-5.1.so
b658c000 b6593000 r-xp /usr/lib/libembryo.so.1.7.99
b659b000 b65a1000 r-xp /lib/librt-2.13.so
b65aa000 b6600000 r-xp /usr/lib/libpixman-1.so.0.28.2
b660d000 b6663000 r-xp /usr/lib/libfreetype.so.6.11.3
b666f000 b6697000 r-xp /usr/lib/libfontconfig.so.1.8.0
b6699000 b66d6000 r-xp /usr/lib/libharfbuzz.so.0.940.0
b66df000 b66f2000 r-xp /usr/lib/libfribidi.so.0.3.1
b66fa000 b6714000 r-xp /usr/lib/libecore_con.so.1.7.99
b671d000 b6726000 r-xp /usr/lib/libedbus.so.1.7.99
b672e000 b677e000 r-xp /usr/lib/libecore_x.so.1.7.99
b6781000 b6785000 r-xp /usr/lib/libvconf.so.0.2.45
b678d000 b679e000 r-xp /usr/lib/libecore_input.so.1.7.99
b67a6000 b67ab000 r-xp /usr/lib/libecore_file.so.1.7.99
b67b3000 b67d5000 r-xp /usr/lib/libecore_evas.so.1.7.99
b67de000 b681f000 r-xp /usr/lib/libeina.so.1.7.99
b6828000 b6841000 r-xp /usr/lib/libeet.so.1.7.99
b6852000 b68bb000 r-xp /lib/libm-2.13.so
b68c4000 b68ca000 r-xp /usr/lib/libcapi-base-common.so.0.1.8
b68d3000 b68d6000 r-xp /usr/lib/libproc-stat.so.0.2.86
b68de000 b6900000 r-xp /usr/lib/libpkgmgr-info.so.0.0.17
b6908000 b690d000 r-xp /usr/lib/libxdgmime.so.1.1.0
b6915000 b693f000 r-xp /usr/lib/libdbus-1.so.3.8.12
b6948000 b695f000 r-xp /usr/lib/libdbus-glib-1.so.2.2.2
b6967000 b6972000 r-xp /lib/libunwind.so.8.0.1
b699f000 b69db000 r-xp /usr/lib/libsystemd.so.0.4.0
b69e4000 b6aff000 r-xp /lib/libc-2.13.so
b6b0d000 b6b15000 r-xp /lib/libgcc_s-4.6.so.1
b6b16000 b6b19000 r-xp /usr/lib/libsmack.so.1.0.0
b6b21000 b6b27000 r-xp /usr/lib/libprivilege-control.so.0.0.2
b6b2f000 b6bff000 r-xp /usr/lib/libglib-2.0.so.0.3200.3
b6c00000 b6c5d000 r-xp /usr/lib/libedje.so.1.7.99
b6c67000 b6c7e000 r-xp /usr/lib/libecore.so.1.7.99
b6c95000 b6d64000 r-xp /usr/lib/libevas.so.1.7.99
b6d88000 b6ec2000 r-xp /usr/lib/libelementary.so.1.7.99
b6ed8000 b6eec000 r-xp /lib/libpthread-2.13.so
b6ef7000 b6ef9000 r-xp /usr/lib/libdlog.so.0.0.0
b6f01000 b6f04000 r-xp /usr/lib/libbundle.so.0.1.22
b6f0c000 b6f0e000 r-xp /lib/libdl-2.13.so
b6f17000 b6f23000 r-xp /usr/lib/libaul.so.0.1.0
b6f35000 b6f3a000 r-xp /usr/lib/libappcore-efl.so.1.1
b6f43000 b6f47000 r-xp /usr/lib/libsys-assert.so
b6f50000 b6f6d000 r-xp /lib/ld-2.13.so
b6f76000 b6f7b000 r-xp /usr/bin/launchpad-loader
b7afb000 b7f53000 rw-p [heap]
bec1f000 bec40000 rwxp [stack]
End of Maps Information

Callstack Information (PID:3024)
Call Stack Count: 4
 0: evas_object_evas_get + 0x5 (0xb6cc2bde) [/usr/lib/libevas.so.1] + 0x2dbde
 1: elm_widget_add + 0xc (0xb6e7932d) [/usr/lib/libelementary.so.1] + 0xf132d
 2: elm_genlist_add + 0x28 (0xb6e140bd) [/usr/lib/libelementary.so.1] + 0x8c0bd
 3: _user_info_entry_cb2 + 0x44 (0xb57ecdc5) [/opt/usr/apps/org.example.uicomponents/bin/uicomponents] + 0x5dc5
End of Call Stack

Package Information
Package Name: org.example.uicomponents
Package ID : org.example.uicomponents
Version: 1.0.0
Package Type: rpm
App Name: uicomponents
App ID: org.example.uicomponents
Type: capp
Categories: 

Latest Debug Message Information
--------- beginning of /dev/log_main
lm_scroll_mouse_move_event_cb() [DDO] obj(b7dcaf88), ev->cur.canvas.x(174) ev->cur.canvas.y(268)
06-06 23:44:22.711+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7dcaf88), hold(0) freeze(0)
06-06 23:44:22.731+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7dcaf88), block(1)
06-06 23:44:22.731+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7dcaf88), ev->cur.canvas.x(174) ev->cur.canvas.y(266)
06-06 23:44:22.731+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7dcaf88), hold(0) freeze(0)
06-06 23:44:22.741+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7dcaf88), block(1)
06-06 23:44:22.741+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7dcaf88), ev->cur.canvas.x(175) ev->cur.canvas.y(262)
06-06 23:44:22.741+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7dcaf88), hold(0) freeze(0)
06-06 23:44:22.741+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7dcaf88), block(1)
06-06 23:44:22.741+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7dcaf88), ev->cur.canvas.x(181) ev->cur.canvas.y(253)
06-06 23:44:22.741+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7dcaf88), hold(0) freeze(0)
06-06 23:44:22.761+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7dcaf88), block(1)
06-06 23:44:22.761+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7dcaf88), ev->cur.canvas.x(185) ev->cur.canvas.y(243)
06-06 23:44:22.761+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7dcaf88), hold(0) freeze(0)
06-06 23:44:22.771+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7dcaf88), block(1)
06-06 23:44:22.771+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7dcaf88), ev->cur.canvas.x(187) ev->cur.canvas.y(234)
06-06 23:44:22.771+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7dcaf88), hold(0) freeze(0)
06-06 23:44:22.771+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:4249 _elm_scroll_mouse_move_event_cb() [DDO] animator
06-06 23:44:22.771+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3353 _elm_scroll_post_event_move() [DDO] obj(b7dcaf88), type(elm_genlist)
06-06 23:44:22.771+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3354 _elm_scroll_post_event_move() [DDO] hold_parent(0)
06-06 23:44:22.771+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3405 _elm_scroll_post_event_move() [DDO] elm_widget_drag_lock_y_set : obj(b7dcaf88), type(elm_genlist)
06-06 23:44:22.771+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b7dcaf88), locked_x(0)
06-06 23:44:22.771+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b7dcaf88)
06-06 23:44:22.801+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7dcaf88), block(1)
06-06 23:44:22.801+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7dcaf88), ev->cur.canvas.x(195) ev->cur.canvas.y(225)
06-06 23:44:22.801+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7dcaf88), hold(0) freeze(0)
06-06 23:44:22.801+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7dcaf88), block(1)
06-06 23:44:22.801+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7dcaf88), ev->cur.canvas.x(202) ev->cur.canvas.y(215)
06-06 23:44:22.801+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7dcaf88), hold(0) freeze(0)
06-06 23:44:22.801+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7dcaf88), block(1)
06-06 23:44:22.801+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7dcaf88), ev->cur.canvas.x(202) ev->cur.canvas.y(205)
06-06 23:44:22.801+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7dcaf88), hold(0) freeze(0)
06-06 23:44:22.811+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b7dcaf88), locked_x(0)
06-06 23:44:22.811+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b7dcaf88)
06-06 23:44:22.851+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7dcaf88), block(1)
06-06 23:44:22.851+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7dcaf88), ev->cur.canvas.x(207) ev->cur.canvas.y(194)
06-06 23:44:22.851+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7dcaf88), hold(0) freeze(0)
06-06 23:44:22.851+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7dcaf88), block(1)
06-06 23:44:22.851+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7dcaf88), ev->cur.canvas.x(215) ev->cur.canvas.y(184)
06-06 23:44:22.851+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7dcaf88), hold(0) freeze(0)
06-06 23:44:22.851+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7dcaf88), block(1)
06-06 23:44:22.851+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7dcaf88), ev->cur.canvas.x(218) ev->cur.canvas.y(174)
06-06 23:44:22.851+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7dcaf88), hold(0) freeze(0)
06-06 23:44:22.851+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7dcaf88), block(1)
06-06 23:44:22.851+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7dcaf88), ev->cur.canvas.x(223) ev->cur.canvas.y(165)
06-06 23:44:22.851+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7dcaf88), hold(0) freeze(0)
06-06 23:44:22.851+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b7dcaf88), locked_x(0)
06-06 23:44:22.851+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b7dcaf88)
06-06 23:44:22.871+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7dcaf88), block(1)
06-06 23:44:22.871+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7dcaf88), ev->cur.canvas.x(231) ev->cur.canvas.y(155)
06-06 23:44:22.871+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7dcaf88), hold(0) freeze(0)
06-06 23:44:22.871+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7dcaf88), block(1)
06-06 23:44:22.871+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7dcaf88), ev->cur.canvas.x(239) ev->cur.canvas.y(146)
06-06 23:44:22.871+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7dcaf88), hold(0) freeze(0)
06-06 23:44:22.871+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b7dcaf88), locked_x(0)
06-06 23:44:22.871+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b7dcaf88)
06-06 23:44:22.901+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7dcaf88), block(1)
06-06 23:44:22.901+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7dcaf88), ev->cur.canvas.x(247) ev->cur.canvas.y(142)
06-06 23:44:22.901+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7dcaf88), hold(0) freeze(0)
06-06 23:44:22.901+0900 E/EFL     ( 3024): evas_main<3024> evas_events.c:1275 evas_event_feed_mouse_up() ButtonEvent:up time=22812630 button=1 downs=0
06-06 23:44:22.901+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:2278 _elm_scroll_post_event_up() [DDO] lock set false. : obj(b7dcaf88), type(elm_genlist)
06-06 23:44:23.521+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7dcaf88), block(1)
06-06 23:44:23.521+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7dcaf88), ev->cur.canvas.x(224) ev->cur.canvas.y(187)
06-06 23:44:23.521+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7dcaf88), hold(0) freeze(0)
06-06 23:44:23.521+0900 E/EFL     ( 3024): evas_main<3024> evas_events.c:1009 evas_event_feed_mouse_down() ButtonEvent:down time=22813267 button=1 downs=1
06-06 23:44:23.551+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7dcaf88), block(1)
06-06 23:44:23.551+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7dcaf88), ev->cur.canvas.x(223) ev->cur.canvas.y(186)
06-06 23:44:23.551+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7dcaf88), hold(0) freeze(0)
06-06 23:44:23.551+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7dcaf88), block(1)
06-06 23:44:23.551+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7dcaf88), ev->cur.canvas.x(222) ev->cur.canvas.y(186)
06-06 23:44:23.551+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7dcaf88), hold(0) freeze(0)
06-06 23:44:23.581+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7dcaf88), block(1)
06-06 23:44:23.581+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7dcaf88), ev->cur.canvas.x(224) ev->cur.canvas.y(186)
06-06 23:44:23.581+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7dcaf88), hold(0) freeze(0)
06-06 23:44:23.591+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7dcaf88), block(1)
06-06 23:44:23.591+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7dcaf88), ev->cur.canvas.x(231) ev->cur.canvas.y(188)
06-06 23:44:23.601+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7dcaf88), hold(0) freeze(0)
06-06 23:44:23.611+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7dcaf88), block(1)
06-06 23:44:23.611+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7dcaf88), ev->cur.canvas.x(234) ev->cur.canvas.y(196)
06-06 23:44:23.611+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7dcaf88), hold(0) freeze(0)
06-06 23:44:23.611+0900 E/EFL     ( 3024): evas_main<3024> evas_events.c:1275 evas_event_feed_mouse_up() ButtonEvent:up time=22813352 button=1 downs=0
06-06 23:44:24.561+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7dcaf88), block(1)
06-06 23:44:24.561+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7dcaf88), ev->cur.canvas.x(198) ev->cur.canvas.y(171)
06-06 23:44:24.561+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7dcaf88), hold(0) freeze(0)
06-06 23:44:24.561+0900 E/EFL     ( 3024): evas_main<3024> evas_events.c:1009 evas_event_feed_mouse_down() ButtonEvent:down time=22814298 button=1 downs=1
06-06 23:44:24.561+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7dcaf88), block(1)
06-06 23:44:24.561+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7dcaf88), ev->cur.canvas.x(198) ev->cur.canvas.y(169)
06-06 23:44:24.561+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7dcaf88), hold(0) freeze(0)
06-06 23:44:24.571+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7dcaf88), block(1)
06-06 23:44:24.571+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7dcaf88), ev->cur.canvas.x(198) ev->cur.canvas.y(171)
06-06 23:44:24.571+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7dcaf88), hold(0) freeze(0)
06-06 23:44:24.581+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7dcaf88), block(1)
06-06 23:44:24.581+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7dcaf88), ev->cur.canvas.x(196) ev->cur.canvas.y(174)
06-06 23:44:24.581+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7dcaf88), hold(0) freeze(0)
06-06 23:44:24.591+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7dcaf88), block(1)
06-06 23:44:24.591+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7dcaf88), ev->cur.canvas.x(195) ev->cur.canvas.y(179)
06-06 23:44:24.591+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7dcaf88), hold(0) freeze(0)
06-06 23:44:24.601+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7dcaf88), block(1)
06-06 23:44:24.601+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7dcaf88), ev->cur.canvas.x(195) ev->cur.canvas.y(184)
06-06 23:44:24.601+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7dcaf88), hold(0) freeze(0)
06-06 23:44:24.621+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7dcaf88), block(1)
06-06 23:44:24.621+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7dcaf88), ev->cur.canvas.x(193) ev->cur.canvas.y(192)
06-06 23:44:24.621+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7dcaf88), block(1)
06-06 23:44:24.621+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7dcaf88), ev->cur.canvas.x(189) ev->cur.canvas.y(207)
06-06 23:44:24.621+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7dcaf88), hold(0) freeze(0)
06-06 23:44:24.621+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:4249 _elm_scroll_mouse_move_event_cb() [DDO] animator
06-06 23:44:24.621+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3353 _elm_scroll_post_event_move() [DDO] obj(b7dcaf88), type(elm_genlist)
06-06 23:44:24.621+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3354 _elm_scroll_post_event_move() [DDO] hold_parent(0)
06-06 23:44:24.621+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3405 _elm_scroll_post_event_move() [DDO] elm_widget_drag_lock_y_set : obj(b7dcaf88), type(elm_genlist)
06-06 23:44:24.621+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7dcaf88), hold(0) freeze(0)
06-06 23:44:24.631+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7dcaf88), block(1)
06-06 23:44:24.631+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7dcaf88), ev->cur.canvas.x(182) ev->cur.canvas.y(228)
06-06 23:44:24.631+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7dcaf88), hold(0) freeze(0)
06-06 23:44:24.641+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b7dcaf88), locked_x(0)
06-06 23:44:24.641+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b7dcaf88)
06-06 23:44:24.671+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7dcaf88), block(1)
06-06 23:44:24.671+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7dcaf88), ev->cur.canvas.x(172) ev->cur.canvas.y(252)
06-06 23:44:24.671+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7dcaf88), hold(0) freeze(0)
06-06 23:44:24.671+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7dcaf88), block(1)
06-06 23:44:24.671+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7dcaf88), ev->cur.canvas.x(159) ev->cur.canvas.y(273)
06-06 23:44:24.671+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7dcaf88), hold(0) freeze(0)
06-06 23:44:24.671+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7dcaf88), block(1)
06-06 23:44:24.671+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7dcaf88), ev->cur.canvas.x(153) ev->cur.canvas.y(292)
06-06 23:44:24.671+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7dcaf88), hold(0) freeze(0)
06-06 23:44:24.671+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b7dcaf88), locked_x(0)
06-06 23:44:24.671+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b7dcaf88)
06-06 23:44:24.711+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7dcaf88), block(1)
06-06 23:44:24.711+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7dcaf88), ev->cur.canvas.x(153) ev->cur.canvas.y(308)
06-06 23:44:24.711+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7dcaf88), hold(0) freeze(0)
06-06 23:44:24.711+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7dcaf88), block(1)
06-06 23:44:24.711+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7dcaf88), ev->cur.canvas.x(153) ev->cur.canvas.y(321)
06-06 23:44:24.711+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7dcaf88), hold(0) freeze(0)
06-06 23:44:24.711+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7dcaf88), block(1)
06-06 23:44:24.711+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7dcaf88), ev->cur.canvas.x(154) ev->cur.canvas.y(331)
06-06 23:44:24.711+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7dcaf88), hold(0) freeze(0)
06-06 23:44:24.711+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b7dcaf88), locked_x(0)
06-06 23:44:24.711+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b7dcaf88)
06-06 23:44:24.731+0900 E/EFL     ( 3024): evas_main<3024> evas_events.c:1275 evas_event_feed_mouse_up() ButtonEvent:up time=22814453 button=1 downs=0
06-06 23:44:24.731+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:2278 _elm_scroll_post_event_up() [DDO] lock set false. : obj(b7dcaf88), type(elm_genlist)
06-06 23:44:25.181+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7dcaf88), block(1)
06-06 23:44:25.181+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7dcaf88), ev->cur.canvas.x(193) ev->cur.canvas.y(183)
06-06 23:44:25.181+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7dcaf88), hold(0) freeze(0)
06-06 23:44:25.181+0900 E/EFL     ( 3024): evas_main<3024> evas_events.c:1009 evas_event_feed_mouse_down() ButtonEvent:down time=22814926 button=1 downs=1
06-06 23:44:25.201+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7dcaf88), block(1)
06-06 23:44:25.201+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7dcaf88), ev->cur.canvas.x(193) ev->cur.canvas.y(184)
06-06 23:44:25.201+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7dcaf88), hold(0) freeze(0)
06-06 23:44:25.241+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7dcaf88), block(1)
06-06 23:44:25.241+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7dcaf88), ev->cur.canvas.x(196) ev->cur.canvas.y(184)
06-06 23:44:25.241+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7dcaf88), hold(0) freeze(0)
06-06 23:44:25.251+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7dcaf88), block(1)
06-06 23:44:25.251+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7dcaf88), ev->cur.canvas.x(207) ev->cur.canvas.y(188)
06-06 23:44:25.251+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7dcaf88), hold(0) freeze(0)
06-06 23:44:25.261+0900 E/EFL     ( 3024): evas_main<3024> evas_events.c:1275 evas_event_feed_mouse_up() ButtonEvent:up time=22815002 button=1 downs=0
06-06 23:44:26.201+0900 I/RESOURCED(  906): logging.c: logging_send_signal_to_data(1097) > [logging_send_signal_to_data,1097] send signal to logging data thread
06-06 23:44:26.201+0900 I/RESOURCED(  906): logging.c: logging_send_signal_to_update(1177) > [logging_send_signal_to_update,1177] send signal to logging update thread
06-06 23:44:26.441+0900 E/EFL     ( 3024): evas_main<3024> evas_events.c:1009 evas_event_feed_mouse_down() ButtonEvent:down time=22816159 button=1 downs=1
06-06 23:44:26.501+0900 E/EFL     ( 3024): evas_main<3024> evas_events.c:1275 evas_event_feed_mouse_up() ButtonEvent:up time=22816233 button=1 downs=0
06-06 23:44:27.871+0900 I/efl-extension( 3024): efl_extension_rotary.c: _object_deleted_cb(572) > In: data: 0xb7dcaf88, obj: 0xb7dcaf88
06-06 23:44:27.871+0900 I/efl-extension( 3024): efl_extension_rotary.c: _object_deleted_cb(601) > done
06-06 23:44:27.881+0900 I/efl-extension( 3024): efl_extension_rotary.c: _activated_obj_del_cb(607) > _activated_obj_del_cb : 0xb7d56468
06-06 23:44:27.881+0900 I/efl-extension( 3024): efl_extension_rotary.c: eext_rotary_object_event_callback_del(235) > In
06-06 23:44:27.881+0900 I/efl-extension( 3024): efl_extension_rotary.c: eext_rotary_object_event_callback_del(240) > callback del 0xb7dcaf88, elm_genlist, func : 0xb57cc079
06-06 23:44:27.881+0900 I/efl-extension( 3024): efl_extension_rotary.c: eext_rotary_object_event_callback_del(273) > done
06-06 23:44:27.921+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7d80330), block(1)
06-06 23:44:27.921+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7d80330), ev->cur.canvas.x(189) ev->cur.canvas.y(258)
06-06 23:44:27.921+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7d80330), hold(0) freeze(0)
06-06 23:44:27.921+0900 E/EFL     ( 3024): evas_main<3024> evas_events.c:1009 evas_event_feed_mouse_down() ButtonEvent:down time=22817665 button=1 downs=1
06-06 23:44:27.951+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7d80330), block(1)
06-06 23:44:27.951+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7d80330), ev->cur.canvas.x(190) ev->cur.canvas.y(253)
06-06 23:44:27.951+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7d80330), hold(0) freeze(0)
06-06 23:44:27.961+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7d80330), block(1)
06-06 23:44:27.961+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7d80330), ev->cur.canvas.x(191) ev->cur.canvas.y(248)
06-06 23:44:27.961+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7d80330), hold(0) freeze(0)
06-06 23:44:27.961+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7d80330), block(1)
06-06 23:44:27.961+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7d80330), ev->cur.canvas.x(191) ev->cur.canvas.y(244)
06-06 23:44:27.961+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7d80330), hold(0) freeze(0)
06-06 23:44:27.981+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7d80330), block(1)
06-06 23:44:27.981+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7d80330), ev->cur.canvas.x(191) ev->cur.canvas.y(240)
06-06 23:44:27.981+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7d80330), hold(0) freeze(0)
06-06 23:44:27.991+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7d80330), block(1)
06-06 23:44:27.991+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7d80330), ev->cur.canvas.x(191) ev->cur.canvas.y(235)
06-06 23:44:27.991+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7d80330), hold(0) freeze(0)
06-06 23:44:28.001+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7d80330), block(1)
06-06 23:44:28.001+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7d80330), ev->cur.canvas.x(193) ev->cur.canvas.y(231)
06-06 23:44:28.001+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7d80330), hold(0) freeze(0)
06-06 23:44:28.011+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7d80330), block(1)
06-06 23:44:28.011+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7d80330), ev->cur.canvas.x(196) ev->cur.canvas.y(227)
06-06 23:44:28.011+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7d80330), hold(0) freeze(0)
06-06 23:44:28.021+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7d80330), block(1)
06-06 23:44:28.021+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7d80330), ev->cur.canvas.x(202) ev->cur.canvas.y(223)
06-06 23:44:28.021+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7d80330), hold(0) freeze(0)
06-06 23:44:28.021+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:4249 _elm_scroll_mouse_move_event_cb() [DDO] animator
06-06 23:44:28.021+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3353 _elm_scroll_post_event_move() [DDO] obj(b7d80330), type(elm_genlist)
06-06 23:44:28.021+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3354 _elm_scroll_post_event_move() [DDO] hold_parent(0)
06-06 23:44:28.021+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3405 _elm_scroll_post_event_move() [DDO] elm_widget_drag_lock_y_set : obj(b7d80330), type(elm_genlist)
06-06 23:44:28.021+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b7d80330), locked_x(0)
06-06 23:44:28.021+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b7d80330)
06-06 23:44:28.061+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7d80330), block(1)
06-06 23:44:28.061+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7d80330), ev->cur.canvas.x(210) ev->cur.canvas.y(218)
06-06 23:44:28.061+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7d80330), hold(0) freeze(0)
06-06 23:44:28.061+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7d80330), block(1)
06-06 23:44:28.061+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7d80330), ev->cur.canvas.x(214) ev->cur.canvas.y(214)
06-06 23:44:28.061+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7d80330), hold(0) freeze(0)
06-06 23:44:28.061+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7d80330), block(1)
06-06 23:44:28.061+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7d80330), ev->cur.canvas.x(217) ev->cur.canvas.y(209)
06-06 23:44:28.061+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7d80330), hold(0) freeze(0)
06-06 23:44:28.061+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b7d80330), locked_x(0)
06-06 23:44:28.061+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b7d80330)
06-06 23:44:28.091+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7d80330), block(1)
06-06 23:44:28.091+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7d80330), ev->cur.canvas.x(219) ev->cur.canvas.y(202)
06-06 23:44:28.091+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7d80330), hold(0) freeze(0)
06-06 23:44:28.091+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7d80330), block(1)
06-06 23:44:28.091+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7d80330), ev->cur.canvas.x(220) ev->cur.canvas.y(196)
06-06 23:44:28.091+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7d80330), hold(0) freeze(0)
06-06 23:44:28.091+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7d80330), block(1)
06-06 23:44:28.091+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7d80330), ev->cur.canvas.x(223) ev->cur.canvas.y(192)
06-06 23:44:28.091+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7d80330), hold(0) freeze(0)
06-06 23:44:28.091+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b7d80330), locked_x(0)
06-06 23:44:28.091+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b7d80330)
06-06 23:44:28.101+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7d80330), block(1)
06-06 23:44:28.101+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7d80330), ev->cur.canvas.x(225) ev->cur.canvas.y(188)
06-06 23:44:28.101+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7d80330), hold(0) freeze(0)
06-06 23:44:28.101+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b7d80330), locked_x(0)
06-06 23:44:28.101+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b7d80330)
06-06 23:44:28.121+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7d80330), block(1)
06-06 23:44:28.121+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7d80330), ev->cur.canvas.x(227) ev->cur.canvas.y(185)
06-06 23:44:28.121+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7d80330), hold(0) freeze(0)
06-06 23:44:28.121+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7d80330), block(1)
06-06 23:44:28.121+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7d80330), ev->cur.canvas.x(229) ev->cur.canvas.y(182)
06-06 23:44:28.121+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7d80330), hold(0) freeze(0)
06-06 23:44:28.121+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b7d80330), locked_x(0)
06-06 23:44:28.121+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b7d80330)
06-06 23:44:28.141+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7d80330), block(1)
06-06 23:44:28.141+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7d80330), ev->cur.canvas.x(231) ev->cur.canvas.y(179)
06-06 23:44:28.141+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7d80330), hold(0) freeze(0)
06-06 23:44:28.141+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b7d80330), locked_x(0)
06-06 23:44:28.141+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b7d80330)
06-06 23:44:28.151+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7d80330), block(1)
06-06 23:44:28.151+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7d80330), ev->cur.canvas.x(234) ev->cur.canvas.y(178)
06-06 23:44:28.151+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7d80330), hold(0) freeze(0)
06-06 23:44:28.151+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7d80330), block(1)
06-06 23:44:28.151+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7d80330), ev->cur.canvas.x(237) ev->cur.canvas.y(176)
06-06 23:44:28.151+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7d80330), hold(0) freeze(0)
06-06 23:44:28.151+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b7d80330), locked_x(0)
06-06 23:44:28.151+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b7d80330)
06-06 23:44:28.171+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7d80330), block(1)
06-06 23:44:28.171+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7d80330), ev->cur.canvas.x(239) ev->cur.canvas.y(175)
06-06 23:44:28.171+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7d80330), hold(0) freeze(0)
06-06 23:44:28.171+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b7d80330), locked_x(0)
06-06 23:44:28.171+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b7d80330)
06-06 23:44:28.191+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7d80330), block(1)
06-06 23:44:28.191+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7d80330), ev->cur.canvas.x(241) ev->cur.canvas.y(172)
06-06 23:44:28.191+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7d80330), hold(0) freeze(0)
06-06 23:44:28.191+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7d80330), block(1)
06-06 23:44:28.191+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7d80330), ev->cur.canvas.x(249) ev->cur.canvas.y(171)
06-06 23:44:28.191+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7d80330), hold(0) freeze(0)
06-06 23:44:28.191+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b7d80330), locked_x(0)
06-06 23:44:28.191+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b7d80330)
06-06 23:44:28.201+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7d80330), block(1)
06-06 23:44:28.201+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7d80330), ev->cur.canvas.x(258) ev->cur.canvas.y(170)
06-06 23:44:28.201+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7d80330), hold(0) freeze(0)
06-06 23:44:28.201+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b7d80330), locked_x(0)
06-06 23:44:28.201+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b7d80330)
06-06 23:44:28.221+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7d80330), block(1)
06-06 23:44:28.221+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7d80330), ev->cur.canvas.x(263) ev->cur.canvas.y(169)
06-06 23:44:28.221+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7d80330), hold(0) freeze(0)
06-06 23:44:28.221+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7d80330), block(1)
06-06 23:44:28.221+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7d80330), ev->cur.canvas.x(265) ev->cur.canvas.y(169)
06-06 23:44:28.221+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7d80330), hold(0) freeze(0)
06-06 23:44:28.221+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b7d80330), locked_x(0)
06-06 23:44:28.221+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b7d80330)
06-06 23:44:28.221+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b7d80330), locked_x(0)
06-06 23:44:28.221+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b7d80330), locked_x(0)
06-06 23:44:28.221+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7d80330), block(1)
06-06 23:44:28.221+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7d80330), ev->cur.canvas.x(269) ev->cur.canvas.y(169)
06-06 23:44:28.221+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7d80330), hold(0) freeze(0)
06-06 23:44:28.241+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7d80330), block(1)
06-06 23:44:28.241+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7d80330), ev->cur.canvas.x(269) ev->cur.canvas.y(168)
06-06 23:44:28.241+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7d80330), hold(0) freeze(0)
06-06 23:44:28.241+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b7d80330), locked_x(0)
06-06 23:44:28.241+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b7d80330)
06-06 23:44:28.251+0900 E/EFL     ( 3024): evas_main<3024> evas_events.c:1275 evas_event_feed_mouse_up() ButtonEvent:up time=22817990 button=1 downs=0
06-06 23:44:28.251+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:2278 _elm_scroll_post_event_up() [DDO] lock set false. : obj(b7d80330), type(elm_genlist)
06-06 23:44:28.671+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7d80330), block(1)
06-06 23:44:28.671+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7d80330), ev->cur.canvas.x(235) ev->cur.canvas.y(176)
06-06 23:44:28.671+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7d80330), hold(0) freeze(0)
06-06 23:44:28.681+0900 E/EFL     ( 3024): evas_main<3024> evas_events.c:1009 evas_event_feed_mouse_down() ButtonEvent:down time=22818418 button=1 downs=1
06-06 23:44:28.681+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7d80330), block(1)
06-06 23:44:28.681+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7d80330), ev->cur.canvas.x(229) ev->cur.canvas.y(176)
06-06 23:44:28.681+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7d80330), hold(0) freeze(0)
06-06 23:44:28.701+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7d80330), block(1)
06-06 23:44:28.701+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7d80330), ev->cur.canvas.x(226) ev->cur.canvas.y(176)
06-06 23:44:28.701+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7d80330), hold(0) freeze(0)
06-06 23:44:28.751+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7d80330), block(1)
06-06 23:44:28.751+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7d80330), ev->cur.canvas.x(227) ev->cur.canvas.y(177)
06-06 23:44:28.751+0900 E/EFL     ( 3024): elementary<3024> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7d80330), hold(0) freeze(0)
06-06 23:44:28.771+0900 E/EFL     ( 3024): evas_main<3024> evas_events.c:1275 evas_event_feed_mouse_up() ButtonEvent:up time=22818505 button=1 downs=0
06-06 23:44:28.971+0900 W/CRASH_MANAGER( 3367): worker.c: worker_job(1199) > 1103024756963146522426
