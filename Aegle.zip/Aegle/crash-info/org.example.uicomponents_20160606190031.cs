S/W Version Information
Model: SM-R735S
Tizen-Version: 2.3.1.2
Build-Number: R735SKSU1AOKE
Build-Date: 2015.11.25 20:46:58

Crash Information
Process Name: uicomponents
PID: 18611
Date: 2016-06-06 19:00:31+0900
Executable File Path: /opt/usr/apps/org.example.uicomponents/bin/uicomponents
Signal: 11
      (SIGSEGV)
      si_code: -6
      signal sent by tkill (sent by pid 18611, uid 5000)

Register Information
r0   = 0x71737723, r1   = 0x71737723
r2   = 0x00000001, r3   = 0x00000000
r4   = 0x71737723, r5   = 0xb6f399f8
r6   = 0xb8c03198, r7   = 0xbebfe3e8
r8   = 0xb6ced9c0, r9   = 0xb8b0be88
r10  = 0xb6f31e9c, fp   = 0x00000000
ip   = 0xb6f33428, sp   = 0xbebfe2d0
lr   = 0xb6ee032d, pc   = 0xb6d29bde
cpsr = 0xa0000030

Memory Information
MemTotal:   407572 KB
MemFree:     14524 KB
Buffers:     11604 KB
Cached:      91620 KB
VmPeak:      79604 KB
VmSize:      77440 KB
VmLck:           0 KB
VmPin:           0 KB
VmHWM:       20924 KB
VmRSS:       20924 KB
VmData:      17460 KB
VmStk:         136 KB
VmExe:          20 KB
VmLib:       24848 KB
VmPTE:          56 KB
VmSwap:          0 KB

Threads Information
Threads: 2
PID = 18611 TID = 18611
18611 18710 

Maps Information
b2909000 b2919000 r-xp /usr/lib/scim-1.0/1.4.0/IMEngine/socket.so
b2921000 b2925000 r-xp /usr/lib/libogg.so.0.7.1
b292d000 b294f000 r-xp /usr/lib/libvorbis.so.0.4.3
b2957000 b295f000 r-xp /usr/lib/libmdm-common.so.1.0.89
b2960000 b29a3000 r-xp /usr/lib/libsndfile.so.1.0.25
b29b0000 b29f8000 r-xp /usr/lib/pulseaudio/libpulsecommon-4.0.so
b29f9000 b29fe000 r-xp /usr/lib/libjson.so.0.0.1
b2a06000 b2a37000 r-xp /usr/lib/libmdm.so.1.1.85
b2a3f000 b2a47000 r-xp /usr/lib/lib_DNSe_NRSS_ver225.so
b2a56000 b2a66000 r-xp /usr/lib/lib_SamsungRec_TizenV04014.so
b2a87000 b2a94000 r-xp /usr/lib/libail.so.0.1.0
b2a9d000 b2aa0000 r-xp /usr/lib/libsyspopup_caller.so.0.1.0
b2aa8000 b2ae0000 r-xp /usr/lib/libpulse.so.0.16.2
b2ae1000 b2b42000 r-xp /usr/lib/libasound.so.2.0.0
b2b4c000 b2b4f000 r-xp /usr/lib/libpulse-simple.so.0.0.4
b2b57000 b2b5c000 r-xp /usr/lib/libascenario-0.2.so.0.0.0
b2b64000 b2b7d000 r-xp /usr/lib/libavsysaudio.so.0.0.1
b2b86000 b2b8a000 r-xp /usr/lib/libmmfsoundcommon.so.0.0.0
b2b93000 b2b9d000 r-xp /usr/lib/libaudio-session-mgr.so.0.0.0
b2ba9000 b2bae000 r-xp /usr/lib/libmmfsession.so.0.0.0
b2bb6000 b2bcc000 r-xp /usr/lib/libmmfsound.so.0.1.0
b2bde000 b2be5000 r-xp /usr/lib/libmmfcommon.so.0.0.0
b2bed000 b2bf7000 r-xp /usr/lib/libcapi-media-sound-manager.so.0.1.48
b2bff000 b2c01000 r-xp /usr/lib/libcapi-media-wav-player.so.0.1.10
b2c09000 b2c0a000 r-xp /usr/lib/libmmfkeysound.so.0.0.0
b2c12000 b2c19000 r-xp /usr/lib/libfeedback.so.0.1.4
b2c24000 b2c29000 r-xp /usr/lib/scim-1.0/1.4.0/Config/socket.so
b2c38000 b2c39000 r-xp /usr/lib/edje/modules/feedback/linux-gnueabi-armv7l-1.0.0/module.so
b2c41000 b2cc8000 rw-s anon_inode:dmabuf
b2cc8000 b2d4f000 rw-s anon_inode:dmabuf
b2dda000 b2e61000 rw-s anon_inode:dmabuf
b2ee0000 b2f67000 rw-s anon_inode:dmabuf
b3204000 b3a03000 rwxp [stack:18710]
b3a03000 b3a1a000 r-xp /usr/lib/edje/modules/elm/linux-gnueabi-armv7l-1.0.0/module.so
b3a27000 b3a29000 r-xp /usr/lib/libgenlock.so
b3a32000 b3a33000 r-xp /usr/lib/evas/modules/loaders/eet/linux-gnueabi-armv7l-1.7.99/module.so
b3a3b000 b3a3d000 r-xp /usr/lib/evas/modules/loaders/png/linux-gnueabi-armv7l-1.7.99/module.so
b3a47000 b3a4c000 r-xp /usr/lib/bufmgr/libtbm_msm.so.0.0.0
b3a54000 b3a5f000 r-xp /usr/lib/evas/modules/engines/software_generic/linux-gnueabi-armv7l-1.7.99/module.so
b3d87000 b3e51000 r-xp /usr/lib/libCOREGL.so.4.0
b3e62000 b3e67000 r-xp /usr/lib/libcapi-media-tool.so.0.1.5
b3e6f000 b3e90000 r-xp /usr/lib/libexif.so.12.3.3
b3ea3000 b3ea8000 r-xp /usr/lib/libmmutil_imgp.so.0.0.0
b3eb0000 b3eb5000 r-xp /usr/lib/libmmutil_jpeg.so.0.0.0
b5444000 b5446000 r-xp /usr/lib/libdri2.so.0.0.0
b544e000 b5456000 r-xp /usr/lib/libdrm.so.2.4.0
b545e000 b5461000 r-xp /usr/lib/libcapi-media-image-util.so.0.3.5
b5469000 b554d000 r-xp /usr/lib/libicuuc.so.51.1
b5562000 b569f000 r-xp /usr/lib/libicui18n.so.51.1
b56af000 b56b4000 r-xp /usr/lib/libcapi-system-info.so.0.2.0
b56bc000 b56c2000 r-xp /usr/lib/libxcb-render.so.0.0.0
b56ca000 b56cb000 r-xp /usr/lib/libxcb-shm.so.0.0.0
b56d4000 b56d7000 r-xp /usr/lib/libEGL.so.1.4
b56df000 b56ed000 r-xp /usr/lib/libGLESv2.so.2.0
b56f6000 b56fd000 r-xp /usr/lib/libtbm.so.1.0.0
b5705000 b5726000 r-xp /usr/lib/libui-extension.so.0.1.0
b572f000 b5741000 r-xp /usr/lib/libtts.so
b5749000 b5801000 r-xp /usr/lib/libcairo.so.2.11200.14
b580c000 b581e000 r-xp /usr/lib/libefl-assist.so.0.1.0
b5826000 b5847000 r-xp /usr/lib/libefl-extension.so.0.1.0
b584f000 b5862000 r-xp /opt/usr/apps/org.example.uicomponents/bin/uicomponents
b5a29000 b5a33000 r-xp /lib/libnss_files-2.13.so
b5a3c000 b5b0b000 r-xp /usr/lib/libscim-1.0.so.8.2.3
b5b21000 b5b45000 r-xp /usr/lib/ecore/immodules/libisf-imf-module.so
b5b4e000 b5b54000 r-xp /usr/lib/libappsvc.so.0.1.0
b5b5c000 b5b5e000 r-xp /usr/lib/libcapi-appfw-app-common.so.0.3.2.5
b5b67000 b5b6c000 r-xp /usr/lib/libcapi-appfw-app-control.so.0.3.2.5
b5b77000 b5b82000 r-xp /usr/lib/evas/modules/engines/software_x11/linux-gnueabi-armv7l-1.7.99/module.so
b5b8a000 b5b8c000 r-xp /usr/lib/libiniparser.so.0
b5b95000 b5b9a000 r-xp /usr/lib/libappcore-common.so.1.1
b5ba3000 b5bab000 r-xp /usr/lib/libcapi-system-system-settings.so.0.0.2
b5bac000 b5bb0000 r-xp /usr/lib/libcapi-appfw-application.so.0.3.2.5
b5bbd000 b5bbf000 r-xp /usr/lib/libXau.so.6.0.0
b5bc8000 b5bcf000 r-xp /lib/libcrypt-2.13.so
b5bff000 b5c01000 r-xp /usr/lib/libiri.so
b5c09000 b5db1000 r-xp /usr/lib/libcrypto.so.1.0.0
b5dca000 b5e17000 r-xp /usr/lib/libssl.so.1.0.0
b5e24000 b5e52000 r-xp /usr/lib/libidn.so.11.5.44
b5e5a000 b5e63000 r-xp /usr/lib/libcares.so.2.1.0
b5e6c000 b5e7f000 r-xp /usr/lib/libxcb.so.1.1.0
b5e88000 b5e8a000 r-xp /usr/lib/journal/libjournal.so.0.1.0
b5e93000 b5e95000 r-xp /usr/lib/libSLP-db-util.so.0.1.0
b5e9e000 b5f6a000 r-xp /usr/lib/libxml2.so.2.7.8
b5f77000 b5f79000 r-xp /usr/lib/libgmodule-2.0.so.0.3200.3
b5f81000 b5f86000 r-xp /usr/lib/libffi.so.5.0.10
b5f8e000 b5f8f000 r-xp /usr/lib/libgthread-2.0.so.0.3200.3
b5f98000 b5fa3000 r-xp /usr/lib/libgpg-error.so.0.15.0
b5fab000 b5fae000 r-xp /lib/libattr.so.1.1.0
b5fb6000 b604a000 r-xp /usr/lib/libstdc++.so.6.0.16
b605d000 b6079000 r-xp /usr/lib/libsecurity-server-commons.so.1.0.0
b6082000 b609a000 r-xp /usr/lib/libpng12.so.0.50.0
b60a3000 b60b9000 r-xp /lib/libexpat.so.1.5.2
b60c3000 b6107000 r-xp /usr/lib/libcurl.so.4.3.0
b6110000 b611a000 r-xp /usr/lib/libXext.so.6.4.0
b6123000 b6126000 r-xp /usr/lib/libXtst.so.6.1.0
b612f000 b6135000 r-xp /usr/lib/libXrender.so.1.3.0
b613e000 b6144000 r-xp /usr/lib/libXrandr.so.2.2.0
b614c000 b614d000 r-xp /usr/lib/libXinerama.so.1.0.0
b6156000 b615f000 r-xp /usr/lib/libXi.so.6.1.0
b6167000 b616a000 r-xp /usr/lib/libXfixes.so.3.1.0
b6172000 b6174000 r-xp /usr/lib/libXgesture.so.7.0.0
b617c000 b617e000 r-xp /usr/lib/libXcomposite.so.1.0.0
b6187000 b6189000 r-xp /usr/lib/libXdamage.so.1.1.0
b6191000 b6198000 r-xp /usr/lib/libXcursor.so.1.0.2
b61a0000 b61a3000 r-xp /usr/lib/libecore_input_evas.so.1.7.99
b61ab000 b61af000 r-xp /usr/lib/libecore_ipc.so.1.7.99
b61b8000 b61bd000 r-xp /usr/lib/libecore_fb.so.1.7.99
b61c7000 b62a8000 r-xp /usr/lib/libX11.so.6.3.0
b62b3000 b62d6000 r-xp /usr/lib/libjpeg.so.8.0.2
b62ee000 b6304000 r-xp /lib/libz.so.1.2.5
b630c000 b6381000 r-xp /usr/lib/libsqlite3.so.0.8.6
b638b000 b63a0000 r-xp /usr/lib/libpkgmgr_parser.so.0.1.0
b63a9000 b63dd000 r-xp /usr/lib/libgobject-2.0.so.0.3200.3
b63e6000 b64b9000 r-xp /usr/lib/libgio-2.0.so.0.3200.3
b64c4000 b64d4000 r-xp /lib/libresolv-2.13.so
b64d8000 b6554000 r-xp /usr/lib/libgcrypt.so.20.0.3
b6560000 b6578000 r-xp /usr/lib/liblzma.so.5.0.3
b6581000 b6584000 r-xp /lib/libcap.so.2.21
b658c000 b65b2000 r-xp /usr/lib/libsecurity-server-client.so.1.0.1
b65bb000 b65bc000 r-xp /usr/lib/libecore_imf_evas.so.1.7.99
b65c4000 b65ca000 r-xp /usr/lib/libecore_imf.so.1.7.99
b65d2000 b65e9000 r-xp /usr/lib/liblua-5.1.so
b65f3000 b65fa000 r-xp /usr/lib/libembryo.so.1.7.99
b6602000 b6608000 r-xp /lib/librt-2.13.so
b6611000 b6667000 r-xp /usr/lib/libpixman-1.so.0.28.2
b6674000 b66ca000 r-xp /usr/lib/libfreetype.so.6.11.3
b66d6000 b66fe000 r-xp /usr/lib/libfontconfig.so.1.8.0
b6700000 b673d000 r-xp /usr/lib/libharfbuzz.so.0.940.0
b6746000 b6759000 r-xp /usr/lib/libfribidi.so.0.3.1
b6761000 b677b000 r-xp /usr/lib/libecore_con.so.1.7.99
b6784000 b678d000 r-xp /usr/lib/libedbus.so.1.7.99
b6795000 b67e5000 r-xp /usr/lib/libecore_x.so.1.7.99
b67e8000 b67ec000 r-xp /usr/lib/libvconf.so.0.2.45
b67f4000 b6805000 r-xp /usr/lib/libecore_input.so.1.7.99
b680d000 b6812000 r-xp /usr/lib/libecore_file.so.1.7.99
b681a000 b683c000 r-xp /usr/lib/libecore_evas.so.1.7.99
b6845000 b6886000 r-xp /usr/lib/libeina.so.1.7.99
b688f000 b68a8000 r-xp /usr/lib/libeet.so.1.7.99
b68b9000 b6922000 r-xp /lib/libm-2.13.so
b692b000 b6931000 r-xp /usr/lib/libcapi-base-common.so.0.1.8
b693a000 b693d000 r-xp /usr/lib/libproc-stat.so.0.2.86
b6945000 b6967000 r-xp /usr/lib/libpkgmgr-info.so.0.0.17
b696f000 b6974000 r-xp /usr/lib/libxdgmime.so.1.1.0
b697c000 b69a6000 r-xp /usr/lib/libdbus-1.so.3.8.12
b69af000 b69c6000 r-xp /usr/lib/libdbus-glib-1.so.2.2.2
b69ce000 b69d9000 r-xp /lib/libunwind.so.8.0.1
b6a06000 b6a42000 r-xp /usr/lib/libsystemd.so.0.4.0
b6a4b000 b6b66000 r-xp /lib/libc-2.13.so
b6b74000 b6b7c000 r-xp /lib/libgcc_s-4.6.so.1
b6b7d000 b6b80000 r-xp /usr/lib/libsmack.so.1.0.0
b6b88000 b6b8e000 r-xp /usr/lib/libprivilege-control.so.0.0.2
b6b96000 b6c66000 r-xp /usr/lib/libglib-2.0.so.0.3200.3
b6c67000 b6cc4000 r-xp /usr/lib/libedje.so.1.7.99
b6cce000 b6ce5000 r-xp /usr/lib/libecore.so.1.7.99
b6cfc000 b6dcb000 r-xp /usr/lib/libevas.so.1.7.99
b6def000 b6f29000 r-xp /usr/lib/libelementary.so.1.7.99
b6f3f000 b6f53000 r-xp /lib/libpthread-2.13.so
b6f5e000 b6f60000 r-xp /usr/lib/libdlog.so.0.0.0
b6f68000 b6f6b000 r-xp /usr/lib/libbundle.so.0.1.22
b6f73000 b6f75000 r-xp /lib/libdl-2.13.so
b6f7e000 b6f8a000 r-xp /usr/lib/libaul.so.0.1.0
b6f9c000 b6fa1000 r-xp /usr/lib/libappcore-efl.so.1.1
b6faa000 b6fae000 r-xp /usr/lib/libsys-assert.so
b6fb7000 b6fd4000 r-xp /lib/ld-2.13.so
b6fdd000 b6fe2000 r-xp /usr/bin/launchpad-loader
b8ad4000 b8eb3000 rw-p [heap]
bebde000 bebff000 rwxp [stack]
End of Maps Information

Callstack Information (PID:18611)
Call Stack Count: 4
 0: evas_object_evas_get + 0x5 (0xb6d29bde) [/usr/lib/libevas.so.1] + 0x2dbde
 1: elm_widget_add + 0xc (0xb6ee032d) [/usr/lib/libelementary.so.1] + 0xf132d
 2: elm_genlist_add + 0x28 (0xb6e7b0bd) [/usr/lib/libelementary.so.1] + 0x8c0bd
 3: _single_line_entry_cb1 + 0x200 (0xb5854c19) [/opt/usr/apps/org.example.uicomponents/bin/uicomponents] + 0x5c19
End of Call Stack

Package Information
Package Name: org.example.uicomponents
Package ID : org.example.uicomponents
Version: 1.0.0
Package Type: rpm
App Name: uicomponents
App ID: org.example.uicomponents
Type: capp
Categories: 

Latest Debug Message Information
--------- beginning of /dev/log_main
0+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b8d42ec8)
06-06 19:00:23.350+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d42ec8), block(1)
06-06 19:00:23.350+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d42ec8), ev->cur.canvas.x(112) ev->cur.canvas.y(223)
06-06 19:00:23.350+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d42ec8), hold(0) freeze(0)
06-06 19:00:23.350+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d42ec8), block(1)
06-06 19:00:23.350+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d42ec8), ev->cur.canvas.x(110) ev->cur.canvas.y(219)
06-06 19:00:23.350+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d42ec8), hold(0) freeze(0)
06-06 19:00:23.350+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b8d42ec8), locked_x(0)
06-06 19:00:23.350+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3843 _elm_scroll_hold_animator() [DDO] obj(b8d42ec8)
06-06 19:00:23.350+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b8d42ec8)
06-06 19:00:23.370+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d42ec8), block(1)
06-06 19:00:23.370+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d42ec8), ev->cur.canvas.x(110) ev->cur.canvas.y(215)
06-06 19:00:23.370+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d42ec8), hold(0) freeze(0)
06-06 19:00:23.370+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d42ec8), block(1)
06-06 19:00:23.370+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d42ec8), ev->cur.canvas.x(110) ev->cur.canvas.y(208)
06-06 19:00:23.370+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d42ec8), hold(0) freeze(0)
06-06 19:00:23.370+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b8d42ec8), locked_x(0)
06-06 19:00:23.370+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3843 _elm_scroll_hold_animator() [DDO] obj(b8d42ec8)
06-06 19:00:23.370+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b8d42ec8)
06-06 19:00:23.390+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d42ec8), block(1)
06-06 19:00:23.390+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d42ec8), ev->cur.canvas.x(110) ev->cur.canvas.y(205)
06-06 19:00:23.390+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d42ec8), hold(0) freeze(0)
06-06 19:00:23.400+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d42ec8), block(1)
06-06 19:00:23.400+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d42ec8), ev->cur.canvas.x(108) ev->cur.canvas.y(202)
06-06 19:00:23.400+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d42ec8), hold(0) freeze(0)
06-06 19:00:23.400+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b8d42ec8), locked_x(0)
06-06 19:00:23.400+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3843 _elm_scroll_hold_animator() [DDO] obj(b8d42ec8)
06-06 19:00:23.400+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b8d42ec8)
06-06 19:00:23.420+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d42ec8), block(1)
06-06 19:00:23.420+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d42ec8), ev->cur.canvas.x(102) ev->cur.canvas.y(200)
06-06 19:00:23.420+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d42ec8), hold(0) freeze(0)
06-06 19:00:23.420+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d42ec8), block(1)
06-06 19:00:23.420+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d42ec8), ev->cur.canvas.x(93) ev->cur.canvas.y(200)
06-06 19:00:23.420+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d42ec8), hold(0) freeze(0)
06-06 19:00:23.420+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b8d42ec8), locked_x(0)
06-06 19:00:23.420+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3843 _elm_scroll_hold_animator() [DDO] obj(b8d42ec8)
06-06 19:00:23.420+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b8d42ec8)
06-06 19:00:23.440+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d42ec8), block(1)
06-06 19:00:23.440+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d42ec8), ev->cur.canvas.x(86) ev->cur.canvas.y(197)
06-06 19:00:23.440+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d42ec8), hold(0) freeze(0)
06-06 19:00:23.440+0900 E/EFL     (18611): evas_main<18611> evas_events.c:1275 evas_event_feed_mouse_up() ButtonEvent:up time=11217509 button=1 downs=0
06-06 19:00:23.440+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:2278 _elm_scroll_post_event_up() [DDO] lock set false. : obj(b8d42ec8), type(elm_genlist)
06-06 19:00:26.570+0900 I/efl-extension(18611): efl_extension_rotary.c: _object_deleted_cb(572) > In: data: 0xb8d42ec8, obj: 0xb8d42ec8
06-06 19:00:26.570+0900 I/efl-extension(18611): efl_extension_rotary.c: _object_deleted_cb(601) > done
06-06 19:00:26.580+0900 I/efl-extension(18611): efl_extension_rotary.c: _activated_obj_del_cb(607) > _activated_obj_del_cb : 0xb8cb3988
06-06 19:00:26.580+0900 I/efl-extension(18611): efl_extension_rotary.c: eext_rotary_object_event_callback_del(235) > In
06-06 19:00:26.580+0900 I/efl-extension(18611): efl_extension_rotary.c: eext_rotary_object_event_callback_del(240) > callback del 0xb8d42ec8, elm_genlist, func : 0xb5834079
06-06 19:00:26.580+0900 I/efl-extension(18611): efl_extension_rotary.c: eext_rotary_object_event_callback_del(273) > done
06-06 19:00:26.810+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8cd3400), block(1)
06-06 19:00:26.810+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8cd3400), ev->cur.canvas.x(271) ev->cur.canvas.y(242)
06-06 19:00:26.810+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8cd3400), hold(0) freeze(0)
06-06 19:00:26.810+0900 E/EFL     (18611): evas_main<18611> evas_events.c:1009 evas_event_feed_mouse_down() ButtonEvent:down time=11220886 button=1 downs=1
06-06 19:00:26.820+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8cd3400), block(1)
06-06 19:00:26.820+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8cd3400), ev->cur.canvas.x(271) ev->cur.canvas.y(239)
06-06 19:00:26.820+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8cd3400), hold(0) freeze(0)
06-06 19:00:26.830+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8cd3400), block(1)
06-06 19:00:26.830+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8cd3400), ev->cur.canvas.x(271) ev->cur.canvas.y(232)
06-06 19:00:26.830+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8cd3400), hold(0) freeze(0)
06-06 19:00:26.840+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8cd3400), block(1)
06-06 19:00:26.840+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8cd3400), ev->cur.canvas.x(270) ev->cur.canvas.y(225)
06-06 19:00:26.840+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8cd3400), hold(0) freeze(0)
06-06 19:00:26.850+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8cd3400), block(1)
06-06 19:00:26.850+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8cd3400), ev->cur.canvas.x(267) ev->cur.canvas.y(220)
06-06 19:00:26.850+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8cd3400), hold(0) freeze(0)
06-06 19:00:26.860+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8cd3400), block(1)
06-06 19:00:26.860+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8cd3400), ev->cur.canvas.x(264) ev->cur.canvas.y(215)
06-06 19:00:26.860+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8cd3400), hold(0) freeze(0)
06-06 19:00:26.880+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8cd3400), block(1)
06-06 19:00:26.880+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8cd3400), ev->cur.canvas.x(262) ev->cur.canvas.y(209)
06-06 19:00:26.880+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8cd3400), hold(0) freeze(0)
06-06 19:00:26.890+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8cd3400), block(1)
06-06 19:00:26.890+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8cd3400), ev->cur.canvas.x(261) ev->cur.canvas.y(203)
06-06 19:00:26.890+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8cd3400), hold(0) freeze(0)
06-06 19:00:26.890+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:4249 _elm_scroll_mouse_move_event_cb() [DDO] animator
06-06 19:00:26.890+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3353 _elm_scroll_post_event_move() [DDO] obj(b8cd3400), type(elm_genlist)
06-06 19:00:26.890+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3354 _elm_scroll_post_event_move() [DDO] hold_parent(0)
06-06 19:00:26.890+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3405 _elm_scroll_post_event_move() [DDO] elm_widget_drag_lock_y_set : obj(b8cd3400), type(elm_genlist)
06-06 19:00:26.900+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8cd3400), block(1)
06-06 19:00:26.900+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8cd3400), ev->cur.canvas.x(261) ev->cur.canvas.y(196)
06-06 19:00:26.900+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8cd3400), hold(0) freeze(0)
06-06 19:00:26.900+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b8cd3400), locked_x(0)
06-06 19:00:26.900+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b8cd3400)
06-06 19:00:26.920+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8cd3400), block(1)
06-06 19:00:26.920+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8cd3400), ev->cur.canvas.x(265) ev->cur.canvas.y(187)
06-06 19:00:26.920+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8cd3400), hold(0) freeze(0)
06-06 19:00:26.920+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8cd3400), block(1)
06-06 19:00:26.920+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8cd3400), ev->cur.canvas.x(269) ev->cur.canvas.y(180)
06-06 19:00:26.920+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8cd3400), hold(0) freeze(0)
06-06 19:00:26.930+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b8cd3400), locked_x(0)
06-06 19:00:26.930+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b8cd3400)
06-06 19:00:26.950+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8cd3400), block(1)
06-06 19:00:26.950+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8cd3400), ev->cur.canvas.x(274) ev->cur.canvas.y(171)
06-06 19:00:26.950+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8cd3400), hold(0) freeze(0)
06-06 19:00:26.950+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8cd3400), block(1)
06-06 19:00:26.950+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8cd3400), ev->cur.canvas.x(279) ev->cur.canvas.y(159)
06-06 19:00:26.950+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8cd3400), hold(0) freeze(0)
06-06 19:00:26.950+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8cd3400), block(1)
06-06 19:00:26.950+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8cd3400), ev->cur.canvas.x(279) ev->cur.canvas.y(154)
06-06 19:00:26.950+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8cd3400), hold(0) freeze(0)
06-06 19:00:26.950+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b8cd3400), locked_x(0)
06-06 19:00:26.950+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b8cd3400)
06-06 19:00:26.960+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8cd3400), block(1)
06-06 19:00:26.960+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8cd3400), ev->cur.canvas.x(280) ev->cur.canvas.y(152)
06-06 19:00:26.960+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8cd3400), hold(0) freeze(0)
06-06 19:00:26.960+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b8cd3400), locked_x(0)
06-06 19:00:26.960+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b8cd3400)
06-06 19:00:26.980+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8cd3400), block(1)
06-06 19:00:26.980+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8cd3400), ev->cur.canvas.x(280) ev->cur.canvas.y(148)
06-06 19:00:26.980+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8cd3400), hold(0) freeze(0)
06-06 19:00:26.980+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b8cd3400), locked_x(0)
06-06 19:00:26.980+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b8cd3400)
06-06 19:00:26.990+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8cd3400), block(1)
06-06 19:00:26.990+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8cd3400), ev->cur.canvas.x(280) ev->cur.canvas.y(146)
06-06 19:00:26.990+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8cd3400), hold(0) freeze(0)
06-06 19:00:26.990+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8cd3400), block(1)
06-06 19:00:26.990+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8cd3400), ev->cur.canvas.x(280) ev->cur.canvas.y(139)
06-06 19:00:26.990+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8cd3400), hold(0) freeze(0)
06-06 19:00:26.990+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b8cd3400), locked_x(0)
06-06 19:00:26.990+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b8cd3400)
06-06 19:00:27.010+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8cd3400), block(1)
06-06 19:00:27.010+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8cd3400), ev->cur.canvas.x(280) ev->cur.canvas.y(133)
06-06 19:00:27.010+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8cd3400), hold(0) freeze(0)
06-06 19:00:27.010+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b8cd3400), locked_x(0)
06-06 19:00:27.010+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b8cd3400)
06-06 19:00:27.020+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8cd3400), block(1)
06-06 19:00:27.020+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8cd3400), ev->cur.canvas.x(280) ev->cur.canvas.y(131)
06-06 19:00:27.020+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8cd3400), hold(0) freeze(0)
06-06 19:00:27.020+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b8cd3400), locked_x(0)
06-06 19:00:27.020+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b8cd3400)
06-06 19:00:27.040+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8cd3400), block(1)
06-06 19:00:27.040+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8cd3400), ev->cur.canvas.x(280) ev->cur.canvas.y(129)
06-06 19:00:27.040+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8cd3400), hold(0) freeze(0)
06-06 19:00:27.040+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8cd3400), block(1)
06-06 19:00:27.040+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8cd3400), ev->cur.canvas.x(283) ev->cur.canvas.y(125)
06-06 19:00:27.040+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8cd3400), hold(0) freeze(0)
06-06 19:00:27.040+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b8cd3400), locked_x(0)
06-06 19:00:27.040+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b8cd3400)
06-06 19:00:27.060+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8cd3400), block(1)
06-06 19:00:27.060+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8cd3400), ev->cur.canvas.x(285) ev->cur.canvas.y(117)
06-06 19:00:27.060+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8cd3400), hold(0) freeze(0)
06-06 19:00:27.060+0900 E/EFL     (18611): evas_main<18611> evas_events.c:1275 evas_event_feed_mouse_up() ButtonEvent:up time=11221129 button=1 downs=0
06-06 19:00:27.060+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:2278 _elm_scroll_post_event_up() [DDO] lock set false. : obj(b8cd3400), type(elm_genlist)
06-06 19:00:27.470+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8cd3400), block(1)
06-06 19:00:27.470+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8cd3400), ev->cur.canvas.x(231) ev->cur.canvas.y(198)
06-06 19:00:27.470+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8cd3400), hold(0) freeze(0)
06-06 19:00:27.470+0900 E/EFL     (18611): evas_main<18611> evas_events.c:1009 evas_event_feed_mouse_down() ButtonEvent:down time=11221534 button=1 downs=1
06-06 19:00:27.470+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8cd3400), block(1)
06-06 19:00:27.470+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8cd3400), ev->cur.canvas.x(230) ev->cur.canvas.y(195)
06-06 19:00:27.470+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8cd3400), hold(0) freeze(0)
06-06 19:00:27.490+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8cd3400), block(1)
06-06 19:00:27.490+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8cd3400), ev->cur.canvas.x(230) ev->cur.canvas.y(193)
06-06 19:00:27.490+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8cd3400), hold(0) freeze(0)
06-06 19:00:27.490+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8cd3400), block(1)
06-06 19:00:27.490+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8cd3400), ev->cur.canvas.x(230) ev->cur.canvas.y(192)
06-06 19:00:27.490+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8cd3400), hold(0) freeze(0)
06-06 19:00:27.530+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8cd3400), block(1)
06-06 19:00:27.530+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8cd3400), ev->cur.canvas.x(228) ev->cur.canvas.y(192)
06-06 19:00:27.530+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8cd3400), hold(0) freeze(0)
06-06 19:00:27.530+0900 E/EFL     (18611): evas_main<18611> evas_events.c:1275 evas_event_feed_mouse_up() ButtonEvent:up time=11221600 button=1 downs=0
06-06 19:00:27.560+0900 I/efl-extension(18611): efl_extension_rotary.c: eext_rotary_object_event_callback_add(147) > In
06-06 19:00:27.560+0900 I/efl-extension(18611): efl_extension_rotary.c: eext_rotary_object_event_activated_set(283) > eext_rotary_object_event_activated_set : 0xb8d68600, elm_image, _activated_obj : 0x0, activated : 1
06-06 19:00:28.650+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d42d48), block(1)
06-06 19:00:28.650+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d42d48), ev->cur.canvas.x(243) ev->cur.canvas.y(180)
06-06 19:00:28.650+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d42d48), hold(0) freeze(0)
06-06 19:00:28.650+0900 E/EFL     (18611): evas_main<18611> evas_events.c:1009 evas_event_feed_mouse_down() ButtonEvent:down time=11222718 button=1 downs=1
06-06 19:00:28.670+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d42d48), block(1)
06-06 19:00:28.670+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d42d48), ev->cur.canvas.x(242) ev->cur.canvas.y(181)
06-06 19:00:28.670+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d42d48), hold(0) freeze(0)
06-06 19:00:28.700+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d42d48), block(1)
06-06 19:00:28.700+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d42d48), ev->cur.canvas.x(241) ev->cur.canvas.y(181)
06-06 19:00:28.700+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d42d48), hold(0) freeze(0)
06-06 19:00:28.700+0900 E/EFL     (18611): evas_main<18611> evas_events.c:1275 evas_event_feed_mouse_up() ButtonEvent:up time=11222759 button=1 downs=0
06-06 19:00:29.810+0900 E/EFL     (18611): evas_main<18611> evas_events.c:1009 evas_event_feed_mouse_down() ButtonEvent:down time=11223875 button=1 downs=1
06-06 19:00:29.870+0900 E/EFL     (18611): evas_main<18611> evas_events.c:1275 evas_event_feed_mouse_up() ButtonEvent:up time=11223940 button=1 downs=0
06-06 19:00:30.300+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d42d48), block(1)
06-06 19:00:30.300+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d42d48), ev->cur.canvas.x(238) ev->cur.canvas.y(253)
06-06 19:00:30.300+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d42d48), hold(0) freeze(0)
06-06 19:00:30.310+0900 E/EFL     (18611): evas_main<18611> evas_events.c:1009 evas_event_feed_mouse_down() ButtonEvent:down time=11224379 button=1 downs=1
06-06 19:00:30.320+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d42d48), block(1)
06-06 19:00:30.320+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d42d48), ev->cur.canvas.x(235) ev->cur.canvas.y(253)
06-06 19:00:30.320+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d42d48), hold(0) freeze(0)
06-06 19:00:30.330+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d42d48), block(1)
06-06 19:00:30.330+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d42d48), ev->cur.canvas.x(234) ev->cur.canvas.y(249)
06-06 19:00:30.330+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d42d48), hold(0) freeze(0)
06-06 19:00:30.340+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d42d48), block(1)
06-06 19:00:30.340+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d42d48), ev->cur.canvas.x(234) ev->cur.canvas.y(239)
06-06 19:00:30.340+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d42d48), hold(0) freeze(0)
06-06 19:00:30.350+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d42d48), block(1)
06-06 19:00:30.350+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d42d48), ev->cur.canvas.x(237) ev->cur.canvas.y(230)
06-06 19:00:30.350+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d42d48), hold(0) freeze(0)
06-06 19:00:30.370+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d42d48), block(1)
06-06 19:00:30.370+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d42d48), ev->cur.canvas.x(241) ev->cur.canvas.y(216)
06-06 19:00:30.370+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d42d48), hold(0) freeze(0)
06-06 19:00:30.370+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:4249 _elm_scroll_mouse_move_event_cb() [DDO] animator
06-06 19:00:30.370+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3353 _elm_scroll_post_event_move() [DDO] obj(b8d42d48), type(elm_genlist)
06-06 19:00:30.370+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3354 _elm_scroll_post_event_move() [DDO] hold_parent(0)
06-06 19:00:30.370+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3405 _elm_scroll_post_event_move() [DDO] elm_widget_drag_lock_y_set : obj(b8d42d48), type(elm_genlist)
06-06 19:00:30.380+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d42d48), block(1)
06-06 19:00:30.380+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d42d48), ev->cur.canvas.x(246) ev->cur.canvas.y(197)
06-06 19:00:30.380+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d42d48), hold(0) freeze(0)
06-06 19:00:30.380+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b8d42d48), locked_x(0)
06-06 19:00:30.380+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b8d42d48)
06-06 19:00:30.410+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d42d48), block(1)
06-06 19:00:30.410+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d42d48), ev->cur.canvas.x(251) ev->cur.canvas.y(183)
06-06 19:00:30.410+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d42d48), hold(0) freeze(0)
06-06 19:00:30.410+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d42d48), block(1)
06-06 19:00:30.410+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d42d48), ev->cur.canvas.x(256) ev->cur.canvas.y(166)
06-06 19:00:30.410+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d42d48), hold(0) freeze(0)
06-06 19:00:30.410+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d42d48), block(1)
06-06 19:00:30.410+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d42d48), ev->cur.canvas.x(262) ev->cur.canvas.y(156)
06-06 19:00:30.410+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d42d48), hold(0) freeze(0)
06-06 19:00:30.410+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b8d42d48), locked_x(0)
06-06 19:00:30.410+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b8d42d48)
06-06 19:00:30.440+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d42d48), block(1)
06-06 19:00:30.440+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d42d48), ev->cur.canvas.x(266) ev->cur.canvas.y(145)
06-06 19:00:30.440+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d42d48), hold(0) freeze(0)
06-06 19:00:30.440+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d42d48), block(1)
06-06 19:00:30.440+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d42d48), ev->cur.canvas.x(268) ev->cur.canvas.y(133)
06-06 19:00:30.440+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d42d48), hold(0) freeze(0)
06-06 19:00:30.440+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d42d48), block(1)
06-06 19:00:30.440+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d42d48), ev->cur.canvas.x(268) ev->cur.canvas.y(130)
06-06 19:00:30.440+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d42d48), hold(0) freeze(0)
06-06 19:00:30.450+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b8d42d48), locked_x(0)
06-06 19:00:30.450+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b8d42d48)
06-06 19:00:30.470+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d42d48), block(1)
06-06 19:00:30.470+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d42d48), ev->cur.canvas.x(268) ev->cur.canvas.y(127)
06-06 19:00:30.470+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d42d48), hold(0) freeze(0)
06-06 19:00:30.470+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d42d48), block(1)
06-06 19:00:30.470+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d42d48), ev->cur.canvas.x(268) ev->cur.canvas.y(126)
06-06 19:00:30.470+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d42d48), hold(0) freeze(0)
06-06 19:00:30.470+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d42d48), block(1)
06-06 19:00:30.470+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d42d48), ev->cur.canvas.x(268) ev->cur.canvas.y(125)
06-06 19:00:30.470+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d42d48), hold(0) freeze(0)
06-06 19:00:30.470+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b8d42d48), locked_x(0)
06-06 19:00:30.470+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b8d42d48)
06-06 19:00:30.490+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d42d48), block(1)
06-06 19:00:30.490+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d42d48), ev->cur.canvas.x(268) ev->cur.canvas.y(119)
06-06 19:00:30.490+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d42d48), hold(0) freeze(0)
06-06 19:00:30.490+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d42d48), block(1)
06-06 19:00:30.490+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d42d48), ev->cur.canvas.x(268) ev->cur.canvas.y(114)
06-06 19:00:30.490+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d42d48), hold(0) freeze(0)
06-06 19:00:30.490+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b8d42d48), locked_x(0)
06-06 19:00:30.500+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b8d42d48)
06-06 19:00:30.520+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d42d48), block(1)
06-06 19:00:30.520+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d42d48), ev->cur.canvas.x(268) ev->cur.canvas.y(112)
06-06 19:00:30.520+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d42d48), hold(0) freeze(0)
06-06 19:00:30.520+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d42d48), block(1)
06-06 19:00:30.520+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d42d48), ev->cur.canvas.x(268) ev->cur.canvas.y(111)
06-06 19:00:30.520+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d42d48), hold(0) freeze(0)
06-06 19:00:30.520+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b8d42d48), locked_x(0)
06-06 19:00:30.520+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b8d42d48)
06-06 19:00:30.540+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d42d48), block(1)
06-06 19:00:30.540+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d42d48), ev->cur.canvas.x(268) ev->cur.canvas.y(110)
06-06 19:00:30.540+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d42d48), hold(0) freeze(0)
06-06 19:00:30.540+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b8d42d48), locked_x(0)
06-06 19:00:30.540+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b8d42d48)
06-06 19:00:30.560+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d42d48), block(1)
06-06 19:00:30.560+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d42d48), ev->cur.canvas.x(268) ev->cur.canvas.y(109)
06-06 19:00:30.560+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d42d48), hold(0) freeze(0)
06-06 19:00:30.560+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b8d42d48), locked_x(0)
06-06 19:00:30.560+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b8d42d48)
06-06 19:00:30.580+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d42d48), block(1)
06-06 19:00:30.580+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d42d48), ev->cur.canvas.x(268) ev->cur.canvas.y(108)
06-06 19:00:30.580+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d42d48), hold(0) freeze(0)
06-06 19:00:30.580+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d42d48), block(1)
06-06 19:00:30.580+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d42d48), ev->cur.canvas.x(269) ev->cur.canvas.y(108)
06-06 19:00:30.580+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d42d48), hold(0) freeze(0)
06-06 19:00:30.580+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b8d42d48), locked_x(0)
06-06 19:00:30.580+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b8d42d48)
06-06 19:00:30.580+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b8d42d48), locked_x(0)
06-06 19:00:30.580+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b8d42d48), locked_x(0)
06-06 19:00:30.580+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b8d42d48), locked_x(0)
06-06 19:00:30.580+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b8d42d48), locked_x(0)
06-06 19:00:30.590+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d42d48), block(1)
06-06 19:00:30.590+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d42d48), ev->cur.canvas.x(272) ev->cur.canvas.y(109)
06-06 19:00:30.590+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d42d48), hold(0) freeze(0)
06-06 19:00:30.590+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b8d42d48), locked_x(0)
06-06 19:00:30.590+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b8d42d48)
06-06 19:00:30.610+0900 E/EFL     (18611): evas_main<18611> evas_events.c:1275 evas_event_feed_mouse_up() ButtonEvent:up time=11224671 button=1 downs=0
06-06 19:00:30.610+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:2278 _elm_scroll_post_event_up() [DDO] lock set false. : obj(b8d42d48), type(elm_genlist)
06-06 19:00:30.970+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d42d48), block(1)
06-06 19:00:30.970+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d42d48), ev->cur.canvas.x(227) ev->cur.canvas.y(180)
06-06 19:00:30.970+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d42d48), hold(0) freeze(0)
06-06 19:00:30.970+0900 E/EFL     (18611): evas_main<18611> evas_events.c:1009 evas_event_feed_mouse_down() ButtonEvent:down time=11225040 button=1 downs=1
06-06 19:00:30.990+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d42d48), block(1)
06-06 19:00:30.990+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d42d48), ev->cur.canvas.x(228) ev->cur.canvas.y(181)
06-06 19:00:30.990+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d42d48), hold(0) freeze(0)
06-06 19:00:31.000+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d42d48), block(1)
06-06 19:00:31.000+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d42d48), ev->cur.canvas.x(228) ev->cur.canvas.y(182)
06-06 19:00:31.000+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d42d48), hold(0) freeze(0)
06-06 19:00:31.030+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d42d48), block(1)
06-06 19:00:31.030+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d42d48), ev->cur.canvas.x(227) ev->cur.canvas.y(182)
06-06 19:00:31.030+0900 E/EFL     (18611): elementary<18611> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8d42d48), hold(0) freeze(0)
06-06 19:00:31.030+0900 E/EFL     (18611): evas_main<18611> evas_events.c:1275 evas_event_feed_mouse_up() ButtonEvent:up time=11225104 button=1 downs=0
06-06 19:00:31.150+0900 E/EFL     (18611): edje<18611> edje_util.c:3770 edje_object_size_min_restricted_calc() group entry_layout has a non-fixed part 'entry_part'. Adding 'fixed: 1 1;' to source EDC may help. Continuing discarding faulty part.
06-06 19:00:31.170+0900 E/EFL     (18611): edje<18611> edje_util.c:3770 edje_object_size_min_restricted_calc() group entry_layout has a non-fixed part 'entry_part'. Adding 'fixed: 1 1;' to source EDC may help. Continuing discarding faulty part.
06-06 19:00:31.310+0900 W/CRASH_MANAGER(18648): worker.c: worker_job(1199) > 1118611756963146520723
