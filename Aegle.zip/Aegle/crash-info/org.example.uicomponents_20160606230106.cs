S/W Version Information
Model: SM-R735S
Tizen-Version: 2.3.1.2
Build-Number: R735SKSU1AOKE
Build-Date: 2015.11.25 20:46:58

Crash Information
Process Name: uicomponents
PID: 2521
Date: 2016-06-06 23:01:06+0900
Executable File Path: /opt/usr/apps/org.example.uicomponents/bin/uicomponents
Signal: 11
      (SIGSEGV)
      si_code: -6
      signal sent by tkill (sent by pid 2521, uid 5000)

Register Information
r0   = 0x000000a8, r1   = 0xb7882ee8
r2   = 0xb57b6ff9, r3   = 0x00000000
r4   = 0x000000a8, r5   = 0xb782ae70
r6   = 0xb57b6ff9, r7   = 0xb787b930
r8   = 0x000000a8, r9   = 0x00000001
r10  = 0xb785f730, fp   = 0xb57b6ff9
ip   = 0xb6c23d80, sp   = 0xbecc8218
lr   = 0xb6c0b6d5, pc   = 0xb67c0c0a
cpsr = 0x20000030

Memory Information
MemTotal:   407572 KB
MemFree:     16372 KB
Buffers:     12084 KB
Cached:      88428 KB
VmPeak:      78120 KB
VmSize:      75956 KB
VmLck:           0 KB
VmPin:           0 KB
VmHWM:       20308 KB
VmRSS:       20308 KB
VmData:      15976 KB
VmStk:         136 KB
VmExe:          20 KB
VmLib:       24848 KB
VmPTE:          58 KB
VmSwap:          0 KB

Threads Information
Threads: 2
PID = 2521 TID = 2521
2521 2728 

Maps Information
b2923000 b2933000 r-xp /usr/lib/scim-1.0/1.4.0/IMEngine/socket.so
b293b000 b293f000 r-xp /usr/lib/libogg.so.0.7.1
b2947000 b2969000 r-xp /usr/lib/libvorbis.so.0.4.3
b2971000 b2979000 r-xp /usr/lib/libmdm-common.so.1.0.89
b297a000 b29bd000 r-xp /usr/lib/libsndfile.so.1.0.25
b29ca000 b2a12000 r-xp /usr/lib/pulseaudio/libpulsecommon-4.0.so
b2a13000 b2a18000 r-xp /usr/lib/libjson.so.0.0.1
b2a20000 b2a51000 r-xp /usr/lib/libmdm.so.1.1.85
b2a59000 b2a61000 r-xp /usr/lib/lib_DNSe_NRSS_ver225.so
b2a70000 b2a80000 r-xp /usr/lib/lib_SamsungRec_TizenV04014.so
b2aa1000 b2aae000 r-xp /usr/lib/libail.so.0.1.0
b2ab7000 b2aba000 r-xp /usr/lib/libsyspopup_caller.so.0.1.0
b2ac2000 b2afa000 r-xp /usr/lib/libpulse.so.0.16.2
b2afb000 b2b5c000 r-xp /usr/lib/libasound.so.2.0.0
b2b66000 b2b69000 r-xp /usr/lib/libpulse-simple.so.0.0.4
b2b71000 b2b76000 r-xp /usr/lib/libascenario-0.2.so.0.0.0
b2b7e000 b2b97000 r-xp /usr/lib/libavsysaudio.so.0.0.1
b2ba0000 b2ba4000 r-xp /usr/lib/libmmfsoundcommon.so.0.0.0
b2bad000 b2bb7000 r-xp /usr/lib/libaudio-session-mgr.so.0.0.0
b2bc3000 b2bc8000 r-xp /usr/lib/libmmfsession.so.0.0.0
b2bd0000 b2be6000 r-xp /usr/lib/libmmfsound.so.0.1.0
b2bf8000 b2bff000 r-xp /usr/lib/libmmfcommon.so.0.0.0
b2c07000 b2c11000 r-xp /usr/lib/libcapi-media-sound-manager.so.0.1.48
b2c19000 b2c1b000 r-xp /usr/lib/libcapi-media-wav-player.so.0.1.10
b2c23000 b2c24000 r-xp /usr/lib/libmmfkeysound.so.0.0.0
b2c2c000 b2c33000 r-xp /usr/lib/libfeedback.so.0.1.4
b2c3e000 b2c43000 r-xp /usr/lib/scim-1.0/1.4.0/Config/socket.so
b2c52000 b2c53000 r-xp /usr/lib/edje/modules/feedback/linux-gnueabi-armv7l-1.0.0/module.so
b2c5b000 b2ce2000 rw-s anon_inode:dmabuf
b2ce2000 b2d69000 rw-s anon_inode:dmabuf
b2df4000 b2e7b000 rw-s anon_inode:dmabuf
b2efa000 b2f81000 rw-s anon_inode:dmabuf
b315b000 b395a000 rwxp [stack:2728]
b395a000 b3971000 r-xp /usr/lib/edje/modules/elm/linux-gnueabi-armv7l-1.0.0/module.so
b397e000 b3980000 r-xp /usr/lib/libgenlock.so
b3989000 b398a000 r-xp /usr/lib/evas/modules/loaders/eet/linux-gnueabi-armv7l-1.7.99/module.so
b3992000 b3994000 r-xp /usr/lib/evas/modules/loaders/png/linux-gnueabi-armv7l-1.7.99/module.so
b399e000 b39a3000 r-xp /usr/lib/bufmgr/libtbm_msm.so.0.0.0
b39ab000 b39b6000 r-xp /usr/lib/evas/modules/engines/software_generic/linux-gnueabi-armv7l-1.7.99/module.so
b3cde000 b3da8000 r-xp /usr/lib/libCOREGL.so.4.0
b3db9000 b3dbe000 r-xp /usr/lib/libcapi-media-tool.so.0.1.5
b3dc6000 b3de7000 r-xp /usr/lib/libexif.so.12.3.3
b3dfa000 b3dff000 r-xp /usr/lib/libmmutil_imgp.so.0.0.0
b3e07000 b3e0c000 r-xp /usr/lib/libmmutil_jpeg.so.0.0.0
b539b000 b539d000 r-xp /usr/lib/libdri2.so.0.0.0
b53a5000 b53ad000 r-xp /usr/lib/libdrm.so.2.4.0
b53b5000 b53b8000 r-xp /usr/lib/libcapi-media-image-util.so.0.3.5
b53c0000 b54a4000 r-xp /usr/lib/libicuuc.so.51.1
b54b9000 b55f6000 r-xp /usr/lib/libicui18n.so.51.1
b5606000 b560b000 r-xp /usr/lib/libcapi-system-info.so.0.2.0
b5613000 b5619000 r-xp /usr/lib/libxcb-render.so.0.0.0
b5621000 b5622000 r-xp /usr/lib/libxcb-shm.so.0.0.0
b562b000 b562e000 r-xp /usr/lib/libEGL.so.1.4
b5636000 b5644000 r-xp /usr/lib/libGLESv2.so.2.0
b564d000 b5654000 r-xp /usr/lib/libtbm.so.1.0.0
b565c000 b567d000 r-xp /usr/lib/libui-extension.so.0.1.0
b5686000 b5698000 r-xp /usr/lib/libtts.so
b56a0000 b5758000 r-xp /usr/lib/libcairo.so.2.11200.14
b5763000 b5775000 r-xp /usr/lib/libefl-assist.so.0.1.0
b577d000 b579e000 r-xp /usr/lib/libefl-extension.so.0.1.0
b57a6000 b57b9000 r-xp /opt/usr/apps/org.example.uicomponents/bin/uicomponents
b5980000 b598a000 r-xp /lib/libnss_files-2.13.so
b5993000 b5a62000 r-xp /usr/lib/libscim-1.0.so.8.2.3
b5a78000 b5a9c000 r-xp /usr/lib/ecore/immodules/libisf-imf-module.so
b5aa5000 b5aab000 r-xp /usr/lib/libappsvc.so.0.1.0
b5ab3000 b5ab5000 r-xp /usr/lib/libcapi-appfw-app-common.so.0.3.2.5
b5abe000 b5ac3000 r-xp /usr/lib/libcapi-appfw-app-control.so.0.3.2.5
b5ace000 b5ad9000 r-xp /usr/lib/evas/modules/engines/software_x11/linux-gnueabi-armv7l-1.7.99/module.so
b5ae1000 b5ae3000 r-xp /usr/lib/libiniparser.so.0
b5aec000 b5af1000 r-xp /usr/lib/libappcore-common.so.1.1
b5afa000 b5b02000 r-xp /usr/lib/libcapi-system-system-settings.so.0.0.2
b5b03000 b5b07000 r-xp /usr/lib/libcapi-appfw-application.so.0.3.2.5
b5b14000 b5b16000 r-xp /usr/lib/libXau.so.6.0.0
b5b1f000 b5b26000 r-xp /lib/libcrypt-2.13.so
b5b56000 b5b58000 r-xp /usr/lib/libiri.so
b5b60000 b5d08000 r-xp /usr/lib/libcrypto.so.1.0.0
b5d21000 b5d6e000 r-xp /usr/lib/libssl.so.1.0.0
b5d7b000 b5da9000 r-xp /usr/lib/libidn.so.11.5.44
b5db1000 b5dba000 r-xp /usr/lib/libcares.so.2.1.0
b5dc3000 b5dd6000 r-xp /usr/lib/libxcb.so.1.1.0
b5ddf000 b5de1000 r-xp /usr/lib/journal/libjournal.so.0.1.0
b5dea000 b5dec000 r-xp /usr/lib/libSLP-db-util.so.0.1.0
b5df5000 b5ec1000 r-xp /usr/lib/libxml2.so.2.7.8
b5ece000 b5ed0000 r-xp /usr/lib/libgmodule-2.0.so.0.3200.3
b5ed8000 b5edd000 r-xp /usr/lib/libffi.so.5.0.10
b5ee5000 b5ee6000 r-xp /usr/lib/libgthread-2.0.so.0.3200.3
b5eef000 b5efa000 r-xp /usr/lib/libgpg-error.so.0.15.0
b5f02000 b5f05000 r-xp /lib/libattr.so.1.1.0
b5f0d000 b5fa1000 r-xp /usr/lib/libstdc++.so.6.0.16
b5fb4000 b5fd0000 r-xp /usr/lib/libsecurity-server-commons.so.1.0.0
b5fd9000 b5ff1000 r-xp /usr/lib/libpng12.so.0.50.0
b5ffa000 b6010000 r-xp /lib/libexpat.so.1.5.2
b601a000 b605e000 r-xp /usr/lib/libcurl.so.4.3.0
b6067000 b6071000 r-xp /usr/lib/libXext.so.6.4.0
b607a000 b607d000 r-xp /usr/lib/libXtst.so.6.1.0
b6086000 b608c000 r-xp /usr/lib/libXrender.so.1.3.0
b6095000 b609b000 r-xp /usr/lib/libXrandr.so.2.2.0
b60a3000 b60a4000 r-xp /usr/lib/libXinerama.so.1.0.0
b60ad000 b60b6000 r-xp /usr/lib/libXi.so.6.1.0
b60be000 b60c1000 r-xp /usr/lib/libXfixes.so.3.1.0
b60c9000 b60cb000 r-xp /usr/lib/libXgesture.so.7.0.0
b60d3000 b60d5000 r-xp /usr/lib/libXcomposite.so.1.0.0
b60de000 b60e0000 r-xp /usr/lib/libXdamage.so.1.1.0
b60e8000 b60ef000 r-xp /usr/lib/libXcursor.so.1.0.2
b60f7000 b60fa000 r-xp /usr/lib/libecore_input_evas.so.1.7.99
b6102000 b6106000 r-xp /usr/lib/libecore_ipc.so.1.7.99
b610f000 b6114000 r-xp /usr/lib/libecore_fb.so.1.7.99
b611e000 b61ff000 r-xp /usr/lib/libX11.so.6.3.0
b620a000 b622d000 r-xp /usr/lib/libjpeg.so.8.0.2
b6245000 b625b000 r-xp /lib/libz.so.1.2.5
b6263000 b62d8000 r-xp /usr/lib/libsqlite3.so.0.8.6
b62e2000 b62f7000 r-xp /usr/lib/libpkgmgr_parser.so.0.1.0
b6300000 b6334000 r-xp /usr/lib/libgobject-2.0.so.0.3200.3
b633d000 b6410000 r-xp /usr/lib/libgio-2.0.so.0.3200.3
b641b000 b642b000 r-xp /lib/libresolv-2.13.so
b642f000 b64ab000 r-xp /usr/lib/libgcrypt.so.20.0.3
b64b7000 b64cf000 r-xp /usr/lib/liblzma.so.5.0.3
b64d8000 b64db000 r-xp /lib/libcap.so.2.21
b64e3000 b6509000 r-xp /usr/lib/libsecurity-server-client.so.1.0.1
b6512000 b6513000 r-xp /usr/lib/libecore_imf_evas.so.1.7.99
b651b000 b6521000 r-xp /usr/lib/libecore_imf.so.1.7.99
b6529000 b6540000 r-xp /usr/lib/liblua-5.1.so
b654a000 b6551000 r-xp /usr/lib/libembryo.so.1.7.99
b6559000 b655f000 r-xp /lib/librt-2.13.so
b6568000 b65be000 r-xp /usr/lib/libpixman-1.so.0.28.2
b65cb000 b6621000 r-xp /usr/lib/libfreetype.so.6.11.3
b662d000 b6655000 r-xp /usr/lib/libfontconfig.so.1.8.0
b6657000 b6694000 r-xp /usr/lib/libharfbuzz.so.0.940.0
b669d000 b66b0000 r-xp /usr/lib/libfribidi.so.0.3.1
b66b8000 b66d2000 r-xp /usr/lib/libecore_con.so.1.7.99
b66db000 b66e4000 r-xp /usr/lib/libedbus.so.1.7.99
b66ec000 b673c000 r-xp /usr/lib/libecore_x.so.1.7.99
b673f000 b6743000 r-xp /usr/lib/libvconf.so.0.2.45
b674b000 b675c000 r-xp /usr/lib/libecore_input.so.1.7.99
b6764000 b6769000 r-xp /usr/lib/libecore_file.so.1.7.99
b6771000 b6793000 r-xp /usr/lib/libecore_evas.so.1.7.99
b679c000 b67dd000 r-xp /usr/lib/libeina.so.1.7.99
b67e6000 b67ff000 r-xp /usr/lib/libeet.so.1.7.99
b6810000 b6879000 r-xp /lib/libm-2.13.so
b6882000 b6888000 r-xp /usr/lib/libcapi-base-common.so.0.1.8
b6891000 b6894000 r-xp /usr/lib/libproc-stat.so.0.2.86
b689c000 b68be000 r-xp /usr/lib/libpkgmgr-info.so.0.0.17
b68c6000 b68cb000 r-xp /usr/lib/libxdgmime.so.1.1.0
b68d3000 b68fd000 r-xp /usr/lib/libdbus-1.so.3.8.12
b6906000 b691d000 r-xp /usr/lib/libdbus-glib-1.so.2.2.2
b6925000 b6930000 r-xp /lib/libunwind.so.8.0.1
b695d000 b6999000 r-xp /usr/lib/libsystemd.so.0.4.0
b69a2000 b6abd000 r-xp /lib/libc-2.13.so
b6acb000 b6ad3000 r-xp /lib/libgcc_s-4.6.so.1
b6ad4000 b6ad7000 r-xp /usr/lib/libsmack.so.1.0.0
b6adf000 b6ae5000 r-xp /usr/lib/libprivilege-control.so.0.0.2
b6aed000 b6bbd000 r-xp /usr/lib/libglib-2.0.so.0.3200.3
b6bbe000 b6c1b000 r-xp /usr/lib/libedje.so.1.7.99
b6c25000 b6c3c000 r-xp /usr/lib/libecore.so.1.7.99
b6c53000 b6d22000 r-xp /usr/lib/libevas.so.1.7.99
b6d46000 b6e80000 r-xp /usr/lib/libelementary.so.1.7.99
b6e96000 b6eaa000 r-xp /lib/libpthread-2.13.so
b6eb5000 b6eb7000 r-xp /usr/lib/libdlog.so.0.0.0
b6ebf000 b6ec2000 r-xp /usr/lib/libbundle.so.0.1.22
b6eca000 b6ecc000 r-xp /lib/libdl-2.13.so
b6ed5000 b6ee1000 r-xp /usr/lib/libaul.so.0.1.0
b6ef3000 b6ef8000 r-xp /usr/lib/libappcore-efl.so.1.1
b6f01000 b6f05000 r-xp /usr/lib/libsys-assert.so
b6f0e000 b6f2b000 r-xp /lib/ld-2.13.so
b6f34000 b6f39000 r-xp /usr/bin/launchpad-loader
b75bd000 b78ed000 rw-p [heap]
beca8000 becc9000 rwxp [stack]
End of Maps Information

Callstack Information (PID:2521)
Call Stack Count: 1
 0: eina_stringshare_add + 0x5 (0xb67c0c0a) [/usr/lib/libeina.so.1] + 0x24c0a
End of Call Stack

Package Information
Package Name: org.example.uicomponents
Package ID : org.example.uicomponents
Version: 1.0.0
Package Type: rpm
App Name: uicomponents
App ID: org.example.uicomponents
Type: capp
Categories: 

Latest Debug Message Information
--------- beginning of /dev/log_main
9 _elm_scroll_mouse_move_event_cb() [DDO] obj(b77a2760), ev->cur.canvas.x(92) ev->cur.canvas.y(264)
06-06 23:00:59.499+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b77a2760), hold(0) freeze(0)
06-06 23:00:59.519+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b77a2760), locked_x(0)
06-06 23:00:59.519+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b77a2760)
06-06 23:00:59.549+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b77a2760), block(1)
06-06 23:00:59.549+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b77a2760), ev->cur.canvas.x(92) ev->cur.canvas.y(263)
06-06 23:00:59.549+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b77a2760), hold(0) freeze(0)
06-06 23:00:59.549+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b77a2760), block(1)
06-06 23:00:59.549+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b77a2760), ev->cur.canvas.x(91) ev->cur.canvas.y(259)
06-06 23:00:59.549+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b77a2760), hold(0) freeze(0)
06-06 23:00:59.549+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b77a2760), block(1)
06-06 23:00:59.549+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b77a2760), ev->cur.canvas.x(90) ev->cur.canvas.y(254)
06-06 23:00:59.549+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b77a2760), hold(0) freeze(0)
06-06 23:00:59.549+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b77a2760), block(1)
06-06 23:00:59.549+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b77a2760), ev->cur.canvas.x(89) ev->cur.canvas.y(249)
06-06 23:00:59.549+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b77a2760), hold(0) freeze(0)
06-06 23:00:59.549+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b77a2760), locked_x(0)
06-06 23:00:59.549+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b77a2760)
06-06 23:00:59.589+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b77a2760), block(1)
06-06 23:00:59.589+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b77a2760), ev->cur.canvas.x(87) ev->cur.canvas.y(245)
06-06 23:00:59.589+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b77a2760), hold(0) freeze(0)
06-06 23:00:59.589+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b77a2760), block(1)
06-06 23:00:59.589+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b77a2760), ev->cur.canvas.x(87) ev->cur.canvas.y(240)
06-06 23:00:59.589+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b77a2760), hold(0) freeze(0)
06-06 23:00:59.589+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b77a2760), block(1)
06-06 23:00:59.589+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b77a2760), ev->cur.canvas.x(99) ev->cur.canvas.y(240)
06-06 23:00:59.589+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b77a2760), hold(0) freeze(0)
06-06 23:00:59.589+0900 E/EFL     ( 2521): evas_main<2521> evas_events.c:1275 evas_event_feed_mouse_up() ButtonEvent:up time=21435334 button=1 downs=0
06-06 23:00:59.589+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:2278 _elm_scroll_post_event_up() [DDO] lock set false. : obj(b77a2760), type(elm_genlist)
06-06 23:01:00.089+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b77a2760), block(1)
06-06 23:01:00.089+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b77a2760), ev->cur.canvas.x(159) ev->cur.canvas.y(186)
06-06 23:01:00.089+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b77a2760), hold(0) freeze(0)
06-06 23:01:00.089+0900 E/EFL     ( 2521): evas_main<2521> evas_events.c:1009 evas_event_feed_mouse_down() ButtonEvent:down time=21435830 button=1 downs=1
06-06 23:01:00.139+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b77a2760), block(1)
06-06 23:01:00.139+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b77a2760), ev->cur.canvas.x(161) ev->cur.canvas.y(187)
06-06 23:01:00.139+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b77a2760), hold(0) freeze(0)
06-06 23:01:00.139+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b77a2760), block(1)
06-06 23:01:00.139+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b77a2760), ev->cur.canvas.x(163) ev->cur.canvas.y(188)
06-06 23:01:00.139+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b77a2760), hold(0) freeze(0)
06-06 23:01:00.139+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b77a2760), block(1)
06-06 23:01:00.139+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b77a2760), ev->cur.canvas.x(164) ev->cur.canvas.y(189)
06-06 23:01:00.139+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b77a2760), hold(0) freeze(0)
06-06 23:01:00.169+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b77a2760), block(1)
06-06 23:01:00.169+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b77a2760), ev->cur.canvas.x(165) ev->cur.canvas.y(191)
06-06 23:01:00.169+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b77a2760), hold(0) freeze(0)
06-06 23:01:00.169+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b77a2760), block(1)
06-06 23:01:00.169+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b77a2760), ev->cur.canvas.x(166) ev->cur.canvas.y(192)
06-06 23:01:00.169+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b77a2760), hold(0) freeze(0)
06-06 23:01:00.179+0900 I/RESOURCED(  906): logging.c: logging_send_signal_to_data(1097) > [logging_send_signal_to_data,1097] send signal to logging data thread
06-06 23:01:00.179+0900 I/RESOURCED(  906): logging.c: logging_send_signal_to_update(1177) > [logging_send_signal_to_update,1177] send signal to logging update thread
06-06 23:01:00.209+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b77a2760), block(1)
06-06 23:01:00.209+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b77a2760), ev->cur.canvas.x(167) ev->cur.canvas.y(193)
06-06 23:01:00.209+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b77a2760), hold(0) freeze(0)
06-06 23:01:00.209+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b77a2760), block(1)
06-06 23:01:00.209+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b77a2760), ev->cur.canvas.x(168) ev->cur.canvas.y(197)
06-06 23:01:00.209+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b77a2760), hold(0) freeze(0)
06-06 23:01:00.209+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b77a2760), block(1)
06-06 23:01:00.209+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b77a2760), ev->cur.canvas.x(168) ev->cur.canvas.y(200)
06-06 23:01:00.209+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b77a2760), hold(0) freeze(0)
06-06 23:01:00.209+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b77a2760), block(1)
06-06 23:01:00.209+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b77a2760), ev->cur.canvas.x(167) ev->cur.canvas.y(204)
06-06 23:01:00.209+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b77a2760), hold(0) freeze(0)
06-06 23:01:00.249+0900 E/EFL     ( 2521): evas_main<2521> evas_events.c:1275 evas_event_feed_mouse_up() ButtonEvent:up time=21435959 button=1 downs=0
06-06 23:01:00.289+0900 I/efl-extension( 2521): efl_extension_rotary.c: eext_rotary_object_event_callback_add(147) > In
06-06 23:01:00.289+0900 I/efl-extension( 2521): efl_extension_rotary.c: eext_rotary_object_event_activated_set(283) > eext_rotary_object_event_activated_set : 0xb7814888, elm_image, _activated_obj : 0xb77ee798, activated : 1
06-06 23:01:00.289+0900 I/efl-extension( 2521): efl_extension_rotary.c: eext_rotary_object_event_activated_set(291) > Activation delete!!!!
06-06 23:01:00.829+0900 E/TIZEN_N_SYSTEM_SETTINGS( 1282): system_settings.c: system_settings_get_value_string(522) > Enter [system_settings_get_value_string]
06-06 23:01:00.829+0900 E/TIZEN_N_SYSTEM_SETTINGS( 1282): system_settings.c: system_settings_get_value(386) > Enter [system_settings_get_value]
06-06 23:01:00.829+0900 E/TIZEN_N_SYSTEM_SETTINGS( 1282): system_settings.c: system_settings_get_item(361) > Enter [system_settings_get_item], key=13
06-06 23:01:00.829+0900 E/TIZEN_N_SYSTEM_SETTINGS( 1282): system_settings.c: system_settings_get_item(374) > Enter [system_settings_get_item], index = 13, key = 13, type = 0
06-06 23:01:01.019+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), block(1)
06-06 23:01:01.019+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), ev->cur.canvas.x(114) ev->cur.canvas.y(279)
06-06 23:01:01.019+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), hold(0) freeze(0)
06-06 23:01:01.029+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), block(1)
06-06 23:01:01.029+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), ev->cur.canvas.x(116) ev->cur.canvas.y(273)
06-06 23:01:01.029+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), hold(0) freeze(0)
06-06 23:01:01.049+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), block(1)
06-06 23:01:01.049+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), ev->cur.canvas.x(116) ev->cur.canvas.y(267)
06-06 23:01:01.049+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), hold(0) freeze(0)
06-06 23:01:01.049+0900 E/EFL     ( 2521): evas_main<2521> evas_events.c:1009 evas_event_feed_mouse_down() ButtonEvent:down time=21436787 button=1 downs=1
06-06 23:01:01.049+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), block(1)
06-06 23:01:01.049+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), ev->cur.canvas.x(116) ev->cur.canvas.y(264)
06-06 23:01:01.049+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), hold(0) freeze(0)
06-06 23:01:01.059+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), block(1)
06-06 23:01:01.059+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), ev->cur.canvas.x(116) ev->cur.canvas.y(263)
06-06 23:01:01.059+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), hold(0) freeze(0)
06-06 23:01:01.079+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), block(1)
06-06 23:01:01.079+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), ev->cur.canvas.x(116) ev->cur.canvas.y(260)
06-06 23:01:01.079+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), hold(0) freeze(0)
06-06 23:01:01.089+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), block(1)
06-06 23:01:01.089+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), ev->cur.canvas.x(116) ev->cur.canvas.y(256)
06-06 23:01:01.089+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), hold(0) freeze(0)
06-06 23:01:01.099+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), block(1)
06-06 23:01:01.099+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), ev->cur.canvas.x(115) ev->cur.canvas.y(254)
06-06 23:01:01.099+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), hold(0) freeze(0)
06-06 23:01:01.109+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), block(1)
06-06 23:01:01.109+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), ev->cur.canvas.x(112) ev->cur.canvas.y(250)
06-06 23:01:01.109+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), hold(0) freeze(0)
06-06 23:01:01.119+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), block(1)
06-06 23:01:01.119+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), ev->cur.canvas.x(110) ev->cur.canvas.y(246)
06-06 23:01:01.119+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), hold(0) freeze(0)
06-06 23:01:01.139+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), block(1)
06-06 23:01:01.139+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), ev->cur.canvas.x(107) ev->cur.canvas.y(243)
06-06 23:01:01.139+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), hold(0) freeze(0)
06-06 23:01:01.149+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), block(1)
06-06 23:01:01.149+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), ev->cur.canvas.x(101) ev->cur.canvas.y(239)
06-06 23:01:01.149+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), hold(0) freeze(0)
06-06 23:01:01.149+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), block(1)
06-06 23:01:01.149+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), ev->cur.canvas.x(98) ev->cur.canvas.y(235)
06-06 23:01:01.149+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), hold(0) freeze(0)
06-06 23:01:01.149+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:4249 _elm_scroll_mouse_move_event_cb() [DDO] animator
06-06 23:01:01.149+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3353 _elm_scroll_post_event_move() [DDO] obj(b7809258), type(elm_genlist)
06-06 23:01:01.149+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3354 _elm_scroll_post_event_move() [DDO] hold_parent(0)
06-06 23:01:01.149+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3382 _elm_scroll_post_event_move() [DDO] elm_widget_drag_lock_x_set : obj(b7809258), type(elm_genlist)
06-06 23:01:01.149+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3405 _elm_scroll_post_event_move() [DDO] elm_widget_drag_lock_y_set : obj(b7809258), type(elm_genlist)
06-06 23:01:01.159+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b7809258), locked_x(0)
06-06 23:01:01.159+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3843 _elm_scroll_hold_animator() [DDO] obj(b7809258)
06-06 23:01:01.159+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b7809258)
06-06 23:01:01.209+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), block(1)
06-06 23:01:01.209+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), ev->cur.canvas.x(95) ev->cur.canvas.y(231)
06-06 23:01:01.209+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), hold(0) freeze(0)
06-06 23:01:01.209+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), block(1)
06-06 23:01:01.209+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), ev->cur.canvas.x(92) ev->cur.canvas.y(227)
06-06 23:01:01.209+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), hold(0) freeze(0)
06-06 23:01:01.209+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), block(1)
06-06 23:01:01.209+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), ev->cur.canvas.x(89) ev->cur.canvas.y(224)
06-06 23:01:01.209+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), hold(0) freeze(0)
06-06 23:01:01.209+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), block(1)
06-06 23:01:01.209+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), ev->cur.canvas.x(87) ev->cur.canvas.y(221)
06-06 23:01:01.209+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), hold(0) freeze(0)
06-06 23:01:01.209+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), block(1)
06-06 23:01:01.209+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), ev->cur.canvas.x(85) ev->cur.canvas.y(216)
06-06 23:01:01.209+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), hold(0) freeze(0)
06-06 23:01:01.209+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b7809258), locked_x(0)
06-06 23:01:01.209+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3843 _elm_scroll_hold_animator() [DDO] obj(b7809258)
06-06 23:01:01.209+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b7809258)
06-06 23:01:01.279+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), block(1)
06-06 23:01:01.279+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), ev->cur.canvas.x(82) ev->cur.canvas.y(207)
06-06 23:01:01.279+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), hold(0) freeze(0)
06-06 23:01:01.279+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), block(1)
06-06 23:01:01.279+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), ev->cur.canvas.x(80) ev->cur.canvas.y(201)
06-06 23:01:01.279+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), hold(0) freeze(0)
06-06 23:01:01.289+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), block(1)
06-06 23:01:01.289+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), ev->cur.canvas.x(78) ev->cur.canvas.y(198)
06-06 23:01:01.289+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), hold(0) freeze(0)
06-06 23:01:01.289+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), block(1)
06-06 23:01:01.289+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), ev->cur.canvas.x(76) ev->cur.canvas.y(195)
06-06 23:01:01.289+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), hold(0) freeze(0)
06-06 23:01:01.289+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), block(1)
06-06 23:01:01.289+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), ev->cur.canvas.x(74) ev->cur.canvas.y(193)
06-06 23:01:01.289+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), hold(0) freeze(0)
06-06 23:01:01.289+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), block(1)
06-06 23:01:01.289+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), ev->cur.canvas.x(73) ev->cur.canvas.y(192)
06-06 23:01:01.289+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), hold(0) freeze(0)
06-06 23:01:01.289+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b7809258), locked_x(0)
06-06 23:01:01.289+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3843 _elm_scroll_hold_animator() [DDO] obj(b7809258)
06-06 23:01:01.289+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b7809258)
06-06 23:01:01.329+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), block(1)
06-06 23:01:01.329+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), ev->cur.canvas.x(72) ev->cur.canvas.y(191)
06-06 23:01:01.329+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), hold(0) freeze(0)
06-06 23:01:01.329+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), block(1)
06-06 23:01:01.329+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), ev->cur.canvas.x(72) ev->cur.canvas.y(190)
06-06 23:01:01.329+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), hold(0) freeze(0)
06-06 23:01:01.329+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), block(1)
06-06 23:01:01.329+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), ev->cur.canvas.x(69) ev->cur.canvas.y(188)
06-06 23:01:01.329+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), hold(0) freeze(0)
06-06 23:01:01.329+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), block(1)
06-06 23:01:01.329+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), ev->cur.canvas.x(68) ev->cur.canvas.y(188)
06-06 23:01:01.329+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), hold(0) freeze(0)
06-06 23:01:01.329+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), block(1)
06-06 23:01:01.329+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), ev->cur.canvas.x(66) ev->cur.canvas.y(184)
06-06 23:01:01.329+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), hold(0) freeze(0)
06-06 23:01:01.339+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b7809258), locked_x(0)
06-06 23:01:01.339+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3843 _elm_scroll_hold_animator() [DDO] obj(b7809258)
06-06 23:01:01.339+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b7809258)
06-06 23:01:01.369+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), block(1)
06-06 23:01:01.369+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), ev->cur.canvas.x(60) ev->cur.canvas.y(179)
06-06 23:01:01.369+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), hold(0) freeze(0)
06-06 23:01:01.369+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), block(1)
06-06 23:01:01.369+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), ev->cur.canvas.x(60) ev->cur.canvas.y(181)
06-06 23:01:01.369+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), hold(0) freeze(0)
06-06 23:01:01.369+0900 E/EFL     ( 2521): evas_main<2521> evas_events.c:1275 evas_event_feed_mouse_up() ButtonEvent:up time=21437100 button=1 downs=0
06-06 23:01:01.369+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:2278 _elm_scroll_post_event_up() [DDO] lock set false. : obj(b7809258), type(elm_genlist)
06-06 23:01:02.479+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), block(1)
06-06 23:01:02.479+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), ev->cur.canvas.x(159) ev->cur.canvas.y(314)
06-06 23:01:02.479+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), hold(0) freeze(0)
06-06 23:01:02.479+0900 E/EFL     ( 2521): evas_main<2521> evas_events.c:1009 evas_event_feed_mouse_down() ButtonEvent:down time=21438217 button=1 downs=1
06-06 23:01:02.559+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), block(1)
06-06 23:01:02.559+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), ev->cur.canvas.x(159) ev->cur.canvas.y(315)
06-06 23:01:02.559+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), hold(0) freeze(0)
06-06 23:01:02.559+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), block(1)
06-06 23:01:02.559+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), ev->cur.canvas.x(160) ev->cur.canvas.y(318)
06-06 23:01:02.559+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), hold(0) freeze(0)
06-06 23:01:02.559+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), block(1)
06-06 23:01:02.559+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), ev->cur.canvas.x(151) ev->cur.canvas.y(318)
06-06 23:01:02.559+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), hold(0) freeze(0)
06-06 23:01:02.579+0900 E/EFL     ( 2521): evas_main<2521> evas_events.c:1275 evas_event_feed_mouse_up() ButtonEvent:up time=21438315 button=1 downs=0
06-06 23:01:02.979+0900 E/EFL     ( 2521): edje<2521> edje_util.c:3770 edje_object_size_min_restricted_calc() group entry_layout has a non-fixed part 'entry_part'. Adding 'fixed: 1 1;' to source EDC may help. Continuing discarding faulty part.
06-06 23:01:02.999+0900 E/EFL     ( 2521): edje<2521> edje_util.c:3770 edje_object_size_min_restricted_calc() group entry_layout has a non-fixed part 'entry_part'. Adding 'fixed: 1 1;' to source EDC may help. Continuing discarding faulty part.
06-06 23:01:03.019+0900 E/EFL     ( 2521): edje<2521> edje_util.c:3770 edje_object_size_min_restricted_calc() group entry_layout has a non-fixed part 'entry_part'. Adding 'fixed: 1 1;' to source EDC may help. Continuing discarding faulty part.
06-06 23:01:05.069+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), block(1)
06-06 23:01:05.069+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), ev->cur.canvas.x(139) ev->cur.canvas.y(114)
06-06 23:01:05.069+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), hold(0) freeze(0)
06-06 23:01:05.069+0900 E/EFL     ( 2521): evas_main<2521> evas_events.c:1009 evas_event_feed_mouse_down() ButtonEvent:down time=21440814 button=1 downs=1
06-06 23:01:05.079+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), block(1)
06-06 23:01:05.079+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), ev->cur.canvas.x(147) ev->cur.canvas.y(122)
06-06 23:01:05.079+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), hold(0) freeze(0)
06-06 23:01:05.099+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), block(1)
06-06 23:01:05.099+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), ev->cur.canvas.x(157) ev->cur.canvas.y(137)
06-06 23:01:05.099+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), hold(0) freeze(0)
06-06 23:01:05.099+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), block(1)
06-06 23:01:05.099+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), ev->cur.canvas.x(163) ev->cur.canvas.y(156)
06-06 23:01:05.099+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), hold(0) freeze(0)
06-06 23:01:05.099+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:4249 _elm_scroll_mouse_move_event_cb() [DDO] animator
06-06 23:01:05.099+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3353 _elm_scroll_post_event_move() [DDO] obj(b7809258), type(elm_genlist)
06-06 23:01:05.099+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3354 _elm_scroll_post_event_move() [DDO] hold_parent(0)
06-06 23:01:05.099+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3382 _elm_scroll_post_event_move() [DDO] elm_widget_drag_lock_x_set : obj(b7809258), type(elm_genlist)
06-06 23:01:05.099+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3405 _elm_scroll_post_event_move() [DDO] elm_widget_drag_lock_y_set : obj(b7809258), type(elm_genlist)
06-06 23:01:05.119+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b7809258), locked_x(0)
06-06 23:01:05.119+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3843 _elm_scroll_hold_animator() [DDO] obj(b7809258)
06-06 23:01:05.119+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b7809258)
06-06 23:01:05.139+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), block(1)
06-06 23:01:05.139+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), ev->cur.canvas.x(170) ev->cur.canvas.y(176)
06-06 23:01:05.139+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), hold(0) freeze(0)
06-06 23:01:05.139+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), block(1)
06-06 23:01:05.139+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), ev->cur.canvas.x(175) ev->cur.canvas.y(195)
06-06 23:01:05.139+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), hold(0) freeze(0)
06-06 23:01:05.139+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), block(1)
06-06 23:01:05.139+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), ev->cur.canvas.x(177) ev->cur.canvas.y(216)
06-06 23:01:05.139+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), hold(0) freeze(0)
06-06 23:01:05.139+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b7809258), locked_x(0)
06-06 23:01:05.139+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3843 _elm_scroll_hold_animator() [DDO] obj(b7809258)
06-06 23:01:05.139+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b7809258)
06-06 23:01:05.199+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), block(1)
06-06 23:01:05.199+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), ev->cur.canvas.x(180) ev->cur.canvas.y(250)
06-06 23:01:05.199+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), hold(0) freeze(0)
06-06 23:01:05.199+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), block(1)
06-06 23:01:05.199+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), ev->cur.canvas.x(184) ev->cur.canvas.y(291)
06-06 23:01:05.199+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), hold(0) freeze(0)
06-06 23:01:05.199+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), block(1)
06-06 23:01:05.199+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), ev->cur.canvas.x(194) ev->cur.canvas.y(311)
06-06 23:01:05.199+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), hold(0) freeze(0)
06-06 23:01:05.199+0900 E/EFL     ( 2521): evas_main<2521> evas_events.c:1275 evas_event_feed_mouse_up() ButtonEvent:up time=21440921 button=1 downs=0
06-06 23:01:05.199+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:2278 _elm_scroll_post_event_up() [DDO] lock set false. : obj(b7809258), type(elm_genlist)
06-06 23:01:06.419+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), block(1)
06-06 23:01:06.419+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), ev->cur.canvas.x(141) ev->cur.canvas.y(180)
06-06 23:01:06.419+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), hold(0) freeze(0)
06-06 23:01:06.419+0900 E/EFL     ( 2521): evas_main<2521> evas_events.c:1009 evas_event_feed_mouse_down() ButtonEvent:down time=21442158 button=1 downs=1
06-06 23:01:06.449+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), block(1)
06-06 23:01:06.449+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), ev->cur.canvas.x(142) ev->cur.canvas.y(180)
06-06 23:01:06.449+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), hold(0) freeze(0)
06-06 23:01:06.469+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), block(1)
06-06 23:01:06.469+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), ev->cur.canvas.x(143) ev->cur.canvas.y(180)
06-06 23:01:06.469+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), hold(0) freeze(0)
06-06 23:01:06.479+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), block(1)
06-06 23:01:06.479+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), ev->cur.canvas.x(141) ev->cur.canvas.y(176)
06-06 23:01:06.479+0900 E/EFL     ( 2521): elementary<2521> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7809258), hold(0) freeze(0)
06-06 23:01:06.489+0900 E/EFL     ( 2521): evas_main<2521> evas_events.c:1275 evas_event_feed_mouse_up() ButtonEvent:up time=21442232 button=1 downs=0
06-06 23:01:06.919+0900 I/AUL_AMD (  905): amd_main.c: __app_dead_handler(261) > __app_dead_handler, pid: 2521
06-06 23:01:06.919+0900 W/AUL_AMD (  905): amd_key.c: _key_ungrab(254) > fail(-1) to ungrab key(XF86Stop)
06-06 23:01:06.919+0900 W/AUL_AMD (  905): amd_launch.c: __e17_status_handler(2194) > back key ungrab error
06-06 23:01:06.969+0900 W/PROCESSMGR(  585): e_mod_processmgr.c: _e_mod_processmgr_send_update_watch_action(639) > [PROCESSMGR] =====================> send UpdateClock
06-06 23:01:06.989+0900 W/WATCH_CORE(12148): appcore-watch.c: __signal_process_manager_handler(1163) > process_manager_signal
06-06 23:01:06.989+0900 I/WATCH_CORE(12148): appcore-watch.c: __signal_process_manager_handler(1179) > Call the time_tick_cb
06-06 23:01:06.989+0900 I/CAPI_WATCH_APPLICATION(12148): watch_app_main.c: _watch_core_time_tick(306) > _watch_core_time_tick
06-06 23:01:06.989+0900 E/watchface-loader(12148): watchface-loader.cpp: OnAppTimeTick(744) > 
06-06 23:01:06.989+0900 I/watchface-loader(12148): watchface-loader.cpp: OnAppTimeTick(756) > set force update!!
06-06 23:01:07.029+0900 W/W_HOME  ( 1184): event_manager.c: _ecore_x_message_cb(403) > state: 1 -> 0
06-06 23:01:07.029+0900 W/W_HOME  ( 1184): event_manager.c: _state_control(194) > control:4, app_state:2 win_state:0(0) pm_state:1 home_visible:1 clock_visible:1 tutorial_state:0 editing : 0, home_clocklist:0, addviewer:0 scrolling : 0, powersaving : 0, apptray state : 1, apptray visibility : 0, apptray edit visibility : 0
06-06 23:01:07.029+0900 W/W_HOME  ( 1184): event_manager.c: _state_control(194) > control:2, app_state:2 win_state:0(0) pm_state:1 home_visible:1 clock_visible:1 tutorial_state:0 editing : 0, home_clocklist:0, addviewer:0 scrolling : 0, powersaving : 0, apptray state : 1, apptray visibility : 0, apptray edit visibility : 0
06-06 23:01:07.029+0900 W/W_HOME  ( 1184): event_manager.c: _state_control(194) > control:1, app_state:2 win_state:0(0) pm_state:1 home_visible:1 clock_visible:1 tutorial_state:0 editing : 0, home_clocklist:0, addviewer:0 scrolling : 0, powersaving : 0, apptray state : 1, apptray visibility : 0, apptray edit visibility : 0
06-06 23:01:07.029+0900 W/W_HOME  ( 1184): main.c: _ecore_x_message_cb(1233) > main_info.is_win_on_top: 1
06-06 23:01:07.029+0900 W/W_HOME  ( 1184): event_manager.c: _window_visibility_cb(448) > Window [0x2C00003] is now visible(0)
06-06 23:01:07.029+0900 W/W_HOME  ( 1184): event_manager.c: _window_visibility_cb(458) > state: 0 -> 1
06-06 23:01:07.029+0900 W/W_HOME  ( 1184): event_manager.c: _state_control(194) > control:4, app_state:2 win_state:0(1) pm_state:1 home_visible:1 clock_visible:1 tutorial_state:0 editing : 0, home_clocklist:0, addviewer:0 scrolling : 0, powersaving : 0, apptray state : 1, apptray visibility : 0, apptray edit visibility : 0
06-06 23:01:07.029+0900 W/W_HOME  ( 1184): main.c: _window_visibility_cb(1200) > Window [0x2C00003] is now visible(0)
06-06 23:01:07.029+0900 I/APP_CORE( 1184): appcore-efl.c: __do_app(429) > [APP 1184] Event: RESUME State: PAUSED
06-06 23:01:07.029+0900 I/CAPI_APPFW_APPLICATION( 1184): app_main.c: app_appcore_resume(223) > app_appcore_resume
06-06 23:01:07.029+0900 W/W_HOME  ( 1184): main.c: _appcore_resume_cb(683) > appcore resume
06-06 23:01:07.029+0900 W/W_HOME  ( 1184): event_manager.c: _app_resume_cb(355) > state: 2 -> 1
06-06 23:01:07.029+0900 W/W_HOME  ( 1184): event_manager.c: _state_control(194) > control:2, app_state:1 win_state:0(1) pm_state:1 home_visible:1 clock_visible:1 tutorial_state:0 editing : 0, home_clocklist:0, addviewer:0 scrolling : 0, powersaving : 0, apptray state : 1, apptray visibility : 0, apptray edit visibility : 0
06-06 23:01:07.079+0900 W/W_HOME  ( 1184): event_manager.c: _state_control(194) > control:0, app_state:1 win_state:0(1) pm_state:1 home_visible:1 clock_visible:1 tutorial_state:0 editing : 0, home_clocklist:0, addviewer:0 scrolling : 0, powersaving : 0, apptray state : 1, apptray visibility : 0, apptray edit visibility : 0
06-06 23:01:07.079+0900 W/W_HOME  ( 1184): main.c: home_resume(731) > journal_appcore_app_fully_loaded called
06-06 23:01:07.079+0900 W/W_HOME  ( 1184): main.c: home_resume(735) > clock/widget resumed
06-06 23:01:07.079+0900 W/W_HOME  ( 1184): event_manager.c: _state_control(194) > control:1, app_state:1 win_state:0(1) pm_state:1 home_visible:1 clock_visible:1 tutorial_state:0 editing : 0, home_clocklist:0, addviewer:0 scrolling : 0, powersaving : 0, apptray state : 1, apptray visibility : 0, apptray edit visibility : 0
06-06 23:01:07.079+0900 I/wnotib  ( 1184): w-notification-board-broker-main.c: _wnotib_ecore_x_event_visibility_changed_cb(701) > fully_obscured: 0
06-06 23:01:07.079+0900 E/wnotib  ( 1184): w-notification-board-action-drawer.c: wnotib_action_drawer_hidden_get(4570) > [NULL==g_wnotib_action_drawer_data] msg Drawer not initialized.
06-06 23:01:07.079+0900 W/wnotib  ( 1184): w-notification-board-noti-manager.c: wnotib_noti_manager_do_postponed_job(1695) > No postponed update.
06-06 23:01:07.079+0900 I/GESTURE (  239): gesture.c: BackGestureSetProperty(4501) > [BackGestureSetProperty] atom=_E_MOVE_W_HOME_CLOCK_STATE, value=1, Clock display 
06-06 23:01:07.139+0900 W/WATCH_CORE(12148): appcore-watch.c: __widget_resume(1012) > widget_resume
06-06 23:01:07.139+0900 E/watchface-loader(12148): watchface-loader.cpp: OnAppResume(725) > 
06-06 23:01:07.139+0900 I/CAPI_WATCH_APPLICATION(12148): watch_app_main.c: _watch_core_time_tick(306) > _watch_core_time_tick
06-06 23:01:07.139+0900 E/watchface-loader(12148): watchface-loader.cpp: OnAppTimeTick(744) > 
06-06 23:01:07.309+0900 I/CAPI_WATCH_APPLICATION(12148): watch_app_main.c: _watch_core_time_tick(306) > _watch_core_time_tick
06-06 23:01:07.309+0900 E/watchface-loader(12148): watchface-loader.cpp: OnAppTimeTick(744) > 
06-06 23:01:07.459+0900 W/CRASH_MANAGER( 2731): worker.c: worker_job(1199) > 1102521756963146522166
