S/W Version Information
Model: SM-R735S
Tizen-Version: 2.3.1.2
Build-Number: R735SKSU1AOKE
Build-Date: 2015.11.25 20:46:58

Crash Information
Process Name: uicomponents
PID: 563
Date: 2016-06-06 22:34:31+0900
Executable File Path: /opt/usr/apps/org.example.uicomponents/bin/uicomponents
Signal: 11
      (SIGSEGV)
      si_code: -6
      signal sent by tkill (sent by pid 563, uid 5000)

Register Information
r0   = 0x71737723, r1   = 0x71737723
r2   = 0xb807afa0, r3   = 0xb807afa0
r4   = 0xb8073600, r5   = 0x71737723
r6   = 0x00000000, r7   = 0xb6ed8e9c
r8   = 0xb6c949c0, r9   = 0xb7e85780
r10  = 0xb6ca2b18, fp   = 0x00000000
ip   = 0xb6eda428, sp   = 0xbebc82e0
lr   = 0xb6e6e507, pc   = 0xb6cd0bde
cpsr = 0x20000030

Memory Information
MemTotal:   407572 KB
MemFree:     15736 KB
Buffers:     11276 KB
Cached:      88568 KB
VmPeak:      76956 KB
VmSize:      74792 KB
VmLck:           0 KB
VmPin:           0 KB
VmHWM:       19104 KB
VmRSS:       19104 KB
VmData:      16228 KB
VmStk:         136 KB
VmExe:          20 KB
VmLib:       24764 KB
VmPTE:          56 KB
VmSwap:          0 KB

Threads Information
Threads: 2
PID = 563 TID = 563
563 650 

Maps Information
b2885000 b2889000 r-xp /usr/lib/libogg.so.0.7.1
b2891000 b28b3000 r-xp /usr/lib/libvorbis.so.0.4.3
b28bb000 b28c3000 r-xp /usr/lib/libmdm-common.so.1.0.89
b28c4000 b2907000 r-xp /usr/lib/libsndfile.so.1.0.25
b2914000 b295c000 r-xp /usr/lib/pulseaudio/libpulsecommon-4.0.so
b295d000 b2962000 r-xp /usr/lib/libjson.so.0.0.1
b296a000 b299b000 r-xp /usr/lib/libmdm.so.1.1.85
b29a3000 b29ab000 r-xp /usr/lib/lib_DNSe_NRSS_ver225.so
b29ba000 b29ca000 r-xp /usr/lib/lib_SamsungRec_TizenV04014.so
b29eb000 b29f8000 r-xp /usr/lib/libail.so.0.1.0
b2a01000 b2a04000 r-xp /usr/lib/libsyspopup_caller.so.0.1.0
b2a0c000 b2a44000 r-xp /usr/lib/libpulse.so.0.16.2
b2a45000 b2aa6000 r-xp /usr/lib/libasound.so.2.0.0
b2ab0000 b2ab3000 r-xp /usr/lib/libpulse-simple.so.0.0.4
b2abb000 b2ac0000 r-xp /usr/lib/libascenario-0.2.so.0.0.0
b2ac8000 b2ae1000 r-xp /usr/lib/libavsysaudio.so.0.0.1
b2aea000 b2aee000 r-xp /usr/lib/libmmfsoundcommon.so.0.0.0
b2af7000 b2b01000 r-xp /usr/lib/libaudio-session-mgr.so.0.0.0
b2b0d000 b2b12000 r-xp /usr/lib/libmmfsession.so.0.0.0
b2b1a000 b2b30000 r-xp /usr/lib/libmmfsound.so.0.1.0
b2b42000 b2b49000 r-xp /usr/lib/libmmfcommon.so.0.0.0
b2b51000 b2b5b000 r-xp /usr/lib/libcapi-media-sound-manager.so.0.1.48
b2b63000 b2b65000 r-xp /usr/lib/libcapi-media-wav-player.so.0.1.10
b2b6d000 b2b6e000 r-xp /usr/lib/libmmfkeysound.so.0.0.0
b2b76000 b2b7d000 r-xp /usr/lib/libfeedback.so.0.1.4
b2b86000 b2b87000 r-xp /usr/lib/edje/modules/feedback/linux-gnueabi-armv7l-1.0.0/module.so
b2b8f000 b2c16000 rw-s anon_inode:dmabuf
b2c16000 b2c9d000 rw-s anon_inode:dmabuf
b2d28000 b2daf000 rw-s anon_inode:dmabuf
b2e2e000 b2eb5000 rw-s anon_inode:dmabuf
b31ab000 b39aa000 rwxp [stack:650]
b39aa000 b39c1000 r-xp /usr/lib/edje/modules/elm/linux-gnueabi-armv7l-1.0.0/module.so
b39ce000 b39d0000 r-xp /usr/lib/libgenlock.so
b39d9000 b39da000 r-xp /usr/lib/evas/modules/loaders/eet/linux-gnueabi-armv7l-1.7.99/module.so
b39e2000 b39e4000 r-xp /usr/lib/evas/modules/loaders/png/linux-gnueabi-armv7l-1.7.99/module.so
b39ee000 b39f3000 r-xp /usr/lib/bufmgr/libtbm_msm.so.0.0.0
b39fb000 b3a06000 r-xp /usr/lib/evas/modules/engines/software_generic/linux-gnueabi-armv7l-1.7.99/module.so
b3d2e000 b3df8000 r-xp /usr/lib/libCOREGL.so.4.0
b3e09000 b3e0e000 r-xp /usr/lib/libcapi-media-tool.so.0.1.5
b3e16000 b3e37000 r-xp /usr/lib/libexif.so.12.3.3
b3e4a000 b3e4f000 r-xp /usr/lib/libmmutil_imgp.so.0.0.0
b3e57000 b3e5c000 r-xp /usr/lib/libmmutil_jpeg.so.0.0.0
b53eb000 b53ed000 r-xp /usr/lib/libdri2.so.0.0.0
b53f5000 b53fd000 r-xp /usr/lib/libdrm.so.2.4.0
b5405000 b5408000 r-xp /usr/lib/libcapi-media-image-util.so.0.3.5
b5410000 b54f4000 r-xp /usr/lib/libicuuc.so.51.1
b5509000 b5646000 r-xp /usr/lib/libicui18n.so.51.1
b5656000 b565b000 r-xp /usr/lib/libcapi-system-info.so.0.2.0
b5663000 b5669000 r-xp /usr/lib/libxcb-render.so.0.0.0
b5671000 b5672000 r-xp /usr/lib/libxcb-shm.so.0.0.0
b567b000 b567e000 r-xp /usr/lib/libEGL.so.1.4
b5686000 b5694000 r-xp /usr/lib/libGLESv2.so.2.0
b569d000 b56a4000 r-xp /usr/lib/libtbm.so.1.0.0
b56ac000 b56cd000 r-xp /usr/lib/libui-extension.so.0.1.0
b56d6000 b56e8000 r-xp /usr/lib/libtts.so
b56f0000 b57a8000 r-xp /usr/lib/libcairo.so.2.11200.14
b57b3000 b57c5000 r-xp /usr/lib/libefl-assist.so.0.1.0
b57cd000 b57ee000 r-xp /usr/lib/libefl-extension.so.0.1.0
b57f6000 b5809000 r-xp /opt/usr/apps/org.example.uicomponents/bin/uicomponents
b59d0000 b59da000 r-xp /lib/libnss_files-2.13.so
b59e3000 b5ab2000 r-xp /usr/lib/libscim-1.0.so.8.2.3
b5ac8000 b5aec000 r-xp /usr/lib/ecore/immodules/libisf-imf-module.so
b5af5000 b5afb000 r-xp /usr/lib/libappsvc.so.0.1.0
b5b03000 b5b05000 r-xp /usr/lib/libcapi-appfw-app-common.so.0.3.2.5
b5b0e000 b5b13000 r-xp /usr/lib/libcapi-appfw-app-control.so.0.3.2.5
b5b1e000 b5b29000 r-xp /usr/lib/evas/modules/engines/software_x11/linux-gnueabi-armv7l-1.7.99/module.so
b5b31000 b5b33000 r-xp /usr/lib/libiniparser.so.0
b5b3c000 b5b41000 r-xp /usr/lib/libappcore-common.so.1.1
b5b4a000 b5b52000 r-xp /usr/lib/libcapi-system-system-settings.so.0.0.2
b5b53000 b5b57000 r-xp /usr/lib/libcapi-appfw-application.so.0.3.2.5
b5b64000 b5b66000 r-xp /usr/lib/libXau.so.6.0.0
b5b6f000 b5b76000 r-xp /lib/libcrypt-2.13.so
b5ba6000 b5ba8000 r-xp /usr/lib/libiri.so
b5bb0000 b5d58000 r-xp /usr/lib/libcrypto.so.1.0.0
b5d71000 b5dbe000 r-xp /usr/lib/libssl.so.1.0.0
b5dcb000 b5df9000 r-xp /usr/lib/libidn.so.11.5.44
b5e01000 b5e0a000 r-xp /usr/lib/libcares.so.2.1.0
b5e13000 b5e26000 r-xp /usr/lib/libxcb.so.1.1.0
b5e2f000 b5e31000 r-xp /usr/lib/journal/libjournal.so.0.1.0
b5e3a000 b5e3c000 r-xp /usr/lib/libSLP-db-util.so.0.1.0
b5e45000 b5f11000 r-xp /usr/lib/libxml2.so.2.7.8
b5f1e000 b5f20000 r-xp /usr/lib/libgmodule-2.0.so.0.3200.3
b5f28000 b5f2d000 r-xp /usr/lib/libffi.so.5.0.10
b5f35000 b5f36000 r-xp /usr/lib/libgthread-2.0.so.0.3200.3
b5f3f000 b5f4a000 r-xp /usr/lib/libgpg-error.so.0.15.0
b5f52000 b5f55000 r-xp /lib/libattr.so.1.1.0
b5f5d000 b5ff1000 r-xp /usr/lib/libstdc++.so.6.0.16
b6004000 b6020000 r-xp /usr/lib/libsecurity-server-commons.so.1.0.0
b6029000 b6041000 r-xp /usr/lib/libpng12.so.0.50.0
b604a000 b6060000 r-xp /lib/libexpat.so.1.5.2
b606a000 b60ae000 r-xp /usr/lib/libcurl.so.4.3.0
b60b7000 b60c1000 r-xp /usr/lib/libXext.so.6.4.0
b60ca000 b60cd000 r-xp /usr/lib/libXtst.so.6.1.0
b60d6000 b60dc000 r-xp /usr/lib/libXrender.so.1.3.0
b60e5000 b60eb000 r-xp /usr/lib/libXrandr.so.2.2.0
b60f3000 b60f4000 r-xp /usr/lib/libXinerama.so.1.0.0
b60fd000 b6106000 r-xp /usr/lib/libXi.so.6.1.0
b610e000 b6111000 r-xp /usr/lib/libXfixes.so.3.1.0
b6119000 b611b000 r-xp /usr/lib/libXgesture.so.7.0.0
b6123000 b6125000 r-xp /usr/lib/libXcomposite.so.1.0.0
b612e000 b6130000 r-xp /usr/lib/libXdamage.so.1.1.0
b6138000 b613f000 r-xp /usr/lib/libXcursor.so.1.0.2
b6147000 b614a000 r-xp /usr/lib/libecore_input_evas.so.1.7.99
b6152000 b6156000 r-xp /usr/lib/libecore_ipc.so.1.7.99
b615f000 b6164000 r-xp /usr/lib/libecore_fb.so.1.7.99
b616e000 b624f000 r-xp /usr/lib/libX11.so.6.3.0
b625a000 b627d000 r-xp /usr/lib/libjpeg.so.8.0.2
b6295000 b62ab000 r-xp /lib/libz.so.1.2.5
b62b3000 b6328000 r-xp /usr/lib/libsqlite3.so.0.8.6
b6332000 b6347000 r-xp /usr/lib/libpkgmgr_parser.so.0.1.0
b6350000 b6384000 r-xp /usr/lib/libgobject-2.0.so.0.3200.3
b638d000 b6460000 r-xp /usr/lib/libgio-2.0.so.0.3200.3
b646b000 b647b000 r-xp /lib/libresolv-2.13.so
b647f000 b64fb000 r-xp /usr/lib/libgcrypt.so.20.0.3
b6507000 b651f000 r-xp /usr/lib/liblzma.so.5.0.3
b6528000 b652b000 r-xp /lib/libcap.so.2.21
b6533000 b6559000 r-xp /usr/lib/libsecurity-server-client.so.1.0.1
b6562000 b6563000 r-xp /usr/lib/libecore_imf_evas.so.1.7.99
b656b000 b6571000 r-xp /usr/lib/libecore_imf.so.1.7.99
b6579000 b6590000 r-xp /usr/lib/liblua-5.1.so
b659a000 b65a1000 r-xp /usr/lib/libembryo.so.1.7.99
b65a9000 b65af000 r-xp /lib/librt-2.13.so
b65b8000 b660e000 r-xp /usr/lib/libpixman-1.so.0.28.2
b661b000 b6671000 r-xp /usr/lib/libfreetype.so.6.11.3
b667d000 b66a5000 r-xp /usr/lib/libfontconfig.so.1.8.0
b66a7000 b66e4000 r-xp /usr/lib/libharfbuzz.so.0.940.0
b66ed000 b6700000 r-xp /usr/lib/libfribidi.so.0.3.1
b6708000 b6722000 r-xp /usr/lib/libecore_con.so.1.7.99
b672b000 b6734000 r-xp /usr/lib/libedbus.so.1.7.99
b673c000 b678c000 r-xp /usr/lib/libecore_x.so.1.7.99
b678f000 b6793000 r-xp /usr/lib/libvconf.so.0.2.45
b679b000 b67ac000 r-xp /usr/lib/libecore_input.so.1.7.99
b67b4000 b67b9000 r-xp /usr/lib/libecore_file.so.1.7.99
b67c1000 b67e3000 r-xp /usr/lib/libecore_evas.so.1.7.99
b67ec000 b682d000 r-xp /usr/lib/libeina.so.1.7.99
b6836000 b684f000 r-xp /usr/lib/libeet.so.1.7.99
b6860000 b68c9000 r-xp /lib/libm-2.13.so
b68d2000 b68d8000 r-xp /usr/lib/libcapi-base-common.so.0.1.8
b68e1000 b68e4000 r-xp /usr/lib/libproc-stat.so.0.2.86
b68ec000 b690e000 r-xp /usr/lib/libpkgmgr-info.so.0.0.17
b6916000 b691b000 r-xp /usr/lib/libxdgmime.so.1.1.0
b6923000 b694d000 r-xp /usr/lib/libdbus-1.so.3.8.12
b6956000 b696d000 r-xp /usr/lib/libdbus-glib-1.so.2.2.2
b6975000 b6980000 r-xp /lib/libunwind.so.8.0.1
b69ad000 b69e9000 r-xp /usr/lib/libsystemd.so.0.4.0
b69f2000 b6b0d000 r-xp /lib/libc-2.13.so
b6b1b000 b6b23000 r-xp /lib/libgcc_s-4.6.so.1
b6b24000 b6b27000 r-xp /usr/lib/libsmack.so.1.0.0
b6b2f000 b6b35000 r-xp /usr/lib/libprivilege-control.so.0.0.2
b6b3d000 b6c0d000 r-xp /usr/lib/libglib-2.0.so.0.3200.3
b6c0e000 b6c6b000 r-xp /usr/lib/libedje.so.1.7.99
b6c75000 b6c8c000 r-xp /usr/lib/libecore.so.1.7.99
b6ca3000 b6d72000 r-xp /usr/lib/libevas.so.1.7.99
b6d96000 b6ed0000 r-xp /usr/lib/libelementary.so.1.7.99
b6ee6000 b6efa000 r-xp /lib/libpthread-2.13.so
b6f05000 b6f07000 r-xp /usr/lib/libdlog.so.0.0.0
b6f0f000 b6f12000 r-xp /usr/lib/libbundle.so.0.1.22
b6f1a000 b6f1c000 r-xp /lib/libdl-2.13.so
b6f25000 b6f31000 r-xp /usr/lib/libaul.so.0.1.0
b6f43000 b6f48000 r-xp /usr/lib/libappcore-efl.so.1.1
b6f51000 b6f55000 r-xp /usr/lib/libsys-assert.so
b6f5e000 b6f7b000 r-xp /lib/ld-2.13.so
b6f84000 b6f89000 r-xp /usr/bin/launchpad-loader
b7e4d000 b80bc000 rw-p [heap]
beba8000 bebc9000 rwxp [stack]
End of Maps Information

Callstack Information (PID:563)
Call Stack Count: 3
 0: evas_object_evas_get + 0x5 (0xb6cd0bde) [/usr/lib/libevas.so.1] + 0x2dbde
 1: elm_scroller_add + 0x16 (0xb6e6e507) [/usr/lib/libelementary.so.1] + 0xd8507
 2: create_scroller + 0x10 (0xb57fb1e5) [/opt/usr/apps/org.example.uicomponents/bin/uicomponents] + 0x51e5
End of Call Stack

Package Information
Package Name: org.example.uicomponents
Package ID : org.example.uicomponents
Version: 1.0.0
Package Type: rpm
App Name: uicomponents
App ID: org.example.uicomponents
Type: capp
Categories: 

Latest Debug Message Information
--------- beginning of /dev/log_main
 visibility : 1, apptray edit visibility : 0
06-06 22:34:25.339+0900 W/W_HOME  ( 1184): rotary.c: rotary_deattach(156) > rotary_deattach:0xaff82190
06-06 22:34:25.339+0900 I/efl-extension( 1184): efl_extension_rotary.c: eext_rotary_object_event_callback_del(235) > In
06-06 22:34:25.339+0900 I/efl-extension( 1184): efl_extension_rotary.c: eext_rotary_object_event_callback_del(240) > callback del 0xaff82190, elm_layout, func : 0xb6f53fd1
06-06 22:34:25.339+0900 I/efl-extension( 1184): efl_extension_rotary.c: eext_rotary_object_event_callback_del(248) > Removed cb from callbacks
06-06 22:34:25.339+0900 I/efl-extension( 1184): efl_extension_rotary.c: eext_rotary_object_event_callback_del(266) > Freed cb
06-06 22:34:25.339+0900 I/efl-extension( 1184): efl_extension_rotary.c: eext_rotary_object_event_callback_del(273) > done
06-06 22:34:25.339+0900 I/efl-extension( 1184): efl_extension_rotary.c: eext_rotary_object_event_activated_set(283) > eext_rotary_object_event_activated_set : 0xb74ac380, elm_box, _activated_obj : 0xaff82190, activated : 1
06-06 22:34:25.339+0900 I/efl-extension( 1184): efl_extension_rotary.c: eext_rotary_object_event_activated_set(291) > Activation delete!!!!
06-06 22:34:25.339+0900 E/wnotib  ( 1184): w-notification-board-action-drawer.c: wnotib_action_drawer_hidden_get(4570) > [NULL==g_wnotib_action_drawer_data] msg Drawer not initialized.
06-06 22:34:25.339+0900 I/wnotib  ( 1184): w-notification-board-broker-main.c: _wnotib_scroller_event_handler(1108) > No second depth view available.
06-06 22:34:25.339+0900 I/APP_CORE(32467): appcore-efl.c: __do_app(429) > [APP 32467] Event: RESUME State: RUNNING
06-06 22:34:25.349+0900 I/MESSAGE_PORT(  839): MessagePortIpcServer.cpp: OnReadMessage(739) > _MessagePortIpcServer::OnReadMessage
06-06 22:34:25.349+0900 I/MESSAGE_PORT(  839): MessagePortIpcServer.cpp: HandleReceivedMessage(578) > _MessagePortIpcServer::HandleReceivedMessage
06-06 22:34:25.349+0900 I/MESSAGE_PORT(  839): MessagePortStub.cpp: OnIpcRequestReceived(147) > MessagePort message received
06-06 22:34:25.349+0900 I/MESSAGE_PORT(  839): MessagePortStub.cpp: OnCheckRemotePort(115) > _MessagePortStub::OnCheckRemotePort.
06-06 22:34:25.349+0900 I/MESSAGE_PORT(  839): MessagePortService.cpp: CheckRemotePort(207) > _MessagePortService::CheckRemotePort
06-06 22:34:25.349+0900 I/MESSAGE_PORT(  839): MessagePortService.cpp: GetKey(365) > _MessagePortService::GetKey
06-06 22:34:25.349+0900 I/MESSAGE_PORT(  839): MessagePortService.cpp: CheckRemotePort(220) > Check a remote message port: [com.samsung.w-music-player.music-control-service:music-control-service-request-message-port]
06-06 22:34:25.349+0900 I/MESSAGE_PORT(  839): MessagePortIpcServer.cpp: Send(847) > _MessagePortIpcServer::Stop
06-06 22:34:25.349+0900 I/MESSAGE_PORT(  839): MessagePortIpcServer.cpp: OnReadMessage(739) > _MessagePortIpcServer::OnReadMessage
06-06 22:34:25.349+0900 I/MESSAGE_PORT(  839): MessagePortIpcServer.cpp: HandleReceivedMessage(578) > _MessagePortIpcServer::HandleReceivedMessage
06-06 22:34:25.349+0900 I/MESSAGE_PORT(  839): MessagePortStub.cpp: OnIpcRequestReceived(147) > MessagePort message received
06-06 22:34:25.349+0900 I/MESSAGE_PORT(  839): MessagePortStub.cpp: OnSendMessage(126) > MessagePort OnSendMessage
06-06 22:34:25.349+0900 I/MESSAGE_PORT(  839): MessagePortService.cpp: SendMessage(291) > _MessagePortService::SendMessage
06-06 22:34:25.349+0900 I/MESSAGE_PORT(  839): MessagePortService.cpp: GetKey(365) > _MessagePortService::GetKey
06-06 22:34:25.349+0900 I/MESSAGE_PORT(  839): MessagePortService.cpp: SendMessage(299) > Sends a message to a remote message port [com.samsung.w-music-player.music-control-service:music-control-service-request-message-port]
06-06 22:34:25.349+0900 I/MESSAGE_PORT(  839): MessagePortStub.cpp: SendMessage(138) > MessagePort SendMessage
06-06 22:34:25.349+0900 I/MESSAGE_PORT(  839): MessagePortIpcServer.cpp: SendResponse(884) > _MessagePortIpcServer::SendResponse
06-06 22:34:25.349+0900 I/MESSAGE_PORT(  839): MessagePortIpcServer.cpp: Send(847) > _MessagePortIpcServer::Stop
06-06 22:34:25.349+0900 E/CAPI_APPFW_APP_CONTROL( 1471): app_control.c: app_control_error(133) > [app_control_get_caller] INVALID_PARAMETER(0xffffffea) : invalid app_control handle type
06-06 22:34:25.349+0900 W/MUSIC_CONTROL_SERVICE( 1471): music-control-service.c: _music_control_service_pasre_request(409) > [33m[TID:1471]   value = [false][0m
06-06 22:34:25.359+0900 I/GESTURE (  239): gesture.c: BackGestureSetProperty(4538) > [BackGestureSetProperty] atom=_E_MOVE_ENABLE_DISABLE_BACK_GESTURE, value=0, No apps display 
06-06 22:34:25.359+0900 I/GESTURE (  239): gesture.c: BackGestureSetProperty(4538) > [BackGestureSetProperty] atom=_E_MOVE_ENABLE_DISABLE_BACK_GESTURE, value=0, No apps display 
06-06 22:34:25.449+0900 I/wnotib  ( 1184): w-notification-board-broker-main.c: _wnotib_ecore_x_event_visibility_changed_cb(701) > fully_obscured: 1
06-06 22:34:25.449+0900 E/wnotib  ( 1184): w-notification-board-action-drawer.c: wnotib_action_drawer_hidden_get(4570) > [NULL==g_wnotib_action_drawer_data] msg Drawer not initialized.
06-06 22:34:25.859+0900 I/APP_CORE( 1184): appcore-efl.c: __do_app(429) > [APP 1184] Event: MEM_FLUSH State: PAUSED
06-06 22:34:25.969+0900 W/AUL_AMD (  905): amd_request.c: __request_handler(640) > __request_handler: 14
06-06 22:34:25.999+0900 W/AUL_AMD (  905): amd_request.c: __send_result_to_client(83) > __send_result_to_client, pid: 32467
06-06 22:34:25.999+0900 W/AUL_AMD (  905): amd_request.c: __request_handler(640) > __request_handler: 12
06-06 22:34:26.309+0900 I/efl-extension(  644): efl_extension.c: eext_mod_init(40) > Init
06-06 22:34:26.349+0900 I/UXT     (  644): Uxt_ObjectManager.cpp: OnInitialized(731) > Initialized.
06-06 22:34:26.439+0900 I/AUL_PAD (  644): launchpad_loader.c: main(600) > [candidate] elm init, returned: 1
06-06 22:34:26.459+0900 I/Adreno-EGL(  644): <qeglDrvAPI_eglInitialize:410>: EGL 1.4 QUALCOMM build:  ()
06-06 22:34:26.459+0900 I/Adreno-EGL(  644): OpenGL ES Shader Compiler Version: E031.24.00.16
06-06 22:34:26.459+0900 I/Adreno-EGL(  644): Build Date: 09/02/15 Wed
06-06 22:34:26.459+0900 I/Adreno-EGL(  644): Local Branch: 
06-06 22:34:26.459+0900 I/Adreno-EGL(  644): Remote Branch: 
06-06 22:34:26.459+0900 I/Adreno-EGL(  644): Local Patches: 
06-06 22:34:26.459+0900 I/Adreno-EGL(  644): Reconstruct Branch: 
06-06 22:34:26.589+0900 E/EFL     (32467): elementary<32467> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b751a890), block(1)
06-06 22:34:26.589+0900 E/EFL     (32467): elementary<32467> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b751a890), ev->cur.canvas.x(170) ev->cur.canvas.y(170)
06-06 22:34:26.589+0900 E/EFL     (32467): elementary<32467> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b751a890), hold(0) freeze(0)
06-06 22:34:26.599+0900 E/EFL     (32467): evas_main<32467> evas_events.c:1009 evas_event_feed_mouse_down() ButtonEvent:down time=19842338 button=1 downs=1
06-06 22:34:26.609+0900 E/EFL     (32467): elementary<32467> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b751a890), block(1)
06-06 22:34:26.609+0900 E/EFL     (32467): elementary<32467> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b751a890), ev->cur.canvas.x(171) ev->cur.canvas.y(170)
06-06 22:34:26.609+0900 E/EFL     (32467): elementary<32467> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b751a890), hold(0) freeze(0)
06-06 22:34:26.629+0900 E/EFL     (32467): elementary<32467> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b751a890), block(1)
06-06 22:34:26.629+0900 E/EFL     (32467): elementary<32467> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b751a890), ev->cur.canvas.x(173) ev->cur.canvas.y(170)
06-06 22:34:26.629+0900 E/EFL     (32467): elementary<32467> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b751a890), hold(0) freeze(0)
06-06 22:34:26.639+0900 E/EFL     (32467): elementary<32467> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b751a890), block(1)
06-06 22:34:26.639+0900 E/EFL     (32467): elementary<32467> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b751a890), ev->cur.canvas.x(175) ev->cur.canvas.y(169)
06-06 22:34:26.639+0900 E/EFL     (32467): elementary<32467> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b751a890), hold(0) freeze(0)
06-06 22:34:26.649+0900 E/EFL     (32467): elementary<32467> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b751a890), block(1)
06-06 22:34:26.649+0900 E/EFL     (32467): elementary<32467> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b751a890), ev->cur.canvas.x(176) ev->cur.canvas.y(168)
06-06 22:34:26.649+0900 E/EFL     (32467): elementary<32467> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b751a890), hold(0) freeze(0)
06-06 22:34:26.659+0900 E/EFL     (32467): elementary<32467> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b751a890), block(1)
06-06 22:34:26.659+0900 E/EFL     (32467): elementary<32467> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b751a890), ev->cur.canvas.x(177) ev->cur.canvas.y(167)
06-06 22:34:26.659+0900 E/EFL     (32467): elementary<32467> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b751a890), hold(0) freeze(0)
06-06 22:34:26.669+0900 E/EFL     (32467): elementary<32467> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b751a890), block(1)
06-06 22:34:26.669+0900 E/EFL     (32467): elementary<32467> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b751a890), ev->cur.canvas.x(178) ev->cur.canvas.y(166)
06-06 22:34:26.669+0900 E/EFL     (32467): elementary<32467> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b751a890), hold(0) freeze(0)
06-06 22:34:26.699+0900 E/EFL     (32467): elementary<32467> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b751a890), block(1)
06-06 22:34:26.699+0900 E/EFL     (32467): elementary<32467> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b751a890), ev->cur.canvas.x(178) ev->cur.canvas.y(168)
06-06 22:34:26.699+0900 E/EFL     (32467): elementary<32467> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b751a890), hold(0) freeze(0)
06-06 22:34:26.709+0900 E/EFL     (32467): elementary<32467> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b751a890), block(1)
06-06 22:34:26.709+0900 E/EFL     (32467): elementary<32467> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b751a890), ev->cur.canvas.x(173) ev->cur.canvas.y(160)
06-06 22:34:26.709+0900 E/EFL     (32467): elementary<32467> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b751a890), hold(0) freeze(0)
06-06 22:34:26.719+0900 E/EFL     (32467): evas_main<32467> evas_events.c:1275 evas_event_feed_mouse_up() ButtonEvent:up time=19842466 button=1 downs=0
06-06 22:34:26.739+0900 W/AUL_AMD (  905): amd_request.c: __request_handler(640) > __request_handler: 14
06-06 22:34:26.759+0900 W/AUL_AMD (  905): amd_request.c: __send_result_to_client(83) > __send_result_to_client, pid: -1
06-06 22:34:26.759+0900 W/AUL_AMD (  905): amd_request.c: __request_handler(640) > __request_handler: 0
06-06 22:34:26.759+0900 W/AUL_AMD (  905): amd_launch.c: _start_app(1659) > caller pid : 32467
06-06 22:34:26.779+0900 W/AUL_AMD (  905): amd_launch.c: _start_app(2026) > pad pid(-5)
06-06 22:34:26.779+0900 W/AUL_PAD ( 1730): launchpad.c: __launchpad_main_loop(512) > Launch on type-based process-pool
06-06 22:34:26.779+0900 W/AUL_PAD ( 1730): launchpad.c: __send_result_to_caller(265) > Check app launching
06-06 22:34:26.779+0900 E/RESOURCED(  906): block.c: block_prelaunch_state(134) > [block_prelaunch_state,134] insert data org.example.uicomponents, table num : 3
06-06 22:34:26.779+0900 E/RESOURCED(  906): heart-memory.c: heart_memory_get_data(601) > [heart_memory_get_data,601] hashtable heart_memory_app_list is NULL
06-06 22:34:26.809+0900 I/efl-extension(  563): efl_extension.c: eext_mod_init(40) > Init
06-06 22:34:26.809+0900 I/UXT     (  563): Uxt_ObjectManager.cpp: OnInitialized(731) > Initialized.
06-06 22:34:26.809+0900 I/CAPI_APPFW_APPLICATION(  563): app_main.c: ui_app_main(704) > app_efl_main
06-06 22:34:26.819+0900 I/CAPI_APPFW_APPLICATION(  563): app_main.c: _ui_app_appcore_create(563) > app_appcore_create
06-06 22:34:26.879+0900 E/W_TASKMANAGER(32467): task.c: taskmanager_launch_task_info(888) > [taskmanager_launch_task_info:888] _launch_app() failed(563)
06-06 22:34:26.879+0900 E/RESOURCED(  906): proc-main.c: proc_add_program_list(233) > [proc_add_program_list,233] not found ppi : org.example.uicomponents
06-06 22:34:26.939+0900 I/efl-extension(  563): efl_extension_circle_surface.c: eext_circle_surface_conformant_add(1245) > Put the surface[0xb7f7ddc0]'s widget[0xb7f87208] to elm_conformant widget[0xb7f4fd30]
06-06 22:34:26.939+0900 I/efl-extension(  563): efl_extension_circle_surface.c: _eext_circle_surface_resize_cb(642) > surface 0xb7f7ddc0 = w: 0 h: 0  obj 0xb7f87208 w: 1 h: 1
06-06 22:34:26.979+0900 I/efl-extension(  563): efl_extension_rotary.c: eext_rotary_object_event_callback_add(147) > In
06-06 22:34:26.979+0900 I/efl-extension(  563): efl_extension_rotary.c: eext_rotary_event_handler_add(77) > init_count: 0
06-06 22:34:26.979+0900 I/efl-extension(  563): efl_extension_rotary.c: _init_Xi2_system(314) > In
06-06 22:34:26.989+0900 I/efl-extension(  563): efl_extension_rotary.c: _init_Xi2_system(375) > Done
06-06 22:34:26.989+0900 I/efl-extension(  563): efl_extension_rotary.c: eext_rotary_object_event_activated_set(283) > eext_rotary_object_event_activated_set : 0xb301b638, elm_image, _activated_obj : 0x0, activated : 1
06-06 22:34:27.049+0900 E/E17     (  585): e_manager.c: _e_manager_cb_window_show_request(1128) > Show request(0x04a00002)
06-06 22:34:27.099+0900 I/APP_CORE(  563): appcore-efl.c: __do_app(429) > [APP 563] Event: RESET State: CREATED
06-06 22:34:27.099+0900 I/CAPI_APPFW_APPLICATION(  563): app_main.c: _ui_app_appcore_reset(645) > app_appcore_reset
06-06 22:34:27.109+0900 I/APP_CORE(  563): appcore-efl.c: __do_app(472) > Legacy lifecycle: 0
06-06 22:34:27.109+0900 I/APP_CORE(  563): appcore-efl.c: __do_app(474) > [APP 563] Initial Launching, call the resume_cb
06-06 22:34:27.109+0900 I/CAPI_APPFW_APPLICATION(  563): app_main.c: _ui_app_appcore_resume(628) > app_appcore_resume
06-06 22:34:27.119+0900 W/APP_CORE(  563): appcore-efl.c: __show_cb(787) > [EVENT_TEST][EVENT] GET SHOW EVENT!!!. WIN:4a00002
06-06 22:34:27.139+0900 I/efl-extension(  563): efl_extension_circle_surface.c: _eext_circle_surface_resize_cb(642) > surface 0xb7f7ddc0 = w: 0 h: 0  obj 0xb7f87208 w: 360 h: 360
06-06 22:34:27.139+0900 I/efl-extension(  563): efl_extension_circle_surface.c: _eext_circle_surface_resize_cb(666) > Surface will be initialized! surface->w= 360 surface->h = 360
06-06 22:34:27.209+0900 I/APP_CORE(32401): appcore-efl.c: __do_app(429) > [APP 32401] Event: MEM_FLUSH State: PAUSED
06-06 22:34:27.269+0900 I/APP_CORE(  563): appcore-efl.c: __do_app(429) > [APP 563] Event: RESUME State: RUNNING
06-06 22:34:27.309+0900 I/APP_CORE(32467): appcore-efl.c: __do_app(429) > [APP 32467] Event: PAUSE State: RUNNING
06-06 22:34:27.309+0900 I/CAPI_APPFW_APPLICATION(32467): app_main.c: app_appcore_pause(202) > app_appcore_pause
06-06 22:34:27.309+0900 E/EFL     (32467): elementary<32467> elm_interface_scrollable.c:5303 _elm_scroll_freeze_set() [DDO] obj(b751a890), freeze(1)
06-06 22:34:27.309+0900 E/EFL     (32467): elementary<32467> elm_interface_scrollable.c:5303 _elm_scroll_freeze_set() [DDO] obj(b751a890), freeze(1)
06-06 22:34:27.829+0900 W/AUL_AMD (  905): amd_request.c: __request_handler(640) > __request_handler: 22
06-06 22:34:27.829+0900 W/AUL_AMD (  905): amd_request.c: __request_handler(884) > app status : 4
06-06 22:34:27.829+0900 E/APP_CORE(32467): appcore.c: __del_vconf(429) > [FAILED]vconfkey_ignore_key_changed
06-06 22:34:27.829+0900 I/APP_CORE(32467): appcore-efl.c: __after_loop(1086) > Legacy lifecycle: 0
06-06 22:34:27.829+0900 I/CAPI_APPFW_APPLICATION(32467): app_main.c: app_appcore_terminate(177) > app_appcore_terminate
06-06 22:34:27.829+0900 I/efl-extension(32467): efl_extension_rotary.c: _object_deleted_cb(572) > In: data: 0xb751a890, obj: 0xb751a890
06-06 22:34:27.829+0900 I/efl-extension(32467): efl_extension_rotary.c: _remove_ecore_handlers(554) > In
06-06 22:34:27.829+0900 I/efl-extension(32467): efl_extension_rotary.c: _remove_ecore_handlers(559) > removed _motion_handler
06-06 22:34:27.829+0900 I/efl-extension(32467): efl_extension_rotary.c: _remove_ecore_handlers(565) > removed _rotate_handler
06-06 22:34:27.829+0900 I/efl-extension(32467): efl_extension_rotary.c: _object_deleted_cb(601) > done
06-06 22:34:27.839+0900 I/efl-extension(32467): efl_extension_rotary.c: _activated_obj_del_cb(607) > _activated_obj_del_cb : 0xb7565e20
06-06 22:34:27.839+0900 I/efl-extension(32467): efl_extension_circle_surface.c: _eext_circle_surface_del_cb(680) > Surface is going to free in delete callback for image widget.
06-06 22:34:27.839+0900 I/efl-extension(32467): efl_extension_circle_surface.c: _eext_circle_surface_del_internal(993) > surface 0xb7581b88 is freed
06-06 22:34:27.839+0900 I/efl-extension(32467): efl_extension_rotary.c: eext_rotary_object_event_callback_del(235) > In
06-06 22:34:27.839+0900 I/efl-extension(32467): efl_extension_rotary.c: eext_rotary_object_event_callback_del(240) > callback del 0xb751a890, elm_scroller, func : 0xb3a59249
06-06 22:34:27.839+0900 I/efl-extension(32467): efl_extension_rotary.c: eext_rotary_object_event_callback_del(273) > done
06-06 22:34:27.839+0900 I/efl-extension(32467): efl_extension_rotary.c: eext_rotary_object_event_callback_del(235) > In
06-06 22:34:27.839+0900 I/efl-extension(32467): efl_extension_rotary.c: eext_rotary_object_event_callback_del(240) > callback del 0xb7565e20, elm_image, func : 0xb3a59249
06-06 22:34:27.839+0900 I/efl-extension(32467): efl_extension_rotary.c: eext_rotary_object_event_callback_del(273) > done
06-06 22:34:27.839+0900 I/efl-extension(32467): efl_extension_circle_object_scroller.c: _eext_circle_object_scroller_del_cb(841) > [0xb751a890 : elm_scroller] rotary callabck is deleted
06-06 22:34:27.949+0900 W/AUL_AMD (  905): amd_request.c: __request_handler(640) > __request_handler: 14
06-06 22:34:27.969+0900 W/AUL_AMD (  905): amd_request.c: __send_result_to_client(83) > __send_result_to_client, pid: 563
06-06 22:34:27.969+0900 W/AUL_AMD (  905): amd_request.c: __request_handler(640) > __request_handler: 12
06-06 22:34:28.179+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7f88588), block(1)
06-06 22:34:28.179+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7f88588), ev->cur.canvas.x(127) ev->cur.canvas.y(305)
06-06 22:34:28.179+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7f88588), hold(0) freeze(0)
06-06 22:34:28.179+0900 E/EFL     (  563): evas_main<563> evas_events.c:1009 evas_event_feed_mouse_down() ButtonEvent:down time=19843925 button=1 downs=1
06-06 22:34:28.189+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7f88588), block(1)
06-06 22:34:28.189+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7f88588), ev->cur.canvas.x(127) ev->cur.canvas.y(300)
06-06 22:34:28.189+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7f88588), hold(0) freeze(0)
06-06 22:34:28.199+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7f88588), block(1)
06-06 22:34:28.199+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7f88588), ev->cur.canvas.x(128) ev->cur.canvas.y(296)
06-06 22:34:28.199+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7f88588), hold(0) freeze(0)
06-06 22:34:28.209+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7f88588), block(1)
06-06 22:34:28.209+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7f88588), ev->cur.canvas.x(129) ev->cur.canvas.y(291)
06-06 22:34:28.209+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7f88588), hold(0) freeze(0)
06-06 22:34:28.209+0900 I/AUL_PAD (  647): launchpad_loader.c: main(600) > [candidate] elm init, returned: 1
06-06 22:34:28.219+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7f88588), block(1)
06-06 22:34:28.219+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7f88588), ev->cur.canvas.x(131) ev->cur.canvas.y(285)
06-06 22:34:28.219+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7f88588), hold(0) freeze(0)
06-06 22:34:28.229+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7f88588), block(1)
06-06 22:34:28.229+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7f88588), ev->cur.canvas.x(133) ev->cur.canvas.y(280)
06-06 22:34:28.229+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7f88588), hold(0) freeze(0)
06-06 22:34:28.239+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7f88588), block(1)
06-06 22:34:28.239+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7f88588), ev->cur.canvas.x(133) ev->cur.canvas.y(275)
06-06 22:34:28.239+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7f88588), hold(0) freeze(0)
06-06 22:34:28.249+0900 I/UXT     (32467): Uxt_ObjectManager.cpp: OnTerminating(750) > Terminating.
06-06 22:34:28.259+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7f88588), block(1)
06-06 22:34:28.259+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7f88588), ev->cur.canvas.x(133) ev->cur.canvas.y(269)
06-06 22:34:28.259+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7f88588), hold(0) freeze(0)
06-06 22:34:28.259+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:4249 _elm_scroll_mouse_move_event_cb() [DDO] animator
06-06 22:34:28.259+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3353 _elm_scroll_post_event_move() [DDO] obj(b7f88588), type(elm_genlist)
06-06 22:34:28.259+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3354 _elm_scroll_post_event_move() [DDO] hold_parent(0)
06-06 22:34:28.259+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3405 _elm_scroll_post_event_move() [DDO] elm_widget_drag_lock_y_set : obj(b7f88588), type(elm_genlist)
06-06 22:34:28.259+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b7f88588), locked_x(0)
06-06 22:34:28.259+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b7f88588)
06-06 22:34:28.279+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7f88588), block(1)
06-06 22:34:28.279+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7f88588), ev->cur.canvas.x(134) ev->cur.canvas.y(263)
06-06 22:34:28.279+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7f88588), hold(0) freeze(0)
06-06 22:34:28.279+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7f88588), block(1)
06-06 22:34:28.279+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7f88588), ev->cur.canvas.x(134) ev->cur.canvas.y(257)
06-06 22:34:28.279+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7f88588), hold(0) freeze(0)
06-06 22:34:28.279+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b7f88588), locked_x(0)
06-06 22:34:28.279+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b7f88588)
06-06 22:34:28.309+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7f88588), block(1)
06-06 22:34:28.309+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7f88588), ev->cur.canvas.x(134) ev->cur.canvas.y(249)
06-06 22:34:28.309+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7f88588), hold(0) freeze(0)
06-06 22:34:28.309+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7f88588), block(1)
06-06 22:34:28.309+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7f88588), ev->cur.canvas.x(134) ev->cur.canvas.y(242)
06-06 22:34:28.309+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7f88588), hold(0) freeze(0)
06-06 22:34:28.309+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7f88588), block(1)
06-06 22:34:28.309+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7f88588), ev->cur.canvas.x(134) ev->cur.canvas.y(236)
06-06 22:34:28.309+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7f88588), hold(0) freeze(0)
06-06 22:34:28.309+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b7f88588), locked_x(0)
06-06 22:34:28.309+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b7f88588)
06-06 22:34:28.329+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7f88588), block(1)
06-06 22:34:28.329+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7f88588), ev->cur.canvas.x(134) ev->cur.canvas.y(234)
06-06 22:34:28.329+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7f88588), hold(0) freeze(0)
06-06 22:34:28.329+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7f88588), block(1)
06-06 22:34:28.329+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7f88588), ev->cur.canvas.x(133) ev->cur.canvas.y(232)
06-06 22:34:28.329+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7f88588), hold(0) freeze(0)
06-06 22:34:28.329+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b7f88588), locked_x(0)
06-06 22:34:28.329+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b7f88588)
06-06 22:34:28.359+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7f88588), block(1)
06-06 22:34:28.359+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7f88588), ev->cur.canvas.x(131) ev->cur.canvas.y(232)
06-06 22:34:28.359+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7f88588), hold(0) freeze(0)
06-06 22:34:28.359+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7f88588), block(1)
06-06 22:34:28.359+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7f88588), ev->cur.canvas.x(129) ev->cur.canvas.y(234)
06-06 22:34:28.359+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7f88588), hold(0) freeze(0)
06-06 22:34:28.359+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7f88588), block(1)
06-06 22:34:28.359+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7f88588), ev->cur.canvas.x(127) ev->cur.canvas.y(238)
06-06 22:34:28.359+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7f88588), hold(0) freeze(0)
06-06 22:34:28.369+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b7f88588), locked_x(0)
06-06 22:34:28.369+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b7f88588)
06-06 22:34:28.389+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7f88588), block(1)
06-06 22:34:28.389+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7f88588), ev->cur.canvas.x(126) ev->cur.canvas.y(242)
06-06 22:34:28.389+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7f88588), hold(0) freeze(0)
06-06 22:34:28.389+0900 E/EFL     (  563): evas_main<563> evas_events.c:1275 evas_event_feed_mouse_up() ButtonEvent:up time=19844127 button=1 downs=0
06-06 22:34:28.389+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:2278 _elm_scroll_post_event_up() [DDO] lock set false. : obj(b7f88588), type(elm_genlist)
06-06 22:34:28.909+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7f88588), block(1)
06-06 22:34:28.909+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7f88588), ev->cur.canvas.x(177) ev->cur.canvas.y(195)
06-06 22:34:28.909+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7f88588), hold(0) freeze(0)
06-06 22:34:28.909+0900 E/EFL     (  563): evas_main<563> evas_events.c:1009 evas_event_feed_mouse_down() ButtonEvent:down time=19844642 button=1 downs=1
06-06 22:34:28.919+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7f88588), block(1)
06-06 22:34:28.919+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7f88588), ev->cur.canvas.x(178) ev->cur.canvas.y(192)
06-06 22:34:28.919+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7f88588), hold(0) freeze(0)
06-06 22:34:28.919+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7f88588), block(1)
06-06 22:34:28.919+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7f88588), ev->cur.canvas.x(179) ev->cur.canvas.y(191)
06-06 22:34:28.919+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7f88588), hold(0) freeze(0)
06-06 22:34:28.949+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7f88588), block(1)
06-06 22:34:28.949+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7f88588), ev->cur.canvas.x(180) ev->cur.canvas.y(191)
06-06 22:34:28.949+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7f88588), hold(0) freeze(0)
06-06 22:34:28.949+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7f88588), block(1)
06-06 22:34:28.949+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7f88588), ev->cur.canvas.x(182) ev->cur.canvas.y(191)
06-06 22:34:28.949+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7f88588), hold(0) freeze(0)
06-06 22:34:28.949+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7f88588), block(1)
06-06 22:34:28.949+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7f88588), ev->cur.canvas.x(184) ev->cur.canvas.y(191)
06-06 22:34:28.949+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7f88588), hold(0) freeze(0)
06-06 22:34:28.989+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7f88588), block(1)
06-06 22:34:28.989+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7f88588), ev->cur.canvas.x(186) ev->cur.canvas.y(191)
06-06 22:34:28.989+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7f88588), hold(0) freeze(0)
06-06 22:34:28.989+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7f88588), block(1)
06-06 22:34:28.989+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7f88588), ev->cur.canvas.x(188) ev->cur.canvas.y(192)
06-06 22:34:28.989+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7f88588), hold(0) freeze(0)
06-06 22:34:28.989+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7f88588), block(1)
06-06 22:34:28.989+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7f88588), ev->cur.canvas.x(190) ev->cur.canvas.y(192)
06-06 22:34:28.989+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7f88588), hold(0) freeze(0)
06-06 22:34:29.029+0900 I/efl-extension(32467): efl_extension.c: eext_mod_shutdown(46) > Shutdown
06-06 22:34:29.039+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7f88588), block(1)
06-06 22:34:29.039+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7f88588), ev->cur.canvas.x(191) ev->cur.canvas.y(193)
06-06 22:34:29.039+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7f88588), hold(0) freeze(0)
06-06 22:34:29.039+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7f88588), block(1)
06-06 22:34:29.039+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7f88588), ev->cur.canvas.x(192) ev->cur.canvas.y(195)
06-06 22:34:29.039+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7f88588), hold(0) freeze(0)
06-06 22:34:29.039+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7f88588), block(1)
06-06 22:34:29.039+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7f88588), ev->cur.canvas.x(194) ev->cur.canvas.y(196)
06-06 22:34:29.039+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7f88588), hold(0) freeze(0)
06-06 22:34:29.039+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7f88588), block(1)
06-06 22:34:29.039+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7f88588), ev->cur.canvas.x(195) ev->cur.canvas.y(201)
06-06 22:34:29.039+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b7f88588), hold(0) freeze(0)
06-06 22:34:29.069+0900 E/EFL     (  563): evas_main<563> evas_events.c:1275 evas_event_feed_mouse_up() ButtonEvent:up time=19844781 button=1 downs=0
06-06 22:34:29.199+0900 I/AUL_AMD (  905): amd_main.c: __app_dead_handler(261) > __app_dead_handler, pid: 32467
06-06 22:34:29.259+0900 I/efl-extension(  563): efl_extension_rotary.c: eext_rotary_object_event_callback_add(147) > In
06-06 22:34:29.259+0900 I/efl-extension(  563): efl_extension_rotary.c: eext_rotary_object_event_activated_set(283) > eext_rotary_object_event_activated_set : 0xb805aec0, elm_image, _activated_obj : 0xb301b638, activated : 1
06-06 22:34:29.259+0900 I/efl-extension(  563): efl_extension_rotary.c: eext_rotary_object_event_activated_set(291) > Activation delete!!!!
06-06 22:34:29.829+0900 W/AUL_AMD (  905): amd_status.c: __app_terminate_timer_cb(166) > send SIGKILL: No such process
06-06 22:34:29.949+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8007278), block(1)
06-06 22:34:29.949+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8007278), ev->cur.canvas.x(185) ev->cur.canvas.y(299)
06-06 22:34:29.949+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8007278), hold(0) freeze(0)
06-06 22:34:29.949+0900 E/EFL     (  563): evas_main<563> evas_events.c:1009 evas_event_feed_mouse_down() ButtonEvent:down time=19845695 button=1 downs=1
06-06 22:34:29.959+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8007278), block(1)
06-06 22:34:29.959+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8007278), ev->cur.canvas.x(184) ev->cur.canvas.y(303)
06-06 22:34:29.959+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8007278), hold(0) freeze(0)
06-06 22:34:29.999+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8007278), block(1)
06-06 22:34:29.999+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8007278), ev->cur.canvas.x(185) ev->cur.canvas.y(303)
06-06 22:34:29.999+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8007278), hold(0) freeze(0)
06-06 22:34:30.019+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8007278), block(1)
06-06 22:34:30.019+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8007278), ev->cur.canvas.x(186) ev->cur.canvas.y(303)
06-06 22:34:30.019+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8007278), hold(0) freeze(0)
06-06 22:34:30.019+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8007278), block(1)
06-06 22:34:30.019+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8007278), ev->cur.canvas.x(187) ev->cur.canvas.y(306)
06-06 22:34:30.019+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8007278), hold(0) freeze(0)
06-06 22:34:30.029+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8007278), block(1)
06-06 22:34:30.029+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8007278), ev->cur.canvas.x(191) ev->cur.canvas.y(313)
06-06 22:34:30.029+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8007278), hold(0) freeze(0)
06-06 22:34:30.039+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8007278), block(1)
06-06 22:34:30.039+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8007278), ev->cur.canvas.x(199) ev->cur.canvas.y(319)
06-06 22:34:30.039+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8007278), hold(0) freeze(0)
06-06 22:34:30.059+0900 E/EFL     (  563): evas_main<563> evas_events.c:1275 evas_event_feed_mouse_up() ButtonEvent:up time=19845796 button=1 downs=0
06-06 22:34:30.359+0900 I/APP_CORE( 1184): appcore-efl.c: __do_app(429) > [APP 1184] Event: MEM_FLUSH State: PAUSED
06-06 22:34:30.379+0900 I/efl-extension(  563): efl_extension_rotary.c: eext_rotary_object_event_callback_add(147) > In
06-06 22:34:30.379+0900 I/efl-extension(  563): efl_extension_rotary.c: eext_rotary_object_event_activated_set(283) > eext_rotary_object_event_activated_set : 0xb8083b08, elm_image, _activated_obj : 0xb805aec0, activated : 1
06-06 22:34:30.379+0900 I/efl-extension(  563): efl_extension_rotary.c: eext_rotary_object_event_activated_set(291) > Activation delete!!!!
06-06 22:34:31.089+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8073600), block(1)
06-06 22:34:31.089+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8073600), ev->cur.canvas.x(186) ev->cur.canvas.y(295)
06-06 22:34:31.089+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8073600), hold(0) freeze(0)
06-06 22:34:31.089+0900 E/EFL     (  563): evas_main<563> evas_events.c:1009 evas_event_feed_mouse_down() ButtonEvent:down time=19846826 button=1 downs=1
06-06 22:34:31.089+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8073600), block(1)
06-06 22:34:31.089+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8073600), ev->cur.canvas.x(188) ev->cur.canvas.y(295)
06-06 22:34:31.089+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8073600), hold(0) freeze(0)
06-06 22:34:31.099+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8073600), block(1)
06-06 22:34:31.099+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8073600), ev->cur.canvas.x(189) ev->cur.canvas.y(295)
06-06 22:34:31.099+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8073600), hold(0) freeze(0)
06-06 22:34:31.119+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8073600), block(1)
06-06 22:34:31.119+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8073600), ev->cur.canvas.x(190) ev->cur.canvas.y(295)
06-06 22:34:31.119+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8073600), hold(0) freeze(0)
06-06 22:34:31.119+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8073600), block(1)
06-06 22:34:31.119+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8073600), ev->cur.canvas.x(191) ev->cur.canvas.y(295)
06-06 22:34:31.119+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8073600), hold(0) freeze(0)
06-06 22:34:31.129+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8073600), block(1)
06-06 22:34:31.129+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8073600), ev->cur.canvas.x(192) ev->cur.canvas.y(295)
06-06 22:34:31.129+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8073600), hold(0) freeze(0)
06-06 22:34:31.139+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8073600), block(1)
06-06 22:34:31.139+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8073600), ev->cur.canvas.x(195) ev->cur.canvas.y(296)
06-06 22:34:31.139+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8073600), hold(0) freeze(0)
06-06 22:34:31.159+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8073600), block(1)
06-06 22:34:31.159+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8073600), ev->cur.canvas.x(196) ev->cur.canvas.y(296)
06-06 22:34:31.159+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8073600), hold(0) freeze(0)
06-06 22:34:31.169+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8073600), block(1)
06-06 22:34:31.169+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8073600), ev->cur.canvas.x(196) ev->cur.canvas.y(298)
06-06 22:34:31.169+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8073600), hold(0) freeze(0)
06-06 22:34:31.179+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8073600), block(1)
06-06 22:34:31.179+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8073600), ev->cur.canvas.x(206) ev->cur.canvas.y(298)
06-06 22:34:31.179+0900 E/EFL     (  563): elementary<563> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8073600), hold(0) freeze(0)
06-06 22:34:31.209+0900 E/EFL     (  563): evas_main<563> evas_events.c:1275 evas_event_feed_mouse_up() ButtonEvent:up time=19846931 button=1 downs=0
06-06 22:34:31.609+0900 W/CRASH_MANAGER(  339): worker.c: worker_job(1199) > 1100563756963146522007
