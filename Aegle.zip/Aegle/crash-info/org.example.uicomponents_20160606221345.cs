S/W Version Information
Model: SM-R735S
Tizen-Version: 2.3.1.2
Build-Number: R735SKSU1AOKE
Build-Date: 2015.11.25 20:46:58

Crash Information
Process Name: uicomponents
PID: 31068
Date: 2016-06-06 22:13:45+0900
Executable File Path: /opt/usr/apps/org.example.uicomponents/bin/uicomponents
Signal: 11
      (SIGSEGV)
      si_code: -6
      signal sent by tkill (sent by pid 31068, uid 5000)

Register Information
r0   = 0x00000000, r1   = 0xb6c5ec78
r2   = 0x77a18700, r3   = 0x00000000
r4   = 0xb8930c28, r5   = 0xb88f47d0
r6   = 0x00000001, r7   = 0xb8930c28
r8   = 0x00000000, r9   = 0xb6ebf4c8
r10  = 0xb6ebf58c, fp   = 0xb87a1150
ip   = 0xb6c6f738, sp   = 0xbedf61a0
lr   = 0xb6c5c7f3, pc   = 0xb6a609d0
cpsr = 0x60000010

Memory Information
MemTotal:   407572 KB
MemFree:     11100 KB
Buffers:     11756 KB
Cached:      92012 KB
VmPeak:      77688 KB
VmSize:      75524 KB
VmLck:           0 KB
VmPin:           0 KB
VmHWM:       19520 KB
VmRSS:       19520 KB
VmData:      15676 KB
VmStk:         136 KB
VmExe:          20 KB
VmLib:       24764 KB
VmPTE:          56 KB
VmSwap:          0 KB

Threads Information
Threads: 2
PID = 31068 TID = 31068
31068 31262 

Maps Information
b2987000 b298b000 r-xp /usr/lib/libogg.so.0.7.1
b2993000 b29b5000 r-xp /usr/lib/libvorbis.so.0.4.3
b29bd000 b29c5000 r-xp /usr/lib/libmdm-common.so.1.0.89
b29c6000 b2a09000 r-xp /usr/lib/libsndfile.so.1.0.25
b2a16000 b2a5e000 r-xp /usr/lib/pulseaudio/libpulsecommon-4.0.so
b2a5f000 b2a64000 r-xp /usr/lib/libjson.so.0.0.1
b2a6c000 b2a9d000 r-xp /usr/lib/libmdm.so.1.1.85
b2aa5000 b2aad000 r-xp /usr/lib/lib_DNSe_NRSS_ver225.so
b2abc000 b2acc000 r-xp /usr/lib/lib_SamsungRec_TizenV04014.so
b2aed000 b2afa000 r-xp /usr/lib/libail.so.0.1.0
b2b03000 b2b06000 r-xp /usr/lib/libsyspopup_caller.so.0.1.0
b2b0e000 b2b46000 r-xp /usr/lib/libpulse.so.0.16.2
b2b47000 b2ba8000 r-xp /usr/lib/libasound.so.2.0.0
b2bb2000 b2bb5000 r-xp /usr/lib/libpulse-simple.so.0.0.4
b2bbd000 b2bc2000 r-xp /usr/lib/libascenario-0.2.so.0.0.0
b2bca000 b2be3000 r-xp /usr/lib/libavsysaudio.so.0.0.1
b2bec000 b2bf0000 r-xp /usr/lib/libmmfsoundcommon.so.0.0.0
b2bf9000 b2c03000 r-xp /usr/lib/libaudio-session-mgr.so.0.0.0
b2c0f000 b2c14000 r-xp /usr/lib/libmmfsession.so.0.0.0
b2c1c000 b2c32000 r-xp /usr/lib/libmmfsound.so.0.1.0
b2c44000 b2c4b000 r-xp /usr/lib/libmmfcommon.so.0.0.0
b2c53000 b2c5d000 r-xp /usr/lib/libcapi-media-sound-manager.so.0.1.48
b2c65000 b2c67000 r-xp /usr/lib/libcapi-media-wav-player.so.0.1.10
b2c6f000 b2c70000 r-xp /usr/lib/libmmfkeysound.so.0.0.0
b2c78000 b2c7f000 r-xp /usr/lib/libfeedback.so.0.1.4
b2c9e000 b2c9f000 r-xp /usr/lib/edje/modules/feedback/linux-gnueabi-armv7l-1.0.0/module.so
b2ca7000 b2d2e000 rw-s anon_inode:dmabuf
b2d2e000 b2db5000 rw-s anon_inode:dmabuf
b2db5000 b2e3c000 rw-s anon_inode:dmabuf
b2f46000 b2fcd000 rw-s anon_inode:dmabuf
b31a7000 b39a6000 rwxp [stack:31262]
b39a6000 b39bd000 r-xp /usr/lib/edje/modules/elm/linux-gnueabi-armv7l-1.0.0/module.so
b39ca000 b39cc000 r-xp /usr/lib/libgenlock.so
b39d5000 b39d6000 r-xp /usr/lib/evas/modules/loaders/eet/linux-gnueabi-armv7l-1.7.99/module.so
b39de000 b39e0000 r-xp /usr/lib/evas/modules/loaders/png/linux-gnueabi-armv7l-1.7.99/module.so
b39ea000 b39ef000 r-xp /usr/lib/bufmgr/libtbm_msm.so.0.0.0
b39f7000 b3a02000 r-xp /usr/lib/evas/modules/engines/software_generic/linux-gnueabi-armv7l-1.7.99/module.so
b3d2a000 b3df4000 r-xp /usr/lib/libCOREGL.so.4.0
b3e05000 b3e0a000 r-xp /usr/lib/libcapi-media-tool.so.0.1.5
b3e12000 b3e33000 r-xp /usr/lib/libexif.so.12.3.3
b3e46000 b3e4b000 r-xp /usr/lib/libmmutil_imgp.so.0.0.0
b3e53000 b3e58000 r-xp /usr/lib/libmmutil_jpeg.so.0.0.0
b53e7000 b53e9000 r-xp /usr/lib/libdri2.so.0.0.0
b53f1000 b53f9000 r-xp /usr/lib/libdrm.so.2.4.0
b5401000 b5404000 r-xp /usr/lib/libcapi-media-image-util.so.0.3.5
b540c000 b54f0000 r-xp /usr/lib/libicuuc.so.51.1
b5505000 b5642000 r-xp /usr/lib/libicui18n.so.51.1
b5652000 b5657000 r-xp /usr/lib/libcapi-system-info.so.0.2.0
b565f000 b5665000 r-xp /usr/lib/libxcb-render.so.0.0.0
b566d000 b566e000 r-xp /usr/lib/libxcb-shm.so.0.0.0
b5677000 b567a000 r-xp /usr/lib/libEGL.so.1.4
b5682000 b5690000 r-xp /usr/lib/libGLESv2.so.2.0
b5699000 b56a0000 r-xp /usr/lib/libtbm.so.1.0.0
b56a8000 b56c9000 r-xp /usr/lib/libui-extension.so.0.1.0
b56d2000 b56e4000 r-xp /usr/lib/libtts.so
b56ec000 b57a4000 r-xp /usr/lib/libcairo.so.2.11200.14
b57af000 b57c1000 r-xp /usr/lib/libefl-assist.so.0.1.0
b57c9000 b57ea000 r-xp /usr/lib/libefl-extension.so.0.1.0
b57f2000 b5805000 r-xp /opt/usr/apps/org.example.uicomponents/bin/uicomponents
b59cc000 b59d6000 r-xp /lib/libnss_files-2.13.so
b59df000 b5aae000 r-xp /usr/lib/libscim-1.0.so.8.2.3
b5ac4000 b5ae8000 r-xp /usr/lib/ecore/immodules/libisf-imf-module.so
b5af1000 b5af7000 r-xp /usr/lib/libappsvc.so.0.1.0
b5aff000 b5b01000 r-xp /usr/lib/libcapi-appfw-app-common.so.0.3.2.5
b5b0a000 b5b0f000 r-xp /usr/lib/libcapi-appfw-app-control.so.0.3.2.5
b5b1a000 b5b25000 r-xp /usr/lib/evas/modules/engines/software_x11/linux-gnueabi-armv7l-1.7.99/module.so
b5b2d000 b5b2f000 r-xp /usr/lib/libiniparser.so.0
b5b38000 b5b3d000 r-xp /usr/lib/libappcore-common.so.1.1
b5b46000 b5b4e000 r-xp /usr/lib/libcapi-system-system-settings.so.0.0.2
b5b4f000 b5b53000 r-xp /usr/lib/libcapi-appfw-application.so.0.3.2.5
b5b60000 b5b62000 r-xp /usr/lib/libXau.so.6.0.0
b5b6b000 b5b72000 r-xp /lib/libcrypt-2.13.so
b5ba2000 b5ba4000 r-xp /usr/lib/libiri.so
b5bac000 b5d54000 r-xp /usr/lib/libcrypto.so.1.0.0
b5d6d000 b5dba000 r-xp /usr/lib/libssl.so.1.0.0
b5dc7000 b5df5000 r-xp /usr/lib/libidn.so.11.5.44
b5dfd000 b5e06000 r-xp /usr/lib/libcares.so.2.1.0
b5e0f000 b5e22000 r-xp /usr/lib/libxcb.so.1.1.0
b5e2b000 b5e2d000 r-xp /usr/lib/journal/libjournal.so.0.1.0
b5e36000 b5e38000 r-xp /usr/lib/libSLP-db-util.so.0.1.0
b5e41000 b5f0d000 r-xp /usr/lib/libxml2.so.2.7.8
b5f1a000 b5f1c000 r-xp /usr/lib/libgmodule-2.0.so.0.3200.3
b5f24000 b5f29000 r-xp /usr/lib/libffi.so.5.0.10
b5f31000 b5f32000 r-xp /usr/lib/libgthread-2.0.so.0.3200.3
b5f3b000 b5f46000 r-xp /usr/lib/libgpg-error.so.0.15.0
b5f4e000 b5f51000 r-xp /lib/libattr.so.1.1.0
b5f59000 b5fed000 r-xp /usr/lib/libstdc++.so.6.0.16
b6000000 b601c000 r-xp /usr/lib/libsecurity-server-commons.so.1.0.0
b6025000 b603d000 r-xp /usr/lib/libpng12.so.0.50.0
b6046000 b605c000 r-xp /lib/libexpat.so.1.5.2
b6066000 b60aa000 r-xp /usr/lib/libcurl.so.4.3.0
b60b3000 b60bd000 r-xp /usr/lib/libXext.so.6.4.0
b60c6000 b60c9000 r-xp /usr/lib/libXtst.so.6.1.0
b60d2000 b60d8000 r-xp /usr/lib/libXrender.so.1.3.0
b60e1000 b60e7000 r-xp /usr/lib/libXrandr.so.2.2.0
b60ef000 b60f0000 r-xp /usr/lib/libXinerama.so.1.0.0
b60f9000 b6102000 r-xp /usr/lib/libXi.so.6.1.0
b610a000 b610d000 r-xp /usr/lib/libXfixes.so.3.1.0
b6115000 b6117000 r-xp /usr/lib/libXgesture.so.7.0.0
b611f000 b6121000 r-xp /usr/lib/libXcomposite.so.1.0.0
b612a000 b612c000 r-xp /usr/lib/libXdamage.so.1.1.0
b6134000 b613b000 r-xp /usr/lib/libXcursor.so.1.0.2
b6143000 b6146000 r-xp /usr/lib/libecore_input_evas.so.1.7.99
b614e000 b6152000 r-xp /usr/lib/libecore_ipc.so.1.7.99
b615b000 b6160000 r-xp /usr/lib/libecore_fb.so.1.7.99
b616a000 b624b000 r-xp /usr/lib/libX11.so.6.3.0
b6256000 b6279000 r-xp /usr/lib/libjpeg.so.8.0.2
b6291000 b62a7000 r-xp /lib/libz.so.1.2.5
b62af000 b6324000 r-xp /usr/lib/libsqlite3.so.0.8.6
b632e000 b6343000 r-xp /usr/lib/libpkgmgr_parser.so.0.1.0
b634c000 b6380000 r-xp /usr/lib/libgobject-2.0.so.0.3200.3
b6389000 b645c000 r-xp /usr/lib/libgio-2.0.so.0.3200.3
b6467000 b6477000 r-xp /lib/libresolv-2.13.so
b647b000 b64f7000 r-xp /usr/lib/libgcrypt.so.20.0.3
b6503000 b651b000 r-xp /usr/lib/liblzma.so.5.0.3
b6524000 b6527000 r-xp /lib/libcap.so.2.21
b652f000 b6555000 r-xp /usr/lib/libsecurity-server-client.so.1.0.1
b655e000 b655f000 r-xp /usr/lib/libecore_imf_evas.so.1.7.99
b6567000 b656d000 r-xp /usr/lib/libecore_imf.so.1.7.99
b6575000 b658c000 r-xp /usr/lib/liblua-5.1.so
b6596000 b659d000 r-xp /usr/lib/libembryo.so.1.7.99
b65a5000 b65ab000 r-xp /lib/librt-2.13.so
b65b4000 b660a000 r-xp /usr/lib/libpixman-1.so.0.28.2
b6617000 b666d000 r-xp /usr/lib/libfreetype.so.6.11.3
b6679000 b66a1000 r-xp /usr/lib/libfontconfig.so.1.8.0
b66a3000 b66e0000 r-xp /usr/lib/libharfbuzz.so.0.940.0
b66e9000 b66fc000 r-xp /usr/lib/libfribidi.so.0.3.1
b6704000 b671e000 r-xp /usr/lib/libecore_con.so.1.7.99
b6727000 b6730000 r-xp /usr/lib/libedbus.so.1.7.99
b6738000 b6788000 r-xp /usr/lib/libecore_x.so.1.7.99
b678b000 b678f000 r-xp /usr/lib/libvconf.so.0.2.45
b6797000 b67a8000 r-xp /usr/lib/libecore_input.so.1.7.99
b67b0000 b67b5000 r-xp /usr/lib/libecore_file.so.1.7.99
b67bd000 b67df000 r-xp /usr/lib/libecore_evas.so.1.7.99
b67e8000 b6829000 r-xp /usr/lib/libeina.so.1.7.99
b6832000 b684b000 r-xp /usr/lib/libeet.so.1.7.99
b685c000 b68c5000 r-xp /lib/libm-2.13.so
b68ce000 b68d4000 r-xp /usr/lib/libcapi-base-common.so.0.1.8
b68dd000 b68e0000 r-xp /usr/lib/libproc-stat.so.0.2.86
b68e8000 b690a000 r-xp /usr/lib/libpkgmgr-info.so.0.0.17
b6912000 b6917000 r-xp /usr/lib/libxdgmime.so.1.1.0
b691f000 b6949000 r-xp /usr/lib/libdbus-1.so.3.8.12
b6952000 b6969000 r-xp /usr/lib/libdbus-glib-1.so.2.2.2
b6971000 b697c000 r-xp /lib/libunwind.so.8.0.1
b69a9000 b69e5000 r-xp /usr/lib/libsystemd.so.0.4.0
b69ee000 b6b09000 r-xp /lib/libc-2.13.so
b6b17000 b6b1f000 r-xp /lib/libgcc_s-4.6.so.1
b6b20000 b6b23000 r-xp /usr/lib/libsmack.so.1.0.0
b6b2b000 b6b31000 r-xp /usr/lib/libprivilege-control.so.0.0.2
b6b39000 b6c09000 r-xp /usr/lib/libglib-2.0.so.0.3200.3
b6c0a000 b6c67000 r-xp /usr/lib/libedje.so.1.7.99
b6c71000 b6c88000 r-xp /usr/lib/libecore.so.1.7.99
b6c9f000 b6d6e000 r-xp /usr/lib/libevas.so.1.7.99
b6d92000 b6ecc000 r-xp /usr/lib/libelementary.so.1.7.99
b6ee2000 b6ef6000 r-xp /lib/libpthread-2.13.so
b6f01000 b6f03000 r-xp /usr/lib/libdlog.so.0.0.0
b6f0b000 b6f0e000 r-xp /usr/lib/libbundle.so.0.1.22
b6f16000 b6f18000 r-xp /lib/libdl-2.13.so
b6f21000 b6f2d000 r-xp /usr/lib/libaul.so.0.1.0
b6f3f000 b6f44000 r-xp /usr/lib/libappcore-efl.so.1.1
b6f4d000 b6f51000 r-xp /usr/lib/libsys-assert.so
b6f5a000 b6f77000 r-xp /lib/ld-2.13.so
b6f80000 b6f85000 r-xp /usr/bin/launchpad-loader
b86a9000 b8990000 rw-p [heap]
bedd6000 bedf7000 rwxp [stack]
End of Maps Information

Callstack Information (PID:31068)
Call Stack Count: 1
 0: strcmp + 0x0 (0xb6a609d0) [/lib/libc.so.6] + 0x729d0
End of Call Stack

Package Information
Package Name: org.example.uicomponents
Package ID : org.example.uicomponents
Version: 1.0.0
Package Type: rpm
App Name: uicomponents
App ID: org.example.uicomponents
Type: capp
Categories: 

Latest Debug Message Information
--------- beginning of /dev/log_main
-06 22:13:41.109+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:41.109+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:41.109+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:41.109+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:41.109+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:41.109+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:41.109+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:41.109+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:41.109+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:41.109+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:41.109+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:41.109+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:41.109+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:41.109+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:41.109+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:41.109+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:41.109+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:41.109+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:41.109+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:41.109+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:41.109+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:41.109+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:41.109+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:41.109+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:41.109+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:41.109+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:41.109+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:41.109+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:41.109+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:41.109+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:41.109+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:41.109+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:41.109+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:41.109+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:41.109+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:41.109+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:41.109+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:41.109+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:41.109+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:41.109+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:41.109+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:41.109+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:41.109+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:41.109+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:41.109+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:41.109+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:41.109+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:41.109+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:41.109+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:41.109+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:41.109+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:41.109+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:41.109+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:41.109+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:41.109+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:41.109+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:41.109+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:41.109+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:41.119+0900 E/EFL     (31068): edje<31068> edje_util.c:3770 edje_object_size_min_restricted_calc() group entry_layout has a non-fixed part 'entry_part'. Adding 'fixed: 1 1;' to source EDC may help. Continuing discarding faulty part.
06-06 22:13:41.119+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:41.119+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:41.119+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:41.119+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:41.119+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:41.119+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:41.119+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:41.119+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:41.119+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:41.119+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:41.119+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:41.119+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:41.119+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:41.119+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:41.119+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:41.139+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:41.139+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:41.139+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:41.139+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:41.139+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:41.139+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:41.139+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:41.139+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:41.139+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:41.139+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:41.139+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:41.139+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:41.139+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:41.139+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:41.139+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:41.189+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:41.189+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:41.189+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:41.189+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:41.189+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:41.189+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:41.189+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:41.189+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:41.189+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:41.189+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:41.189+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:41.189+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:41.189+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:41.189+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:41.189+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:41.239+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:41.239+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:41.239+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:41.239+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:41.239+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:41.239+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:41.239+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:41.239+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:41.239+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:41.239+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:41.239+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:41.239+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:41.239+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:41.239+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:41.239+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:41.289+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:41.289+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:41.289+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:41.289+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:41.289+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:41.289+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:41.289+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:41.289+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:41.289+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:41.289+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:41.289+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:41.289+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:41.289+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:41.289+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:41.289+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:41.339+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:41.339+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:41.339+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:41.339+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:41.339+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:41.339+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:41.339+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:41.339+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:41.339+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:41.339+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:41.339+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:41.339+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:41.339+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:41.339+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:41.339+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:41.379+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:41.379+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:41.379+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:41.379+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:41.379+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:41.379+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:41.379+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:41.379+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:41.379+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:41.379+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:41.379+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:41.379+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:41.379+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:41.379+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:41.379+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:41.419+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:41.419+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:41.419+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:41.419+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:41.419+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:41.419+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:41.419+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:41.419+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:41.419+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:41.419+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:41.419+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:41.419+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:41.419+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:41.419+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:41.419+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:41.469+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:41.469+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:41.469+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:41.469+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:41.469+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:41.469+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:41.469+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:41.469+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:41.469+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:41.469+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:41.469+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:41.469+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:41.469+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:41.469+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:41.469+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:41.519+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:41.519+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:41.519+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:41.519+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:41.519+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:41.519+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:41.519+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:41.519+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:41.519+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:41.519+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:41.519+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:41.519+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:41.519+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:41.519+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:41.519+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:41.569+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:41.569+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:41.569+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:41.569+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:41.569+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:41.569+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:41.569+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:41.569+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:41.569+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:41.569+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:41.569+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:41.569+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:41.569+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:41.569+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:41.569+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:41.589+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:41.589+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:41.589+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:41.589+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:41.589+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:41.589+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:41.589+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:41.589+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:41.589+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:41.589+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:41.589+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:41.589+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:41.589+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:41.589+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:41.589+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:41.589+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:41.589+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:41.589+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:41.589+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:41.589+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:41.589+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:42.309+0900 I/APP_CORE( 1184): appcore-efl.c: __do_app(429) > [APP 1184] Event: MEM_FLUSH State: PAUSED
06-06 22:13:44.559+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:44.559+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:44.559+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:44.559+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:44.559+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:44.559+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:44.559+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:44.559+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:44.559+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:44.559+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:44.559+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:44.559+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:44.559+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:44.559+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:44.559+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:44.659+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:44.659+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:44.659+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:44.659+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:44.659+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:44.659+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:44.659+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:44.659+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:44.659+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:44.659+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:44.659+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:44.659+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:44.659+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:44.659+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:44.659+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:44.729+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:44.729+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:44.729+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:44.729+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:44.729+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:44.729+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:44.729+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:44.729+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:44.729+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:44.729+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:44.729+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:44.729+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:44.729+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:44.729+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:44.729+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:44.759+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:44.759+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:44.759+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:44.759+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:44.759+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:44.759+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:44.759+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:44.759+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:44.759+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:44.759+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:44.759+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:44.759+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:44.759+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:44.759+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:44.759+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:44.789+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:44.789+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:44.789+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:44.789+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:44.789+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:44.789+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:44.789+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:44.789+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:44.789+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:44.789+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:44.789+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:44.789+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:44.789+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:44.789+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:44.789+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:44.819+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:44.819+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:44.819+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:44.819+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:44.819+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:44.819+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:44.819+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:44.819+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:44.819+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:44.819+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:44.819+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:44.819+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:44.819+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:44.819+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:44.819+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:44.859+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:44.859+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:44.859+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:44.859+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:44.859+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:44.859+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:44.859+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:44.859+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:44.859+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:44.859+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:44.859+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:44.859+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:44.859+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:44.859+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:44.859+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:44.889+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:44.889+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:44.889+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:44.889+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:44.889+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:44.889+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:44.889+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:44.889+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:44.889+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:44.889+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:44.889+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:44.889+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:44.889+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:44.889+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:44.889+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:44.919+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:44.919+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:44.919+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:44.919+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:44.919+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:44.919+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:44.919+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:44.919+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:44.919+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:44.919+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:44.919+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:44.919+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:44.919+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:44.919+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:44.919+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:44.959+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:44.959+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:44.959+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:44.959+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:44.959+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:44.959+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:44.959+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:44.959+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:44.959+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:44.959+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:44.959+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:44.959+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:44.959+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:44.959+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:44.959+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:44.969+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:44.969+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:44.969+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:44.969+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:44.969+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:44.969+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:44.969+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:44.969+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:44.969+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:44.969+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:44.969+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:44.969+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:44.969+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:44.969+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:44.969+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:44.999+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:44.999+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:44.999+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:44.999+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:44.999+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:44.999+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:44.999+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:44.999+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:44.999+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:44.999+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:44.999+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:44.999+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:44.999+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:44.999+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:44.999+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:44.999+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:44.999+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:44.999+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:44.999+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:44.999+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:44.999+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:44.999+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:44.999+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:44.999+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:44.999+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:44.999+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:44.999+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:44.999+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:44.999+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:44.999+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:44.999+0900 E/EFL     (31068): elementary<31068> elm_widget.c:386 _elm_widget_sub_object_del_func() removing sub object 0xb88f47d0 ((null)) from parent 0xb8926748 (elm_layout), but elm-parent is different (nil) ((null))!
06-06 22:13:44.999+0900 E/EFL     (31068): elementary<31068> elm_widget.c:675 _smart_del() failed to remove sub object 0xb88f47d0 from 0xb8926748
06-06 22:13:44.999+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:44.999+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:44.999+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:44.999+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:44.999+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:44.999+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:44.999+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:44.999+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:44.999+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:44.999+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:44.999+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:44.999+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:44.999+0900 F/EFL     (31068): evas_main<31068> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:13:44.999+0900 F/EFL     (31068):     Expected: 71737723 - Evas_Object
06-06 22:13:44.999+0900 F/EFL     (31068):     Supplied: b8886b48 - <UNKNOWN>
06-06 22:13:45.319+0900 I/AUL_AMD (  905): amd_main.c: __app_dead_handler(261) > __app_dead_handler, pid: 31068
06-06 22:13:45.319+0900 W/AUL_AMD (  905): amd_key.c: _key_ungrab(254) > fail(-1) to ungrab key(XF86Stop)
06-06 22:13:45.319+0900 W/AUL_AMD (  905): amd_launch.c: __e17_status_handler(2194) > back key ungrab error
06-06 22:13:45.379+0900 W/PROCESSMGR(  585): e_mod_processmgr.c: _e_mod_processmgr_send_update_watch_action(639) > [PROCESSMGR] =====================> send UpdateClock
06-06 22:13:45.389+0900 W/WATCH_CORE(12148): appcore-watch.c: __signal_process_manager_handler(1163) > process_manager_signal
06-06 22:13:45.389+0900 I/WATCH_CORE(12148): appcore-watch.c: __signal_process_manager_handler(1179) > Call the time_tick_cb
06-06 22:13:45.389+0900 I/CAPI_WATCH_APPLICATION(12148): watch_app_main.c: _watch_core_time_tick(306) > _watch_core_time_tick
06-06 22:13:45.389+0900 E/watchface-loader(12148): watchface-loader.cpp: OnAppTimeTick(744) > 
06-06 22:13:45.389+0900 I/watchface-loader(12148): watchface-loader.cpp: OnAppTimeTick(756) > set force update!!
06-06 22:13:45.399+0900 W/W_HOME  ( 1184): event_manager.c: _ecore_x_message_cb(403) > state: 1 -> 0
06-06 22:13:45.399+0900 W/W_HOME  ( 1184): event_manager.c: _state_control(194) > control:4, app_state:2 win_state:0(0) pm_state:1 home_visible:1 clock_visible:1 tutorial_state:0 editing : 0, home_clocklist:0, addviewer:0 scrolling : 0, powersaving : 0, apptray state : 1, apptray visibility : 0, apptray edit visibility : 0
06-06 22:13:45.399+0900 W/W_HOME  ( 1184): event_manager.c: _state_control(194) > control:2, app_state:2 win_state:0(0) pm_state:1 home_visible:1 clock_visible:1 tutorial_state:0 editing : 0, home_clocklist:0, addviewer:0 scrolling : 0, powersaving : 0, apptray state : 1, apptray visibility : 0, apptray edit visibility : 0
06-06 22:13:45.409+0900 W/W_HOME  ( 1184): event_manager.c: _state_control(194) > control:1, app_state:2 win_state:0(0) pm_state:1 home_visible:1 clock_visible:1 tutorial_state:0 editing : 0, home_clocklist:0, addviewer:0 scrolling : 0, powersaving : 0, apptray state : 1, apptray visibility : 0, apptray edit visibility : 0
06-06 22:13:45.409+0900 W/W_HOME  ( 1184): main.c: _ecore_x_message_cb(1233) > main_info.is_win_on_top: 1
06-06 22:13:45.469+0900 W/W_HOME  ( 1184): event_manager.c: _window_visibility_cb(448) > Window [0x2C00003] is now visible(0)
06-06 22:13:45.469+0900 W/W_HOME  ( 1184): event_manager.c: _window_visibility_cb(458) > state: 0 -> 1
06-06 22:13:45.469+0900 W/W_HOME  ( 1184): event_manager.c: _state_control(194) > control:4, app_state:2 win_state:0(1) pm_state:1 home_visible:1 clock_visible:1 tutorial_state:0 editing : 0, home_clocklist:0, addviewer:0 scrolling : 0, powersaving : 0, apptray state : 1, apptray visibility : 0, apptray edit visibility : 0
06-06 22:13:45.469+0900 W/W_HOME  ( 1184): main.c: _window_visibility_cb(1200) > Window [0x2C00003] is now visible(0)
06-06 22:13:45.469+0900 I/APP_CORE( 1184): appcore-efl.c: __do_app(429) > [APP 1184] Event: RESUME State: PAUSED
06-06 22:13:45.469+0900 I/CAPI_APPFW_APPLICATION( 1184): app_main.c: app_appcore_resume(223) > app_appcore_resume
06-06 22:13:45.469+0900 W/W_HOME  ( 1184): main.c: _appcore_resume_cb(683) > appcore resume
06-06 22:13:45.469+0900 W/W_HOME  ( 1184): event_manager.c: _app_resume_cb(355) > state: 2 -> 1
06-06 22:13:45.469+0900 W/W_HOME  ( 1184): event_manager.c: _state_control(194) > control:2, app_state:1 win_state:0(1) pm_state:1 home_visible:1 clock_visible:1 tutorial_state:0 editing : 0, home_clocklist:0, addviewer:0 scrolling : 0, powersaving : 0, apptray state : 1, apptray visibility : 0, apptray edit visibility : 0
06-06 22:13:45.519+0900 W/W_HOME  ( 1184): event_manager.c: _state_control(194) > control:0, app_state:1 win_state:0(1) pm_state:1 home_visible:1 clock_visible:1 tutorial_state:0 editing : 0, home_clocklist:0, addviewer:0 scrolling : 0, powersaving : 0, apptray state : 1, apptray visibility : 0, apptray edit visibility : 0
06-06 22:13:45.519+0900 W/W_HOME  ( 1184): main.c: home_resume(731) > journal_appcore_app_fully_loaded called
06-06 22:13:45.519+0900 W/W_HOME  ( 1184): main.c: home_resume(735) > clock/widget resumed
06-06 22:13:45.519+0900 W/W_HOME  ( 1184): event_manager.c: _state_control(194) > control:1, app_state:1 win_state:0(1) pm_state:1 home_visible:1 clock_visible:1 tutorial_state:0 editing : 0, home_clocklist:0, addviewer:0 scrolling : 0, powersaving : 0, apptray state : 1, apptray visibility : 0, apptray edit visibility : 0
06-06 22:13:45.519+0900 I/wnotib  ( 1184): w-notification-board-broker-main.c: _wnotib_ecore_x_event_visibility_changed_cb(701) > fully_obscured: 0
06-06 22:13:45.519+0900 E/wnotib  ( 1184): w-notification-board-action-drawer.c: wnotib_action_drawer_hidden_get(4570) > [NULL==g_wnotib_action_drawer_data] msg Drawer not initialized.
06-06 22:13:45.519+0900 W/wnotib  ( 1184): w-notification-board-noti-manager.c: wnotib_noti_manager_do_postponed_job(1695) > No postponed update.
06-06 22:13:45.539+0900 I/GESTURE (  239): gesture.c: BackGestureSetProperty(4501) > [BackGestureSetProperty] atom=_E_MOVE_W_HOME_CLOCK_STATE, value=1, Clock display 
06-06 22:13:45.569+0900 W/WATCH_CORE(12148): appcore-watch.c: __widget_resume(1012) > widget_resume
06-06 22:13:45.569+0900 E/watchface-loader(12148): watchface-loader.cpp: OnAppResume(725) > 
06-06 22:13:45.569+0900 I/CAPI_WATCH_APPLICATION(12148): watch_app_main.c: _watch_core_time_tick(306) > _watch_core_time_tick
06-06 22:13:45.569+0900 E/watchface-loader(12148): watchface-loader.cpp: OnAppTimeTick(744) > 
06-06 22:13:45.739+0900 I/CAPI_WATCH_APPLICATION(12148): watch_app_main.c: _watch_core_time_tick(306) > _watch_core_time_tick
06-06 22:13:45.739+0900 E/watchface-loader(12148): watchface-loader.cpp: OnAppTimeTick(744) > 
06-06 22:13:45.829+0900 W/CRASH_MANAGER(31265): worker.c: worker_job(1199) > 1131068756963146521882
