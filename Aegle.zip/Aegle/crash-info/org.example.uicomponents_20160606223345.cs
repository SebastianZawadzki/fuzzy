S/W Version Information
Model: SM-R735S
Tizen-Version: 2.3.1.2
Build-Number: R735SKSU1AOKE
Build-Date: 2015.11.25 20:46:58

Crash Information
Process Name: uicomponents
PID: 32474
Date: 2016-06-06 22:33:45+0900
Executable File Path: /opt/usr/apps/org.example.uicomponents/bin/uicomponents
Signal: 11
      (SIGSEGV)
      si_code: -6
      signal sent by tkill (sent by pid 32474, uid 5000)

Register Information
r0   = 0x00000000, r1   = 0xb6c87c78
r2   = 0xb8d32b00, r3   = 0x00000000
r4   = 0xb8191d00, r5   = 0xb7f37780
r6   = 0x00000001, r7   = 0xb8191d00
r8   = 0x00000000, r9   = 0xb6ee84c8
r10  = 0xb6ee858c, fp   = 0xb7ff6ec8
ip   = 0xb6c98738, sp   = 0xbeaee0e8
lr   = 0xb6c857f3, pc   = 0xb6a899d0
cpsr = 0x60000010

Memory Information
MemTotal:   407572 KB
MemFree:      7312 KB
Buffers:     13020 KB
Cached:      91728 KB
VmPeak:      77712 KB
VmSize:      75548 KB
VmLck:           0 KB
VmPin:           0 KB
VmHWM:       20080 KB
VmRSS:       20080 KB
VmData:      16876 KB
VmStk:         136 KB
VmExe:          20 KB
VmLib:       24780 KB
VmPTE:          56 KB
VmSwap:          0 KB

Threads Information
Threads: 2
PID = 32474 TID = 32474
32474 32736 

Maps Information
b28df000 b28e0000 r-xp /usr/lib/evas/modules/savers/jpeg/linux-gnueabi-armv7l-1.7.99/module.so
b28e8000 b28ec000 r-xp /usr/lib/libogg.so.0.7.1
b28f4000 b2916000 r-xp /usr/lib/libvorbis.so.0.4.3
b291e000 b2926000 r-xp /usr/lib/libmdm-common.so.1.0.89
b2927000 b296a000 r-xp /usr/lib/libsndfile.so.1.0.25
b2977000 b29bf000 r-xp /usr/lib/pulseaudio/libpulsecommon-4.0.so
b29c0000 b29c5000 r-xp /usr/lib/libjson.so.0.0.1
b29cd000 b29fe000 r-xp /usr/lib/libmdm.so.1.1.85
b2a06000 b2a0e000 r-xp /usr/lib/lib_DNSe_NRSS_ver225.so
b2a1d000 b2a2d000 r-xp /usr/lib/lib_SamsungRec_TizenV04014.so
b2a4e000 b2a5b000 r-xp /usr/lib/libail.so.0.1.0
b2a64000 b2a67000 r-xp /usr/lib/libsyspopup_caller.so.0.1.0
b2a6f000 b2aa7000 r-xp /usr/lib/libpulse.so.0.16.2
b2aa8000 b2b09000 r-xp /usr/lib/libasound.so.2.0.0
b2b13000 b2b16000 r-xp /usr/lib/libpulse-simple.so.0.0.4
b2b1e000 b2b23000 r-xp /usr/lib/libascenario-0.2.so.0.0.0
b2b2b000 b2b44000 r-xp /usr/lib/libavsysaudio.so.0.0.1
b2b4d000 b2b51000 r-xp /usr/lib/libmmfsoundcommon.so.0.0.0
b2b5a000 b2b64000 r-xp /usr/lib/libaudio-session-mgr.so.0.0.0
b2b70000 b2b75000 r-xp /usr/lib/libmmfsession.so.0.0.0
b2b7d000 b2b93000 r-xp /usr/lib/libmmfsound.so.0.1.0
b2ba5000 b2bac000 r-xp /usr/lib/libmmfcommon.so.0.0.0
b2bb4000 b2bbe000 r-xp /usr/lib/libcapi-media-sound-manager.so.0.1.48
b2bc6000 b2bc7000 r-xp /usr/lib/edje/modules/feedback/linux-gnueabi-armv7l-1.0.0/module.so
b2bcf000 b2c56000 rw-s anon_inode:dmabuf
b2c56000 b2cdd000 rw-s anon_inode:dmabuf
b2d68000 b2def000 rw-s anon_inode:dmabuf
b2e6e000 b2ef5000 rw-s anon_inode:dmabuf
b3108000 b310a000 r-xp /usr/lib/libcapi-media-wav-player.so.0.1.10
b3112000 b3113000 r-xp /usr/lib/libmmfkeysound.so.0.0.0
b311b000 b3122000 r-xp /usr/lib/libfeedback.so.0.1.4
b312f000 b3132000 r-xp /usr/lib/evas/modules/engines/buffer/linux-gnueabi-armv7l-1.7.99/module.so
b31d0000 b39cf000 rwxp [stack:32736]
b39cf000 b39e6000 r-xp /usr/lib/edje/modules/elm/linux-gnueabi-armv7l-1.0.0/module.so
b39f3000 b39f5000 r-xp /usr/lib/libgenlock.so
b39fe000 b39ff000 r-xp /usr/lib/evas/modules/loaders/eet/linux-gnueabi-armv7l-1.7.99/module.so
b3a07000 b3a09000 r-xp /usr/lib/evas/modules/loaders/png/linux-gnueabi-armv7l-1.7.99/module.so
b3a13000 b3a18000 r-xp /usr/lib/bufmgr/libtbm_msm.so.0.0.0
b3a20000 b3a2b000 r-xp /usr/lib/evas/modules/engines/software_generic/linux-gnueabi-armv7l-1.7.99/module.so
b3d53000 b3e1d000 r-xp /usr/lib/libCOREGL.so.4.0
b3e2e000 b3e33000 r-xp /usr/lib/libcapi-media-tool.so.0.1.5
b3e3b000 b3e5c000 r-xp /usr/lib/libexif.so.12.3.3
b3e6f000 b3e74000 r-xp /usr/lib/libmmutil_imgp.so.0.0.0
b3e7c000 b3e81000 r-xp /usr/lib/libmmutil_jpeg.so.0.0.0
b5410000 b5412000 r-xp /usr/lib/libdri2.so.0.0.0
b541a000 b5422000 r-xp /usr/lib/libdrm.so.2.4.0
b542a000 b542d000 r-xp /usr/lib/libcapi-media-image-util.so.0.3.5
b5435000 b5519000 r-xp /usr/lib/libicuuc.so.51.1
b552e000 b566b000 r-xp /usr/lib/libicui18n.so.51.1
b567b000 b5680000 r-xp /usr/lib/libcapi-system-info.so.0.2.0
b5688000 b568e000 r-xp /usr/lib/libxcb-render.so.0.0.0
b5696000 b5697000 r-xp /usr/lib/libxcb-shm.so.0.0.0
b56a0000 b56a3000 r-xp /usr/lib/libEGL.so.1.4
b56ab000 b56b9000 r-xp /usr/lib/libGLESv2.so.2.0
b56c2000 b56c9000 r-xp /usr/lib/libtbm.so.1.0.0
b56d1000 b56f2000 r-xp /usr/lib/libui-extension.so.0.1.0
b56fb000 b570d000 r-xp /usr/lib/libtts.so
b5715000 b57cd000 r-xp /usr/lib/libcairo.so.2.11200.14
b57d8000 b57ea000 r-xp /usr/lib/libefl-assist.so.0.1.0
b57f2000 b5813000 r-xp /usr/lib/libefl-extension.so.0.1.0
b581b000 b582e000 r-xp /opt/usr/apps/org.example.uicomponents/bin/uicomponents
b59f5000 b59ff000 r-xp /lib/libnss_files-2.13.so
b5a08000 b5ad7000 r-xp /usr/lib/libscim-1.0.so.8.2.3
b5aed000 b5b11000 r-xp /usr/lib/ecore/immodules/libisf-imf-module.so
b5b1a000 b5b20000 r-xp /usr/lib/libappsvc.so.0.1.0
b5b28000 b5b2a000 r-xp /usr/lib/libcapi-appfw-app-common.so.0.3.2.5
b5b33000 b5b38000 r-xp /usr/lib/libcapi-appfw-app-control.so.0.3.2.5
b5b43000 b5b4e000 r-xp /usr/lib/evas/modules/engines/software_x11/linux-gnueabi-armv7l-1.7.99/module.so
b5b56000 b5b58000 r-xp /usr/lib/libiniparser.so.0
b5b61000 b5b66000 r-xp /usr/lib/libappcore-common.so.1.1
b5b6f000 b5b77000 r-xp /usr/lib/libcapi-system-system-settings.so.0.0.2
b5b78000 b5b7c000 r-xp /usr/lib/libcapi-appfw-application.so.0.3.2.5
b5b89000 b5b8b000 r-xp /usr/lib/libXau.so.6.0.0
b5b94000 b5b9b000 r-xp /lib/libcrypt-2.13.so
b5bcb000 b5bcd000 r-xp /usr/lib/libiri.so
b5bd5000 b5d7d000 r-xp /usr/lib/libcrypto.so.1.0.0
b5d96000 b5de3000 r-xp /usr/lib/libssl.so.1.0.0
b5df0000 b5e1e000 r-xp /usr/lib/libidn.so.11.5.44
b5e26000 b5e2f000 r-xp /usr/lib/libcares.so.2.1.0
b5e38000 b5e4b000 r-xp /usr/lib/libxcb.so.1.1.0
b5e54000 b5e56000 r-xp /usr/lib/journal/libjournal.so.0.1.0
b5e5f000 b5e61000 r-xp /usr/lib/libSLP-db-util.so.0.1.0
b5e6a000 b5f36000 r-xp /usr/lib/libxml2.so.2.7.8
b5f43000 b5f45000 r-xp /usr/lib/libgmodule-2.0.so.0.3200.3
b5f4d000 b5f52000 r-xp /usr/lib/libffi.so.5.0.10
b5f5a000 b5f5b000 r-xp /usr/lib/libgthread-2.0.so.0.3200.3
b5f64000 b5f6f000 r-xp /usr/lib/libgpg-error.so.0.15.0
b5f77000 b5f7a000 r-xp /lib/libattr.so.1.1.0
b5f82000 b6016000 r-xp /usr/lib/libstdc++.so.6.0.16
b6029000 b6045000 r-xp /usr/lib/libsecurity-server-commons.so.1.0.0
b604e000 b6066000 r-xp /usr/lib/libpng12.so.0.50.0
b606f000 b6085000 r-xp /lib/libexpat.so.1.5.2
b608f000 b60d3000 r-xp /usr/lib/libcurl.so.4.3.0
b60dc000 b60e6000 r-xp /usr/lib/libXext.so.6.4.0
b60ef000 b60f2000 r-xp /usr/lib/libXtst.so.6.1.0
b60fb000 b6101000 r-xp /usr/lib/libXrender.so.1.3.0
b610a000 b6110000 r-xp /usr/lib/libXrandr.so.2.2.0
b6118000 b6119000 r-xp /usr/lib/libXinerama.so.1.0.0
b6122000 b612b000 r-xp /usr/lib/libXi.so.6.1.0
b6133000 b6136000 r-xp /usr/lib/libXfixes.so.3.1.0
b613e000 b6140000 r-xp /usr/lib/libXgesture.so.7.0.0
b6148000 b614a000 r-xp /usr/lib/libXcomposite.so.1.0.0
b6153000 b6155000 r-xp /usr/lib/libXdamage.so.1.1.0
b615d000 b6164000 r-xp /usr/lib/libXcursor.so.1.0.2
b616c000 b616f000 r-xp /usr/lib/libecore_input_evas.so.1.7.99
b6177000 b617b000 r-xp /usr/lib/libecore_ipc.so.1.7.99
b6184000 b6189000 r-xp /usr/lib/libecore_fb.so.1.7.99
b6193000 b6274000 r-xp /usr/lib/libX11.so.6.3.0
b627f000 b62a2000 r-xp /usr/lib/libjpeg.so.8.0.2
b62ba000 b62d0000 r-xp /lib/libz.so.1.2.5
b62d8000 b634d000 r-xp /usr/lib/libsqlite3.so.0.8.6
b6357000 b636c000 r-xp /usr/lib/libpkgmgr_parser.so.0.1.0
b6375000 b63a9000 r-xp /usr/lib/libgobject-2.0.so.0.3200.3
b63b2000 b6485000 r-xp /usr/lib/libgio-2.0.so.0.3200.3
b6490000 b64a0000 r-xp /lib/libresolv-2.13.so
b64a4000 b6520000 r-xp /usr/lib/libgcrypt.so.20.0.3
b652c000 b6544000 r-xp /usr/lib/liblzma.so.5.0.3
b654d000 b6550000 r-xp /lib/libcap.so.2.21
b6558000 b657e000 r-xp /usr/lib/libsecurity-server-client.so.1.0.1
b6587000 b6588000 r-xp /usr/lib/libecore_imf_evas.so.1.7.99
b6590000 b6596000 r-xp /usr/lib/libecore_imf.so.1.7.99
b659e000 b65b5000 r-xp /usr/lib/liblua-5.1.so
b65bf000 b65c6000 r-xp /usr/lib/libembryo.so.1.7.99
b65ce000 b65d4000 r-xp /lib/librt-2.13.so
b65dd000 b6633000 r-xp /usr/lib/libpixman-1.so.0.28.2
b6640000 b6696000 r-xp /usr/lib/libfreetype.so.6.11.3
b66a2000 b66ca000 r-xp /usr/lib/libfontconfig.so.1.8.0
b66cc000 b6709000 r-xp /usr/lib/libharfbuzz.so.0.940.0
b6712000 b6725000 r-xp /usr/lib/libfribidi.so.0.3.1
b672d000 b6747000 r-xp /usr/lib/libecore_con.so.1.7.99
b6750000 b6759000 r-xp /usr/lib/libedbus.so.1.7.99
b6761000 b67b1000 r-xp /usr/lib/libecore_x.so.1.7.99
b67b4000 b67b8000 r-xp /usr/lib/libvconf.so.0.2.45
b67c0000 b67d1000 r-xp /usr/lib/libecore_input.so.1.7.99
b67d9000 b67de000 r-xp /usr/lib/libecore_file.so.1.7.99
b67e6000 b6808000 r-xp /usr/lib/libecore_evas.so.1.7.99
b6811000 b6852000 r-xp /usr/lib/libeina.so.1.7.99
b685b000 b6874000 r-xp /usr/lib/libeet.so.1.7.99
b6885000 b68ee000 r-xp /lib/libm-2.13.so
b68f7000 b68fd000 r-xp /usr/lib/libcapi-base-common.so.0.1.8
b6906000 b6909000 r-xp /usr/lib/libproc-stat.so.0.2.86
b6911000 b6933000 r-xp /usr/lib/libpkgmgr-info.so.0.0.17
b693b000 b6940000 r-xp /usr/lib/libxdgmime.so.1.1.0
b6948000 b6972000 r-xp /usr/lib/libdbus-1.so.3.8.12
b697b000 b6992000 r-xp /usr/lib/libdbus-glib-1.so.2.2.2
b699a000 b69a5000 r-xp /lib/libunwind.so.8.0.1
b69d2000 b6a0e000 r-xp /usr/lib/libsystemd.so.0.4.0
b6a17000 b6b32000 r-xp /lib/libc-2.13.so
b6b40000 b6b48000 r-xp /lib/libgcc_s-4.6.so.1
b6b49000 b6b4c000 r-xp /usr/lib/libsmack.so.1.0.0
b6b54000 b6b5a000 r-xp /usr/lib/libprivilege-control.so.0.0.2
b6b62000 b6c32000 r-xp /usr/lib/libglib-2.0.so.0.3200.3
b6c33000 b6c90000 r-xp /usr/lib/libedje.so.1.7.99
b6c9a000 b6cb1000 r-xp /usr/lib/libecore.so.1.7.99
b6cc8000 b6d97000 r-xp /usr/lib/libevas.so.1.7.99
b6dbb000 b6ef5000 r-xp /usr/lib/libelementary.so.1.7.99
b6f0b000 b6f1f000 r-xp /lib/libpthread-2.13.so
b6f2a000 b6f2c000 r-xp /usr/lib/libdlog.so.0.0.0
b6f34000 b6f37000 r-xp /usr/lib/libbundle.so.0.1.22
b6f3f000 b6f41000 r-xp /lib/libdl-2.13.so
b6f4a000 b6f56000 r-xp /usr/lib/libaul.so.0.1.0
b6f68000 b6f6d000 r-xp /usr/lib/libappcore-efl.so.1.1
b6f76000 b6f7a000 r-xp /usr/lib/libsys-assert.so
b6f83000 b6fa0000 r-xp /lib/ld-2.13.so
b6fa9000 b6fae000 r-xp /usr/bin/launchpad-loader
b7eff000 b824a000 rw-p [heap]
beace000 beaef000 rwxp [stack]
End of Maps Information

Callstack Information (PID:32474)
Call Stack Count: 1
 0: strcmp + 0x0 (0xb6a899d0) [/lib/libc.so.6] + 0x729d0
End of Call Stack

Package Information
Package Name: org.example.uicomponents
Package ID : org.example.uicomponents
Version: 1.0.0
Package Type: rpm
App Name: uicomponents
App ID: org.example.uicomponents
Type: capp
Categories: 

Latest Debug Message Information
--------- beginning of /dev/log_main
 (32474): elementary<32474> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8160218), ev->cur.canvas.x(182) ev->cur.canvas.y(294)
06-06 22:32:35.799+0900 E/EFL     (32474): elementary<32474> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8160218), hold(0) freeze(0)
06-06 22:32:35.829+0900 E/EFL     (32474): elementary<32474> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8160218), block(1)
06-06 22:32:35.829+0900 E/EFL     (32474): elementary<32474> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8160218), ev->cur.canvas.x(187) ev->cur.canvas.y(297)
06-06 22:32:35.829+0900 E/EFL     (32474): elementary<32474> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8160218), hold(0) freeze(0)
06-06 22:32:35.829+0900 E/EFL     (32474): evas_main<32474> evas_events.c:1275 evas_event_feed_mouse_up() ButtonEvent:up time=19731567 button=1 downs=0
06-06 22:32:36.139+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.139+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.139+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.139+0900 E/EFL     (32474): <32474> elm_entry.c:5248 elm_entry_add() safety check failed: parent == NULL
06-06 22:32:36.139+0900 E/EFL     (32474): elementary<32474> elm_scroller.c:1094 elm_scroller_policy_set() Passing object ((nil)) of type '(null)' in function elm_scroller_policy_set, but it doesn't implement the Elementary scrollable interface.
06-06 22:32:36.139+0900 E/EFL     (32474): <32474> elm_main.c:1203 elm_object_part_content_set() safety check failed: obj == NULL
06-06 22:32:36.139+0900 E/EFL     (32474): <32474> elm_main.c:1156 elm_object_part_text_set() safety check failed: obj == NULL
06-06 22:32:36.139+0900 E/EFL     (32474): <32474> elm_button.c:455 elm_button_add() safety check failed: parent == NULL
06-06 22:32:36.139+0900 E/EFL     (32474): <32474> elm_main.c:1247 elm_object_style_set() safety check failed: obj == NULL
06-06 22:32:36.139+0900 E/EFL     (32474): <32474> elm_main.c:1156 elm_object_part_text_set() safety check failed: obj == NULL
06-06 22:32:36.139+0900 E/EFL     (32474): <32474> elm_main.c:1203 elm_object_part_content_set() safety check failed: obj == NULL
06-06 22:32:36.149+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.149+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.149+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.149+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.149+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.149+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.149+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.149+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.149+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.149+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.149+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.149+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.149+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.149+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.149+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.149+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.149+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.149+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.149+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.149+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.149+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.149+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.149+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.149+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.149+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.149+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.149+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.149+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.149+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.149+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.149+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.149+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.149+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.149+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.149+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.149+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.149+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.149+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.149+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.149+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.149+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.149+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.149+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.149+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.149+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.149+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.149+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.149+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.149+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.149+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.149+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.149+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.149+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.149+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.149+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.149+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.149+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.149+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.149+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.149+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.149+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.149+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.149+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.149+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.149+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.149+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.149+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.149+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.149+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.149+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.149+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.149+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.149+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.149+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.149+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.149+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.149+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.149+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.149+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.149+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.149+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.149+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.149+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.149+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.149+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.149+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.149+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.149+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.149+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.149+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.149+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.149+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.149+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.149+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.149+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.149+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.149+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.149+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.149+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.149+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.149+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.149+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.149+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.149+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.149+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.149+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.149+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.149+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.149+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.149+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.149+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.149+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.149+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.149+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.149+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.149+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.149+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.149+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.149+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.149+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.149+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.149+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.149+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.149+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.149+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.149+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.149+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.149+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.149+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.159+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.159+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.159+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.159+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.159+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.159+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.159+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.159+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.159+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.159+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.159+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.159+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.159+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.159+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.159+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.179+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.179+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.179+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.179+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.179+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.179+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.179+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.179+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.179+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.179+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.179+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.179+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.179+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.179+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.179+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.219+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.219+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.219+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.219+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.219+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.219+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.219+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.219+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.219+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.219+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.219+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.219+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.219+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.219+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.219+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.249+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.249+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.249+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.249+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.249+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.249+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.249+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.249+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.249+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.249+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.249+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.249+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.249+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.249+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.249+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.289+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.289+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.289+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.289+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.289+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.289+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.289+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.289+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.289+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.289+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.289+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.289+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.289+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.289+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.289+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.309+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.309+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.309+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.309+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.309+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.309+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.309+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.309+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.309+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.309+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.309+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.309+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.309+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.309+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.309+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.349+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.349+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.349+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.349+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.349+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.349+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.349+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.349+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.349+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.349+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.349+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.349+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.349+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.349+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.349+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.379+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.379+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.379+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.379+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.379+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.379+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.379+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.379+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.379+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.379+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.379+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.379+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.379+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.379+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.379+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.429+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.429+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.429+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.429+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.429+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.429+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.429+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.429+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.429+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.429+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.429+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.429+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.429+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.429+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.429+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.479+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.479+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.479+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.479+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.479+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.479+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.479+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.479+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.479+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.479+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.479+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.479+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.479+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.479+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.479+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.519+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.519+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.519+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.519+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.519+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.519+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.519+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.519+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.519+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.519+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.519+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.519+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.519+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.519+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.519+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.569+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.569+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.569+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.569+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.569+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.569+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.569+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.569+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.569+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.569+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.569+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.569+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.569+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.569+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.569+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.599+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.599+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.599+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.599+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.599+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.599+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.599+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.599+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.599+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.599+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.599+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.599+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.599+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.599+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.599+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.609+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.609+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.609+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.609+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.609+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.609+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.609+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.609+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.609+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.609+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.609+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.609+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.609+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.609+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.609+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.609+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.609+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.609+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:36.609+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:32:36.609+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:32:36.609+0900 F/EFL     (32474):     Supplied: f7d713f4 - <UNKNOWN>
06-06 22:32:37.089+0900 E/EFL     (32474): evas_main<32474> evas_events.c:1009 evas_event_feed_mouse_down() ButtonEvent:down time=19732835 button=1 downs=1
06-06 22:32:37.339+0900 E/EFL     (32474): evas_main<32474> evas_events.c:1275 evas_event_feed_mouse_up() ButtonEvent:up time=19733076 button=1 downs=0
06-06 22:32:37.659+0900 E/EFL     (32474): evas_main<32474> evas_events.c:1009 evas_event_feed_mouse_down() ButtonEvent:down time=19733398 button=1 downs=1
06-06 22:32:38.339+0900 E/EFL     (32474): evas_main<32474> evas_events.c:1275 evas_event_feed_mouse_up() ButtonEvent:up time=19734084 button=1 downs=0
06-06 22:32:38.479+0900 E/EFL     (32474): evas_main<32474> evas_events.c:1009 evas_event_feed_mouse_down() ButtonEvent:down time=19734227 button=1 downs=1
06-06 22:32:39.249+0900 E/EFL     (32474): evas_main<32474> evas_events.c:1275 evas_event_feed_mouse_up() ButtonEvent:up time=19734995 button=1 downs=0
06-06 22:32:39.499+0900 E/EFL     (32474): evas_main<32474> evas_events.c:1009 evas_event_feed_mouse_down() ButtonEvent:down time=19735239 button=1 downs=1
06-06 22:32:40.819+0900 E/EFL     (32474): evas_main<32474> evas_events.c:1275 evas_event_feed_mouse_up() ButtonEvent:up time=19736558 button=1 downs=0
06-06 22:32:54.049+0900 I/watchface-viewer(12148): viewer-data-provider.cpp: AddPendingChanges(1053) > added [32] to pending list
06-06 22:32:54.049+0900 I/watchface-viewer(12148): viewer-data-provider.cpp: AddPendingChanges(1053) > added [34] to pending list
06-06 22:32:54.069+0900 I/RESOURCED(  906): heart-battery.c: heart_battery_add_capacity(1168) > [heart_battery_add_capacity,1168] 36 -> 37 1465219974 184
06-06 22:32:54.079+0900 I/RESOURCED(  906): heart-battery.c: heart_battery_calculate_prediction(1137) > [heart_battery_calculate_prediction,1137] TimeToFull: 37 121 162 127
06-06 22:32:54.079+0900 I/RESOURCED(  906): heart-battery.c: heart_battery_calculate_prediction(1137) > [heart_battery_calculate_prediction,1137] TimeToFull: 37 0 0 98
06-06 22:32:54.079+0900 I/RESOURCED(  906): heart-battery.c: heart_battery_calculate_prediction(1137) > [heart_battery_calculate_prediction,1137] TimeToFull: 37 110 131 116
06-06 22:32:54.079+0900 I/RESOURCED(  906): heart-battery.c: heart_battery_calculate_prediction(1137) > [heart_battery_calculate_prediction,1137] TimeToFull: 37 207 5 217
06-06 22:32:54.079+0900 I/RESOURCED(  906): heart-battery.c: heart_battery_calculate_prediction(1137) > [heart_battery_calculate_prediction,1137] TimeToFull: 37 135 38 142
06-06 22:33:00.269+0900 I/RESOURCED(  906): logging.c: logging_send_signal_to_data(1097) > [logging_send_signal_to_data,1097] send signal to logging data thread
06-06 22:33:00.269+0900 I/RESOURCED(  906): logging.c: logging_send_signal_to_update(1177) > [logging_send_signal_to_update,1177] send signal to logging update thread
06-06 22:33:00.269+0900 I/RESOURCED(  906): logging.c: logging_save_to_storage(969) > [logging_save_to_storage,969] storage cache is empty
06-06 22:33:00.839+0900 E/TIZEN_N_SYSTEM_SETTINGS( 1282): system_settings.c: system_settings_get_value_string(522) > Enter [system_settings_get_value_string]
06-06 22:33:00.839+0900 E/TIZEN_N_SYSTEM_SETTINGS( 1282): system_settings.c: system_settings_get_value(386) > Enter [system_settings_get_value]
06-06 22:33:00.839+0900 E/TIZEN_N_SYSTEM_SETTINGS( 1282): system_settings.c: system_settings_get_item(361) > Enter [system_settings_get_item], key=13
06-06 22:33:00.839+0900 E/TIZEN_N_SYSTEM_SETTINGS( 1282): system_settings.c: system_settings_get_item(374) > Enter [system_settings_get_item], index = 13, key = 13, type = 0
06-06 22:33:45.519+0900 E/PKGMGR_SERVER(  331): pkgmgr-server.c: main(2126) > package manager server start
06-06 22:33:45.609+0900 E/PKGMGR_SERVER(  331): pkgmgr-server.c: req_cb(686) > req_id=[org.example.uicomponents_522319720], req_type=[12], pkg_type=[rpm], pkgid=[org.example.uicomponents], args=[], cookie=[], backend_flag=[0]
06-06 22:33:45.609+0900 E/PKGMGR_SERVER(  336): pkgmgr-server.c: queue_job(1954) > KILL/CHECK APP, pkgid=[org.example.uicomponents]
06-06 22:33:45.619+0900 E/PKGMGR  (  329): pkgmgr.c: __check_sync_process(842) > file is can not remove[/tmp/org.example.uicomponents, -1]
06-06 22:33:45.699+0900 W/AUL_AMD (  905): amd_request.c: __request_handler(640) > __request_handler: 14
06-06 22:33:45.709+0900 W/AUL_AMD (  905): amd_request.c: __send_result_to_client(83) > __send_result_to_client, pid: 32474
06-06 22:33:45.709+0900 W/AUL_AMD (  905): amd_request.c: __request_handler(640) > __request_handler: 12
06-06 22:33:45.709+0900 W/AUL_AMD (  905): amd_request.c: __request_handler(640) > __request_handler: 5
06-06 22:33:45.709+0900 I/APP_CORE(32474): appcore-efl.c: __do_app(429) > [APP 32474] Event: TERMINATE State: RUNNING
06-06 22:33:45.709+0900 W/AUL_AMD (  905): amd_request.c: __request_handler(640) > __request_handler: 22
06-06 22:33:45.709+0900 W/AUL_AMD (  905): amd_request.c: __request_handler(884) > app status : 4
06-06 22:33:45.709+0900 W/AUL_AMD (  905): amd_launch.c: __reply_handler(909) > listen fd(27) , send fd(13), pid(32474), cmd(4)
06-06 22:33:45.719+0900 W/AUL_AMD (  905): amd_request.c: __request_handler(640) > __request_handler: 14
06-06 22:33:45.719+0900 W/AUL_AMD (  905): amd_request.c: __send_result_to_client(83) > __send_result_to_client, pid: 32474
06-06 22:33:45.779+0900 I/APP_CORE(32474): appcore-efl.c: __after_loop(1086) > Legacy lifecycle: 0
06-06 22:33:45.779+0900 I/CAPI_APPFW_APPLICATION(32474): app_main.c: _ui_app_appcore_terminate(585) > app_appcore_terminate
06-06 22:33:45.799+0900 W/AUL_AMD (  905): amd_key.c: _key_ungrab(254) > fail(-1) to ungrab key(XF86Stop)
06-06 22:33:45.799+0900 W/AUL_AMD (  905): amd_launch.c: __e17_status_handler(2194) > back key ungrab error
06-06 22:33:45.799+0900 W/AUL_AMD (  905): amd_key.c: _key_ungrab(254) > fail(-1) to ungrab key(XF86Stop)
06-06 22:33:45.799+0900 W/AUL_AMD (  905): amd_launch.c: __e17_status_handler(2194) > back key ungrab error
06-06 22:33:45.799+0900 I/efl-extension(32474): efl_extension_rotary.c: _object_deleted_cb(572) > In: data: 0xb803a1d0, obj: 0xb803a1d0
06-06 22:33:45.799+0900 I/efl-extension(32474): efl_extension_rotary.c: _object_deleted_cb(601) > done
06-06 22:33:45.809+0900 I/efl-extension(32474): efl_extension_rotary.c: eext_rotary_object_event_callback_del(235) > In
06-06 22:33:45.809+0900 I/efl-extension(32474): efl_extension_rotary.c: eext_rotary_object_event_callback_del(240) > callback del 0xb803a1d0, elm_genlist, func : 0xb5800079
06-06 22:33:45.809+0900 I/efl-extension(32474): efl_extension_rotary.c: eext_rotary_object_event_callback_del(273) > done
06-06 22:33:45.809+0900 I/efl-extension(32474): efl_extension_rotary.c: _object_deleted_cb(572) > In: data: 0xb80f1178, obj: 0xb80f1178
06-06 22:33:45.809+0900 I/efl-extension(32474): efl_extension_rotary.c: _object_deleted_cb(601) > done
06-06 22:33:45.809+0900 I/efl-extension(32474): efl_extension_rotary.c: eext_rotary_object_event_callback_del(235) > In
06-06 22:33:45.809+0900 I/efl-extension(32474): efl_extension_rotary.c: eext_rotary_object_event_callback_del(240) > callback del 0xb80f1178, elm_genlist, func : 0xb5800079
06-06 22:33:45.809+0900 I/efl-extension(32474): efl_extension_rotary.c: eext_rotary_object_event_callback_del(273) > done
06-06 22:33:45.819+0900 I/efl-extension(32474): efl_extension_rotary.c: _object_deleted_cb(572) > In: data: 0xb8160218, obj: 0xb8160218
06-06 22:33:45.819+0900 I/efl-extension(32474): efl_extension_rotary.c: _remove_ecore_handlers(554) > In
06-06 22:33:45.819+0900 I/efl-extension(32474): efl_extension_rotary.c: _remove_ecore_handlers(559) > removed _motion_handler
06-06 22:33:45.819+0900 I/efl-extension(32474): efl_extension_rotary.c: _remove_ecore_handlers(565) > removed _rotate_handler
06-06 22:33:45.819+0900 I/efl-extension(32474): efl_extension_rotary.c: _object_deleted_cb(601) > done
06-06 22:33:45.819+0900 W/AUL_AMD (  905): amd_request.c: __request_handler(640) > __request_handler: 14
06-06 22:33:45.829+0900 W/AUL_AMD (  905): amd_request.c: __send_result_to_client(83) > __send_result_to_client, pid: 32474
06-06 22:33:45.829+0900 I/efl-extension(32474): efl_extension_rotary.c: _activated_obj_del_cb(607) > _activated_obj_del_cb : 0xb8170720
06-06 22:33:45.829+0900 I/efl-extension(32474): efl_extension_rotary.c: eext_rotary_object_event_callback_del(235) > In
06-06 22:33:45.829+0900 I/efl-extension(32474): efl_extension_rotary.c: eext_rotary_object_event_callback_del(240) > callback del 0xb8160218, elm_genlist, func : 0xb5800079
06-06 22:33:45.829+0900 I/efl-extension(32474): efl_extension_rotary.c: eext_rotary_object_event_callback_del(273) > done
06-06 22:33:45.839+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:33:45.839+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:33:45.839+0900 F/EFL     (32474):     Supplied: 1234fedc - <UNKNOWN>
06-06 22:33:45.839+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:33:45.839+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:33:45.839+0900 F/EFL     (32474):     Supplied: 1234fedc - <UNKNOWN>
06-06 22:33:45.839+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:33:45.839+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:33:45.839+0900 F/EFL     (32474):     Supplied: 1234fedc - <UNKNOWN>
06-06 22:33:45.839+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:33:45.839+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:33:45.839+0900 F/EFL     (32474):     Supplied: 1234fedc - <UNKNOWN>
06-06 22:33:45.839+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:33:45.839+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:33:45.839+0900 F/EFL     (32474):     Supplied: 1234fedc - <UNKNOWN>
06-06 22:33:45.839+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:33:45.839+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:33:45.839+0900 F/EFL     (32474):     Supplied: 1234fedc - <UNKNOWN>
06-06 22:33:45.839+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:33:45.839+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:33:45.839+0900 F/EFL     (32474):     Supplied: 1234fedc - <UNKNOWN>
06-06 22:33:45.839+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:33:45.839+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:33:45.839+0900 F/EFL     (32474):     Supplied: 1234fedc - <UNKNOWN>
06-06 22:33:45.839+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:33:45.839+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:33:45.839+0900 F/EFL     (32474):     Supplied: 1234fedc - <UNKNOWN>
06-06 22:33:45.839+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:33:45.839+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:33:45.839+0900 F/EFL     (32474):     Supplied: 1234fedc - <UNKNOWN>
06-06 22:33:45.839+0900 E/EFL     (32474): elementary<32474> elm_widget.c:386 _elm_widget_sub_object_del_func() removing sub object 0xb7f37780 ((null)) from parent 0xb816d060 (elm_layout), but elm-parent is different (nil) ((null))!
06-06 22:33:45.839+0900 E/EFL     (32474): elementary<32474> elm_widget.c:675 _smart_del() failed to remove sub object 0xb7f37780 from 0xb816d060
06-06 22:33:45.839+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:33:45.839+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:33:45.839+0900 F/EFL     (32474):     Supplied: 1234fedc - <UNKNOWN>
06-06 22:33:45.839+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:33:45.839+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:33:45.839+0900 F/EFL     (32474):     Supplied: 1234fedc - <UNKNOWN>
06-06 22:33:45.839+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:33:45.839+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:33:45.839+0900 F/EFL     (32474):     Supplied: 1234fedc - <UNKNOWN>
06-06 22:33:45.839+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:33:45.839+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:33:45.839+0900 F/EFL     (32474):     Supplied: 1234fedc - <UNKNOWN>
06-06 22:33:45.839+0900 F/EFL     (32474): evas_main<32474> main.c:122 evas_debug_magic_wrong() Input object is wrong type
06-06 22:33:45.839+0900 F/EFL     (32474):     Expected: 71737723 - Evas_Object
06-06 22:33:45.839+0900 F/EFL     (32474):     Supplied: 1234fedc - <UNKNOWN>
06-06 22:33:45.889+0900 I/APP_CORE(32401): appcore-efl.c: __do_app(429) > [APP 32401] Event: RESUME State: PAUSED
06-06 22:33:45.889+0900 I/CAPI_APPFW_APPLICATION(32401): app_main.c: app_appcore_resume(223) > app_appcore_resume
06-06 22:33:45.889+0900 I/WIFI_EFL_SDK(32401): app_main.c: app_resume(4329) > [Enter]
06-06 22:33:45.889+0900 I/WIFI_EFL_SDK(32401): wifi_manager.c: wifi_manager_set_scan_mode(526) > Wi-Fi Scan mode 1.
06-06 22:33:45.929+0900 W/AUL_AMD (  905): amd_request.c: __request_handler(640) > __request_handler: 14
06-06 22:33:45.949+0900 W/AUL_AMD (  905): amd_request.c: __send_result_to_client(83) > __send_result_to_client, pid: 32474
06-06 22:33:46.059+0900 W/AUL_AMD (  905): amd_request.c: __request_handler(640) > __request_handler: 14
06-06 22:33:46.059+0900 W/AUL_AMD (  905): amd_request.c: __send_result_to_client(83) > __send_result_to_client, pid: -1
06-06 22:33:46.059+0900 E/PKGMGR_SERVER(  336): pkgmgr-server.c: queue_job(1976) > KILL/CHECK_APP end.
06-06 22:33:46.079+0900 E/PKGMGR_SERVER(  331): pkgmgr-server.c: sighandler(445) > child NORMAL exit [336]
06-06 22:33:46.209+0900 W/CRASH_MANAGER(  339): worker.c: worker_job(1199) > 1132474756963146522002
