S/W Version Information
Model: SM-R735S
Tizen-Version: 2.3.1.2
Build-Number: R735SKSU1AOKE
Build-Date: 2015.11.25 20:46:58

Crash Information
Process Name: uicomponents
PID: 9012
Date: 2016-06-06 16:45:37+0900
Executable File Path: /opt/usr/apps/org.example.uicomponents/bin/uicomponents
Signal: 11
      (SIGSEGV)
      si_code: -6
      signal sent by tkill (sent by pid 9012, uid 5000)

Register Information
r0   = 0x000000a5, r1   = 0xb883b6d8
r2   = 0xb57fc191, r3   = 0x00000000
r4   = 0x000000a5, r5   = 0xb87f0350
r6   = 0xb57fc191, r7   = 0xb8822d70
r8   = 0x000000a5, r9   = 0x00000001
r10  = 0xb881dbb8, fp   = 0xb57fc191
ip   = 0xb6c68d80, sp   = 0xbed1e218
lr   = 0xb6c506d5, pc   = 0xb6805c0a
cpsr = 0x20000030

Memory Information
MemTotal:   407572 KB
MemFree:     11664 KB
Buffers:     17440 KB
Cached:      84440 KB
VmPeak:      78288 KB
VmSize:      76124 KB
VmLck:           0 KB
VmPin:           0 KB
VmHWM:       20616 KB
VmRSS:       20616 KB
VmData:      17564 KB
VmStk:         136 KB
VmExe:          20 KB
VmLib:       24760 KB
VmPTE:          58 KB
VmSwap:          0 KB

Threads Information
Threads: 2
PID = 9012 TID = 9012
9012 9100 

Maps Information
b2881000 b2885000 r-xp /usr/lib/libogg.so.0.7.1
b288d000 b28af000 r-xp /usr/lib/libvorbis.so.0.4.3
b28b7000 b28fa000 r-xp /usr/lib/libsndfile.so.1.0.25
b2907000 b294f000 r-xp /usr/lib/pulseaudio/libpulsecommon-4.0.so
b2950000 b2955000 r-xp /usr/lib/libjson.so.0.0.1
b295d000 b298e000 r-xp /usr/lib/libmdm.so.1.1.85
b2996000 b299e000 r-xp /usr/lib/lib_DNSe_NRSS_ver225.so
b29ad000 b29bd000 r-xp /usr/lib/lib_SamsungRec_TizenV04014.so
b29de000 b29eb000 r-xp /usr/lib/libail.so.0.1.0
b29f4000 b29f7000 r-xp /usr/lib/libsyspopup_caller.so.0.1.0
b29ff000 b2a37000 r-xp /usr/lib/libpulse.so.0.16.2
b2a38000 b2a99000 r-xp /usr/lib/libasound.so.2.0.0
b2aa3000 b2aa6000 r-xp /usr/lib/libpulse-simple.so.0.0.4
b2aae000 b2ab3000 r-xp /usr/lib/libascenario-0.2.so.0.0.0
b2abb000 b2ad4000 r-xp /usr/lib/libavsysaudio.so.0.0.1
b2add000 b2ae1000 r-xp /usr/lib/libmmfsoundcommon.so.0.0.0
b2aea000 b2af4000 r-xp /usr/lib/libaudio-session-mgr.so.0.0.0
b2b00000 b2b05000 r-xp /usr/lib/libmmfsession.so.0.0.0
b2b0d000 b2b23000 r-xp /usr/lib/libmmfsound.so.0.1.0
b2b35000 b2b3c000 r-xp /usr/lib/libmmfcommon.so.0.0.0
b2b44000 b2b4e000 r-xp /usr/lib/libcapi-media-sound-manager.so.0.1.48
b2b56000 b2b58000 r-xp /usr/lib/libcapi-media-wav-player.so.0.1.10
b2b60000 b2b67000 r-xp /usr/lib/libfeedback.so.0.1.4
b2b86000 b2b87000 r-xp /usr/lib/edje/modules/feedback/linux-gnueabi-armv7l-1.0.0/module.so
b2b8f000 b2c16000 rw-s anon_inode:dmabuf
b2c16000 b2c9d000 rw-s anon_inode:dmabuf
b2d28000 b2daf000 rw-s anon_inode:dmabuf
b2e2e000 b2eb5000 rw-s anon_inode:dmabuf
b3100000 b3108000 r-xp /usr/lib/libmdm-common.so.1.0.89
b3109000 b310a000 r-xp /usr/lib/libmmfkeysound.so.0.0.0
b31a1000 b39a0000 rwxp [stack:9100]
b39a0000 b39b7000 r-xp /usr/lib/edje/modules/elm/linux-gnueabi-armv7l-1.0.0/module.so
b39c4000 b39c6000 r-xp /usr/lib/libgenlock.so
b39cf000 b39d0000 r-xp /usr/lib/evas/modules/loaders/eet/linux-gnueabi-armv7l-1.7.99/module.so
b39d8000 b39da000 r-xp /usr/lib/evas/modules/loaders/png/linux-gnueabi-armv7l-1.7.99/module.so
b39e4000 b39e9000 r-xp /usr/lib/bufmgr/libtbm_msm.so.0.0.0
b39f1000 b39fc000 r-xp /usr/lib/evas/modules/engines/software_generic/linux-gnueabi-armv7l-1.7.99/module.so
b3d24000 b3dee000 r-xp /usr/lib/libCOREGL.so.4.0
b3dff000 b3e04000 r-xp /usr/lib/libcapi-media-tool.so.0.1.5
b3e0c000 b3e2d000 r-xp /usr/lib/libexif.so.12.3.3
b3e40000 b3e45000 r-xp /usr/lib/libmmutil_imgp.so.0.0.0
b3e4d000 b3e52000 r-xp /usr/lib/libmmutil_jpeg.so.0.0.0
b53e1000 b53e3000 r-xp /usr/lib/libdri2.so.0.0.0
b53eb000 b53f3000 r-xp /usr/lib/libdrm.so.2.4.0
b53fb000 b53fe000 r-xp /usr/lib/libcapi-media-image-util.so.0.3.5
b5406000 b54ea000 r-xp /usr/lib/libicuuc.so.51.1
b54ff000 b563c000 r-xp /usr/lib/libicui18n.so.51.1
b564c000 b5651000 r-xp /usr/lib/libcapi-system-info.so.0.2.0
b5659000 b565f000 r-xp /usr/lib/libxcb-render.so.0.0.0
b5667000 b5668000 r-xp /usr/lib/libxcb-shm.so.0.0.0
b5671000 b5674000 r-xp /usr/lib/libEGL.so.1.4
b567c000 b568a000 r-xp /usr/lib/libGLESv2.so.2.0
b5693000 b569a000 r-xp /usr/lib/libtbm.so.1.0.0
b56a2000 b56c3000 r-xp /usr/lib/libui-extension.so.0.1.0
b56cc000 b56de000 r-xp /usr/lib/libtts.so
b56e6000 b579e000 r-xp /usr/lib/libcairo.so.2.11200.14
b57a9000 b57bb000 r-xp /usr/lib/libefl-assist.so.0.1.0
b57c3000 b57e4000 r-xp /usr/lib/libefl-extension.so.0.1.0
b57ec000 b57fe000 r-xp /opt/usr/apps/org.example.uicomponents/bin/uicomponents
b59c5000 b59cf000 r-xp /lib/libnss_files-2.13.so
b59d8000 b5aa7000 r-xp /usr/lib/libscim-1.0.so.8.2.3
b5abd000 b5ae1000 r-xp /usr/lib/ecore/immodules/libisf-imf-module.so
b5aea000 b5af0000 r-xp /usr/lib/libappsvc.so.0.1.0
b5af8000 b5afa000 r-xp /usr/lib/libcapi-appfw-app-common.so.0.3.2.5
b5b03000 b5b08000 r-xp /usr/lib/libcapi-appfw-app-control.so.0.3.2.5
b5b13000 b5b1e000 r-xp /usr/lib/evas/modules/engines/software_x11/linux-gnueabi-armv7l-1.7.99/module.so
b5b26000 b5b28000 r-xp /usr/lib/libiniparser.so.0
b5b31000 b5b36000 r-xp /usr/lib/libappcore-common.so.1.1
b5b3f000 b5b47000 r-xp /usr/lib/libcapi-system-system-settings.so.0.0.2
b5b48000 b5b4c000 r-xp /usr/lib/libcapi-appfw-application.so.0.3.2.5
b5b59000 b5b5b000 r-xp /usr/lib/libXau.so.6.0.0
b5b64000 b5b6b000 r-xp /lib/libcrypt-2.13.so
b5b9b000 b5b9d000 r-xp /usr/lib/libiri.so
b5ba5000 b5d4d000 r-xp /usr/lib/libcrypto.so.1.0.0
b5d66000 b5db3000 r-xp /usr/lib/libssl.so.1.0.0
b5dc0000 b5dee000 r-xp /usr/lib/libidn.so.11.5.44
b5df6000 b5dff000 r-xp /usr/lib/libcares.so.2.1.0
b5e08000 b5e1b000 r-xp /usr/lib/libxcb.so.1.1.0
b5e24000 b5e26000 r-xp /usr/lib/journal/libjournal.so.0.1.0
b5e2f000 b5e31000 r-xp /usr/lib/libSLP-db-util.so.0.1.0
b5e3a000 b5f06000 r-xp /usr/lib/libxml2.so.2.7.8
b5f13000 b5f15000 r-xp /usr/lib/libgmodule-2.0.so.0.3200.3
b5f1d000 b5f22000 r-xp /usr/lib/libffi.so.5.0.10
b5f2a000 b5f2b000 r-xp /usr/lib/libgthread-2.0.so.0.3200.3
b5f34000 b5f3f000 r-xp /usr/lib/libgpg-error.so.0.15.0
b5f47000 b5f4a000 r-xp /lib/libattr.so.1.1.0
b5f52000 b5fe6000 r-xp /usr/lib/libstdc++.so.6.0.16
b5ff9000 b6015000 r-xp /usr/lib/libsecurity-server-commons.so.1.0.0
b601e000 b6036000 r-xp /usr/lib/libpng12.so.0.50.0
b603f000 b6055000 r-xp /lib/libexpat.so.1.5.2
b605f000 b60a3000 r-xp /usr/lib/libcurl.so.4.3.0
b60ac000 b60b6000 r-xp /usr/lib/libXext.so.6.4.0
b60bf000 b60c2000 r-xp /usr/lib/libXtst.so.6.1.0
b60cb000 b60d1000 r-xp /usr/lib/libXrender.so.1.3.0
b60da000 b60e0000 r-xp /usr/lib/libXrandr.so.2.2.0
b60e8000 b60e9000 r-xp /usr/lib/libXinerama.so.1.0.0
b60f2000 b60fb000 r-xp /usr/lib/libXi.so.6.1.0
b6103000 b6106000 r-xp /usr/lib/libXfixes.so.3.1.0
b610e000 b6110000 r-xp /usr/lib/libXgesture.so.7.0.0
b6118000 b611a000 r-xp /usr/lib/libXcomposite.so.1.0.0
b6123000 b6125000 r-xp /usr/lib/libXdamage.so.1.1.0
b612d000 b6134000 r-xp /usr/lib/libXcursor.so.1.0.2
b613c000 b613f000 r-xp /usr/lib/libecore_input_evas.so.1.7.99
b6147000 b614b000 r-xp /usr/lib/libecore_ipc.so.1.7.99
b6154000 b6159000 r-xp /usr/lib/libecore_fb.so.1.7.99
b6163000 b6244000 r-xp /usr/lib/libX11.so.6.3.0
b624f000 b6272000 r-xp /usr/lib/libjpeg.so.8.0.2
b628a000 b62a0000 r-xp /lib/libz.so.1.2.5
b62a8000 b631d000 r-xp /usr/lib/libsqlite3.so.0.8.6
b6327000 b633c000 r-xp /usr/lib/libpkgmgr_parser.so.0.1.0
b6345000 b6379000 r-xp /usr/lib/libgobject-2.0.so.0.3200.3
b6382000 b6455000 r-xp /usr/lib/libgio-2.0.so.0.3200.3
b6460000 b6470000 r-xp /lib/libresolv-2.13.so
b6474000 b64f0000 r-xp /usr/lib/libgcrypt.so.20.0.3
b64fc000 b6514000 r-xp /usr/lib/liblzma.so.5.0.3
b651d000 b6520000 r-xp /lib/libcap.so.2.21
b6528000 b654e000 r-xp /usr/lib/libsecurity-server-client.so.1.0.1
b6557000 b6558000 r-xp /usr/lib/libecore_imf_evas.so.1.7.99
b6560000 b6566000 r-xp /usr/lib/libecore_imf.so.1.7.99
b656e000 b6585000 r-xp /usr/lib/liblua-5.1.so
b658f000 b6596000 r-xp /usr/lib/libembryo.so.1.7.99
b659e000 b65a4000 r-xp /lib/librt-2.13.so
b65ad000 b6603000 r-xp /usr/lib/libpixman-1.so.0.28.2
b6610000 b6666000 r-xp /usr/lib/libfreetype.so.6.11.3
b6672000 b669a000 r-xp /usr/lib/libfontconfig.so.1.8.0
b669c000 b66d9000 r-xp /usr/lib/libharfbuzz.so.0.940.0
b66e2000 b66f5000 r-xp /usr/lib/libfribidi.so.0.3.1
b66fd000 b6717000 r-xp /usr/lib/libecore_con.so.1.7.99
b6720000 b6729000 r-xp /usr/lib/libedbus.so.1.7.99
b6731000 b6781000 r-xp /usr/lib/libecore_x.so.1.7.99
b6784000 b6788000 r-xp /usr/lib/libvconf.so.0.2.45
b6790000 b67a1000 r-xp /usr/lib/libecore_input.so.1.7.99
b67a9000 b67ae000 r-xp /usr/lib/libecore_file.so.1.7.99
b67b6000 b67d8000 r-xp /usr/lib/libecore_evas.so.1.7.99
b67e1000 b6822000 r-xp /usr/lib/libeina.so.1.7.99
b682b000 b6844000 r-xp /usr/lib/libeet.so.1.7.99
b6855000 b68be000 r-xp /lib/libm-2.13.so
b68c7000 b68cd000 r-xp /usr/lib/libcapi-base-common.so.0.1.8
b68d6000 b68d9000 r-xp /usr/lib/libproc-stat.so.0.2.86
b68e1000 b6903000 r-xp /usr/lib/libpkgmgr-info.so.0.0.17
b690b000 b6910000 r-xp /usr/lib/libxdgmime.so.1.1.0
b6918000 b6942000 r-xp /usr/lib/libdbus-1.so.3.8.12
b694b000 b6962000 r-xp /usr/lib/libdbus-glib-1.so.2.2.2
b696a000 b6975000 r-xp /lib/libunwind.so.8.0.1
b69a2000 b69de000 r-xp /usr/lib/libsystemd.so.0.4.0
b69e7000 b6b02000 r-xp /lib/libc-2.13.so
b6b10000 b6b18000 r-xp /lib/libgcc_s-4.6.so.1
b6b19000 b6b1c000 r-xp /usr/lib/libsmack.so.1.0.0
b6b24000 b6b2a000 r-xp /usr/lib/libprivilege-control.so.0.0.2
b6b32000 b6c02000 r-xp /usr/lib/libglib-2.0.so.0.3200.3
b6c03000 b6c60000 r-xp /usr/lib/libedje.so.1.7.99
b6c6a000 b6c81000 r-xp /usr/lib/libecore.so.1.7.99
b6c98000 b6d67000 r-xp /usr/lib/libevas.so.1.7.99
b6d8b000 b6ec5000 r-xp /usr/lib/libelementary.so.1.7.99
b6edb000 b6eef000 r-xp /lib/libpthread-2.13.so
b6efa000 b6efc000 r-xp /usr/lib/libdlog.so.0.0.0
b6f04000 b6f07000 r-xp /usr/lib/libbundle.so.0.1.22
b6f0f000 b6f11000 r-xp /lib/libdl-2.13.so
b6f1a000 b6f26000 r-xp /usr/lib/libaul.so.0.1.0
b6f38000 b6f3d000 r-xp /usr/lib/libappcore-efl.so.1.1
b6f46000 b6f4a000 r-xp /usr/lib/libsys-assert.so
b6f53000 b6f70000 r-xp /lib/ld-2.13.so
b6f79000 b6f7e000 r-xp /usr/bin/launchpad-loader
b85b0000 b896d000 rw-p [heap]
becfe000 bed1f000 rwxp [stack]
End of Maps Information

Callstack Information (PID:9012)
Call Stack Count: 1
 0: eina_stringshare_add + 0x5 (0xb6805c0a) [/usr/lib/libeina.so.1] + 0x24c0a
End of Call Stack

Package Information
Package Name: org.example.uicomponents
Package ID : org.example.uicomponents
Version: 1.0.0
Package Type: rpm
App Name: uicomponents
App ID: org.example.uicomponents
Type: capp
Categories: 

Latest Debug Message Information
--------- beginning of /dev/log_main
6 16:45:28.922+0900 E/EFL     ( 9012): evas_main<9012> evas_events.c:1275 evas_event_feed_mouse_up() ButtonEvent:up time=4744767 button=1 downs=0
06-06 16:45:28.922+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:2278 _elm_scroll_post_event_up() [DDO] lock set false. : obj(b86eb4e8), type(elm_genlist)
06-06 16:45:29.312+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b86eb4e8), block(1)
06-06 16:45:29.312+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b86eb4e8), ev->cur.canvas.x(178) ev->cur.canvas.y(192)
06-06 16:45:29.312+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b86eb4e8), hold(0) freeze(0)
06-06 16:45:29.312+0900 E/EFL     ( 9012): evas_main<9012> evas_events.c:1009 evas_event_feed_mouse_down() ButtonEvent:down time=4745169 button=1 downs=1
06-06 16:45:29.322+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b86eb4e8), block(1)
06-06 16:45:29.322+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b86eb4e8), ev->cur.canvas.x(181) ev->cur.canvas.y(194)
06-06 16:45:29.322+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b86eb4e8), hold(0) freeze(0)
06-06 16:45:29.342+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b86eb4e8), block(1)
06-06 16:45:29.342+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b86eb4e8), ev->cur.canvas.x(184) ev->cur.canvas.y(194)
06-06 16:45:29.342+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b86eb4e8), hold(0) freeze(0)
06-06 16:45:29.362+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b86eb4e8), block(1)
06-06 16:45:29.362+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b86eb4e8), ev->cur.canvas.x(183) ev->cur.canvas.y(194)
06-06 16:45:29.362+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b86eb4e8), hold(0) freeze(0)
06-06 16:45:29.392+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b86eb4e8), block(1)
06-06 16:45:29.392+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b86eb4e8), ev->cur.canvas.x(180) ev->cur.canvas.y(193)
06-06 16:45:29.392+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b86eb4e8), hold(0) freeze(0)
06-06 16:45:29.392+0900 E/EFL     ( 9012): evas_main<9012> evas_events.c:1275 evas_event_feed_mouse_up() ButtonEvent:up time=4745245 button=1 downs=0
06-06 16:45:29.602+0900 I/efl-extension( 9012): efl_extension_rotary.c: eext_rotary_object_event_callback_add(147) > In
06-06 16:45:29.602+0900 I/efl-extension( 9012): efl_extension_rotary.c: eext_rotary_object_event_activated_set(283) > eext_rotary_object_event_activated_set : 0xb3007898, elm_image, _activated_obj : 0xb87033c0, activated : 1
06-06 16:45:29.602+0900 I/efl-extension( 9012): efl_extension_rotary.c: eext_rotary_object_event_activated_set(291) > Activation delete!!!!
06-06 16:45:30.012+0900 E/SHealth_Common( 1586): SHealthMessagePortConnection.cpp: Send(344) > [0;40;31mexception [[Send]Send appIdList is empty][0;m
06-06 16:45:30.552+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8787c20), block(1)
06-06 16:45:30.552+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8787c20), ev->cur.canvas.x(139) ev->cur.canvas.y(180)
06-06 16:45:30.552+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8787c20), hold(0) freeze(0)
06-06 16:45:30.552+0900 E/EFL     ( 9012): evas_main<9012> evas_events.c:1009 evas_event_feed_mouse_down() ButtonEvent:down time=4746412 button=1 downs=1
06-06 16:45:30.592+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8787c20), block(1)
06-06 16:45:30.592+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8787c20), ev->cur.canvas.x(138) ev->cur.canvas.y(180)
06-06 16:45:30.592+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8787c20), hold(0) freeze(0)
06-06 16:45:30.592+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8787c20), block(1)
06-06 16:45:30.592+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8787c20), ev->cur.canvas.x(133) ev->cur.canvas.y(180)
06-06 16:45:30.592+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8787c20), hold(0) freeze(0)
06-06 16:45:30.612+0900 E/EFL     ( 9012): evas_main<9012> evas_events.c:1275 evas_event_feed_mouse_up() ButtonEvent:up time=4746467 button=1 downs=0
06-06 16:45:30.652+0900 I/efl-extension( 9012): efl_extension_rotary.c: eext_rotary_object_event_callback_add(147) > In
06-06 16:45:30.652+0900 I/efl-extension( 9012): efl_extension_rotary.c: eext_rotary_object_event_activated_set(283) > eext_rotary_object_event_activated_set : 0xb87e1ad8, elm_image, _activated_obj : 0xb3007898, activated : 1
06-06 16:45:30.652+0900 I/efl-extension( 9012): efl_extension_rotary.c: eext_rotary_object_event_activated_set(291) > Activation delete!!!!
06-06 16:45:31.322+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), block(1)
06-06 16:45:31.322+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), ev->cur.canvas.x(171) ev->cur.canvas.y(179)
06-06 16:45:31.322+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), hold(0) freeze(0)
06-06 16:45:31.322+0900 E/EFL     ( 9012): evas_main<9012> evas_events.c:1009 evas_event_feed_mouse_down() ButtonEvent:down time=4747179 button=1 downs=1
06-06 16:45:31.322+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), block(1)
06-06 16:45:31.322+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), ev->cur.canvas.x(174) ev->cur.canvas.y(179)
06-06 16:45:31.322+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), hold(0) freeze(0)
06-06 16:45:31.392+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), block(1)
06-06 16:45:31.392+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), ev->cur.canvas.x(171) ev->cur.canvas.y(179)
06-06 16:45:31.392+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), hold(0) freeze(0)
06-06 16:45:31.402+0900 E/EFL     ( 9012): evas_main<9012> evas_events.c:1275 evas_event_feed_mouse_up() ButtonEvent:up time=4747263 button=1 downs=0
06-06 16:45:32.602+0900 I/APP_CORE( 1184): appcore-efl.c: __do_app(429) > [APP 1184] Event: MEM_FLUSH State: PAUSED
06-06 16:45:32.692+0900 E/EFL     ( 9012): evas_main<9012> evas_events.c:1009 evas_event_feed_mouse_down() ButtonEvent:down time=4748540 button=1 downs=1
06-06 16:45:32.752+0900 E/EFL     ( 9012): evas_main<9012> evas_events.c:1275 evas_event_feed_mouse_up() ButtonEvent:up time=4748603 button=1 downs=0
06-06 16:45:33.202+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), block(1)
06-06 16:45:33.202+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), ev->cur.canvas.x(158) ev->cur.canvas.y(302)
06-06 16:45:33.202+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), hold(0) freeze(0)
06-06 16:45:33.202+0900 E/EFL     ( 9012): evas_main<9012> evas_events.c:1009 evas_event_feed_mouse_down() ButtonEvent:down time=4749055 button=1 downs=1
06-06 16:45:33.202+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), block(1)
06-06 16:45:33.202+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), ev->cur.canvas.x(158) ev->cur.canvas.y(295)
06-06 16:45:33.202+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), hold(0) freeze(0)
06-06 16:45:33.222+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), block(1)
06-06 16:45:33.222+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), ev->cur.canvas.x(158) ev->cur.canvas.y(288)
06-06 16:45:33.222+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), hold(0) freeze(0)
06-06 16:45:33.232+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), block(1)
06-06 16:45:33.232+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), ev->cur.canvas.x(158) ev->cur.canvas.y(279)
06-06 16:45:33.232+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), hold(0) freeze(0)
06-06 16:45:33.242+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), block(1)
06-06 16:45:33.242+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), ev->cur.canvas.x(152) ev->cur.canvas.y(269)
06-06 16:45:33.242+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), hold(0) freeze(0)
06-06 16:45:33.242+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), block(1)
06-06 16:45:33.242+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), ev->cur.canvas.x(147) ev->cur.canvas.y(262)
06-06 16:45:33.242+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), hold(0) freeze(0)
06-06 16:45:33.242+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:4249 _elm_scroll_mouse_move_event_cb() [DDO] animator
06-06 16:45:33.242+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3353 _elm_scroll_post_event_move() [DDO] obj(b87da330), type(elm_genlist)
06-06 16:45:33.242+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3354 _elm_scroll_post_event_move() [DDO] hold_parent(0)
06-06 16:45:33.242+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3405 _elm_scroll_post_event_move() [DDO] elm_widget_drag_lock_y_set : obj(b87da330), type(elm_genlist)
06-06 16:45:33.252+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b87da330), locked_x(0)
06-06 16:45:33.252+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b87da330)
06-06 16:45:33.282+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), block(1)
06-06 16:45:33.282+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), ev->cur.canvas.x(145) ev->cur.canvas.y(257)
06-06 16:45:33.282+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), hold(0) freeze(0)
06-06 16:45:33.282+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), block(1)
06-06 16:45:33.282+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), ev->cur.canvas.x(143) ev->cur.canvas.y(252)
06-06 16:45:33.282+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), hold(0) freeze(0)
06-06 16:45:33.282+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), block(1)
06-06 16:45:33.282+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), ev->cur.canvas.x(141) ev->cur.canvas.y(243)
06-06 16:45:33.282+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), hold(0) freeze(0)
06-06 16:45:33.292+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b87da330), locked_x(0)
06-06 16:45:33.292+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b87da330)
06-06 16:45:33.322+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), block(1)
06-06 16:45:33.322+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), ev->cur.canvas.x(136) ev->cur.canvas.y(234)
06-06 16:45:33.322+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), hold(0) freeze(0)
06-06 16:45:33.322+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), block(1)
06-06 16:45:33.322+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), ev->cur.canvas.x(132) ev->cur.canvas.y(228)
06-06 16:45:33.322+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), hold(0) freeze(0)
06-06 16:45:33.322+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), block(1)
06-06 16:45:33.322+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), ev->cur.canvas.x(130) ev->cur.canvas.y(224)
06-06 16:45:33.322+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), hold(0) freeze(0)
06-06 16:45:33.322+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), block(1)
06-06 16:45:33.322+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), ev->cur.canvas.x(129) ev->cur.canvas.y(219)
06-06 16:45:33.322+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), hold(0) freeze(0)
06-06 16:45:33.322+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b87da330), locked_x(0)
06-06 16:45:33.322+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b87da330)
06-06 16:45:33.362+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), block(1)
06-06 16:45:33.362+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), ev->cur.canvas.x(128) ev->cur.canvas.y(214)
06-06 16:45:33.362+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), hold(0) freeze(0)
06-06 16:45:33.372+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), block(1)
06-06 16:45:33.372+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), ev->cur.canvas.x(128) ev->cur.canvas.y(211)
06-06 16:45:33.372+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), hold(0) freeze(0)
06-06 16:45:33.372+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), block(1)
06-06 16:45:33.372+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), ev->cur.canvas.x(128) ev->cur.canvas.y(206)
06-06 16:45:33.372+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), hold(0) freeze(0)
06-06 16:45:33.372+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), block(1)
06-06 16:45:33.372+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), ev->cur.canvas.x(127) ev->cur.canvas.y(201)
06-06 16:45:33.372+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), hold(0) freeze(0)
06-06 16:45:33.372+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b87da330), locked_x(0)
06-06 16:45:33.372+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b87da330)
06-06 16:45:33.412+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), block(1)
06-06 16:45:33.412+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), ev->cur.canvas.x(126) ev->cur.canvas.y(200)
06-06 16:45:33.412+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), hold(0) freeze(0)
06-06 16:45:33.412+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), block(1)
06-06 16:45:33.412+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), ev->cur.canvas.x(125) ev->cur.canvas.y(199)
06-06 16:45:33.412+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), hold(0) freeze(0)
06-06 16:45:33.412+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), block(1)
06-06 16:45:33.412+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), ev->cur.canvas.x(125) ev->cur.canvas.y(198)
06-06 16:45:33.412+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), hold(0) freeze(0)
06-06 16:45:33.412+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), block(1)
06-06 16:45:33.412+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), ev->cur.canvas.x(125) ev->cur.canvas.y(197)
06-06 16:45:33.412+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), hold(0) freeze(0)
06-06 16:45:33.412+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b87da330), locked_x(0)
06-06 16:45:33.412+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b87da330)
06-06 16:45:33.442+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), block(1)
06-06 16:45:33.442+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), ev->cur.canvas.x(125) ev->cur.canvas.y(196)
06-06 16:45:33.442+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), hold(0) freeze(0)
06-06 16:45:33.442+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b87da330), locked_x(0)
06-06 16:45:33.442+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b87da330)
06-06 16:45:33.472+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), block(1)
06-06 16:45:33.472+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), ev->cur.canvas.x(124) ev->cur.canvas.y(196)
06-06 16:45:33.472+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), hold(0) freeze(0)
06-06 16:45:33.472+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), block(1)
06-06 16:45:33.472+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), ev->cur.canvas.x(122) ev->cur.canvas.y(195)
06-06 16:45:33.472+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), hold(0) freeze(0)
06-06 16:45:33.472+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), block(1)
06-06 16:45:33.472+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), ev->cur.canvas.x(119) ev->cur.canvas.y(194)
06-06 16:45:33.472+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), hold(0) freeze(0)
06-06 16:45:33.482+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b87da330), locked_x(0)
06-06 16:45:33.482+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b87da330)
06-06 16:45:33.512+0900 E/EFL     ( 9012): evas_main<9012> evas_events.c:1275 evas_event_feed_mouse_up() ButtonEvent:up time=4749346 button=1 downs=0
06-06 16:45:33.512+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:2278 _elm_scroll_post_event_up() [DDO] lock set false. : obj(b87da330), type(elm_genlist)
06-06 16:45:33.772+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), block(1)
06-06 16:45:33.772+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), ev->cur.canvas.x(158) ev->cur.canvas.y(206)
06-06 16:45:33.772+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), hold(0) freeze(0)
06-06 16:45:33.772+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), block(1)
06-06 16:45:33.772+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), ev->cur.canvas.x(161) ev->cur.canvas.y(206)
06-06 16:45:33.772+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), hold(0) freeze(0)
06-06 16:45:33.772+0900 E/EFL     ( 9012): evas_main<9012> evas_events.c:1009 evas_event_feed_mouse_down() ButtonEvent:down time=4749632 button=1 downs=1
06-06 16:45:33.792+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), block(1)
06-06 16:45:33.792+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), ev->cur.canvas.x(162) ev->cur.canvas.y(207)
06-06 16:45:33.792+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), hold(0) freeze(0)
06-06 16:45:33.812+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), block(1)
06-06 16:45:33.812+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), ev->cur.canvas.x(163) ev->cur.canvas.y(207)
06-06 16:45:33.812+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), hold(0) freeze(0)
06-06 16:45:33.812+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), block(1)
06-06 16:45:33.812+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), ev->cur.canvas.x(164) ev->cur.canvas.y(205)
06-06 16:45:33.812+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), hold(0) freeze(0)
06-06 16:45:33.832+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), block(1)
06-06 16:45:33.832+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), ev->cur.canvas.x(164) ev->cur.canvas.y(204)
06-06 16:45:33.832+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), hold(0) freeze(0)
06-06 16:45:33.832+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), block(1)
06-06 16:45:33.832+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), ev->cur.canvas.x(164) ev->cur.canvas.y(201)
06-06 16:45:33.832+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), hold(0) freeze(0)
06-06 16:45:33.862+0900 E/EFL     ( 9012): evas_main<9012> evas_events.c:1275 evas_event_feed_mouse_up() ButtonEvent:up time=4749697 button=1 downs=0
06-06 16:45:33.892+0900 I/efl-extension( 9012): efl_extension_rotary.c: eext_rotary_object_event_callback_add(147) > In
06-06 16:45:33.892+0900 I/efl-extension( 9012): efl_extension_rotary.c: eext_rotary_object_event_activated_set(283) > eext_rotary_object_event_activated_set : 0xb8816390, elm_image, _activated_obj : 0xb87e1ad8, activated : 1
06-06 16:45:33.892+0900 I/efl-extension( 9012): efl_extension_rotary.c: eext_rotary_object_event_activated_set(291) > Activation delete!!!!
06-06 16:45:34.372+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8834ba8), block(1)
06-06 16:45:34.372+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8834ba8), ev->cur.canvas.x(157) ev->cur.canvas.y(198)
06-06 16:45:34.372+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8834ba8), hold(0) freeze(0)
06-06 16:45:34.372+0900 E/EFL     ( 9012): evas_main<9012> evas_events.c:1009 evas_event_feed_mouse_down() ButtonEvent:down time=4750229 button=1 downs=1
06-06 16:45:34.452+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8834ba8), block(1)
06-06 16:45:34.452+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8834ba8), ev->cur.canvas.x(160) ev->cur.canvas.y(198)
06-06 16:45:34.452+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b8834ba8), hold(0) freeze(0)
06-06 16:45:34.452+0900 E/EFL     ( 9012): evas_main<9012> evas_events.c:1275 evas_event_feed_mouse_up() ButtonEvent:up time=4750316 button=1 downs=0
06-06 16:45:35.042+0900 E/EFL     ( 9012): evas_main<9012> evas_events.c:1009 evas_event_feed_mouse_down() ButtonEvent:down time=4750889 button=1 downs=1
06-06 16:45:35.072+0900 E/EFL     ( 9012): evas_main<9012> evas_events.c:1275 evas_event_feed_mouse_up() ButtonEvent:up time=4750911 button=1 downs=0
06-06 16:45:36.282+0900 I/efl-extension( 9012): efl_extension_rotary.c: _object_deleted_cb(572) > In: data: 0xb8834ba8, obj: 0xb8834ba8
06-06 16:45:36.282+0900 I/efl-extension( 9012): efl_extension_rotary.c: _object_deleted_cb(601) > done
06-06 16:45:36.292+0900 I/efl-extension( 9012): efl_extension_rotary.c: _activated_obj_del_cb(607) > _activated_obj_del_cb : 0xb8816390
06-06 16:45:36.292+0900 I/efl-extension( 9012): efl_extension_rotary.c: eext_rotary_object_event_callback_del(235) > In
06-06 16:45:36.292+0900 I/efl-extension( 9012): efl_extension_rotary.c: eext_rotary_object_event_callback_del(240) > callback del 0xb8834ba8, elm_genlist, func : 0xb57d1079
06-06 16:45:36.292+0900 I/efl-extension( 9012): efl_extension_rotary.c: eext_rotary_object_event_callback_del(273) > done
06-06 16:45:36.802+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), block(1)
06-06 16:45:36.802+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), ev->cur.canvas.x(182) ev->cur.canvas.y(143)
06-06 16:45:36.802+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), hold(0) freeze(0)
06-06 16:45:36.812+0900 E/EFL     ( 9012): evas_main<9012> evas_events.c:1009 evas_event_feed_mouse_down() ButtonEvent:down time=4752666 button=1 downs=1
06-06 16:45:36.812+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), block(1)
06-06 16:45:36.812+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), ev->cur.canvas.x(180) ev->cur.canvas.y(145)
06-06 16:45:36.812+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), hold(0) freeze(0)
06-06 16:45:36.832+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), block(1)
06-06 16:45:36.832+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), ev->cur.canvas.x(177) ev->cur.canvas.y(153)
06-06 16:45:36.832+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), hold(0) freeze(0)
06-06 16:45:36.842+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), block(1)
06-06 16:45:36.842+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), ev->cur.canvas.x(174) ev->cur.canvas.y(160)
06-06 16:45:36.842+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), hold(0) freeze(0)
06-06 16:45:36.852+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), block(1)
06-06 16:45:36.852+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), ev->cur.canvas.x(172) ev->cur.canvas.y(166)
06-06 16:45:36.852+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), hold(0) freeze(0)
06-06 16:45:36.862+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), block(1)
06-06 16:45:36.862+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), ev->cur.canvas.x(170) ev->cur.canvas.y(174)
06-06 16:45:36.862+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), hold(0) freeze(0)
06-06 16:45:36.872+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), block(1)
06-06 16:45:36.872+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), ev->cur.canvas.x(168) ev->cur.canvas.y(180)
06-06 16:45:36.872+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), hold(0) freeze(0)
06-06 16:45:36.872+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:4249 _elm_scroll_mouse_move_event_cb() [DDO] animator
06-06 16:45:36.872+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3353 _elm_scroll_post_event_move() [DDO] obj(b87da330), type(elm_genlist)
06-06 16:45:36.872+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3354 _elm_scroll_post_event_move() [DDO] hold_parent(0)
06-06 16:45:36.872+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3405 _elm_scroll_post_event_move() [DDO] elm_widget_drag_lock_y_set : obj(b87da330), type(elm_genlist)
06-06 16:45:36.882+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), block(1)
06-06 16:45:36.882+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), ev->cur.canvas.x(168) ev->cur.canvas.y(185)
06-06 16:45:36.882+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), hold(0) freeze(0)
06-06 16:45:36.892+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b87da330), locked_x(0)
06-06 16:45:36.892+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b87da330)
06-06 16:45:36.912+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), block(1)
06-06 16:45:36.912+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), ev->cur.canvas.x(167) ev->cur.canvas.y(192)
06-06 16:45:36.912+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), hold(0) freeze(0)
06-06 16:45:36.912+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), block(1)
06-06 16:45:36.912+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), ev->cur.canvas.x(166) ev->cur.canvas.y(199)
06-06 16:45:36.912+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), hold(0) freeze(0)
06-06 16:45:36.912+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), block(1)
06-06 16:45:36.912+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), ev->cur.canvas.x(166) ev->cur.canvas.y(204)
06-06 16:45:36.912+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), hold(0) freeze(0)
06-06 16:45:36.922+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b87da330), locked_x(0)
06-06 16:45:36.922+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b87da330)
06-06 16:45:36.942+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), block(1)
06-06 16:45:36.942+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), ev->cur.canvas.x(164) ev->cur.canvas.y(217)
06-06 16:45:36.942+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), hold(0) freeze(0)
06-06 16:45:36.942+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), block(1)
06-06 16:45:36.942+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), ev->cur.canvas.x(163) ev->cur.canvas.y(230)
06-06 16:45:36.942+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), hold(0) freeze(0)
06-06 16:45:36.942+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b87da330), locked_x(0)
06-06 16:45:36.942+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b87da330)
06-06 16:45:36.962+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), block(1)
06-06 16:45:36.962+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), ev->cur.canvas.x(162) ev->cur.canvas.y(235)
06-06 16:45:36.962+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), hold(0) freeze(0)
06-06 16:45:36.962+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), block(1)
06-06 16:45:36.962+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), ev->cur.canvas.x(161) ev->cur.canvas.y(240)
06-06 16:45:36.962+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), hold(0) freeze(0)
06-06 16:45:36.962+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b87da330), locked_x(0)
06-06 16:45:36.962+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b87da330)
06-06 16:45:36.982+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), block(1)
06-06 16:45:36.982+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), ev->cur.canvas.x(160) ev->cur.canvas.y(244)
06-06 16:45:36.982+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), hold(0) freeze(0)
06-06 16:45:36.982+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), block(1)
06-06 16:45:36.982+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), ev->cur.canvas.x(159) ev->cur.canvas.y(248)
06-06 16:45:36.982+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), hold(0) freeze(0)
06-06 16:45:36.982+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b87da330), locked_x(0)
06-06 16:45:36.982+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b87da330)
06-06 16:45:36.992+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), block(1)
06-06 16:45:36.992+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), ev->cur.canvas.x(159) ev->cur.canvas.y(251)
06-06 16:45:36.992+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), hold(0) freeze(0)
06-06 16:45:36.992+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b87da330), locked_x(0)
06-06 16:45:36.992+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b87da330)
06-06 16:45:37.012+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), block(1)
06-06 16:45:37.012+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), ev->cur.canvas.x(159) ev->cur.canvas.y(252)
06-06 16:45:37.012+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), hold(0) freeze(0)
06-06 16:45:37.012+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), block(1)
06-06 16:45:37.012+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), ev->cur.canvas.x(159) ev->cur.canvas.y(253)
06-06 16:45:37.012+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), hold(0) freeze(0)
06-06 16:45:37.012+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b87da330), locked_x(0)
06-06 16:45:37.012+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b87da330)
06-06 16:45:37.022+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), block(1)
06-06 16:45:37.022+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), ev->cur.canvas.x(160) ev->cur.canvas.y(254)
06-06 16:45:37.022+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), hold(0) freeze(0)
06-06 16:45:37.022+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b87da330), locked_x(0)
06-06 16:45:37.022+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b87da330)
06-06 16:45:37.042+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), block(1)
06-06 16:45:37.042+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), ev->cur.canvas.x(164) ev->cur.canvas.y(255)
06-06 16:45:37.042+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), hold(0) freeze(0)
06-06 16:45:37.042+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), block(1)
06-06 16:45:37.042+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), ev->cur.canvas.x(166) ev->cur.canvas.y(258)
06-06 16:45:37.042+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), hold(0) freeze(0)
06-06 16:45:37.042+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3617 _elm_scroll_hold_animator() [DDO] obj(b87da330), locked_x(0)
06-06 16:45:37.042+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3852 _elm_scroll_hold_animator() [DDO] obj(b87da330)
06-06 16:45:37.062+0900 E/EFL     ( 9012): evas_main<9012> evas_events.c:1275 evas_event_feed_mouse_up() ButtonEvent:up time=4752914 button=1 downs=0
06-06 16:45:37.062+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:2278 _elm_scroll_post_event_up() [DDO] lock set false. : obj(b87da330), type(elm_genlist)
06-06 16:45:37.472+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), block(1)
06-06 16:45:37.472+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), ev->cur.canvas.x(160) ev->cur.canvas.y(192)
06-06 16:45:37.472+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), hold(0) freeze(0)
06-06 16:45:37.502+0900 E/EFL     ( 9012): evas_main<9012> evas_events.c:1009 evas_event_feed_mouse_down() ButtonEvent:down time=4753348 button=1 downs=1
06-06 16:45:37.522+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), block(1)
06-06 16:45:37.522+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), ev->cur.canvas.x(160) ev->cur.canvas.y(191)
06-06 16:45:37.522+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), hold(0) freeze(0)
06-06 16:45:37.542+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), block(1)
06-06 16:45:37.542+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), ev->cur.canvas.x(160) ev->cur.canvas.y(189)
06-06 16:45:37.542+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), hold(0) freeze(0)
06-06 16:45:37.552+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3965 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), block(1)
06-06 16:45:37.552+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3979 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), ev->cur.canvas.x(160) ev->cur.canvas.y(187)
06-06 16:45:37.552+0900 E/EFL     ( 9012): elementary<9012> elm_interface_scrollable.c:3980 _elm_scroll_mouse_move_event_cb() [DDO] obj(b87da330), hold(0) freeze(0)
06-06 16:45:37.562+0900 E/EFL     ( 9012): evas_main<9012> evas_events.c:1275 evas_event_feed_mouse_up() ButtonEvent:up time=4753424 button=1 downs=0
06-06 16:45:37.822+0900 W/CRASH_MANAGER( 9140): worker.c: worker_job(1199) > 1109012756963146519913
