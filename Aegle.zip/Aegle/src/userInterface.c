/*
 * Copyright (c) 2014 Samsung Electronics Co., Ltd All Rights Reserved
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *
 */
#include "main.h"
#include <string.h>
#include <stdio.h>

Evas_Object *entry;
int calories=0, gender=0, age=0, weight=0, height=0, calories_goal=0;

//new String array
char *meal_time_names[] = {
	"Total Calories", "Breakfast", "Lunch","Dinner", "Snack",
	NULL
};

char *add_number[] = {
	"Show total", "+10", "+5", "+1",
	NULL
};

char *add_number2[] = {
	"Show total", "+50", "+10", "+5", "+1",
	NULL
};

char *gender_name[] = {
	"Show gender", "Male", "Female",
	NULL
};

char name[50];


int getCalories()
{
	return calories;
}



char *button_menu_names[] = {
	"Meal List", "Calories Goal",
	NULL
};

char *meal_names[] = {
	"100g chicken breast", "1 large apple","1 banana", "1 hard boiled egg", "1 shin ramen",
	NULL
};

char *user_info[] = {
	"Goal", "Gender", "Age", "Weight", "Height",
	NULL
};



typedef struct _item_data
{
	int index;
	Elm_Object_Item *item;
} item_data;

static void
gl_selected_cb(void *data, Evas_Object *obj, void *event_info)
{
	Elm_Object_Item *it = (Elm_Object_Item *)event_info;
	elm_genlist_item_selected_set(it, EINA_FALSE);
}

static char *
_gl_menu_title_text_get(void *data, Evas_Object *obj, const char *part)
{
	char buf[1024];

	snprintf(buf, 1023, "%s", "Diet");
	return strdup(buf);
}

static char *
_gl_menu_text_get(void *data, Evas_Object *obj, const char *part)
{
	char buf[1024];
	item_data *id = (item_data *)data;
	int index = id->index;

	if (!strcmp(part, "elm.text")) {
		snprintf(buf, 1023, "%s", button_menu_names[index]);
		return strdup(buf);
	}
	return NULL;
}

static char *
_gl_menu_text_get1(void *data, Evas_Object *obj, const char *part)
{
	char buf[1024];
	item_data *id = (item_data *)data;
	int index = id->index;

	if (!strcmp(part, "elm.text")) {
		snprintf(buf, 1023, "%s", meal_time_names[index]);
		return strdup(buf);
	}
	return NULL;
}

static char *
_gl_menu_text_get2(void *data, Evas_Object *obj, const char *part)
{
	char buf[1024];
	item_data *id = (item_data *)data;
	int index = id->index;

	if (!strcmp(part, "elm.text")) {
		snprintf(buf, 1023, "%s", meal_names[index]);
		return strdup(buf);
	}
	return NULL;
}

static char *
_gl_menu_text_get3(void *data, Evas_Object *obj, const char *part)
{
	char buf[1024];
	item_data *id = (item_data *)data;
	int index = id->index;

	if (!strcmp(part, "elm.text")) {
		snprintf(buf, 1023, "%s", user_info[index]);
		return strdup(buf);
	}
	return NULL;
}


static char *
_gl_menu_text_get4(void *data, Evas_Object *obj, const char *part)
{
	char buf[1024];
	item_data *id = (item_data *)data;
	int index = id->index;

	if (!strcmp(part, "elm.text")) {
		snprintf(buf, 1023, "%s", add_number[index]);
		return strdup(buf);
	}
	return NULL;
}

static char *
_gl_menu_text_get5(void *data, Evas_Object *obj, const char *part)
{
	char buf[1024];
	item_data *id = (item_data *)data;
	int index = id->index;

	if (!strcmp(part, "elm.text")) {
		snprintf(buf, 1023, "%s", gender_name[index]);
		return strdup(buf);
	}
	return NULL;
}

static char *
_gl_menu_text_get6(void *data, Evas_Object *obj, const char *part)
{
	char buf[1024];
	item_data *id = (item_data *)data;
	int index = id->index;

	if (!strcmp(part, "elm.text")) {
		snprintf(buf, 1023, "%s", add_number2[index]);
		return strdup(buf);
	}
	return NULL;
}

static void
_gl_menu_del(void *data, Evas_Object *obj)
{
	// FIXME: Unrealized callback can be called after this.
	// Accessing Item_Data can be dangerous on unrealized callback.
	item_data *id = (item_data *)data;
	if (id) free(id);
}

static void
_popup_hide_cb(void *data, Evas_Object *obj, void *event_info)
{
	if(!obj) return;
	elm_popup_dismiss(obj);
}

static void
_popup_hide_finished_cb(void *data, Evas_Object *obj, void *event_info)
{
	if(!obj) return;
	evas_object_del(obj);
}

static void _block_clicked_cb(void *data, Evas_Object *obj, void *event_info)
{
	if(!obj) return;
	elm_popup_dismiss(obj);
}

static void _timeout_cb(void *data, Evas_Object *obj, void *event_info)
{
	if(!obj) return;
	elm_popup_dismiss(obj);
}

static void _popup_toast_cb1(void *data, Evas_Object *obj, void *event_info)
{
	Evas_Object *popup;
	appdata_s *ad = (appdata_s *)data;

	popup = elm_popup_add(ad->win);
	elm_object_style_set(popup, "toast/circle");
	elm_popup_orient_set(popup, ELM_POPUP_ORIENT_BOTTOM);
	evas_object_size_hint_weight_set(popup, EVAS_HINT_EXPAND, EVAS_HINT_EXPAND);
	eext_object_event_callback_add(popup, EEXT_CALLBACK_BACK, _popup_hide_cb, NULL);
	evas_object_smart_callback_add(popup, "dismissed", _popup_hide_finished_cb, NULL);
	elm_object_part_text_set(popup,"elm.text", "100g chicken breast added!");
	calories+=165;
	evas_object_smart_callback_add(popup, "block,clicked", _block_clicked_cb, NULL);

	elm_popup_timeout_set(popup, 2.0);
	evas_object_smart_callback_add(popup, "timeout", _timeout_cb, NULL);

	evas_object_show(popup);
}

static void _popup_toast_cb2(void *data, Evas_Object *obj, void *event_info)
{
	Evas_Object *popup;
	appdata_s *ad = (appdata_s *)data;

	popup = elm_popup_add(ad->win);
	elm_object_style_set(popup, "toast/circle");
	elm_popup_orient_set(popup, ELM_POPUP_ORIENT_BOTTOM);
	evas_object_size_hint_weight_set(popup, EVAS_HINT_EXPAND, EVAS_HINT_EXPAND);
	eext_object_event_callback_add(popup, EEXT_CALLBACK_BACK, _popup_hide_cb, NULL);
	evas_object_smart_callback_add(popup, "dismissed", _popup_hide_finished_cb, NULL);
	elm_object_part_text_set(popup,"elm.text", "1 large apple added!");
	calories+=100;
	evas_object_smart_callback_add(popup, "block,clicked", _block_clicked_cb, NULL);

	elm_popup_timeout_set(popup, 2.0);
	evas_object_smart_callback_add(popup, "timeout", _timeout_cb, NULL);

	evas_object_show(popup);
}

static void _popup_toast_cb3(void *data, Evas_Object *obj, void *event_info)
{
	Evas_Object *popup;
	appdata_s *ad = (appdata_s *)data;

	popup = elm_popup_add(ad->win);
	elm_object_style_set(popup, "toast/circle");
	elm_popup_orient_set(popup, ELM_POPUP_ORIENT_BOTTOM);
	evas_object_size_hint_weight_set(popup, EVAS_HINT_EXPAND, EVAS_HINT_EXPAND);
	eext_object_event_callback_add(popup, EEXT_CALLBACK_BACK, _popup_hide_cb, NULL);
	evas_object_smart_callback_add(popup, "dismissed", _popup_hide_finished_cb, NULL);
	elm_object_part_text_set(popup,"elm.text", "1 banana added!");
	calories+=125;
	evas_object_smart_callback_add(popup, "block,clicked", _block_clicked_cb, NULL);

	elm_popup_timeout_set(popup, 2.0);
	evas_object_smart_callback_add(popup, "timeout", _timeout_cb, NULL);

	evas_object_show(popup);
}

static void _popup_toast_cb4(void *data, Evas_Object *obj, void *event_info)
{
	Evas_Object *popup;
	appdata_s *ad = (appdata_s *)data;

	popup = elm_popup_add(ad->win);
	elm_object_style_set(popup, "toast/circle");
	elm_popup_orient_set(popup, ELM_POPUP_ORIENT_BOTTOM);
	evas_object_size_hint_weight_set(popup, EVAS_HINT_EXPAND, EVAS_HINT_EXPAND);
	eext_object_event_callback_add(popup, EEXT_CALLBACK_BACK, _popup_hide_cb, NULL);
	evas_object_smart_callback_add(popup, "dismissed", _popup_hide_finished_cb, NULL);
	elm_object_part_text_set(popup,"elm.text", "1 hard boiled egg added!");
	calories+=72;
	evas_object_smart_callback_add(popup, "block,clicked", _block_clicked_cb, NULL);

	elm_popup_timeout_set(popup, 2.0);
	evas_object_smart_callback_add(popup, "timeout", _timeout_cb, NULL);

	evas_object_show(popup);
}

static void _popup_toast_cb5(void *data, Evas_Object *obj, void *event_info)
{
	Evas_Object *popup;
	appdata_s *ad = (appdata_s *)data;

	popup = elm_popup_add(ad->win);
	elm_object_style_set(popup, "toast/circle");
	elm_popup_orient_set(popup, ELM_POPUP_ORIENT_BOTTOM);
	evas_object_size_hint_weight_set(popup, EVAS_HINT_EXPAND, EVAS_HINT_EXPAND);
	eext_object_event_callback_add(popup, EEXT_CALLBACK_BACK, _popup_hide_cb, NULL);
	evas_object_smart_callback_add(popup, "dismissed", _popup_hide_finished_cb, NULL);
	elm_object_part_text_set(popup,"elm.text", "1 shin ramen added!");
	calories+=240;
	evas_object_smart_callback_add(popup, "block,clicked", _block_clicked_cb, NULL);

	elm_popup_timeout_set(popup, 2.0);
	evas_object_smart_callback_add(popup, "timeout", _timeout_cb, NULL);

	evas_object_show(popup);
}

static void _popup_calorie_cb(void *data, Evas_Object *obj, void *event_info)
{
	Evas_Object *popup;
	appdata_s *ad = (appdata_s *)data;
	sprintf(name, "Total calories:  %d", getCalories());
	popup = elm_popup_add(ad->win);
	elm_object_style_set(popup, "toast/circle");
	elm_popup_orient_set(popup, ELM_POPUP_ORIENT_BOTTOM);
	evas_object_size_hint_weight_set(popup, EVAS_HINT_EXPAND, EVAS_HINT_EXPAND);
	eext_object_event_callback_add(popup, EEXT_CALLBACK_BACK, _popup_hide_cb, NULL);
	evas_object_smart_callback_add(popup, "dismissed", _popup_hide_finished_cb, NULL);
	elm_object_part_text_set(popup,"elm.text", name);
	evas_object_smart_callback_add(popup, "block,clicked", _block_clicked_cb, NULL);

	elm_popup_timeout_set(popup, 2.0);
	evas_object_smart_callback_add(popup, "timeout", _timeout_cb, NULL);

	evas_object_show(popup);
}

static void show_goal_cb(void *data, Evas_Object *obj, void *event_info)
{
		Evas_Object *popup;
		appdata_s *ad = (appdata_s *)data;
		calories_goal = (int)10*weight+6.25*height-5*age;
		if(gender==0)
		{
			calories_goal+=5;
		}
		else
		{
			calories_goal-=161;
		}
		sprintf(name, "Total calories goal :  %d", calories_goal);
		popup = elm_popup_add(ad->win);
		elm_object_style_set(popup, "toast/circle");
		elm_popup_orient_set(popup, ELM_POPUP_ORIENT_BOTTOM);
		evas_object_size_hint_weight_set(popup, EVAS_HINT_EXPAND, EVAS_HINT_EXPAND);
		eext_object_event_callback_add(popup, EEXT_CALLBACK_BACK, _popup_hide_cb, NULL);
		evas_object_smart_callback_add(popup, "dismissed", _popup_hide_finished_cb, NULL);
		elm_object_part_text_set(popup,"elm.text", name);
		evas_object_smart_callback_add(popup, "block,clicked", _block_clicked_cb, NULL);

		elm_popup_timeout_set(popup, 2.0);
		evas_object_smart_callback_add(popup, "timeout", _timeout_cb, NULL);

		evas_object_show(popup);
}

static void show_gender_cb(void *data, Evas_Object *obj, void *event_info)
{
	Evas_Object *popup;
	appdata_s *ad = (appdata_s *)data;
	char *male="male";
	char *female="female";
	if(gender==0)
	{
		sprintf(name, "Gender:  %s", male);
	}
	else
	{
		sprintf(name, "Gender:  %s", female);
	}
	popup = elm_popup_add(ad->win);
	elm_object_style_set(popup, "toast/circle");
	elm_popup_orient_set(popup, ELM_POPUP_ORIENT_BOTTOM);
	evas_object_size_hint_weight_set(popup, EVAS_HINT_EXPAND, EVAS_HINT_EXPAND);
	eext_object_event_callback_add(popup, EEXT_CALLBACK_BACK, _popup_hide_cb, NULL);
	evas_object_smart_callback_add(popup, "dismissed", _popup_hide_finished_cb, NULL);
	elm_object_part_text_set(popup,"elm.text", name);
	evas_object_smart_callback_add(popup, "block,clicked", _block_clicked_cb, NULL);

	elm_popup_timeout_set(popup, 2.0);
	evas_object_smart_callback_add(popup, "timeout", _timeout_cb, NULL);

	evas_object_show(popup);
}

static void _add_male_cb(void *data, Evas_Object *obj, void *event_info)
{
	gender=0;
}

static void _add_female_cb(void *data, Evas_Object *obj, void *event_info)
{
	gender=1;
}

static void _user_info_entry_cb1(void *data, Evas_Object *obj, void *event_info)
{
	appdata_s *ad = (appdata_s *)data;
	Evas_Object *genlist;
	Evas_Object *circle_genlist;
	Evas_Object *nf = ad->nf;
	Elm_Object_Item *nf_it;
	Elm_Genlist_Item_Class *itc = elm_genlist_item_class_new();
	Elm_Genlist_Item_Class *ttc = elm_genlist_item_class_new();
	Elm_Genlist_Item_Class *ptc = elm_genlist_item_class_new();
	item_data *id;
	int index = 0;

	genlist = elm_genlist_add(nf);
	elm_genlist_mode_set(genlist, ELM_LIST_COMPRESS);
	evas_object_smart_callback_add(genlist, "selected", gl_selected_cb, NULL);

	circle_genlist = eext_circle_object_genlist_add(genlist, ad->circle_surface);
	eext_circle_object_genlist_scroller_policy_set(circle_genlist, ELM_SCROLLER_POLICY_OFF, ELM_SCROLLER_POLICY_AUTO);
	eext_rotary_object_event_activated_set(circle_genlist, EINA_TRUE);

	ttc->item_style = "title";
	ttc->func.text_get = _gl_menu_title_text_get;
	ttc->func.del = _gl_menu_del;

	itc->item_style = "default";
	itc->func.text_get = _gl_menu_text_get5;
	itc->func.del = _gl_menu_del;

	ptc->item_style = "padding";
	ptc->func.del = _gl_menu_del;

	elm_genlist_item_append(genlist, ttc, NULL, NULL, ELM_GENLIST_ITEM_NONE, NULL, NULL);



	id = calloc(sizeof(item_data), 1);
	id->index = index++;
	id->item = elm_genlist_item_append(genlist, itc, id, NULL, ELM_GENLIST_ITEM_NONE, show_gender_cb, ad);
	id = calloc(sizeof(item_data), 1);
	id->index = index++;
	id->item = elm_genlist_item_append(genlist, itc, id, NULL, ELM_GENLIST_ITEM_NONE, _add_male_cb, ad);
	id = calloc(sizeof(item_data), 1);
	id->index = index++;
	id->item = elm_genlist_item_append(genlist, itc, id, NULL, ELM_GENLIST_ITEM_NONE, _add_female_cb, ad);




	elm_genlist_item_append(genlist, ptc, NULL, NULL, ELM_GENLIST_ITEM_NONE, NULL, NULL);

	elm_genlist_item_class_free(ttc);
	elm_genlist_item_class_free(itc);
	elm_genlist_item_class_free(ptc);

	nf_it = elm_naviframe_item_push(nf, "Button", NULL, NULL, genlist, "empty");
}

static void show_age_cb(void *data, Evas_Object *obj, void *event_info)
{
	Evas_Object *popup;
	appdata_s *ad = (appdata_s *)data;

	sprintf(name, "Age :  %d", age);
	popup = elm_popup_add(ad->win);
	elm_object_style_set(popup, "toast/circle");
	elm_popup_orient_set(popup, ELM_POPUP_ORIENT_BOTTOM);
	evas_object_size_hint_weight_set(popup, EVAS_HINT_EXPAND, EVAS_HINT_EXPAND);
	eext_object_event_callback_add(popup, EEXT_CALLBACK_BACK, _popup_hide_cb, NULL);
	evas_object_smart_callback_add(popup, "dismissed", _popup_hide_finished_cb, NULL);
	elm_object_part_text_set(popup,"elm.text", name);
	evas_object_smart_callback_add(popup, "block,clicked", _block_clicked_cb, NULL);

	elm_popup_timeout_set(popup, 2.0);
	evas_object_smart_callback_add(popup, "timeout", _timeout_cb, NULL);

	evas_object_show(popup);
}

static void _add_10_years_cb(void *data, Evas_Object *obj, void *event_info)
{
	age+=10;
}

static void _add_5_years_cb(void *data, Evas_Object *obj, void *event_info)
{
	age+=5;
}

static void _add_1_year_cb(void *data, Evas_Object *obj, void *event_info)
{
	age+=1;
}

static void _user_info_entry_cb2(void *data, Evas_Object *obj, void *event_info)
{
	appdata_s *ad = (appdata_s *)data;
		Evas_Object *genlist;
		Evas_Object *circle_genlist;
		Evas_Object *nf = ad->nf;
		Elm_Object_Item *nf_it;
		Elm_Genlist_Item_Class *itc = elm_genlist_item_class_new();
		Elm_Genlist_Item_Class *ttc = elm_genlist_item_class_new();
		Elm_Genlist_Item_Class *ptc = elm_genlist_item_class_new();
		item_data *id;
		int index = 0;

		genlist = elm_genlist_add(nf);
		elm_genlist_mode_set(genlist, ELM_LIST_COMPRESS);
		evas_object_smart_callback_add(genlist, "selected", gl_selected_cb, NULL);

		circle_genlist = eext_circle_object_genlist_add(genlist, ad->circle_surface);
		eext_circle_object_genlist_scroller_policy_set(circle_genlist, ELM_SCROLLER_POLICY_OFF, ELM_SCROLLER_POLICY_AUTO);
		eext_rotary_object_event_activated_set(circle_genlist, EINA_TRUE);

		ttc->item_style = "title";
		ttc->func.text_get = _gl_menu_title_text_get;
		ttc->func.del = _gl_menu_del;

		itc->item_style = "default";
		itc->func.text_get = _gl_menu_text_get4;
		itc->func.del = _gl_menu_del;

		ptc->item_style = "padding";
		ptc->func.del = _gl_menu_del;

		elm_genlist_item_append(genlist, ttc, NULL, NULL, ELM_GENLIST_ITEM_NONE, NULL, NULL);



		id = calloc(sizeof(item_data), 1);
		id->index = index++;
		id->item = elm_genlist_item_append(genlist, itc, id, NULL, ELM_GENLIST_ITEM_NONE, show_age_cb, ad);
		id = calloc(sizeof(item_data), 1);
		id->index = index++;
		id->item = elm_genlist_item_append(genlist, itc, id, NULL, ELM_GENLIST_ITEM_NONE, _add_10_years_cb, ad);
		id = calloc(sizeof(item_data), 1);
		id->index = index++;
		id->item = elm_genlist_item_append(genlist, itc, id, NULL, ELM_GENLIST_ITEM_NONE, _add_5_years_cb, ad);
		id = calloc(sizeof(item_data), 1);
		id->index = index++;
		id->item = elm_genlist_item_append(genlist, itc, id, NULL, ELM_GENLIST_ITEM_NONE, _add_1_year_cb, ad);



		elm_genlist_item_append(genlist, ptc, NULL, NULL, ELM_GENLIST_ITEM_NONE, NULL, NULL);

		elm_genlist_item_class_free(ttc);
		elm_genlist_item_class_free(itc);
		elm_genlist_item_class_free(ptc);

		nf_it = elm_naviframe_item_push(nf, "Button", NULL, NULL, genlist, "empty");
}

static void show_weight_cb(void *data, Evas_Object *obj, void *event_info)
{
	Evas_Object *popup;
	appdata_s *ad = (appdata_s *)data;

	sprintf(name, "Weight :  %d", weight);
	popup = elm_popup_add(ad->win);
	elm_object_style_set(popup, "toast/circle");
	elm_popup_orient_set(popup, ELM_POPUP_ORIENT_BOTTOM);
	evas_object_size_hint_weight_set(popup, EVAS_HINT_EXPAND, EVAS_HINT_EXPAND);
	eext_object_event_callback_add(popup, EEXT_CALLBACK_BACK, _popup_hide_cb, NULL);
	evas_object_smart_callback_add(popup, "dismissed", _popup_hide_finished_cb, NULL);
	elm_object_part_text_set(popup,"elm.text", name);
	evas_object_smart_callback_add(popup, "block,clicked", _block_clicked_cb, NULL);

	elm_popup_timeout_set(popup, 2.0);
	evas_object_smart_callback_add(popup, "timeout", _timeout_cb, NULL);

	evas_object_show(popup);
}

static void _add_10_kilo_cb(void *data, Evas_Object *obj, void *event_info)
{
	weight+=10;
}

static void _add_5_kilo_cb(void *data, Evas_Object *obj, void *event_info)
{
	weight+=5;
}

static void _add_1_kilo_cb(void *data, Evas_Object *obj, void *event_info)
{
	weight+=1;
}

static void _user_info_entry_cb3(void *data, Evas_Object *obj, void *event_info)
{
	appdata_s *ad = (appdata_s *)data;
		Evas_Object *genlist;
		Evas_Object *circle_genlist;
		Evas_Object *nf = ad->nf;
		Elm_Object_Item *nf_it;
		Elm_Genlist_Item_Class *itc = elm_genlist_item_class_new();
		Elm_Genlist_Item_Class *ttc = elm_genlist_item_class_new();
		Elm_Genlist_Item_Class *ptc = elm_genlist_item_class_new();
		item_data *id;
		int index = 0;

		genlist = elm_genlist_add(nf);
		elm_genlist_mode_set(genlist, ELM_LIST_COMPRESS);
		evas_object_smart_callback_add(genlist, "selected", gl_selected_cb, NULL);

		circle_genlist = eext_circle_object_genlist_add(genlist, ad->circle_surface);
		eext_circle_object_genlist_scroller_policy_set(circle_genlist, ELM_SCROLLER_POLICY_OFF, ELM_SCROLLER_POLICY_AUTO);
		eext_rotary_object_event_activated_set(circle_genlist, EINA_TRUE);

		ttc->item_style = "title";
		ttc->func.text_get = _gl_menu_title_text_get;
		ttc->func.del = _gl_menu_del;

		itc->item_style = "default";
		itc->func.text_get = _gl_menu_text_get4;
		itc->func.del = _gl_menu_del;

		ptc->item_style = "padding";
		ptc->func.del = _gl_menu_del;

		elm_genlist_item_append(genlist, ttc, NULL, NULL, ELM_GENLIST_ITEM_NONE, NULL, NULL);



		id = calloc(sizeof(item_data), 1);
		id->index = index++;
		id->item = elm_genlist_item_append(genlist, itc, id, NULL, ELM_GENLIST_ITEM_NONE, show_weight_cb, ad);
		id = calloc(sizeof(item_data), 1);
		id->index = index++;
		id->item = elm_genlist_item_append(genlist, itc, id, NULL, ELM_GENLIST_ITEM_NONE, _add_10_kilo_cb, ad);
		id = calloc(sizeof(item_data), 1);
		id->index = index++;
		id->item = elm_genlist_item_append(genlist, itc, id, NULL, ELM_GENLIST_ITEM_NONE, _add_5_kilo_cb, ad);
		id = calloc(sizeof(item_data), 1);
		id->index = index++;
		id->item = elm_genlist_item_append(genlist, itc, id, NULL, ELM_GENLIST_ITEM_NONE, _add_1_kilo_cb, ad);



		elm_genlist_item_append(genlist, ptc, NULL, NULL, ELM_GENLIST_ITEM_NONE, NULL, NULL);

		elm_genlist_item_class_free(ttc);
		elm_genlist_item_class_free(itc);
		elm_genlist_item_class_free(ptc);

		nf_it = elm_naviframe_item_push(nf, "Button", NULL, NULL, genlist, "empty");

}

static void show_height_cb(void *data, Evas_Object *obj, void *event_info)
{
	Evas_Object *popup;
	appdata_s *ad = (appdata_s *)data;

	sprintf(name, "Height :  %d", height);
	popup = elm_popup_add(ad->win);
	elm_object_style_set(popup, "toast/circle");
	elm_popup_orient_set(popup, ELM_POPUP_ORIENT_BOTTOM);
	evas_object_size_hint_weight_set(popup, EVAS_HINT_EXPAND, EVAS_HINT_EXPAND);
	eext_object_event_callback_add(popup, EEXT_CALLBACK_BACK, _popup_hide_cb, NULL);
	evas_object_smart_callback_add(popup, "dismissed", _popup_hide_finished_cb, NULL);
	elm_object_part_text_set(popup,"elm.text", name);
	evas_object_smart_callback_add(popup, "block,clicked", _block_clicked_cb, NULL);

	elm_popup_timeout_set(popup, 2.0);
	evas_object_smart_callback_add(popup, "timeout", _timeout_cb, NULL);

	evas_object_show(popup);
}

static void _add_50_cm_cb(void *data, Evas_Object *obj, void *event_info)
{
	height+=50;
}

static void _add_10_cm_cb(void *data, Evas_Object *obj, void *event_info)
{
	height+=10;
}

static void _add_5_cm_cb(void *data, Evas_Object *obj, void *event_info)
{
	height+=5;
}

static void _add_1_cm_cb(void *data, Evas_Object *obj, void *event_info)
{
	height+=1;
}

static void _user_info_entry_cb4(void *data, Evas_Object *obj, void *event_info)
{
	appdata_s *ad = (appdata_s *)data;
		Evas_Object *genlist;
		Evas_Object *circle_genlist;
		Evas_Object *nf = ad->nf;
		Elm_Object_Item *nf_it;
		Elm_Genlist_Item_Class *itc = elm_genlist_item_class_new();
		Elm_Genlist_Item_Class *ttc = elm_genlist_item_class_new();
		Elm_Genlist_Item_Class *ptc = elm_genlist_item_class_new();
		item_data *id;
		int index = 0;

		genlist = elm_genlist_add(nf);
		elm_genlist_mode_set(genlist, ELM_LIST_COMPRESS);
		evas_object_smart_callback_add(genlist, "selected", gl_selected_cb, NULL);

		circle_genlist = eext_circle_object_genlist_add(genlist, ad->circle_surface);
		eext_circle_object_genlist_scroller_policy_set(circle_genlist, ELM_SCROLLER_POLICY_OFF, ELM_SCROLLER_POLICY_AUTO);
		eext_rotary_object_event_activated_set(circle_genlist, EINA_TRUE);

		ttc->item_style = "title";
		ttc->func.text_get = _gl_menu_title_text_get;
		ttc->func.del = _gl_menu_del;

		itc->item_style = "default";
		itc->func.text_get = _gl_menu_text_get6;
		itc->func.del = _gl_menu_del;

		ptc->item_style = "padding";
		ptc->func.del = _gl_menu_del;

		elm_genlist_item_append(genlist, ttc, NULL, NULL, ELM_GENLIST_ITEM_NONE, NULL, NULL);



		id = calloc(sizeof(item_data), 1);
		id->index = index++;
		id->item = elm_genlist_item_append(genlist, itc, id, NULL, ELM_GENLIST_ITEM_NONE, show_height_cb, ad);
		id = calloc(sizeof(item_data), 1);
		id->index = index++;
		id->item = elm_genlist_item_append(genlist, itc, id, NULL, ELM_GENLIST_ITEM_NONE, _add_50_cm_cb, ad);
		id = calloc(sizeof(item_data), 1);
		id->index = index++;
		id->item = elm_genlist_item_append(genlist, itc, id, NULL, ELM_GENLIST_ITEM_NONE, _add_10_cm_cb, ad);
		id = calloc(sizeof(item_data), 1);
		id->index = index++;
		id->item = elm_genlist_item_append(genlist, itc, id, NULL, ELM_GENLIST_ITEM_NONE, _add_5_cm_cb, ad);
		id = calloc(sizeof(item_data), 1);
		id->index = index++;
		id->item = elm_genlist_item_append(genlist, itc, id, NULL, ELM_GENLIST_ITEM_NONE, _add_1_cm_cb, ad);



		elm_genlist_item_append(genlist, ptc, NULL, NULL, ELM_GENLIST_ITEM_NONE, NULL, NULL);

		elm_genlist_item_class_free(ttc);
		elm_genlist_item_class_free(itc);
		elm_genlist_item_class_free(ptc);

		nf_it = elm_naviframe_item_push(nf, "Button", NULL, NULL, genlist, "empty");

}

void
calorie_goal_cb(void *data, Evas_Object *obj, void *event_info)
{
	appdata_s *ad = (appdata_s *)data;
	Evas_Object *genlist;
	Evas_Object *circle_genlist;
	Evas_Object *nf = ad->nf;
	Elm_Object_Item *nf_it;
	Elm_Genlist_Item_Class *itc = elm_genlist_item_class_new();
	Elm_Genlist_Item_Class *ttc = elm_genlist_item_class_new();
	Elm_Genlist_Item_Class *ptc = elm_genlist_item_class_new();
	item_data *id;
	int index = 0;

	genlist = elm_genlist_add(nf);
	elm_genlist_mode_set(genlist, ELM_LIST_COMPRESS);
	evas_object_smart_callback_add(genlist, "selected", gl_selected_cb, NULL);

	circle_genlist = eext_circle_object_genlist_add(genlist, ad->circle_surface);
	eext_circle_object_genlist_scroller_policy_set(circle_genlist, ELM_SCROLLER_POLICY_OFF, ELM_SCROLLER_POLICY_AUTO);
	eext_rotary_object_event_activated_set(circle_genlist, EINA_TRUE);

	ttc->item_style = "title";
	ttc->func.text_get = _gl_menu_title_text_get;
	ttc->func.del = _gl_menu_del;

	itc->item_style = "default";
	itc->func.text_get = _gl_menu_text_get3;
	itc->func.del = _gl_menu_del;

	ptc->item_style = "padding";
	ptc->func.del = _gl_menu_del;

	elm_genlist_item_append(genlist, ttc, NULL, NULL, ELM_GENLIST_ITEM_NONE, NULL, NULL);



	id = calloc(sizeof(item_data), 1);
	id->index = index++;
	id->item = elm_genlist_item_append(genlist, itc, id, NULL, ELM_GENLIST_ITEM_NONE, show_goal_cb, ad);
	id = calloc(sizeof(item_data), 1);
	id->index = index++;
	id->item = elm_genlist_item_append(genlist, itc, id, NULL, ELM_GENLIST_ITEM_NONE, _user_info_entry_cb1, ad);
	id = calloc(sizeof(item_data), 1);
	id->index = index++;
	id->item = elm_genlist_item_append(genlist, itc, id, NULL, ELM_GENLIST_ITEM_NONE, _user_info_entry_cb2, ad);
	id = calloc(sizeof(item_data), 1);
	id->index = index++;
	id->item = elm_genlist_item_append(genlist, itc, id, NULL, ELM_GENLIST_ITEM_NONE, _user_info_entry_cb3, ad);
	id = calloc(sizeof(item_data), 1);
	id->index = index++;
	id->item = elm_genlist_item_append(genlist, itc, id, NULL, ELM_GENLIST_ITEM_NONE, _user_info_entry_cb4, ad);


	elm_genlist_item_append(genlist, ptc, NULL, NULL, ELM_GENLIST_ITEM_NONE, NULL, NULL);

	elm_genlist_item_class_free(ttc);
	elm_genlist_item_class_free(itc);
	elm_genlist_item_class_free(ptc);

	nf_it = elm_naviframe_item_push(nf, "Button", NULL, NULL, genlist, "empty");
}

void
mealList_cb(void *data, Evas_Object *obj, void *event_info)
{
	appdata_s *ad = (appdata_s *)data;
	Evas_Object *genlist;
	Evas_Object *circle_genlist;
	Evas_Object *nf = ad->nf;
	Elm_Object_Item *nf_it;
	Elm_Genlist_Item_Class *itc = elm_genlist_item_class_new();
	Elm_Genlist_Item_Class *ttc = elm_genlist_item_class_new();
	Elm_Genlist_Item_Class *ptc = elm_genlist_item_class_new();
	item_data *id;
	int index = 0;

	genlist = elm_genlist_add(nf);
	elm_genlist_mode_set(genlist, ELM_LIST_COMPRESS);
	evas_object_smart_callback_add(genlist, "selected", gl_selected_cb, NULL);

	circle_genlist = eext_circle_object_genlist_add(genlist, ad->circle_surface);
	eext_circle_object_genlist_scroller_policy_set(circle_genlist, ELM_SCROLLER_POLICY_OFF, ELM_SCROLLER_POLICY_AUTO);
	eext_rotary_object_event_activated_set(circle_genlist, EINA_TRUE);

	ttc->item_style = "title";
	ttc->func.text_get = _gl_menu_title_text_get;
	ttc->func.del = _gl_menu_del;

	itc->item_style = "default";
	itc->func.text_get = _gl_menu_text_get2;
	itc->func.del = _gl_menu_del;

	ptc->item_style = "padding";
	ptc->func.del = _gl_menu_del;

	elm_genlist_item_append(genlist, ttc, NULL, NULL, ELM_GENLIST_ITEM_NONE, NULL, NULL);

	id = calloc(sizeof(item_data), 1);
	id->index = index++;
	id->item = elm_genlist_item_append(genlist, itc, id, NULL, ELM_GENLIST_ITEM_NONE, _popup_toast_cb1, ad);
	id = calloc(sizeof(item_data), 1);
	id->index = index++;
	id->item = elm_genlist_item_append(genlist, itc, id, NULL, ELM_GENLIST_ITEM_NONE, _popup_toast_cb2, ad);
	id = calloc(sizeof(item_data), 1);
	id->index = index++;
	id->item = elm_genlist_item_append(genlist, itc, id, NULL, ELM_GENLIST_ITEM_NONE, _popup_toast_cb3, ad);
	id = calloc(sizeof(item_data), 1);
	id->index = index++;
	id->item = elm_genlist_item_append(genlist, itc, id, NULL, ELM_GENLIST_ITEM_NONE, _popup_toast_cb4, ad);
	id = calloc(sizeof(item_data), 1);
	id->index = index++;
	id->item = elm_genlist_item_append(genlist, itc, id, NULL, ELM_GENLIST_ITEM_NONE, _popup_toast_cb5, ad);


	elm_genlist_item_append(genlist, ptc, NULL, NULL, ELM_GENLIST_ITEM_NONE, NULL, NULL);

	elm_genlist_item_class_free(ttc);
	elm_genlist_item_class_free(itc);
	elm_genlist_item_class_free(ptc);

	nf_it = elm_naviframe_item_push(nf, "Button", NULL, NULL, genlist, "empty");
}

void
mealTimes_cb(void *data, Evas_Object *obj, void *event_info)
{
	appdata_s *ad = (appdata_s *)data;
	Evas_Object *genlist;
	Evas_Object *circle_genlist;
	Evas_Object *nf = ad->nf;
	Elm_Object_Item *nf_it;
	Elm_Genlist_Item_Class *itc = elm_genlist_item_class_new();
	Elm_Genlist_Item_Class *ttc = elm_genlist_item_class_new();
	Elm_Genlist_Item_Class *ptc = elm_genlist_item_class_new();
	item_data *id;
	int index = 0;

	genlist = elm_genlist_add(nf);
	elm_genlist_mode_set(genlist, ELM_LIST_COMPRESS);
	evas_object_smart_callback_add(genlist, "selected", gl_selected_cb, NULL);

	circle_genlist = eext_circle_object_genlist_add(genlist, ad->circle_surface);
	eext_circle_object_genlist_scroller_policy_set(circle_genlist, ELM_SCROLLER_POLICY_OFF, ELM_SCROLLER_POLICY_AUTO);
	eext_rotary_object_event_activated_set(circle_genlist, EINA_TRUE);

	ttc->item_style = "title";
	ttc->func.text_get = _gl_menu_title_text_get;
	ttc->func.del = _gl_menu_del;

	itc->item_style = "default";
	itc->func.text_get = _gl_menu_text_get1;
	itc->func.del = _gl_menu_del;

	ptc->item_style = "padding";
	ptc->func.del = _gl_menu_del;

	elm_genlist_item_append(genlist, ttc, NULL, NULL, ELM_GENLIST_ITEM_NONE, NULL, NULL);


	id = calloc(sizeof(item_data), 1);
	id->index = index++;
	id->item = elm_genlist_item_append(genlist, itc, id, NULL, ELM_GENLIST_ITEM_NONE, _popup_calorie_cb, ad);
	id = calloc(sizeof(item_data), 1);
	id->index = index++;
	id->item = elm_genlist_item_append(genlist, itc, id, NULL, ELM_GENLIST_ITEM_NONE, mealList_cb, ad);
	id = calloc(sizeof(item_data), 1);
	id->index = index++;
	id->item = elm_genlist_item_append(genlist, itc, id, NULL, ELM_GENLIST_ITEM_NONE, mealList_cb, ad);
	id = calloc(sizeof(item_data), 1);
	id->index = index++;
	id->item = elm_genlist_item_append(genlist, itc, id, NULL, ELM_GENLIST_ITEM_NONE, mealList_cb, ad);
	id = calloc(sizeof(item_data), 1);
	id->index = index++;
	id->item = elm_genlist_item_append(genlist, itc, id, NULL, ELM_GENLIST_ITEM_NONE, mealList_cb, ad);


	elm_genlist_item_append(genlist, ptc, NULL, NULL, ELM_GENLIST_ITEM_NONE, NULL, NULL);

	elm_genlist_item_class_free(ttc);
	elm_genlist_item_class_free(itc);
	elm_genlist_item_class_free(ptc);

	nf_it = elm_naviframe_item_push(nf, "Button", NULL, NULL, genlist, "empty");
}

void
ui_cb(void *data, Evas_Object *obj, void *event_info)
{
	appdata_s *ad = (appdata_s *)data;
	Evas_Object *genlist;
	Evas_Object *circle_genlist;
	Evas_Object *nf = ad->nf;
	Elm_Object_Item *nf_it;
	Elm_Genlist_Item_Class *itc = elm_genlist_item_class_new();
	Elm_Genlist_Item_Class *ttc = elm_genlist_item_class_new();
	Elm_Genlist_Item_Class *ptc = elm_genlist_item_class_new();
	item_data *id;
	int index = 0;

	genlist = elm_genlist_add(nf);
	elm_genlist_mode_set(genlist, ELM_LIST_COMPRESS);
	evas_object_smart_callback_add(genlist, "selected", gl_selected_cb, NULL);

	circle_genlist = eext_circle_object_genlist_add(genlist, ad->circle_surface);
	eext_circle_object_genlist_scroller_policy_set(circle_genlist, ELM_SCROLLER_POLICY_OFF, ELM_SCROLLER_POLICY_AUTO);
	eext_rotary_object_event_activated_set(circle_genlist, EINA_TRUE);

	ttc->item_style = "title";
	ttc->func.text_get = _gl_menu_title_text_get;
	ttc->func.del = _gl_menu_del;

	itc->item_style = "default";
	itc->func.text_get = _gl_menu_text_get;
	itc->func.del = _gl_menu_del;

	ptc->item_style = "padding";
	ptc->func.del = _gl_menu_del;

	elm_genlist_item_append(genlist, ttc, NULL, NULL, ELM_GENLIST_ITEM_NONE, NULL, NULL);

	id = calloc(sizeof(item_data), 1);
	id->index = index++;
	id->item = elm_genlist_item_append(genlist, itc, id, NULL, ELM_GENLIST_ITEM_NONE, mealTimes_cb, ad);
	id = calloc(sizeof(item_data), 1);
	id->index = index++;
	id->item = elm_genlist_item_append(genlist, itc, id, NULL, ELM_GENLIST_ITEM_NONE, calorie_goal_cb, ad);

	elm_genlist_item_append(genlist, ptc, NULL, NULL, ELM_GENLIST_ITEM_NONE, NULL, NULL);

	elm_genlist_item_class_free(ttc);
	elm_genlist_item_class_free(itc);
	elm_genlist_item_class_free(ptc);

	nf_it = elm_naviframe_item_push(nf, "Button", NULL, NULL, genlist, "empty");
}
